"""Ders dağıtımı CP-SAT paketi. Veri/doğrulama katmanı OR-Tools olmadan test edilebilir."""


def __getattr__(name):
    if name in ("coz", "Cozucu"):
        from importlib import import_module
        return getattr(import_module(".coz", __name__), name)
    raise AttributeError(name)

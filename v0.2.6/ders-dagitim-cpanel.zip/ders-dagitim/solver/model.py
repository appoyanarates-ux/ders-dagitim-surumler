"""
CP-SAT modeli.

Karar değişkeni: x[oturum, gün, başlangıç saati] (Boolean). Yalnızca geçerli (açık, uygun, kilitle uyumlu)
başlangıçlar için değişken oluşturulur. Her zorunlu oturum tam bir kez yerleşir (add_exactly_one).
Öğretmen, şube ve derslik için zaman dilimi bazlı kullanım toplamı en fazla 1'dir (add_at_most_one);
aynı türden birden çok derslik varsa kapasite kadar kullanım (sum <= n).
"""
from collections import defaultdict
from ortools.sat.python import cp_model

from .veri import Oturum, M_GUN

ONCELIK = ("yuksek", "orta", "dusuk")
AGIRLIK = {
    "subeBosluk": 10, "maxBosluk": 20, "gunSiniri": 30,
    "ogretmenBosluk": 3, "zorDers": 2, "tercihGun": 1, "binaDegisim": 2,
    "azGun": 2, "ogretmenDenge": 1, "sinifDenge": 1, "ilkSon": 1, "nobet": 1, "onceki": 1,
    "saatTercihi": 2, "zumre": 15,
}


class Ayar:
    """Aşama ayarları."""
    def __init__(self, alternatif=False, tercih_esnek=False, esnet=None, teshis=False, varsayim=False, hedefli=True):
        self.alternatif = alternatif          # 2. aşama: VEYA kalıpları ve bölünebilir bloklar
        self.tercih_esnek = tercih_esnek      # 3. aşama: kesin işaretli tercih sınırları yumuşar
        self.esnet = esnet or {}              # 4. aşama: kullanıcının izin verdiği sınırlar
        self.teshis = teshis                  # yerleşebilecek en çok saati bul (taslak + yerleşmeyenler)
        self.varsayim = varsayim              # çelişki çekirdeği için kural grupları varsayım literaliyle
        self.hedefli = hedefli                # yumuşak kurallar (amaç terimleri) kurulsun mu


class Model:
    def __init__(self, P, ayar):
        self.P, self.ayar = P, ayar
        self.m = cp_model.CpModel()
        self.oturumlar = []
        self.X = {}                          # oturum no -> [(gun, saat, var)]
        self.kalip_secim = {}                # birim id -> [(kalip, var|None)]
        self.varsayimlar = []                # (literal, açıklama)
        self.hatalar = []                    # model kurulurken bulunan kesin çelişkiler
        self.terimler = defaultdict(list)    # öncelik -> [(ağırlık, ifade, ad)]
        self.yerlesen_saat = []              # teşhis amacı
        self.oda_secim = {}                  # (oturum no, uye, gün, başlangıç, oda) -> Boolean
        self._kur()

    # ------------------------------------------------------------------ yardımcılar
    def _lit(self, ad):
        """Varsayım kipinde kural grubu literali; değilse None (kural koşulsuz)."""
        if not self.ayar.varsayim:
            return None
        v = self.m.NewBoolVar("v_" + ad[:40])
        self.varsayimlar.append((v, ad))
        return v

    def _kosul(self, ct, lit):
        if lit is not None:
            ct.OnlyEnforceIf(lit)
        return ct

    # ------------------------------------------------------------------ kurulum
    def _kur(self):
        P, a = self.P, self.ayar
        self.kapsam = defaultdict(list)       # kaynak anahtarı -> [literal]
        self.kapasite = {}
        self.ogr_bina = defaultdict(list)     # (öğretmen, gün, saat, bina) -> [literal]
        self.birim_gun = defaultdict(list)    # (birim, gün) -> [(uzunluk, var, bas)]
        self.yasak_baslangic = defaultdict(list)   # varsayım kipinde: grup adı -> [var]

        for b in P.birimler.values():
            self._birim(b)
        for k in P.kulupler:
            self._kulup(k)
        self._kaynaklar()
        self._gunluk_kurallar()
        self._bina_gecisi()
        self._ogretmen_sinirlari()
        if a.hedefli and not a.teshis:
            self._yumusak()
        if a.teshis:
            self.m.Maximize(sum(self.yerlesen_saat))

    def _kaliplar(self, b):
        P, a = self.P, self.ayar
        k = list(b.kaliplar) if a.alternatif else [b.kaliplar[0]]
        if a.esnet.get("blokYapisi"):
            for ek in ([2] * (b.saat // 2) + [1] * (b.saat % 2), [1] * b.saat):
                if ek not in k:
                    k.append(ek)
        if P.kurallar.get("ucluTekrarYasak"):
            uygun = [x for x in k if max(x) <= 2]
            if len(uygun) < len(k):
                P.uyarilar.append(f"{b.ad}: 3 ve daha uzun bloklar K05 (üçlü tekrar yasağı) nedeniyle kullanılmadı.")
            if not uygun:
                self.hatalar.append({"kural": "K05", "mesaj": f"{b.ad}: tanımlanan blok kalıpları üçlü ders yasağıyla çelişiyor; açık izin olmadan yeni kalıba dönüştürülmedi."})
            k = uygun
        return k

    def _baslangiclar(self, subeler, ogretmenler, uzunluk, kilit, varsayim_grubu=None):
        """Geçerli başlangıçlar. Varsayım kipinde kapalı saatler yasaklanmaz, ayrı literalle bağlanır."""
        P = self.P
        out, yasak = [], []
        for d in range(P.D):
            for h in range(P.H - uzunluk + 1):
                if kilit and not (d == kilit[0] and h <= kilit[1] and h + uzunluk >= kilit[1] + kilit[2]):
                    continue
                sorun = []
                for i in range(uzunluk):
                    sl = (d, h + i)
                    for s in subeler:
                        if sl in P.subeler[s]["kapali"]:
                            sorun.append(("sube", s))
                    for t in ogretmenler:
                        if sl in P.ogretmenler[t]["kapali"]:
                            sorun.append(("ogr", t))
                if not sorun:
                    out.append((d, h))
                elif self.ayar.varsayim:
                    out.append((d, h))
                    yasak.append(((d, h), sorun))
        return out, yasak

    def _oturum_ekle(self, birim, dersler, subeler, ogretmenler, uzunluk, oda_listesi, kilit, kulup=None, zorunlu=True, secim=None, ad=""):
        no = len(self.oturumlar)
        bas, yasak = self._baslangiclar(subeler, ogretmenler, uzunluk, kilit)
        o = Oturum(no=no, birim=birim, dersler=dersler, subeler=subeler, ogretmenler=ogretmenler, uzunluk=uzunluk,
                   oda=oda_listesi, kilit=kilit, kulup=kulup, ad=ad)
        self.oturumlar.append(o)
        xs = []
        for (d, h) in bas:
            v = self.m.NewBoolVar(f"x{no}_{d}_{h}")
            xs.append((d, h, v))
        self.X[no] = xs
        # varsayım kipinde kapalı saat ihlalleri ayrı gruplarda
        if yasak:
            harita = {(d, h): v for d, h, v in xs}
            for (dh, sorunlar) in yasak:
                for (tur, kim) in set(sorunlar):
                    self.yasak_baslangic[(tur, kim)].append(harita[dh])
        lits = [v for _, _, v in xs]
        if self.ayar.teshis:
            if lits:
                if secim is not None:
                    self.m.Add(sum(lits) <= secim)
                else:
                    self.m.Add(sum(lits) <= 1)
                self.yerlesen_saat.append(uzunluk * sum(lits))
        else:
            if not lits:
                return o, False
            if secim is not None:
                self.m.Add(sum(lits) == secim)
            else:
                self.m.AddExactlyOne(lits)
        return o, True

    def _birim(self, b):
        P = self.P
        kaliplar = self._kaliplar(b)
        secenekler = []
        if not kaliplar:
            return
        for ki, kalip in enumerate(kaliplar):
            eslesme, hata = P.oturumlar(b, kalip)
            if hata:
                secenekler.append((kalip, None, hata))
                continue
            secenekler.append((kalip, eslesme, None))
        gecerli = [s for s in secenekler if s[1] is not None]
        if not gecerli:
            self.hatalar.append({"kural": "K14", "mesaj": secenekler[0][2]})
            return
        cok = len(gecerli) > 1
        self.kalip_secim[b.id] = []
        secim_vars = []
        for ki, (kalip, eslesme, _) in enumerate(gecerli):
            sv = self.m.NewBoolVar(f"k_{b.id[:20]}_{ki}") if cok else None
            if sv is not None:
                secim_vars.append(sv)
            self.kalip_secim[b.id].append((kalip, sv))
            tum_ok = True
            for (uz, kilit) in eslesme:
                # paralel grupta her üyenin kendi öğretmeni ve dersliği vardır
                uyeler = []
                for i, did in enumerate(b.dersler):
                    bilgi = P.ders_bilgi[did]
                    uyeler.append((did, bilgi["ogretmenler"], b.oda[i] if i < len(b.oda) else None))
                o, ok = self._oturum_ekle(b, b.dersler, [b.sube], b.ogretmenler, uz, uyeler, kilit, zorunlu=True, secim=sv,
                                          ad=b.ad)
                if not ok:
                    tum_ok = False
                    if kilit:
                        self.hatalar.append({"kural": "K14", "mesaj": f"{P.subeler[b.sube]['ad']} · {b.ad}: {M_GUN(kilit[0])} {kilit[1] + 1}. ders kilidi kapalı bir saate ya da gün sonuna denk geliyor."})
                    elif not cok:
                        self.hatalar.append({"kural": "K11", "mesaj": f"{P.subeler[b.sube]['ad']} · {b.ad}: {uz} saatlik blok için şube ve öğretmenin ortak açık ardışık saati yok."})
            if not tum_ok and sv is not None:
                self.m.Add(sv == 0)
        if cok:
            self.m.AddExactlyOne(secim_vars) if not self.ayar.teshis else self.m.Add(sum(secim_vars) <= 1)
            # 1. kalıp tercih edilir (VEYA kuralı)
            for ki, (kalip, sv) in enumerate(self.kalip_secim[b.id]):
                if ki > 0:
                    self.terimler["yuksek"].append((5, sv, "alternatif blok"))

    def _kulup(self, k):
        uz = k["saat"]
        kilit = (k["sabit"][0], k["sabit"][1], uz) if k["sabit"] else None
        o, ok = self._oturum_ekle(None, [], k["subeler"], k["ogretmenler"], uz,
                                  [(None, k["ogretmenler"], ("sabit", k["oda"]) if k["oda"] else None)], kilit, kulup=k["id"], ad=k["ad"])
        if not ok and not self.ayar.teshis:
            self.hatalar.append({"kural": "K15", "mesaj": f"{k['ad']} kulübü için katılımcı şubelerin ve öğretmenin ortak açık saati yok" + (" (sabit saat kapalı)" if kilit else "") + "."})

    # ------------------------------------------------------------------ kaynaklar (K01, K02, K12)
    def _kaynaklar(self):
        P, m = self.P, self.m
        for o in self.oturumlar:
            for (d, h, v) in self.X[o.no]:
                for i in range(o.uzunluk):
                    sl = (d, h + i)
                    for s in o.subeler:
                        self.kapsam[("S", s) + sl].append(v)
                    for t in o.ogretmenler:
                        self.kapsam[("T", t) + sl].append(v)
            # derslikler
            for ui, (did, ogr, oda) in enumerate(o.oda or []):
                if not oda:
                    # öğretmenin bulunduğu bina: şubenin dersliği
                    bina = P.oda_binasi(P.subeler[o.subeler[0]]["oda"]) if o.subeler else None
                    if bina:
                        self._ogr_bina_ekle(o, ogr, bina, None)
                    continue
                if oda[0] == "sabit":
                    r = oda[1]
                    for (d, h, v) in self.X[o.no]:
                        for i in range(o.uzunluk):
                            self.kapsam[("R", r, d, h + i)].append(v)
                    bina = P.oda_binasi(r)
                    if bina:
                        self._ogr_bina_ekle(o, ogr, bina, None)
                else:
                    # Tür havuzundaki gerçek odaları başlangıçla birlikte seç.
                    # RT toplu kapasite modeli sabit oda rezervasyonlarını görmediğinden
                    # bazı sonuçlarda fiziksel derslik atanamıyordu.
                    for (d, h, v) in self.X[o.no]:
                        secenek = []
                        for r in P.oda_turleri[oda[1]]:
                            q = m.NewBoolVar(f"oda_{o.no}_{ui}_{d}_{h}_{r}")
                            self.oda_secim[(o.no, ui, d, h, r)] = q
                            secenek.append(q)
                            for i in range(o.uzunluk):
                                self.kapsam[("R", r, d, h + i)].append(q)
                                bina = P.oda_binasi(r)
                                if bina:
                                    for t in ogr:
                                        self.ogr_bina[(t, d, h + i, bina)].append(q)
                        if secenek:
                            m.Add(sum(secenek) == v)
                        else:
                            m.Add(v == 0)
        for anahtar, l in self.kapsam.items():
            if len(l) > 1:
                m.AddAtMostOne(l)
        # varsayım kipinde kapalı saatler: grup başına bir literal
        for (tur, kim), lits in self.yasak_baslangic.items():
            ad = (f"K09 {P.ogretmenler[kim]['ad']} kapalı saatleri" if tur == "ogr" else f"K11 {P.subeler[kim]['ad']} kapalı saatleri")
            lit = self._lit(ad)
            for v in lits:
                m.AddImplication(lit, v.Not())

    def _ogr_bina_ekle(self, o, ogretmenler, bina, _):
        for (d, h, v) in self.X[o.no]:
            for i in range(o.uzunluk):
                for t in ogretmenler:
                    self.ogr_bina[(t, d, h + i, bina)].append(v)

    # ------------------------------------------------------------------ K04 K05 K07 K08 K16
    def _gunluk_kurallar(self):
        P, m, a = self.P, self.m, self.ayar
        kur = P.kurallar
        ekle_max = 1 if a.esnet.get("gunlukMax") else 0
        ayni_gun_serbest = bool(a.esnet.get("ayniGunBlok"))
        self.birim_kapsam = defaultdict(list)    # (birim, d, h) -> [var]
        for o in self.oturumlar:
            if o.birim is None:
                continue
            for (d, h, v) in self.X[o.no]:
                self.birim_gun[(o.birim.id, d)].append((o.uzunluk, v, h))
                for i in range(o.uzunluk):
                    self.birim_kapsam[(o.birim.id, d, h + i)].append(v)
        self.gun_var = {}
        for b in P.birimler.values():
            lit4 = self._lit(f"K04 {P.subeler[b.sube]['ad']} · {b.ad}: günde en fazla {b.gunluk_max + ekle_max} saat")
            lit7 = self._lit(f"K07 {P.subeler[b.sube]['ad']} · {b.ad}: blokları farklı günlerde")
            lit5 = self._lit(f"K05 {P.subeler[b.sube]['ad']} · {b.ad}: art arda en fazla 2 saat")
            for d in range(P.D):
                l = self.birim_gun.get((b.id, d), [])
                if not l:
                    continue
                self._kosul(m.Add(sum(u * v for u, v, _ in l) <= b.gunluk_max + ekle_max), lit4)
                if kur.get("blokFarkliGun") and not ayni_gun_serbest:
                    self._kosul(m.Add(sum(v for _, v, _ in l) <= 1), lit7)
                # K05: kesintisiz 3 saat yok (aynı günde birden çok blok mümkünse gerekli)
                if kur.get("ucluTekrarYasak"):
                    for h in range(P.H - 2):
                        terim = []
                        for j in range(3):
                            terim.extend(self.birim_kapsam.get((b.id, d, h + j), []))
                        if len(terim) > 2:
                            self._kosul(m.Add(sum(terim) <= 2), lit5)
        # K08: İngilizce ve Yabancı Dil aynı şubede aynı gün olmaz
        if kur.get("dilAyriGun"):
            sube_dil = defaultdict(lambda: defaultdict(list))
            for b in P.birimler.values():
                if b.dil:
                    sube_dil[b.sube][b.dil].append(b)
            for s, diller in sube_dil.items():
                if len(diller) < 2:
                    continue
                lit = self._lit(f"K08 {P.subeler[s]['ad']}: İngilizce ve Yabancı Dil ayrı günlerde")
                for d in range(P.D):
                    gv = {}
                    for dil, birimler in diller.items():
                        terim = [v for b in birimler for _, v, _ in self.birim_gun.get((b.id, d), [])]
                        if not terim:
                            continue
                        g = m.NewBoolVar(f"dil_{s}_{dil}_{d}")
                        for v in terim:
                            m.AddImplication(v, g)
                        gv[dil] = g
                    dl = list(gv.values())
                    for i in range(len(dl)):
                        for j in range(i + 1, len(dl)):
                            self._kosul(m.Add(dl[i] + dl[j] <= 1), lit)
        # K16: ders etiket kuralları
        for kural in P.ders_etiket_kurallari:
            et = kural.get("ad")
            sube_birim = defaultdict(list)
            for b in P.birimler.values():
                if et in b.etiketler:
                    sube_birim[b.sube].append(b)
            for s, birimler in sube_birim.items():
                lit = self._lit(f"K16 {P.subeler[s]['ad']}: “{et}” etiketi kuralı")
                for d in range(P.D):
                    if kural.get("maxGunluk"):
                        terim = [u * v for b in birimler for u, v, _ in self.birim_gun.get((b.id, d), [])]
                        if terim:
                            self._kosul(m.Add(sum(terim) <= int(kural["maxGunluk"])), lit)
                    if kural.get("ardisikYasak") and len(birimler) > 1:
                        for h in range(P.H - 1):
                            for A in birimler:
                                a1 = self.birim_kapsam.get((A.id, d, h), [])
                                digerleri = [v for B in birimler if B.id != A.id for v in self.birim_kapsam.get((B.id, d, h + 1), [])]
                                if a1 and digerleri:
                                    self._kosul(m.Add(sum(a1) + sum(digerleri) <= 1), lit)

    # ------------------------------------------------------------------ K13
    def _bina_gecisi(self):
        P, m = self.P, self.m
        if len(P.binalar) < 2 or not P.gecis:
            return
        ogr_binalar = defaultdict(set)
        for (t, d, h, b) in self.ogr_bina:
            ogr_binalar[t].add(b)
        for t, binalar in ogr_binalar.items():
            if len(binalar) < 2:
                continue
            lit = self._lit(f"K13 {P.ogretmenler[t]['ad']}: bina geçiş süresi")
            for d in range(P.D):
                gunluk = {}
                for h in range(P.H - 1):
                    for b1 in binalar:
                        a = self.ogr_bina.get((t, d, h, b1))
                        if not a:
                            continue
                        for b2 in binalar:
                            if b1 == b2 or (b1, b2) not in P.gecis:
                                continue
                            dk, _ = P.gecis[(b1, b2)]
                            for h2 in range(h + 1, P.H):
                                # Aradaki boş derslerin süreleri de hesaba katılır.
                                if dk <= P.gecis_suresi(h, h2):
                                    break
                                c = self.ogr_bina.get((t, d, h2, b2))
                                if c:
                                    self._kosul(m.Add(sum(a) + sum(c) <= 1), lit)
                # aynı gün iki binada bulunamaz
                for (b1, b2), (dk, yasak) in P.gecis.items():
                    if not yasak or b1 not in binalar or b2 not in binalar or b1 >= b2:
                        continue
                    for bb in (b1, b2):
                        if bb not in gunluk:
                            l = [v for h in range(P.H) for v in self.ogr_bina.get((t, d, h, bb), [])]
                            if l:
                                g = m.NewBoolVar(f"gb_{t}_{d}_{bb}")
                                for v in l:
                                    m.AddImplication(v, g)
                                gunluk[bb] = g
                    if b1 in gunluk and b2 in gunluk:
                        self._kosul(m.Add(gunluk[b1] + gunluk[b2] <= 1), lit)

    # ------------------------------------------------------------------ K10
    def _ogretmen_sinirlari(self):
        P, m, a = self.P, self.m, self.ayar
        self.mesgul = {}        # (t, d, h) -> bool var | None
        for t, o in P.ogretmenler.items():
            for d in range(P.D):
                for h in range(P.H):
                    l = self.kapsam.get(("T", t, d, h), [])
                    if not l:
                        continue
                    if len(l) == 1:
                        self.mesgul[(t, d, h)] = l[0]
                    else:
                        b = m.NewBoolVar(f"m_{t}_{d}_{h}")
                        m.Add(sum(l) == b)
                        self.mesgul[(t, d, h)] = b
        self.gun_kullan = {}
        for t, o in P.ogretmenler.items():
            lit = self._lit(f"K10 {o['ad']}: günde en fazla {o['maxGunluk']} saat") if o["maxGunluk"] else None
            for d in range(P.D):
                l = [self.mesgul[(t, d, h)] for h in range(P.H) if (t, d, h) in self.mesgul]
                if not l:
                    continue
                if o["maxGunluk"] and len(l) > o["maxGunluk"]:
                    self._kosul(m.Add(sum(l) <= o["maxGunluk"]), lit)
                g = m.NewBoolVar(f"g_{t}_{d}")
                for v in l:
                    m.AddImplication(v, g)
                m.Add(g <= sum(l))
                self.gun_kullan[(t, d)] = g
            gunler = [self.gun_kullan[(t, d)] for d in range(P.D) if (t, d) in self.gun_kullan]
            if o["maxHaftalik"]:
                l = [v for d in range(P.D) for h in range(P.H) for v in self.kapsam.get(("T", t, d, h), [])]
                self._kosul(m.Add(sum(l) <= o["maxHaftalik"]), self._lit(f"K10 {o['ad']}: haftalık üst sınır"))
            if o["maxGun"] and o["maxGunKesin"] and gunler:
                lit2 = self._lit(f"K10 {o['ad']}: haftada en fazla {o['maxGun']} gün")
                self._kosul(m.Add(sum(gunler) <= o["maxGun"]), lit2)

    # ------------------------------------------------------------------ yumuşak kurallar
    def _oncelik(self, ad):
        return self.P.kurallar["tercihler"].get(ad, "kapali")

    def _terim(self, ad, ifade, carpan=1):
        p = self._oncelik(ad)
        if p in ONCELIK:
            self.terimler[p].append((AGIRLIK.get(ad, 1) * carpan, ifade, ad))

    def _veya(self, lits):
        if not lits:
            return None
        if len(lits) == 1:
            return lits[0]
        v = self.m.NewBoolVar("")
        self.m.AddMaxEquality(v, lits)
        return v

    def _bosluk(self, mesgul, acik):
        """Gün içi boşluk sayısı: ilk ve son ders arasındaki açık boş saatler.
        mesgul: [bool var | None] (None = o saatte ders olamaz)."""
        H = len(mesgul)
        if sum(1 for x in mesgul if x is not None) < 2:
            return 0
        onek, once = [], None            # onek[h] = h ve öncesinde ders var mı
        for h in range(H):
            if mesgul[h] is not None:
                once = self._veya([x for x in (once, mesgul[h]) if x is not None])
            onek.append(once)
        sonek, sonra = [None] * H, None
        for h in range(H - 1, -1, -1):
            if mesgul[h] is not None:
                sonra = self._veya([x for x in (sonra, mesgul[h]) if x is not None])
            sonek[h] = sonra
        bosluk = []
        for h in range(1, H - 1):
            if not acik[h] or onek[h - 1] is None or sonek[h + 1] is None:
                continue
            g = self.m.NewBoolVar("")
            self.m.Add(g >= onek[h - 1] + sonek[h + 1] - (mesgul[h] if mesgul[h] is not None else 0) - 1)
            bosluk.append(g)
        return sum(bosluk) if bosluk else 0

    def _yumusak(self):
        P, m, a = self.P, self.m, self.ayar
        kur = P.kurallar
        # Şube boşlukları: son dersten önceki her açık boş saat
        for s, sb in P.subeler.items():
            toplam = []
            for d in range(P.D):
                kap = [self.kapsam.get(("S", s, d, h), []) for h in range(P.H)]
                acik = [(d, h) not in sb["kapali"] for h in range(P.H)]
                if not any(kap):
                    continue
                bh = []
                for h in range(P.H):
                    if not kap[h]:
                        bh.append(None)
                        continue
                    x = m.NewBoolVar("")
                    m.Add(sum(kap[h]) == x)
                    bh.append(x)
                sonra = None
                for h in range(P.H - 1, -1, -1):
                    if bh[h] is not None:
                        q = m.NewBoolVar("")
                        m.AddMaxEquality(q, [bh[h]] + ([sonra] if sonra is not None else []))
                        sonra = q
                    if sonra is not None and acik[h]:
                        g = m.NewBoolVar("")
                        m.Add(g >= sonra - (bh[h] if bh[h] is not None else 0))
                        toplam.append(g)
            if toplam:
                self._terim("subeBosluk", sum(toplam))
                izin = int(kur.get("subeMaxBosluk") or 0)
                if izin > 0:
                    asim = m.NewIntVar(0, P.D * P.H, "")
                    m.Add(asim >= sum(toplam) - izin)
                    self._terim("maxBosluk", asim)
        # Öğretmen terimleri
        zor_gun = int(kur.get("zorDersGunluk") or 0)
        for t, o in P.ogretmenler.items():
            gunler = [(d, self.gun_kullan[(t, d)]) for d in range(P.D) if (t, d) in self.gun_kullan]
            if not gunler:
                continue
            haftalik_bosluk = []
            yukler = []
            for d, g in gunler:
                mesgul = [self.mesgul.get((t, d, h)) for h in range(P.H)]
                acik = [(d, h) not in o["kapali"] for h in range(P.H)]
                bos = self._bosluk(mesgul, acik)
                if not isinstance(bos, int):
                    haftalik_bosluk.append(bos)
                yuk = sum(x for x in mesgul if x is not None)
                yukler.append(yuk)
                if o["ilkSaatIstemez"] and mesgul[0] is not None:
                    self._terim("ilkSon", mesgul[0])
                if o["sonSaatIstemez"] and mesgul[-1] is not None:
                    self._terim("ilkSon", mesgul[-1])
                if o["tercihGunler"] and d not in o["tercihGunler"]:
                    self._terim("tercihGun", g)
            if haftalik_bosluk:
                self._terim("ogretmenBosluk", sum(haftalik_bosluk))
                if o["maxBosluk"] is not None:
                    asim = m.NewIntVar(0, P.D * P.H, "")
                    m.Add(asim >= sum(haftalik_bosluk) - o["maxBosluk"])
                    self._terim("maxBosluk", asim)
            self._terim("azGun", sum(g for _, g in gunler))
            if o["maxGun"] and not o["maxGunKesin"]:
                asim = m.NewIntVar(0, P.D, "")
                m.Add(asim >= sum(g for _, g in gunler) - o["maxGun"])
                self._terim("gunSiniri", asim)
            if len(yukler) > 1:
                tepe = m.NewIntVar(0, P.H, "")
                for y in yukler:
                    m.Add(tepe >= y)
                self._terim("ogretmenDenge", tepe)
            if o["nobetGunu"] is not None and (t, o["nobetGunu"]) in self.gun_kullan:
                nd = o["nobetGunu"]
                self._terim("nobet", 1 - self.gun_kullan[(t, nd)])
                nobet_max = int(kur.get("nobetMaxGunluk") or 0)
                if nobet_max > 0:
                    nl = [v for h in range(P.H) for v in self.kapsam.get(("O", t, nd, h), [])]
                    if nl:
                        nasim = m.NewIntVar(0, P.H, "")
                        m.Add(nasim >= sum(nl) - nobet_max)
                        self._terim("nobet", nasim)
            # Bina değişimi: gün içinde birden fazla bina
            binalar = {b for (tt, dd, hh, b) in self.ogr_bina if tt == t}
            if len(binalar) > 1:
                for d, g in gunler:
                    bv = []
                    for b in binalar:
                        l = [v for h in range(P.H) for v in self.ogr_bina.get((t, d, h, b), [])]
                        if l:
                            x = m.NewBoolVar("")
                            for v in l:
                                m.AddImplication(v, x)
                            bv.append(x)
                    if len(bv) > 1:
                        self._terim("binaDegisim", sum(bv) - g)
        # Şube günlük denge ve zor dersler
        for s, sb in P.subeler.items():
            yuk = []
            for d in range(P.D):
                l = [v for h in range(P.H) for v in self.kapsam.get(("S", s, d, h), [])]
                if l:
                    yuk.append(sum(l))
                if zor_gun:
                    z = [u * v for b in P.birimler.values() if b.sube == s and b.zor for u, v, _ in self.birim_gun.get((b.id, d), [])]
                    if z:
                        asim = m.NewIntVar(0, P.H, "")
                        m.Add(asim >= sum(z) - zor_gun)
                        self._terim("zorDers", asim)
            if len(yuk) > 1:
                mx, mn = m.NewIntVar(0, P.H, ""), m.NewIntVar(0, P.H, "")
                for y in yuk:
                    m.Add(mx >= y)
                    m.Add(mn <= y)
                self._terim("sinifDenge", mx - mn)
        # Ders ağırlık profili: ağır dersler sabah ilk saatlere, uygulamalı dersler öğleden sonraya
        if kur.get("dersAgirlikProfili"):
            sabah_sinir = P.ogle_sonra if P.ogle_sonra and 1 <= P.ogle_sonra < P.H else max(2, (P.H + 1) // 2)
            ilk_sinir = min(2, sabah_sinir)
            for o in self.oturumlar:
                if not o.birim or not o.birim.saat_tercihi:
                    continue
                if o.birim.saat_tercihi == "sabah":
                    for (d, h, v) in self.X[o.no]:
                        if h >= sabah_sinir:
                            self._terim("saatTercihi", v)
                elif o.birim.saat_tercihi == "ogleden":
                    for (d, h, v) in self.X[o.no]:
                        if h + o.uzunluk <= ilk_sinir:
                            self._terim("saatTercihi", v)
        # Zümre ortak boş saati: aynı branştaki öğretmenlere haftada en az N ortak boş ders saati
        for zg in P.zumre_gruplari:
            z_slotlar = []
            for d in range(P.D):
                for h in range(P.H):
                    if any((d, h) in P.ogretmenler[t]["kapali"] for t in zg["ogretmenler"]):
                        continue
                    zb = m.NewBoolVar("")
                    for t in zg["ogretmenler"]:
                        for v in self.kapsam.get(("O", t, d, h), []):
                            m.Add(zb + v <= 1)
                    z_slotlar.append(zb)
            if z_slotlar:
                if zg.get("kesin") and not self.ayar.tercih_esnek:
                    m.Add(sum(z_slotlar) >= min(zg["saat"], len(z_slotlar)))
                else:
                    hedef_z = min(zg["saat"], len(z_slotlar))
                    z_eksik = m.NewIntVar(0, hedef_z, "")
                    m.Add(z_eksik >= hedef_z - sum(z_slotlar))
                    self._terim("zumre", z_eksik)
        # Önceki dağıtımı koru (minimum_degisiklik modunda yüksek öncelikle koru)
        if P.onceki:
            min_deg = P.cozucu_mod == "minimum_degisiklik"
            for b in P.birimler.values():
                eski = P.onceki.get(b.dersler[0])
                if not eski:
                    continue
                for (g, s, u) in eski:
                    l = [v for o in self.oturumlar if o.birim is b and o.uzunluk == u for (d, h, v) in self.X[o.no] if d == g and h == s]
                    if l:
                        if min_deg:
                            self.terimler["yuksek"].append((25, 1 - sum(l), "onceki"))
                        else:
                            self._terim("onceki", 1 - sum(l))

    # ------------------------------------------------------------------ ipucu ve çözüm okuma
    def ipucu_ver(self, yerlesim):
        """yerlesim: {(dersId|kulup:id, uzunluk): [(g, s)]} — önceki geçerli çözüm."""
        if not yerlesim:
            return
        kalan = {k: list(v) for k, v in yerlesim.items()}
        for o in self.oturumlar:
            anahtar = (o.dersler[0] if o.dersler else "kulup:" + o.kulup, o.uzunluk)
            hedef = kalan.get(anahtar)
            sec = None
            if hedef:
                aday = {(d, h) for d, h, _ in self.X[o.no]}
                for i, gs in enumerate(hedef):
                    if gs in aday:
                        sec = gs
                        hedef.pop(i)
                        break
            for (d, h, v) in self.X[o.no]:
                self.m.AddHint(v, 1 if sec == (d, h) else 0)

    def boyut(self):
        pr = self.m.Proto()
        return {"degisken": len(pr.variables), "kisit": len(pr.constraints),
                "oturum": len(self.oturumlar), "baslangic": sum(len(v) for v in self.X.values())}

    def oku(self, cozucu):
        """Çözümden oturum yerleşimlerini çıkarır."""
        out = []
        for o in self.oturumlar:
            sec = None
            for (d, h, v) in self.X[o.no]:
                if cozucu.BooleanValue(v):
                    sec = (d, h)
                    break
            odalar = {}
            if sec is not None:
                for (no, ui, d, h, r), v in self.oda_secim.items():
                    if no == o.no and d == sec[0] and h == sec[1] and cozucu.BooleanValue(v):
                        odalar[ui] = r
            out.append((o, sec, odalar))
        return out

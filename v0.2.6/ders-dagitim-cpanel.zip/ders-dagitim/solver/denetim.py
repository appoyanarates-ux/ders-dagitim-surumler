"""
Ön denetim (dağıtımdan önce) ve bağımsız çözüm doğrulayıcı (dağıtımdan sonra).

Ön denetimdeki "hata"lar mantıksal olarak kesin çelişkilerdir (gerekli koşul sağlanmıyor): bu durumda
çözüm aranmaz ve durum INFEASIBLE (ön denetimle kanıtlandı) döner. "uyari"lar olası sorunlardır.
"""
from collections import defaultdict
import math

from .veri import M_GUN


def _ortak_acik_kosu(P, subeler, ogretmenler, d):
    """Gün d'de şube(ler) ve öğretmen(ler)in ortak açık en uzun ardışık koşusu."""
    en, simdi = 0, 0
    for h in range(P.H):
        acik = all((d, h) not in P.subeler[s]["kapali"] for s in subeler) and \
            all((d, h) not in P.ogretmenler[t]["kapali"] for t in ogretmenler)
        simdi = simdi + 1 if acik else 0
        en = max(en, simdi)
    return en


def on_denetim(P):
    hatalar, uyarilar = list(P.hatalar), list(P.uyarilar)
    D, H = P.D, P.H
    kur = P.kurallar
    izin = kur.get("esnetIzin") or {}

    # Şube haftalık saat <= açık saat (K11)
    sube_yuk = defaultdict(int)
    for b in P.birimler.values():
        sube_yuk[b.sube] += b.saat
    for k in P.kulupler:
        for s in k["subeler"]:
            sube_yuk[s] += k["saat"]
    for s, y in sube_yuk.items():
        acik = D * H - len(P.subeler[s]["kapali"])
        if y > acik:
            hatalar.append({"kural": "K11", "mesaj": f"{P.subeler[s]['ad']}: haftalık {y} saat ders var, açık saat yalnız {acik}."})

    # Öğretmen yükü ve kapasite (K09, K10)
    ogr_yuk = defaultdict(int)
    for b in P.birimler.values():
        for t in b.ogretmenler:
            ogr_yuk[t] += b.saat
    for k in P.kulupler:
        for t in k["ogretmenler"]:
            ogr_yuk[t] += k["saat"]
    for t, y in ogr_yuk.items():
        o = P.ogretmenler[t]
        gunluk = [min(H - sum(1 for h in range(H) if (d, h) in o["kapali"]), o["maxGunluk"] or H) for d in range(D)]
        kap = sum(gunluk)
        if o["maxGun"] and o["maxGunKesin"]:
            kap = min(kap, sum(sorted(gunluk, reverse=True)[:o["maxGun"]]))
        if y > kap:
            hatalar.append({"kural": "K10", "mesaj": f"{o['ad']}: haftalık {y} saat ders, açık ders kapasitesi {kap} saat (kapalı saatler, günlük sınır{' ve kesin gün sınırı' if o['maxGun'] and o['maxGunKesin'] else ''})."})
        if o["maxHaftalik"] and y > o["maxHaftalik"]:
            hatalar.append({"kural": "K10", "mesaj": f"{o['ad']}: haftalık {y} saat ders atanmış, üst sınır {o['maxHaftalik']}."})
        elif y > kap * 0.9:
            uyarilar.append(f"{o['ad']}: açık saatlerinin %{round(y * 100 / max(1, kap))}'i dolu; dağıtım zorlaşabilir.")

    # Birim başına gün yeterliliği (K06/K07) ve kilit uyumu (K14)
    for b in P.birimler.values():
        sb = P.subeler[b.sube]["ad"]
        kosu = [_ortak_acik_kosu(P, [b.sube], b.ogretmenler, d) for d in range(D)]
        kaliplar = list(b.kaliplar)
        if izin.get("blokYapisi"):
            for ek in ([2] * (b.saat // 2) + [1] * (b.saat % 2), [1] * b.saat):
                if ek not in kaliplar:
                    kaliplar.append(ek)
        if kur.get("ucluTekrarYasak"):
            kaliplar = [k for k in kaliplar if max(k) <= 2]
        if not kaliplar:
            hatalar.append({"kural": "K05", "mesaj": f"{sb} · {b.ad}: 3 saatlik tekrar yasağıyla uyumlu blok kalıbı yok."})
            continue
        farkli = kur.get("blokFarkliGun") and not izin.get("ayniGunBlok")
        if farkli:
            uygun_kalip_var = False
            for kalip in kaliplar:
                # Sıralanmış bloklara farklı günlerden yeterli sayıda uygun gün atanabilmeli.
                musait = sorted(kosu, reverse=True)
                ist = sorted(kalip, reverse=True)
                if len(ist) <= D and all(k >= u for k, u in zip(musait, ist)):
                    uygun_kalip_var = True
                    break
            if not uygun_kalip_var:
                hatalar.append({"kural": "K06", "mesaj": f"{sb} · {b.ad}: izin verilen blok kalıplarını yerleştirmek için yeterli uygun gün bulunmuyor."})
        kap = sum(min(b.gunluk_max + (1 if izin.get("gunlukMax") else 0), k) for k in kosu)
        if kap < b.saat:
            hatalar.append({"kural": "K04", "mesaj": f"{sb} · {b.ad}: izinli günlük sınırlarla haftada en çok {kap} saat yerleşebilir; ders {b.saat} saat."})
        # kilitler
        gun_kilit = defaultdict(list)
        for (g, s, u) in b.kilitler:
            gun_kilit[g].append((s, u))
            if g >= D or s + u > H:
                hatalar.append({"kural": "K14", "mesaj": f"{sb} · {b.ad}: kilit geçersiz gün/saatte."})
                continue
            if kur.get("ucluTekrarYasak") and u > 2:
                hatalar.append({"kural": "K14", "mesaj": f"{sb} · {b.ad}: {M_GUN(g)} {s + 1}. dersten itibaren {u} saat kilitli; K05 (art arda en fazla 2 saat) ile çelişiyor."})
            for i in range(u):
                if (g, s + i) in P.subeler[b.sube]["kapali"]:
                    hatalar.append({"kural": "K14", "mesaj": f"{sb} · {b.ad}: {M_GUN(g)} {s + i + 1}. ders kilidi şubenin kapalı saatinde."})
                for t in b.ogretmenler:
                    if (g, s + i) in P.ogretmenler[t]["kapali"]:
                        hatalar.append({"kural": "K14", "mesaj": f"{sb} · {b.ad}: {M_GUN(g)} {s + i + 1}. ders kilidi {P.ogretmenler[t]['ad']} için kapalı saatte (K09)."})
        for g, l in gun_kilit.items():
            toplam = sum(u for _, u in l)
            if toplam > b.gunluk_max + (1 if izin.get("gunlukMax") else 0):
                hatalar.append({"kural": "K14", "mesaj": f"{sb} · {b.ad}: {M_GUN(g)} gününe {toplam} saat kilitli; günlük üst sınır {b.gunluk_max + (1 if izin.get('gunlukMax') else 0)} (K04)."})
            if len(l) > 1 and kur.get("blokFarkliGun") and not izin.get("ayniGunBlok"):
                hatalar.append({"kural": "K14", "mesaj": f"{sb} · {b.ad}: {M_GUN(g)} günü birbirinden ayrı iki kilitli blok var (K07)."})

    # Kilitlerin birbiriyle çakışması (K01, K02, K12)
    dolu = {}
    def isaretle(anahtar, ad):
        if anahtar in dolu and dolu[anahtar] != ad:
            tur = {"S": "K02 şube", "T": "K01 öğretmen", "R": "K12 derslik"}[anahtar[0]]
            hatalar.append({"kural": tur.split()[0], "mesaj": f"Kilit çakışması ({tur.split()[1]}): “{dolu[anahtar]}” ile “{ad}” {M_GUN(anahtar[2])} {anahtar[3] + 1}. derste aynı kaynağı kullanıyor."})
        dolu[anahtar] = ad
    for b in P.birimler.values():
        ad = P.subeler[b.sube]["ad"] + " · " + b.ad
        for (g, s, u) in b.kilitler:
            for i in range(u):
                isaretle(("S", b.sube, g, s + i), ad)
                for t in b.ogretmenler:
                    isaretle(("T", t, g, s + i), ad)
                for oda in b.oda:
                    if oda and oda[0] == "sabit":
                        isaretle(("R", oda[1], g, s + i), ad)
    for k in P.kulupler:
        if not k["sabit"]:
            continue
        g, s = k["sabit"]
        if s + k["saat"] > H:
            hatalar.append({"kural": "K15", "mesaj": f"{k['ad']}: sabit saat gün sonunu aşıyor."})
            continue
        for i in range(k["saat"]):
            for sb in k["subeler"]:
                if (g, s + i) in P.subeler[sb]["kapali"]:
                    hatalar.append({"kural": "K15", "mesaj": f"{k['ad']}: {P.subeler[sb]['ad']} şubesi {M_GUN(g)} {s + i + 1}. derste kapalı."})
                isaretle(("S", sb, g, s + i), k["ad"] + " kulübü")
            for t in k["ogretmenler"]:
                if (g, s + i) in P.ogretmenler[t]["kapali"]:
                    hatalar.append({"kural": "K15", "mesaj": f"{k['ad']}: {P.ogretmenler[t]['ad']} {M_GUN(g)} {s + i + 1}. derste kapalı."})
                isaretle(("T", t, g, s + i), k["ad"] + " kulübü")
            if k["oda"]:
                isaretle(("R", k["oda"], g, s + i), k["ad"] + " kulübü")

    # K08 kilitleri
    if kur.get("dilAyriGun"):
        gun_dil = defaultdict(set)
        for b in P.birimler.values():
            if b.dil:
                for (g, s, u) in b.kilitler:
                    gun_dil[(b.sube, g)].add(b.dil)
        for (s, g), diller in gun_dil.items():
            if len(diller) > 1:
                hatalar.append({"kural": "K08", "mesaj": f"{P.subeler[s]['ad']}: İngilizce ve Yabancı Dil {M_GUN(g)} gününe birlikte kilitlenmiş."})

    # Derslik kapasitesi (K12)
    tur_yuk = defaultdict(int)
    for b in P.birimler.values():
        for oda in b.oda:
            if oda and oda[0] == "tur":
                tur_yuk[oda[1]] += b.saat
    for tur, y in tur_yuk.items():
        n = len(P.oda_turleri[tur])
        # Bu türdeki sabit dersliklerin planlanmış ders yükü de toplam kapasiteyi tüketir.
        sabit_yuk = sum(b.saat for b in P.birimler.values() for oda in b.oda if oda and oda[0] == "sabit" and P.derslikler[oda[1]]["tur"] == tur)
        y += sabit_yuk
        if y > n * D * H:
            hatalar.append({"kural": "K12", "mesaj": f"“{tur}” türü derslik gereken {y} saat, {n} derslikle en fazla {n * D * H} saat."})
        elif y > n * D * H * 0.8:
            uyarilar.append(f"“{tur}” türü dersliklerin %{round(y * 100 / (n * D * H))}'i dolu; dağıtım zorlaşabilir.")
    sabit_oda = defaultdict(int)
    for b in P.birimler.values():
        for oda in b.oda:
            if oda and oda[0] == "sabit":
                sabit_oda[oda[1]] += b.saat
    for k in P.kulupler:
        if k.get("oda"):
            sabit_oda[k["oda"]] += k["saat"]
    for r, y in sabit_oda.items():
        if y > D * H:
            hatalar.append({"kural": "K12", "mesaj": f"{P.derslikler[r]['ad']}: {y} saat kullanım isteniyor, haftada {D * H} saat var."})

    # yinelenenleri ayıkla
    gor, tek = set(), []
    for h in hatalar:
        if h["mesaj"] not in gor:
            gor.add(h["mesaj"])
            tek.append(h)
    return {"hatalar": tek, "uyarilar": list(dict.fromkeys(uyarilar)), "bilgiler": list(P.bilgiler)}


def dogrula(P, yerlesim, kulup_yerlesim=(), ayar=None):
    """Bağımsız doğrulayıcı. yerlesim: [{dersId, gun, saat, uzunluk, derslikId?}].
    Döner: [{kural, mesaj}] — boşsa bütün zorunlu kurallar sağlanıyor."""
    kur = P.kurallar
    esnet = getattr(ayar, "esnet", {}) if ayar is not None else {}
    alternatif = bool(getattr(ayar, "alternatif", False)) if ayar is not None else False
    ihl = []
    D, H = P.D, P.H
    ders_birim = {}
    for b in P.birimler.values():
        for did in b.dersler:
            ders_birim[did] = b
    # birim bazında bloklar (paralel grup üyeleri aynı blokları paylaşır)
    birim_blok = defaultdict(set)
    ders_blok = defaultdict(list)
    ders_saat = defaultdict(int)
    oda_kul = []
    for y in yerlesim:
        b = ders_birim.get(y["dersId"])
        if not b:
            continue
        yer = (y["gun"], y["saat"], y["uzunluk"])
        birim_blok[b.id].add(yer)
        ders_blok[y["dersId"]].append(yer)
        ders_saat[y["dersId"]] += y["uzunluk"]
        if y.get("derslikId"):
            oda_kul.append((y["derslikId"], y["gun"], y["saat"], y["uzunluk"], y["dersId"]))
    dolu = {}

    def kullan(anahtar, ad, kural, kimlik=None):
        # Gösterim adı aynı olan iki farklı dersin çakışması da yakalanmalı.
        tekil = kimlik if kimlik is not None else ad
        eski = dolu.get(anahtar)
        if eski is not None and eski[0] != tekil:
            ihl.append({"kural": kural, "mesaj": f"{M_GUN(anahtar[2])} {anahtar[3] + 1}. ders: “{eski[1]}” ve “{ad}” aynı {'öğretmende' if kural == 'K01' else 'şubede' if kural == 'K02' else 'derslikte'}."})
        dolu[anahtar] = (tekil, ad)

    for bid, bloklar in birim_blok.items():
        b = P.birimler[bid]
        ad = P.subeler[b.sube]["ad"] + " · " + b.ad
        gun_saat = defaultdict(int)
        gun_blok = defaultdict(int)
        kapsam = defaultdict(int)
        for (g, s, u) in bloklar:
            if u <= 0 or s < 0 or g < 0 or s + u > H or g >= D:
                ihl.append({"kural": "K11", "mesaj": f"{ad}: gün sonunu aşan blok."})
            gun_saat[g] += u
            gun_blok[g] += 1
            for i in range(u):
                sl = (g, s + i)
                kapsam[sl] += 1
                kullan(("S", b.sube) + sl, ad, "K02", b.id)
                if sl in P.subeler[b.sube]["kapali"]:
                    ihl.append({"kural": "K11", "mesaj": f"{ad}: {M_GUN(g)} {s + i + 1}. ders şubenin kapalı saati."})
                for t in b.ogretmenler:
                    kullan(("T", t) + sl, ad, "K01", b.id)
                    if sl in P.ogretmenler[t]["kapali"]:
                        ihl.append({"kural": "K09", "mesaj": f"{ad}: {P.ogretmenler[t]['ad']} {M_GUN(g)} {s + i + 1}. derste kapalı."})
        toplam = sum(u for _, _, u in bloklar)
        if toplam != b.saat:
            ihl.append({"kural": "K03", "mesaj": f"{ad}: {b.saat} saat olmalı, {toplam} saat yerleşti."})
        # K06: Tam blok desenini denetle. Aşamada izin verilmemiş alternatif/esnetilmiş desen kabul edilmez.
        desenler = list(b.kaliplar) if alternatif else [b.kaliplar[0]]
        if esnet.get("blokYapisi"):
            for ek in ([2] * (b.saat // 2) + [1] * (b.saat % 2), [1] * b.saat):
                if ek not in desenler:
                    desenler.append(ek)
        if kur.get("ucluTekrarYasak"):
            desenler = [k for k in desenler if max(k) <= 2]
            if not desenler:
                ihl.append({"kural": "K05", "mesaj": f"{ad}: üçlü ders yasağıyla uyumlu blok kalıbı yok."})
        kullanilan = sorted((u for _, _, u in bloklar), reverse=True)
        if kullanilan not in [sorted(k, reverse=True) for k in desenler]:
            ihl.append({"kural": "K06", "mesaj": f"{ad}: blok yapısı {'+'.join(map(str, kullanilan)) or 'boş'}, izinli kalıp {' / '.join('+'.join(map(str, k)) for k in desenler)}."})
        for did in b.dersler:
            if ders_saat[did] != b.saat or set(ders_blok[did]) != bloklar or len(ders_blok[did]) != len(bloklar):
                ihl.append({"kural": "K03", "mesaj": f"{P.ders_bilgi[did].get('ad', did)}: tüm paralel grup blokları eksiksiz ve birer kez yerleştirilmelidir."})
        for sl, x in kapsam.items():
            if x > 1:
                ihl.append({"kural": "K02", "mesaj": f"{ad}: {M_GUN(sl[0])} {sl[1] + 1}. derste bloklar birbiriyle örtüşüyor."})
        for g, x in gun_saat.items():
            sinir = b.gunluk_max + (1 if esnet.get("gunlukMax") else 0)
            if x > sinir:
                ihl.append({"kural": "K04", "mesaj": f"{ad}: {M_GUN(g)} {x} saat (en fazla {sinir})."})
            if gun_blok[g] > 1 and kur.get("blokFarkliGun") and not esnet.get("ayniGunBlok"):
                ihl.append({"kural": "K07", "mesaj": f"{ad}: {M_GUN(g)} günü ayrı iki blok."})
        if kur.get("ucluTekrarYasak"):
            for (g, h) in kapsam:
                if all((g, h + j) in kapsam for j in range(3)):
                    ihl.append({"kural": "K05", "mesaj": f"{ad}: {M_GUN(g)} {h + 1}.–{h + 3}. derslerde kesintisiz 3 saat."})
        # kilitler (K14)
        for (g, s, u) in b.kilitler:
            for i in range(u):
                if (g, s + i) not in kapsam:
                    ihl.append({"kural": "K14", "mesaj": f"{ad}: {M_GUN(g)} {s + i + 1}. ders kilidi korunmadı."})
    for did in P.ders_bilgi:
        if did in ders_birim and ders_birim[did].id not in birim_blok:
            b = ders_birim[did]
            ihl.append({"kural": "K03", "mesaj": f"{P.subeler[b.sube]['ad']} · {b.ad}: hiç yerleşmedi ({b.saat} saat)."})
    # kulüpler
    for ky in kulup_yerlesim:
        k = next((x for x in P.kulupler if x["id"] == ky["kulupId"]), None)
        if not k:
            continue
        for i in range(ky["uzunluk"]):
            sl = (ky["gun"], ky["saat"] + i)
            for s in k["subeler"]:
                kullan(("S", s) + sl, k["ad"] + " kulübü", "K02", "kulup:" + k["id"])
            for t in k["ogretmenler"]:
                kullan(("T", t) + sl, k["ad"] + " kulübü", "K01", "kulup:" + k["id"])
            if k.get("oda"):
                kullan(("R", k["oda"]) + sl, k["ad"] + " kulübü", "K12", "kulup:" + k["id"])
    # Derslik zorunluluğu ve tüm derslerin sabit/tür uyumu (K12)
    for y in yerlesim:
        did = y.get("dersId")
        if did not in P.ders_bilgi:
            ihl.append({"kural": "VERI", "mesaj": f"Tanımsız ders: {did}."})
            continue
        bilgi = P.ders_bilgi[did]
        r = y.get("derslikId")
        gerekli = bilgi.get("derslikId") or (P.subeler[bilgi["subeId"]]["oda"] if not bilgi.get("derslikTuru") or bilgi.get("derslikTuru") == "normal" else None)
        tur = bilgi.get("derslikTuru")
        if (gerekli or (tur and tur != "normal")) and not r:
            ihl.append({"kural": "K12", "mesaj": f"{bilgi.get('ad', did)}: zorunlu derslik ataması eksik."})
        if r and r not in P.derslikler:
            ihl.append({"kural": "K12", "mesaj": f"{bilgi.get('ad', did)}: tanımsız derslik ({r})."})
        if gerekli and r and gerekli != r:
            ihl.append({"kural": "K12", "mesaj": f"{bilgi.get('ad', did)}: sabit derslik {gerekli} olmalı (atanan: {r})."})
    # derslikler (K12)
    for (r, g, s, u, did) in oda_kul:
        b = ders_birim.get(did)
        for i in range(u):
            kullan(("R", r, g, s + i), (P.subeler[b.sube]["ad"] + " · " + P.ders_bilgi[did].get("ad", did)) if b else did, "K12", did)
        bilgi = P.ders_bilgi.get(did, {})
        if bilgi.get("derslikTuru") and bilgi["derslikTuru"] != "normal" and P.derslikler.get(r, {}).get("tur") != bilgi["derslikTuru"]:
            ihl.append({"kural": "K12", "mesaj": f"{bilgi.get('ad')}: “{bilgi['derslikTuru']}” gerektiriyor, {P.derslikler.get(r, {}).get('ad', r)} uygun değil."})
    # K08
    if kur.get("dilAyriGun"):
        gun_dil = defaultdict(set)
        for bid, bloklar in birim_blok.items():
            b = P.birimler[bid]
            if b.dil:
                for (g, s, u) in bloklar:
                    gun_dil[(b.sube, g)].add(b.dil)
        for (s, g), diller in gun_dil.items():
            if len(diller) > 1:
                ihl.append({"kural": "K08", "mesaj": f"{P.subeler[s]['ad']}: {M_GUN(g)} İngilizce ve Yabancı Dil aynı gün."})
    # K15: kulüplerin tüm oturum ve sabit saatlerinin korunması.
    for k in P.kulupler:
        es = [x for x in kulup_yerlesim if x.get("kulupId") == k["id"]]
        if len(es) != 1 or (es and es[0]["uzunluk"] != k["saat"]):
            ihl.append({"kural": "K15", "mesaj": f"{k['ad']}: kulüp saati eksik veya mükerrer."})
        if k["sabit"] and (not es or (es[0]["gun"], es[0]["saat"]) != k["sabit"]):
            ihl.append({"kural": "K15", "mesaj": f"{k['ad']}: sabit kulüp saati korunmadı."})
        for y in es:
            for i in range(y["uzunluk"]):
                sl = (y["gun"], y["saat"] + i)
                for sb in k["subeler"]:
                    if sl in P.subeler[sb]["kapali"]:
                        ihl.append({"kural": "K15", "mesaj": f"{k['ad']}: kulüp şubenin kapalı saatinde."})
                for t in k["ogretmenler"]:
                    if sl in P.ogretmenler[t]["kapali"]:
                        ihl.append({"kural": "K15", "mesaj": f"{k['ad']}: kulüp öğretmenin kapalı saatinde."})
            if k["oda"] and y.get("derslikId") != k["oda"]:
                ihl.append({"kural": "K15", "mesaj": f"{k['ad']}: kulüp için sabit derslik korunmadı."})
    # K10 günlük sınır
    ogr_gun = defaultdict(int)
    ogr_gunler = defaultdict(set)
    for (anahtar, ad) in dolu.items():
        if anahtar[0] == "T":
            ogr_gun[(anahtar[1], anahtar[2])] += 1
            ogr_gunler[anahtar[1]].add(anahtar[2])
    for (t, g), x in ogr_gun.items():
        o = P.ogretmenler.get(t)
        if o and o["maxGunluk"] and x > o["maxGunluk"]:
            ihl.append({"kural": "K10", "mesaj": f"{o['ad']}: {M_GUN(g)} {x} saat (en fazla {o['maxGunluk']})."})
    for t, gunler in ogr_gunler.items():
        o = P.ogretmenler.get(t)
        if o and o["maxGun"] and o["maxGunKesin"] and len(gunler) > o["maxGun"]:
            ihl.append({"kural": "K10", "mesaj": f"{o['ad']}: {len(gunler)} gün (kesin sınır {o['maxGun']})."})
    for t, o in P.ogretmenler.items():
        if o["maxHaftalik"] and sum(n for (tt, _), n in ogr_gun.items() if tt == t) > o["maxHaftalik"]:
            ihl.append({"kural": "K10", "mesaj": f"{o['ad']}: haftalık ders sınırı {o['maxHaftalik']} aşıldı."})
    # K13 bina geçişi
    if len(P.binalar) > 1 and P.gecis:
        ogr_bina = {}
        for (r, g, s, u, did) in oda_kul:
            b = ders_birim.get(did)
            bina = P.oda_binasi(r)
            if not b or not bina:
                continue
            for t in P.ders_bilgi[did]["ogretmenler"]:
                for i in range(u):
                    ogr_bina[(t, g, s + i)] = bina
        by_gun = defaultdict(list)
        for (t, g, h), bina in ogr_bina.items():
            by_gun[(t, g)].append((h, bina))
        for (t, g), dersler in by_gun.items():
            sirali = sorted(dersler)
            for (h1, b1), (h2, b2) in zip(sirali, sirali[1:]):
                if b1 == b2:
                    continue
                dakika, yasak = P.gecis.get((b1, b2), (0, False))
                if yasak or dakika > P.gecis_suresi(h1, h2):
                    ihl.append({"kural": "K13", "mesaj": f"{P.ogretmenler[t]['ad']}: {M_GUN(g)} {h1 + 1}.→{h2 + 1}. ders {P.binalar.get(b1, b1)} → {P.binalar.get(b2, b2)} geçişi uygun değil."})
            binalar = {b for _, b in sirali}
            for b1 in binalar:
                for b2 in binalar:
                    if b1 != b2 and P.gecis.get((b1, b2), (0, False))[1]:
                        ihl.append({"kural": "K13", "mesaj": f"{P.ogretmenler[t]['ad']}: {M_GUN(g)} aynı gün geçişi yasak iki bina ({b1}, {b2})."})
    # K16 ders etiketleri
    for kural in P.ders_etiket_kurallari:
        et = kural.get("ad")
        sube_gun = defaultdict(int)
        sube_kapsam = defaultdict(dict)
        for bid, bloklar in birim_blok.items():
            b = P.birimler[bid]
            if et not in b.etiketler:
                continue
            for (g, s, u) in bloklar:
                sube_gun[(b.sube, g)] += u
                for i in range(u):
                    sube_kapsam[(b.sube, g)][s + i] = bid
        if kural.get("maxGunluk"):
            for (s, g), x in sube_gun.items():
                if x > int(kural["maxGunluk"]):
                    ihl.append({"kural": "K16", "mesaj": f"{P.subeler[s]['ad']}: {M_GUN(g)} “{et}” etiketli {x} saat (en fazla {kural['maxGunluk']})."})
        if kural.get("ardisikYasak"):
            for (s, g), kap in sube_kapsam.items():
                for h, bid in kap.items():
                    if kap.get(h + 1) and kap[h + 1] != bid:
                        ihl.append({"kural": "K16", "mesaj": f"{P.subeler[s]['ad']}: {M_GUN(g)} {h + 1}.–{h + 2}. derslerde “{et}” etiketli iki ders art arda."})
    # yinelenenleri ayıkla
    gor, tek = set(), []
    for x in ihl:
        if x["mesaj"] not in gor:
            gor.add(x["mesaj"])
            tek.append(x)
    return tek

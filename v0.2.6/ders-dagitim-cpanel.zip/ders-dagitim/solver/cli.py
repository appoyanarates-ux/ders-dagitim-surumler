"""Komut satırı: python3 -m solver.cli --girdi girdi.json --cikti sonuc.json [--durum durum.json] [--sure 60] [--isci 8]
Girdi verilmezse stdin'den okur, çıktı verilmezse stdout'a yazar. PHP arka plan işi bu modülü çalıştırır."""
import argparse
import json
import os
import sys
import time
import traceback


def yaz(yol, veri):
    gecici = yol + ".tmp"
    with open(gecici, "w", encoding="utf-8") as f:
        json.dump(veri, f, ensure_ascii=False)
    os.replace(gecici, yol)


def main(argv=None):
    ap = argparse.ArgumentParser(description="CP-SAT ders dağıtımı")
    ap.add_argument("--girdi")
    ap.add_argument("--cikti")
    ap.add_argument("--durum")
    ap.add_argument("--sure", type=float)
    ap.add_argument("--isci", type=int)
    ap.add_argument("--pid", help="süreç numarasının yazılacağı dosya (iptal için)")
    a = ap.parse_args(argv)
    if a.pid:
        with open(a.pid, "w") as f:
            f.write(str(os.getpid()))
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from solver.coz import coz

    girdi = json.load(open(a.girdi, encoding="utf-8")) if a.girdi else json.load(sys.stdin)
    girdi = girdi.get("girdi", girdi)
    c = girdi.setdefault("cozucu", {})
    if a.sure:
        c["sureSn"] = a.sure
    if a.isci:
        c["isci"] = a.isci

    def ilerleme(asama, oran, mesaj):
        if a.durum:
            yaz(a.durum, {"durum": "calisiyor", "asama": asama, "oran": round(oran, 3), "mesaj": mesaj, "zaman": time.time()})

    try:
        ilerleme("basladi", 0.0, "Model kuruluyor")
        sonuc = coz(girdi, ilerleme)
        cikti = {"tamam": True, "sonuc": sonuc}
    except Exception as e:
        cikti = {"tamam": False, "hata": f"{type(e).__name__}: {e}", "iz": traceback.format_exc()[-2000:]}
    if a.cikti:
        yaz(a.cikti, cikti)
    else:
        json.dump(cikti, sys.stdout, ensure_ascii=False)
    if a.durum:
        yaz(a.durum, {"durum": "bitti" if cikti["tamam"] else "hata", "oran": 1, "mesaj": "Bitti" if cikti["tamam"] else cikti["hata"], "zaman": time.time()})
    return 0 if cikti["tamam"] else 1


if __name__ == "__main__":
    sys.exit(main())

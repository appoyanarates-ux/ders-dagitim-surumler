"""
Girdi (JSON) -> çözücü veri modeli.

Girdi biçimi (surum 2) — arayüz (public/assets/app.js: motorGirdisi) üretir:
{
  "gunSayisi": 5, "gunlukSaat": 8,
  "zaman": {"teneffusDk": 10, "ogleSonra": 5, "ogleDk": 40},
  "kurallar": {...},                       # bkz. KURAL_VARSAYILAN
  "subeler":     [{"id", "ad", "kapali": ["g-s"], "gunlukSaat"?, "derslikId"?}],
  "ogretmenler": [{"id", "ad", "kapali": [], "maxGunluk"?, "maxGun"?, "maxGunKesin"?, "maxHaftalik"?,
                   "maxBosluk"?, "tercihGunler"?: [g], "ilkSaatIstemez"?, "sonSaatIstemez"?, "nobetGunu"?, "etiketler"?: []}],
  "binalar":     [{"id", "ad"}],
  "binaGecis":   [{"a", "b", "dk", "ayniGunYasak"?}],
  "derslikler":  [{"id", "ad", "binaId", "tur"}],
  "dersler":     [{"id", "ad", "subeId", "ogretmenler": [id], "saat", "yerlesimSecenekleri"?: [[2,2],[2,1,1]],
                   "bolunebilir"?, "kilitli"?: [{"gun","saat","uzunluk"}], "derslikTuru"?, "derslikId"?,
                   "etiketler"?: [], "grup"?: "paralel-grup-anahtarı", "dil"?: "ingilizce"|"yabanci"|null}],
  "kulupler":    [{"id", "ad", "ogretmenler": [id], "subeIds": [], "saat": 1, "sabit"?: {"gun","saat"}, "derslikId"?}],
  "etiketKurallari": [{"ad", "hedef": "ders"|"ogretmen", "maxGunluk"?, "ardisikYasak"?}],
  "onceki":      [{"dersId", "gun", "saat", "uzunluk"}],
  "cozucu":      {"sureSn": 60, "isci": 8}
}
gün/saat 0 tabanlıdır.
"""
from collections import defaultdict
import math

KURAL_VARSAYILAN = {
    "gunlukAyniDersMax": 2,      # K04
    "ucluTekrarYasak": True,     # K05
    "blokFarkliGun": True,       # K06 / K07
    "dilAyriGun": True,          # K08
    "binaGecisDk": 0,            # K13 (0 = kontrol yok; çiftler binaGecis ile ayrıca verilebilir)
    "esnetIzin": {"gunlukMax": False, "blokYapisi": False, "ayniGunBlok": False},
    "tercihler": {                # yuksek | orta | dusuk | kapali
        "subeBosluk": "yuksek", "maxBosluk": "yuksek", "gunSiniri": "yuksek",
        "ogretmenBosluk": "orta", "zorDers": "orta", "tercihGun": "orta", "binaDegisim": "orta",
        "azGun": "dusuk", "ogretmenDenge": "dusuk", "sinifDenge": "dusuk", "ilkSon": "dusuk",
        "nobet": "dusuk", "onceki": "dusuk", "saatTercihi": "orta", "zumre": "yuksek"
    },
    "subeMaxBosluk": 0,
    "zorDersGunluk": 4,
    "nobetMaxGunluk": 0,
    "dersAgirlikProfili": False,
}

SABAH_DERS_KOK = ("matematik", "geometri", "fen bilimleri", "fizik", "kimya", "biyoloji", "türkçe", "türk dili ve edebiyatı")
OGLEDEN_DERS_KOK = ("beden eğitimi", "görsel sanatlar", "müzik", "teknoloji ve tasarım", "drama", "oyun ve fiziki", "resim", "halk oyunları")


def ders_saat_tercihi(ad):
    """Ağır dersler için 'sabah', uygulamalı/sanat/spor dersleri için 'ogleden', diğerleri için None."""
    k = (ad or "").strip().lower()
    if not k:
        return None
    if any(x in k for x in SABAH_DERS_KOK):
        return "sabah"
    if any(x in k for x in OGLEDEN_DERS_KOK):
        return "ogleden"
    return None

# K06 varsayılan blok yapıları
VARSAYILAN_BLOK = {1: [1], 2: [2], 3: [2, 1], 4: [2, 2], 5: [2, 2, 1], 6: [2, 2, 2]}


def kurallari_birlestir(k):
    out = dict(KURAL_VARSAYILAN)
    out["esnetIzin"] = dict(KURAL_VARSAYILAN["esnetIzin"])
    out["tercihler"] = dict(KURAL_VARSAYILAN["tercihler"])
    for a, v in (k or {}).items():
        if a in ("esnetIzin", "tercihler") and isinstance(v, dict):
            out[a].update(v)
        else:
            out[a] = v
    return out


def slot_seti(liste, D, H):
    s = set()
    for x in liste or []:
        try:
            g, h = str(x).split("-")
            g, h = int(g), int(h)
        except ValueError:
            continue
        if 0 <= g < D and 0 <= h < H:
            s.add((g, h))
    return s


def varsayilan_kalip(saat, D, L, blok_modu="ikili"):
    if saat <= 0:
        return []
    if blok_modu == "tekli" or L <= 1:
        return [1] * saat
    if saat in VARSAYILAN_BLOK:
        return list(VARSAYILAN_BLOK[saat])
    return [2] * (saat // 2) + [1] * (saat % 2)


def kilit_gruplari(kilitli):
    """Kilitleri (saatlik ya da blok) gün içinde bitişik gruplara birleştirir: [(gun, bas, uzunluk)]"""
    saatler = set()
    for k in kilitli or []:
        try:
            g, s, u = int(k["gun"]), int(k["saat"]), int(k.get("uzunluk") or 1)
        except (KeyError, TypeError, ValueError):
            continue
        for i in range(max(1, u)):
            saatler.add((g, s + i))
    out = []
    for g, s in sorted(saatler):
        if out and out[-1][0] == g and out[-1][1] + out[-1][2] == s:
            out[-1] = (g, out[-1][1], out[-1][2] + 1)
        else:
            out.append((g, s, 1))
    return out


class Oturum:
    """Bir ders oturumu (blok). Paralel gruplarda birden çok derse, kulüplerde birden çok şubeye aittir."""
    __slots__ = ("no", "birim", "dersler", "subeler", "ogretmenler", "uzunluk", "oda", "kilit",
                 "kalip", "secenek", "kulup", "adaylar", "ad")

    def __init__(self, **k):
        for a in self.__slots__:
            setattr(self, a, k.get(a))


class Birim:
    """Günlük kurallar (K04/K05/K07/K08/K16) için ders birimi: tek ders ya da paralel grup."""
    __slots__ = ("id", "dersler", "sube", "saat", "ad", "dil", "etiketler", "yogun", "gunluk_max",
                 "kaliplar", "ogretmenler", "oda", "kilitler", "zor", "saat_tercihi")

    def __init__(self, **k):
        for a in self.__slots__:
            setattr(self, a, k.get(a))


class Problem:
    def __init__(self, girdi):
        g = girdi
        self.girdi = g
        self.D = int(g.get("gunSayisi") or 5)
        self.H = int(g.get("gunlukSaat") or 8)
        self.kurallar = kurallari_birlestir(g.get("kurallar"))
        self.blok_modu = g.get("blok") or "ikili"
        z = g.get("zaman") or {}
        self.teneffus = int(z.get("teneffusDk") or 10)
        self.ogle_sonra = int(z.get("ogleSonra") or 0)
        self.ogle_dk = int(z.get("ogleDk") or 0)
        self.ders_dk = max(1, int(z.get("dersDk") or 40))
        self.hatalar, self.uyarilar, self.bilgiler = [], [], []

        D, H = self.D, self.H
        # Şubeler
        self.subeler = {}
        for s in g.get("subeler", []):
            gh = int(s.get("gunlukSaat") or H)
            kap = slot_seti(s.get("kapali"), D, H)
            for d in range(D):
                for h in range(min(gh, H), H):
                    kap.add((d, h))
            self.subeler[s["id"]] = {"id": s["id"], "ad": s.get("ad") or s["id"], "kapali": kap, "oda": s.get("derslikId")}
        # Öğretmenler
        self.ogretmenler = {}
        for o in g.get("ogretmenler", []):
            self.ogretmenler[o["id"]] = {
                "id": o["id"], "ad": o.get("ad") or o["id"], "kapali": slot_seti(o.get("kapali"), D, H),
                "maxGunluk": int(o["maxGunluk"]) if o.get("maxGunluk") else None,
                "maxGun": min(D, int(o["maxGun"])) if o.get("maxGun") else None,
                "maxGunKesin": bool(o.get("maxGunKesin")),
                "maxHaftalik": int(o["maxHaftalik"]) if o.get("maxHaftalik") else None,
                "maxBosluk": int(o["maxBosluk"]) if o.get("maxBosluk") not in (None, "") else None,
                "tercihGunler": [int(x) for x in (o.get("tercihGunler") or [])],
                "ilkSaatIstemez": bool(o.get("ilkSaatIstemez")), "sonSaatIstemez": bool(o.get("sonSaatIstemez")),
                "nobetGunu": int(o["nobetGunu"]) if o.get("nobetGunu") not in (None, "") else None,
                "etiketler": list(o.get("etiketler") or []),
            }
        # Binalar, derslikler
        self.binalar = {b["id"]: b.get("ad") or b["id"] for b in g.get("binalar", [])}
        self.derslikler = {r["id"]: {"id": r["id"], "ad": r.get("ad") or r["id"], "bina": r.get("binaId"), "tur": r.get("tur") or "normal"}
                           for r in g.get("derslikler", [])}
        for s in self.subeler.values():
            if s["oda"] and s["oda"] not in self.derslikler:
                self.hatalar.append({"kural": "K12", "mesaj": f"{s['ad']}: varsayılan derslik ({s['oda']}) tanımlı değil."})
        self.oda_turleri = defaultdict(list)          # tur -> [derslik id]
        for r in self.derslikler.values():
            self.oda_turleri[r["tur"]].append(r["id"])
        self.gecis = {}                                # (a,b) -> (dk, ayniGunYasak)
        varsayilan_dk = int(self.kurallar.get("binaGecisDk") or 0)
        for a in self.binalar:
            for b in self.binalar:
                if a != b and varsayilan_dk:
                    self.gecis[(a, b)] = (varsayilan_dk, False)
        for x in g.get("binaGecis", []):
            for a, b in ((x["a"], x["b"]), (x["b"], x["a"])):
                self.gecis[(a, b)] = (int(x.get("dk") or 0), bool(x.get("ayniGunYasak")))
        # Etiket kuralları
        self.etiket_kurallari = list(g.get("etiketKurallari") or [])
        ogr_et = {e["ad"]: e for e in self.etiket_kurallari if e.get("hedef") == "ogretmen"}
        for o in self.ogretmenler.values():
            for e in o["etiketler"]:
                k = ogr_et.get(e)
                if k and k.get("maxGunluk"):
                    o["maxGunluk"] = min(o["maxGunluk"] or H, int(k["maxGunluk"]))
        self.ders_etiket_kurallari = [e for e in self.etiket_kurallari if e.get("hedef", "ders") == "ders"]

        self._birimleri_kur(g)
        self._kulupleri_kur(g)
        self.cozucu_mod = str((g.get("cozucu") or {}).get("mod") or "").strip().lower()
        self.zumre_gruplari = []
        for z in g.get("zumreGruplari") or []:
            ogr_z = [o for o in (z.get("ogretmenler") or []) if o in self.ogretmenler]
            if len(ogr_z) >= 2:
                self.zumre_gruplari.append({
                    "ad": str(z.get("ad") or "Zümre"),
                    "ogretmenler": list(dict.fromkeys(ogr_z)),
                    "saat": max(1, int(z.get("saat") or 1)),
                    "kesin": bool(z.get("kesin")),
                })
        self.onceki = {}
        for y in g.get("onceki") or []:
            self.onceki.setdefault(y["dersId"], []).append((int(y["gun"]), int(y["saat"]), int(y.get("uzunluk") or 1)))

    # ------------------------------------------------------------------
    def _birimleri_kur(self, g):
        D, L = self.D, int(self.kurallar.get("gunlukAyniDersMax") or 2)
        gruplar = defaultdict(list)
        self.ders_bilgi = {}
        for d in g.get("dersler", []):
            if int(d.get("saat") or 0) <= 0:
                continue
            if d.get("subeId") not in self.subeler:
                self.hatalar.append({"kural": "VERI", "mesaj": f"{d.get('ad', d['id'])}: şube bulunamadı."})
                continue
            ogr = [o for o in (d.get("ogretmenler") or ([d["ogretmenId"]] if d.get("ogretmenId") else [])) if o]
            for o in ogr:
                if o not in self.ogretmenler:
                    self.hatalar.append({"kural": "VERI", "mesaj": f"{d.get('ad')}: öğretmen kaydı yok ({o})."})
            ogr = [o for o in ogr if o in self.ogretmenler]
            bilgi = dict(d)
            bilgi["ogretmenler"] = ogr
            self.ders_bilgi[d["id"]] = bilgi
            anahtar = (d["subeId"], d["grup"]) if d.get("grup") else ("tek", d["id"])
            gruplar[anahtar].append(bilgi)

        self.birimler = {}
        for anahtar, uyeler in gruplar.items():
            ilk = uyeler[0]
            saatler = {int(u["saat"]) for u in uyeler}
            if len(saatler) > 1:
                self.hatalar.append({"kural": "K02", "mesaj": f"{self.subeler[ilk['subeId']]['ad']}: paralel grup “{ilk['grup']}” derslerinin haftalık saatleri farklı ({', '.join(u['ad'] + '=' + str(u['saat']) for u in uyeler)})."})
                continue
            saat = int(ilk["saat"])
            bid = ilk["id"] if anahtar[0] == "tek" else f"grup:{anahtar[0]}:{anahtar[1]}"
            ogretmenler = []
            for u in uyeler:
                for o in u["ogretmenler"]:
                    if o in ogretmenler:
                        self.hatalar.append({"kural": "K01", "mesaj": f"{self.subeler[ilk['subeId']]['ad']}: {self.ogretmenler[o]['ad']} aynı paralel grupta iki derse atanmış."})
                    else:
                        ogretmenler.append(o)
            etiketler = sorted({e for u in uyeler for e in (u.get("etiketler") or [])})
            dil = next((u.get("dil") for u in uyeler if u.get("dil")), None)
            yogun = saat > D * L
            # Kalıplar: önce kullanıcı seçenekleri, yoksa K06 varsayılanı
            kaliplar = []
            for k in ilk.get("yerlesimSecenekleri") or []:
                try:
                    k = [int(x) for x in k]
                except (TypeError, ValueError):
                    continue
                if sum(k) == saat and all(x > 0 for x in k) and k not in kaliplar:
                    kaliplar.append(k)
            if not kaliplar:
                kaliplar.append(varsayilan_kalip(saat, D, L, self.blok_modu))
            if ilk.get("bolunebilir") and saat == 2 and [1, 1] not in kaliplar:
                kaliplar.append([1, 1])
            odalar = []
            for u in uyeler:
                if u.get("derslikId"):
                    if u["derslikId"] not in self.derslikler:
                        self.hatalar.append({"kural": "K12", "mesaj": f"{u.get('ad')}: sabit derslik ({u['derslikId']}) tanımlı değil."})
                        odalar.append(None)
                    else:
                        odalar.append(("sabit", u["derslikId"]))
                        if u.get("derslikTuru") and u["derslikTuru"] != "normal" and self.derslikler[u["derslikId"]]["tur"] != u["derslikTuru"]:
                            self.hatalar.append({"kural": "K12", "mesaj": f"{u.get('ad')}: sabit derslik, gereken “{u['derslikTuru']}” türünde değil."})
                elif u.get("derslikTuru") and u["derslikTuru"] != "normal":
                    if not self.oda_turleri.get(u["derslikTuru"]):
                        self.hatalar.append({"kural": "K12", "mesaj": f"{u.get('ad')}: “{u['derslikTuru']}” türünde derslik tanımlı değil."})
                        odalar.append(None)
                    else:
                        odalar.append(("tur", u["derslikTuru"]))
                elif self.subeler[ilk["subeId"]]["oda"] and len(uyeler) == 1:
                    odalar.append(("sabit", self.subeler[ilk["subeId"]]["oda"]))
                else:
                    odalar.append(None)
            kilitler = []
            for u in uyeler:
                kilitler.extend(kilit_gruplari(u.get("kilitli")))
            kilitler = kilit_gruplari([{"gun": a, "saat": b, "uzunluk": c} for a, b, c in kilitler])
            self.birimler[bid] = Birim(
                id=bid, dersler=[u["id"] for u in uyeler], sube=ilk["subeId"], saat=saat,
                ad=" / ".join(u.get("ad") or u["id"] for u in uyeler), dil=dil, etiketler=etiketler,
                yogun=yogun, gunluk_max=L, kaliplar=kaliplar,
                ogretmenler=ogretmenler, oda=odalar, kilitler=kilitler, zor=("zor" in etiketler),
                saat_tercihi=ilk.get("saatTercihi") or ders_saat_tercihi(ilk.get("ad")))
            if yogun:
                self.uyarilar.append(f"{self.subeler[ilk['subeId']]['ad']} · {ilk.get('ad')}: {saat} saat, {D} günde günlük {L} sınırına sığmıyor. K04 otomatik esnetilmedi; yalnız açık izinli esnetme aşamasında yeniden denenebilir.")

    def _kulupleri_kur(self, g):
        self.kulupler = []
        for k in g.get("kulupler") or []:
            subeler = [s for s in (k.get("subeIds") or []) if s in self.subeler]
            ogr = [o for o in (k.get("ogretmenler") or ([k["ogretmenId"]] if k.get("ogretmenId") else [])) if o in self.ogretmenler]
            if not subeler and not ogr:
                continue
            saat = int(k.get("saat") or 1)
            sabit = k.get("sabit")
            self.kulupler.append({"id": k["id"], "ad": k.get("ad") or k["id"], "subeler": subeler, "ogretmenler": ogr,
                                  "saat": saat, "sabit": (int(sabit["gun"]), int(sabit["saat"])) if sabit and sabit.get("gun") is not None else None,
                                  "oda": k.get("derslikId") if k.get("derslikId") in self.derslikler else None})

    # ------------------------------------------------------------------
    def gecis_suresi(self, ilk_saat, son_saat):
        """İlk dersin bitişi ile sonraki dersin başlangıcı arasındaki dakika."""
        if son_saat <= ilk_saat:
            return 0
        return sum(self.gecis_bosluk(h) for h in range(ilk_saat, son_saat)) + \
            max(0, son_saat - ilk_saat - 1) * self.ders_dk

    def gecis_bosluk(self, h):
        """h ve h+1 arasındaki ara (dk)."""
        if self.ogle_sonra and h + 1 == self.ogle_sonra:
            return self.ogle_dk
        return self.teneffus

    def oda_binasi(self, oda):
        return self.derslikler.get(oda, {}).get("bina") if oda else None

    def oturumlar(self, birim, kalip):
        """Bir birimin bir kalıp için oturumları. Kilit grupları uygun parçalara bağlanır.
        Döner: (oturum listesi, hata metni|None)"""
        parcalar = sorted(kalip, reverse=True)
        kalan = list(parcalar)
        eslesme = []          # (uzunluk, kilit grubu|None)
        for (g, s, u) in sorted(birim.kilitler, key=lambda x: -x[2]):
            uygun = [p for p in kalan if p >= u]
            if not uygun:
                return None, f"{birim.ad}: {M_GUN(g)} {s + 1}. dersten itibaren {u} saat kilitli; blok yapısı ({'+'.join(map(str, kalip))}) bunu taşıyamaz."
            p = min(uygun)
            kalan.remove(p)
            eslesme.append((p, (g, s, u)))
        for p in kalan:
            eslesme.append((p, None))
        return eslesme, None


GUNLER = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]


def M_GUN(g):
    return GUNLER[g] if 0 <= g < len(GUNLER) else str(g)

"""
Çok aşamalı CP-SAT dağıtımı.

Aşamalar:
  1. Tam kurallar            — bütün zorunlu kurallar + yumuşak kurallar (öncelik sırasıyla ardışık optimizasyon)
  2. Alternatif blok         — kullanıcının izin verdiği VEYA kalıpları / bölünebilir bloklar
  3. Tercih esnetme          — kesin işaretli tercih sınırları yumuşar, yalnızca geçerli çözüm aranır
  4. İzinli sınır esnetme    — yalnızca kullanıcının esnetilebilir işaretlediği sınırlar (günlük üst sınır, blok yapısı, aynı gün blok)
Öğretmen/şube/derslik çakışması, haftalık saat, kapalı saatler ve kilitler hiçbir aşamada esnetilmez.
"""
import os
import time
from collections import defaultdict

from ortools.sat.python import cp_model

from .veri import Problem, M_GUN
from .model import Model, Ayar, ONCELIK
from .denetim import on_denetim, dogrula

DURUM_AD = {cp_model.OPTIMAL: "OPTIMAL", cp_model.FEASIBLE: "FEASIBLE", cp_model.INFEASIBLE: "INFEASIBLE",
            cp_model.UNKNOWN: "UNKNOWN", cp_model.MODEL_INVALID: "MODEL_INVALID"}
ONCELIK_AD = {"yuksek": "yüksek", "orta": "orta", "dusuk": "düşük"}
HIC_ESNETILMEZ = ["K01 öğretmen çakışması", "K02 şube çakışması", "K03 haftalık ders saatleri",
                  "K09 öğretmen kapalı saatleri", "K11 şube kapalı saatleri", "K12 derslik çakışması", "K14 kilitli dersler"]


class Cozucu:
    def __init__(self, girdi, ilerleme=None):
        self.girdi = girdi
        self.P = Problem(girdi)
        c = girdi.get("cozucu") or {}
        self.sure = max(2.0, float(c.get("sureSn") or 60))
        self.isci = max(1, int(c.get("isci") or (os.cpu_count() or 4)))
        self.tohum = int(girdi.get("tohum") or 1) % 100000
        self.ilerleme = ilerleme or (lambda *a: None)
        self.t0 = time.time()

    def kalan(self):
        return max(1.0, self.sure - (time.time() - self.t0))

    def _parametre(self, s, sure, isci=None):
        s.parameters.max_time_in_seconds = max(0.5, sure)
        s.parameters.num_workers = isci or self.isci
        s.parameters.random_seed = self.tohum
        s.parameters.log_search_progress = False

    # ------------------------------------------------------------------
    def calistir(self):
        P = self.P
        on = on_denetim(P)
        self.ilerleme("ondenetim", 0.02, "Veriler denetlendi")
        if on["hatalar"]:
            return self._basarisiz("INFEASIBLE", "Ön denetim", on, [], cekirdek=[h["mesaj"] for h in on["hatalar"]], kanit="Ön denetim: gerekli koşullar sağlanmıyor")
        izin = {k: v for k, v in (P.kurallar.get("esnetIzin") or {}).items() if v}
        alternatif_var = any(len(b.kaliplar) > 1 for b in P.birimler.values())
        asamalar = [("Tam kurallar", Ayar(), [], 0.55)]
        if alternatif_var:
            asamalar.append(("Alternatif blok", Ayar(alternatif=True), ["K06 birincil blok yapısı yerine izin verilen VEYA / bölünebilir bloklar"], 0.15))
        asamalar.append(("Tercih esnetme", Ayar(alternatif=True, tercih_esnek=True, hedefli=False),
                         ["Yumuşak tercihler optimize edilmedi; kesin gün sınırı korunuyor"], 0.15))
        if izin:
            ad = {"gunlukMax": "K04 günlük üst sınır +1", "blokYapisi": "K06 blok yapısı serbest (1 ve 2 saatlik parçalar)", "ayniGunBlok": "K07 aynı gün ayrı blok serbest (K05 korunur)"}
            asamalar.append(("İzinli sınır esnetme", Ayar(alternatif=True, tercih_esnek=True, esnet=izin, hedefli=False),
                             [ad.get(k, k) for k in izin], 0.15))
        kayit = []
        kanitli_imkansiz = False
        for i, (ad, ayar, esnetilen, pay) in enumerate(asamalar):
            kalan_asama = len(asamalar) - i
            sure = self.kalan() * pay if i == 0 else self.kalan() / kalan_asama
            self.ilerleme("asama", 0.05 + 0.8 * i / len(asamalar), f"{i + 1}. aşama: {ad}")
            sonuc = self._asama(ad, ayar, sure, esnetilen)
            kayit.append(sonuc["kayit"])
            if sonuc.get("cozum"):
                return self._basarili(sonuc, kayit, on)
            if sonuc["kayit"]["durum"] == "INFEASIBLE" and i == 0:
                kanitli_imkansiz = True
            if self.kalan() < 1.5:
                break
        # Çözüm yok: çelişki çekirdeği + taslak
        cekirdek = []
        if kanitli_imkansiz:
            self.ilerleme("teshis", 0.88, "Çelişen kurallar aranıyor")
            cekirdek = self._cekirdek()
        self.ilerleme("teshis", 0.94, "Taslak program hazırlanıyor")
        durum = "INFEASIBLE" if all(k["durum"] == "INFEASIBLE" for k in kayit) else "UNKNOWN"
        return self._basarisiz(durum, kayit[-1]["ad"] if kayit else "", on, kayit, cekirdek=cekirdek,
                               kanit="Çözücü kurallarla çözüm olmadığını kanıtladı" if durum == "INFEASIBLE" else "Süre içinde sonuç kesinleşmedi")

    # ------------------------------------------------------------------
    def _asama(self, ad, ayar, sure, esnetilen):
        t = time.time()
        M = Model(self.P, ayar)
        boyut = M.boyut()
        kayit = {"ad": ad, "esnetilen": esnetilen, "korunan": self._korunan(ayar), "boyut": boyut}
        if M.hatalar:
            kayit.update(durum="INFEASIBLE", sureMs=int((time.time() - t) * 1000), not_=[h["mesaj"] for h in M.hatalar][:20])
            return {"kayit": kayit}
        if self.P.onceki:
            M.ipucu_ver({(d, u): [(g, s) for (g, s, uu) in l if uu == u] for d, l in self.P.onceki.items() for u in {x[2] for x in l}})
        s = cp_model.CpSolver()
        # 1) Önce geçerli çözüm (amaçsız)
        self._parametre(s, sure)
        st = s.Solve(M.m)
        kayit["durum"] = DURUM_AD.get(st, str(st))
        if st not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            kayit["sureMs"] = int((time.time() - t) * 1000)
            return {"kayit": kayit}
        cozum = M.oku(s)
        amac, tam_optimal = {}, True
        # 2) Ardışık (leksikografik) optimizasyon: yüksek -> orta -> düşük
        if ayar.hedefli:
            seviyeler = [p for p in ONCELIK if M.terimler.get(p)]
            for i, p in enumerate(seviyeler):
                # geçerli çözüm bulunduktan sonra kalan bütün süre optimizasyona ayrılır
                kalan_sure = max(0.5, (self.kalan() - 0.5) / (len(seviyeler) - i))
                self.ilerleme("optimizasyon", 0.5 + 0.4 * i / len(seviyeler), f"{ad}: {ONCELIK_AD.get(p, p)} öncelikli tercihler iyileştiriliyor")
                ifade = sum(w * e for (w, e, _) in M.terimler[p])
                M.m.ClearHints()
                self._cozumu_ipucu(M, s)
                M.m.Minimize(ifade)
                s2 = cp_model.CpSolver()
                self._parametre(s2, kalan_sure)
                st2 = s2.Solve(M.m)
                if st2 in (cp_model.OPTIMAL, cp_model.FEASIBLE):
                    deger = int(round(s2.ObjectiveValue()))
                    amac[p] = {"deger": deger, "durum": DURUM_AD[st2], "terimler": sorted({a for (_, _, a) in M.terimler[p]})}
                    tam_optimal = tam_optimal and st2 == cp_model.OPTIMAL
                    M.m.Add(ifade <= deger)
                    cozum = M.oku(s2)
                    s = s2
                else:
                    # bu seviyede iyileştirme bulunamadı: mevcut geçerli çözümle sonraki seviyeye geç
                    tam_optimal = False
                    amac[p] = {"deger": None, "durum": DURUM_AD.get(st2, str(st2))}
            kayit["durum"] = "OPTIMAL" if tam_optimal else "FEASIBLE"
        else:
            kayit["durum"] = "FEASIBLE"
        kayit["sureMs"] = int((time.time() - t) * 1000)
        kayit["amac"] = amac
        return {"kayit": kayit, "cozum": cozum, "model": M, "ayar": ayar}

    def _korunan(self, ayar):
        P, k = self.P, self.P.kurallar
        e = ayar.esnet
        l = list(HIC_ESNETILMEZ)
        l.append("K04 günlük üst sınır" + (" (+1 esnetildi)" if e.get("gunlukMax") else ""))
        if k.get("ucluTekrarYasak"):
            l.append("K05 üçlü tekrar yasağı")
        if not e.get("blokYapisi"):
            l.append("K06 blok yapısı" + (" (alternatifler dahil)" if ayar.alternatif else " (birincil kalıp)"))
        if k.get("blokFarkliGun") and not e.get("ayniGunBlok"):
            l.append("K07 bloklar farklı günlerde")
        if k.get("dilAyriGun"):
            l.append("K08 İngilizce / Yabancı Dil ayrı günlerde")
        l.append("K10 öğretmen günlük/haftalık sınırı ve kesin gün sınırı")
        if len(P.binalar) > 1 and P.gecis:
            l.append("K13 bina geçiş süresi")
        if P.kulupler:
            l.append("K15 sosyal kulüpler")
        if P.ders_etiket_kurallari:
            l.append("K16 etiket kuralları")
        return sorted(l)

    def _cozumu_ipucu(self, M, s):
        for no, xs in M.X.items():
            for (_, _, v) in xs:
                M.m.AddHint(v, 1 if s.BooleanValue(v) else 0)

    def _cekirdek(self):
        """Varsayım literalleriyle kanıtlanmış çelişen kural grupları."""
        try:
            M = Model(self.P, Ayar(varsayim=True, hedefli=False))
            if M.hatalar:
                return [h["mesaj"] for h in M.hatalar]
            M.m.AddAssumptions([v for v, _ in M.varsayimlar])
            s = cp_model.CpSolver()
            self._parametre(s, min(25.0, max(3.0, self.kalan() * 0.5)), isci=1)
            st = s.Solve(M.m)
            if st != cp_model.INFEASIBLE:
                return []
            idx = s.SufficientAssumptionsForInfeasibility()
            harita = {v.Index(): ad for v, ad in M.varsayimlar}
            l = [harita[i] for i in idx if i in harita]
            if not l:
                return ["Öğretmen, şube ve derslik çakışma kuralları ile haftalık ders saatleri birlikte sağlanamıyor (kapasite yetersiz)."]
            return l
        except Exception as e:  # çekirdek isteğe bağlı bir analizdir
            return [f"Çelişki analizi yapılamadı: {e}"]

    # ------------------------------------------------------------------ çıktı
    def _oda_ata(self, cozum):
        """Gerçek oda kararlarını çözücüden al; sonradan açgözlü atama yapma."""
        atama = {}
        for o, sec, odalar in cozum:
            if sec is None:
                continue
            for ui, (did, ogr, oda) in enumerate(o.oda or []):
                if oda and oda[0] == "sabit":
                    atama[(o.no, ui)] = oda[1]
                elif oda and oda[0] == "tur":
                    atama[(o.no, ui)] = odalar.get(ui)
        return atama

    def _yerlesim(self, cozum):
        P = self.P
        atama = self._oda_ata(cozum)
        yerlesim, kulup, yerlesmeyen = [], [], []
        kalip = defaultdict(list)
        for (o, sec, _) in cozum:
            if o.kulup is not None:
                if sec:
                    kulup.append({"kulupId": o.kulup, "gun": sec[0], "saat": sec[1], "uzunluk": o.uzunluk, "derslikId": atama.get((o.no, 0))})
                continue
            if not sec:
                for did in o.dersler:
                    yerlesmeyen.append({"dersId": did, "uzunluk": o.uzunluk, "neden": self._neden(o)})
                continue
            kilitli = any(g == sec[0] and s < sec[1] + o.uzunluk and sec[1] < s + u for (g, s, u) in o.birim.kilitler)
            for ui, did in enumerate(o.dersler):
                yerlesim.append({"dersId": did, "gun": sec[0], "saat": sec[1], "uzunluk": o.uzunluk, "kilitli": kilitli,
                                 "derslikId": atama.get((o.no, ui))})
                kalip[did].append(o.uzunluk)
        kullanilan = {d: "+".join(map(str, sorted(v, reverse=True))) for d, v in kalip.items()}
        return yerlesim, kulup, yerlesmeyen, kullanilan

    def _neden(self, o):
        """Yerleşmeyen oturum için olası nedenler (kanıt değildir)."""
        P = self.P
        b = o.birim
        nedenler = defaultdict(int)
        for d in range(P.D):
            for h in range(P.H - o.uzunluk + 1):
                for i in range(o.uzunluk):
                    sl = (d, h + i)
                    if sl in P.subeler[b.sube]["kapali"]:
                        nedenler["şube kapalı saat"] += 1
                    for t in b.ogretmenler:
                        if sl in P.ogretmenler[t]["kapali"]:
                            nedenler[f"{P.ogretmenler[t]['ad']} kapalı saat"] += 1
        en = sorted(nedenler.items(), key=lambda x: -x[1])[:2]
        ek = (" Başlıca kısıtlar: " + ", ".join(a for a, _ in en) + ".") if en else ""
        return "Olası neden: öğretmen/şube saatleri diğer derslerle dolu ya da günlük kurallar (K04/K07) yer bırakmıyor." + ek

    def _istatistik(self, yerlesim, kulup, yerlesmeyen):
        P = self.P
        sube_dolu = defaultdict(set)
        ogr_dolu = defaultdict(set)
        ders_birim = {did: b for b in P.birimler.values() for did in b.dersler}
        gorulen = set()
        for y in yerlesim:
            b = ders_birim.get(y["dersId"])
            if not b or (b.id, y["gun"], y["saat"]) in gorulen:
                continue
            gorulen.add((b.id, y["gun"], y["saat"]))
            for i in range(y["uzunluk"]):
                sube_dolu[b.sube].add((y["gun"], y["saat"] + i))
                for t in b.ogretmenler:
                    ogr_dolu[t].add((y["gun"], y["saat"] + i))
        for k in kulup:
            kk = next(x for x in P.kulupler if x["id"] == k["kulupId"])
            for i in range(k["uzunluk"]):
                for s in kk["subeler"]:
                    sube_dolu[s].add((k["gun"], k["saat"] + i))
                for t in kk["ogretmenler"]:
                    ogr_dolu[t].add((k["gun"], k["saat"] + i))
        sb = 0
        for s, dolu in sube_dolu.items():
            for d in range(P.D):
                saatler = [h for (g, h) in dolu if g == d]
                if saatler:
                    son = max(saatler)
                    sb += sum(1 for h in range(son + 1) if (d, h) not in dolu and (d, h) not in P.subeler[s]["kapali"])
        ob = 0
        ihlaller = []
        for t, dolu in ogr_dolu.items():
            gunler = set()
            for d in range(P.D):
                saatler = sorted(h for (g, h) in dolu if g == d)
                if saatler:
                    gunler.add(d)
                    ob += (saatler[-1] - saatler[0] + 1) - len(saatler)
            o = P.ogretmenler[t]
            if o["maxGun"] and len(gunler) > o["maxGun"]:
                ihlaller.append({"tip": "gunSayisi", "ogretmenId": t, "sinir": o["maxGun"], "deger": len(gunler)})
        toplam = sum(b.saat for b in P.birimler.values())
        eksik = sum(y["uzunluk"] for y in yerlesmeyen if ders_birim.get(y["dersId"]) and ders_birim[y["dersId"]].dersler[0] == y["dersId"])
        # Önceki yerleşime göre korunan / değişen saat hesabı
        korunan_saat, degisen_saat = 0, 0
        if P.onceki:
            eski_slotlar = set()
            for did, liste in P.onceki.items():
                for (g, s, u) in liste:
                    for i in range(u):
                        eski_slotlar.add((did, g, s + i))
            yeni_slotlar = set()
            for y in yerlesim:
                for i in range(y["uzunluk"]):
                    yeni_slotlar.add((y["dersId"], y["gun"], y["saat"] + i))
            korunan_saat = len(eski_slotlar & yeni_slotlar)
            degisen_saat = len(yeni_slotlar - eski_slotlar)
        # Zümre ortak boş saat özeti
        zumre_ozet = []
        for zg in P.zumre_gruplari:
            ortak = []
            for d in range(P.D):
                for h in range(P.H):
                    if all((d, h) not in P.ogretmenler[t]["kapali"] and (d, h) not in ogr_dolu[t] for t in zg["ogretmenler"]):
                        ortak.append(f"{M_GUN(d)} {h + 1}. saat")
                        if len(ortak) >= 3:
                            break
                if len(ortak) >= 3:
                    break
            zumre_ozet.append({"ad": zg["ad"], "bulundu": len(ortak) > 0, "ornekler": ortak})
        return {"blokSayisi": len({(ders_birim[y['dersId']].id, y['gun'], y['saat']) for y in yerlesim if y['dersId'] in ders_birim}),
                "kilitliBlok": sum(1 for y in yerlesim if y.get("kilitli")), "toplamSaat": toplam, "eksikSaat": eksik,
                "subeBosluk": sb, "ogretmenBosluk": ob, "ihlal": len(ihlaller), "iterasyon": 0, "ceza": 0,
                "korunanSaat": korunan_saat, "degisenSaat": degisen_saat, "zumreOzet": zumre_ozet,
                "tohum": self.tohum, "sureMs": int((time.time() - self.t0) * 1000), "motor": "CP-SAT"}, ihlaller

    def _basarili(self, sonuc, kayit, on):
        yerlesim, kulup, yerlesmeyen, kullanilan = self._yerlesim(sonuc["cozum"])
        ist, ihlaller = self._istatistik(yerlesim, kulup, yerlesmeyen)
        dog = dogrula(self.P, yerlesim, kulup, ayar=sonuc["ayar"])
        durum = kayit[-1]["durum"]
        basarili = not dog and not yerlesmeyen
        return {"yerlesim": yerlesim, "kulupYerlesim": kulup, "yerlesmeyen": yerlesmeyen, "istatistik": ist, "ihlaller": ihlaller,
                "kullanilanKalip": kullanilan,
                "cozucu": {"durum": durum if basarili else "DOGRULAMA_HATASI", "basarili": basarili, "asama": kayit[-1]["ad"],
                           "asamalar": kayit, "modelBoyutu": kayit[-1].get("boyut"), "onDenetim": on, "kuralIhlalleri": dog,
                           "cekirdek": [], "isci": self.isci, "sureSn": self.sure}}

    def _basarisiz(self, durum, asama, on, kayit, cekirdek=(), kanit=""):
        """Çözüm yok: zorunlu kuralları çiğnemeden en çok saati yerleştiren taslak ve nedenler."""
        yerlesim, kulup, yerlesmeyen, kullanilan = [], [], [], {}
        if not on.get("hatalar"):
            try:
                M = Model(self.P, Ayar(alternatif=True, teshis=True, hedefli=False))
                s = cp_model.CpSolver()
                self._parametre(s, min(20.0, max(2.0, self.kalan())))
                st = s.Solve(M.m)
                if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
                    yerlesim, kulup, yerlesmeyen, kullanilan = self._yerlesim(M.oku(s))
            except Exception:
                pass
        if not yerlesim and not yerlesmeyen:
            for b in self.P.birimler.values():
                for did in b.dersler:
                    yerlesmeyen.append({"dersId": did, "uzunluk": b.saat, "neden": "Dağıtım yapılmadı (ön denetim hatası)."})
        ist, ihlaller = self._istatistik(yerlesim, kulup, yerlesmeyen)
        oneriler = []
        for c in cekirdek:
            cm = str(c)
            cl = cm.lower()
            if "kapalı" in cl or "k09" in cl:
                oneri = "İlgili öğretmenin veya şubenin kapalı saatlerinden birkaçını açıp yeniden deneyin."
            elif "kilit" in cl or "k14" in cl:
                oneri = "Çakışan kilitli derslerden birinin kilidini kaldırıp tekrar dağıtın."
            elif "günlük" in cl or "k04" in cl or "k10" in cl:
                oneri = "Öğretmenin günlük üst sınırını veya kesin gün sınırını 1 artırın."
            elif "blok" in cl or "k06" in cl or "k07" in cl:
                oneri = "Blok düzeni sekmesinden bu ders için alternatif kalıp (ör. 2+1+1) ekleyin."
            elif "derslik" in cl or "oda" in cl or "k12" in cl:
                oneri = "Aynı türdeki derslik/laboratuvar sayısını artırın veya bazı dersleri normal sınıfa alın."
            elif "bina" in cl or "k13" in cl:
                oneri = "Bina geçiş süresini düşürün veya öğretmenin aynı gün iki binada dersini azaltın."
            else:
                oneri = "Öğretmen kapalı saatleri, kilitli dersler ve kesin gün sınırlarını gözden geçirin."
            oneriler.append({"mesaj": cm, "oneri": oneri})
        return {"yerlesim": yerlesim, "kulupYerlesim": kulup, "yerlesmeyen": yerlesmeyen, "istatistik": ist, "ihlaller": ihlaller,
                "kullanilanKalip": kullanilan,
                "cozucu": {"durum": durum, "basarili": False, "taslak": bool(yerlesim), "asama": asama, "asamalar": kayit,
                           "modelBoyutu": kayit[-1].get("boyut") if kayit else None, "onDenetim": on,
                           "kuralIhlalleri": dogrula(self.P, yerlesim, kulup) if yerlesim else [],
                           "cekirdek": list(cekirdek), "cekirdekOneriler": oneriler, "kanit": kanit, "isci": self.isci, "sureSn": self.sure}}


def coz(girdi, ilerleme=None):
    return Cozucu(girdi, ilerleme).calistir()

<?php
/**
 * EvrakPlus · Haftalık Ders Dağıtım Programı — WordPress köprüsü
 * ==================================================================
 * Bu dosya programın tek giriş kapısıdır (public_html/<klasör>/index.php):
 *   1. WordPress'i yükler ve oturumu denetler; giriş yapmamış ziyaretçiyi DD_GIRIS_URL'ye yönlendirir.
 *      Ayrı şifre yoktur: evrakplus.com üyeliği yeterlidir.
 *   2. Her üyenin verisini kendi WordPress hesabında (wp_usermeta) DD_PROGRAM_KODU . '_data' anahtarıyla saklar.
 *      Üye başka cihazdan girdiğinde en son çalıştığı proje açılır.
 *   3. index.php?action=…  → JSON API (kaydet, yükle, dağıtım …)
 *      index.php?sayfa=kurulum → sunucu kurulum denetimi (yalnız site yöneticileri)
 *      index.php            → program
 */

// ======================= AYARLAR =======================
const DD_PROGRAM_KODU   = 'ders_dagitim';                      // veri anahtarı: ders_dagitim_data
const DD_GIRIS_URL      = 'https://www.evrakplus.com/giris/';  // giriş yapmayanların gönderileceği sayfa
const DD_GIRIS_DONUS    = false;   // true yapılırsa adrese ?redirect_to=<program adresi> eklenir (giriş sayfanız destekliyorsa)
const DD_CIKIS_DONUS    = 'https://www.evrakplus.com/';        // "Çıkış"tan sonra gidilecek sayfa
const DD_ANA_SAYFA      = 'https://www.evrakplus.com/';        // üst çubuktaki "evrakplus.com" düğmesi
// Herkese görünen duyuru bandı (boş bırakılırsa gösterilmez). E-posta adresi tıklanabilir bağlantıya dönüşür.
const DD_DUYURU         = 'Test aşamasındadır. Geri bildirim için: appo.yanarates@gmail.com';
const DD_IZINLI_ROLLER  = [];      // boş: giriş yapmış tüm üyeler. Örn. ['subscriber', 'customer', 'administrator']
const DD_AZAMI_PROJE    = 20;      // bir üyenin saklayabileceği en fazla okul/proje
const DD_PROGRAM_ADI    = 'Haftalık Ders Dağıtım Programı';
const DD_KISA_AD        = 'Ders Dağıtım';
// WordPress başka bir yerdeyse wp-load.php'nin tam yolunu yazın; boşsa üst klasörlerde kendiliğinden aranır.
const DD_WP_LOAD        = '';
// =======================================================

define('DD_KOPRU', true);

if (PHP_VERSION_ID < 80100) {
    header('Content-Type: text/html; charset=utf-8');
    exit('<h2>PHP sürümü yetersiz</h2><p>Bu program PHP 8.1 ya da üstünü ister; sunucudaki sürüm ' . PHP_VERSION . '.</p>');
}

$dd_api = isset($_GET['action']);

/** wp-load.php'yi bul: ayar → üst klasörler (public_html/klasor/index.php → public_html/wp-load.php) */
function dd_wp_load_bul(): ?string
{
    if (DD_WP_LOAD !== '' && is_file(DD_WP_LOAD)) return DD_WP_LOAD;
    $d = __DIR__;
    for ($i = 0; $i < 4; $i++) {
        $d = dirname($d);
        if (is_file($d . '/wp-load.php')) return $d . '/wp-load.php';
    }
    return null;
}

$dd_wp = dd_wp_load_bul();
if ($dd_wp === null) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    exit('<h2>WordPress bulunamadı</h2><p>Program klasörü WordPress’in kurulu olduğu public_html içine yüklenmeli (ör. public_html/ders-dagitim/). Başka bir yerdeyse index.php içindeki DD_WP_LOAD ayarına wp-load.php yolunu yazın.</p>');
}

// Sayfa önbelleği / küçültme eklentileri bu sayfaya dokunmasın (üyeye özel içerik)
if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
if (!defined('DONOTCACHEDB')) define('DONOTCACHEDB', true);
if (!defined('DONOTMINIFY')) define('DONOTMINIFY', true);
if (!defined('DONOTCDN')) define('DONOTCDN', true);
if (!defined('WP_USE_THEMES')) define('WP_USE_THEMES', false);

// WordPress yüklenirken eklentilerin bastığı boşluk/çıktı yanıtı bozmasın
$dd_seviye = ob_get_level();
ob_start();
require_once $dd_wp;
while (ob_get_level() > $dd_seviye) ob_end_clean();

require_once __DIR__ . '/bootstrap.php';

nocache_headers();
header('X-LiteSpeed-Cache-Control: no-cache');
header('X-Robots-Tag: noindex, nofollow');
dd_guvenlik_basliklari();

/** Programın bu sunucudaki adresi (https://www.evrakplus.com/ders-dagitim/) */
function dd_program_url(): string
{
    $yol = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    $yol = rtrim($yol, '/') . '/';
    $host = $_SERVER['HTTP_HOST'] ?? (string)parse_url(home_url(), PHP_URL_HOST);
    return (is_ssl() ? 'https' : 'http') . '://' . $host . $yol;
}

function dd_giris_url(): string
{
    return DD_GIRIS_DONUS ? add_query_arg('redirect_to', rawurlencode(dd_program_url()), DD_GIRIS_URL) : DD_GIRIS_URL;
}

/** Giriş yapmış üye bu programı kullanabilir mi? (rol sınırı + dd_erisim_izni süzgeci) */
function dd_erisim_var(): bool
{
    if (!is_user_logged_in()) return false;
    $u = wp_get_current_user();
    $izin = true;
    if (DD_IZINLI_ROLLER) $izin = (bool)array_intersect(DD_IZINLI_ROLLER, (array)$u->roles) || user_can($u, 'manage_options');
    // Üyelik eklentisiyle sınırlamak için: add_filter('dd_erisim_izni', fn($izin, $user) => ..., 10, 2);
    return (bool)apply_filters('dd_erisim_izni', $izin, $u);
}

function dd_depo(): \DersDagitim\UyeDeposu
{
    static $d = null;
    return $d ??= new \DersDagitim\UyeDeposu(get_current_user_id(), DD_PROGRAM_KODU . '_data', DD_AZAMI_PROJE);
}

// ---------- Oturum denetimi ----------
if (!is_user_logged_in()) {
    if ($dd_api) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        exit(json_encode(['hata' => 'Oturumunuz kapanmış. Lütfen evrakplus.com’a yeniden giriş yapın.', 'giris' => true, 'girisUrl' => dd_giris_url()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
    header('Location: ' . dd_giris_url(), true, 302);
    exit;
}
if (!dd_erisim_var()) {
    http_response_code(403);
    if ($dd_api) {
        header('Content-Type: application/json; charset=utf-8');
        exit(json_encode(['hata' => 'Bu programı kullanma yetkiniz yok.'], JSON_UNESCAPED_UNICODE));
    }
    header('Content-Type: text/html; charset=utf-8');
    exit('<!DOCTYPE html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Erişim yok</title>'
        . '<div style="font-family:system-ui,sans-serif;max-width:520px;margin:12vh auto;padding:0 20px;line-height:1.5">'
        . '<h2>Bu programa erişiminiz yok</h2><p>Hesabınız bu programı kullanmaya yetkili değil.</p>'
        . '<p><a href="' . esc_url(home_url('/')) . '">evrakplus.com’a dön</a></p></div>');
}

// ---------- Yönlendirme ----------
if ($dd_api) {
    require __DIR__ . '/inc/api.php';
} elseif (($_GET['sayfa'] ?? '') === 'kurulum') {
    if (!current_user_can('manage_options')) {
        http_response_code(403);
        exit('Bu sayfa yalnız site yöneticileri içindir.');
    }
    require __DIR__ . '/inc/kurulum.php';
} else {
    require __DIR__ . '/inc/uygulama.php';
}

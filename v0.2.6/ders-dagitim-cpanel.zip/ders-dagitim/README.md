# Haftalık Ders Dağıtım Programı (Ortaokul ve Lise)

MEB Talim ve Terbiye Kurulu Başkanlığının **haftalık ders çizelgelerine** göre çalışan, okul türüne göre ayrım yapan, şube ve öğretmen çakışması olmadan haftalık ders programı üreten PHP uygulaması.

Kaynak: <https://ttkb.meb.gov.tr/www/haftalik-ders-cizelgeleri/kategori/7>

## Neler var

| Okul türü | Kademe | Sınıflar | Haftalık |
|---|---|---|---|
| Ortaokul | Ortaokul | 5–8 | 35 |
| İmam Hatip Ortaokulu | Ortaokul | 5–8 | 36 |
| Spor Ortaokulu | Ortaokul | 5–8 | 40 |
| Anadolu Lisesi | Lise | 9–12 | 40 |
| Hazırlık Sınıfı Bulunan Anadolu Lisesi | Lise | Hz, 9–12 | 40 |
| Fen Lisesi | Lise | 9–12 | 40 |
| Sosyal Bilimler Lisesi | Lise | 9–12 | 40 |
| Anadolu İmam Hatip Lisesi (hazırlıklı/hazırlıksız) | Lise | Hz, 9–12 | 40 |
| Spor Lisesi | Lise | 9–12 | 40 |
| Güzel Sanatlar Lisesi (Görsel Sanatlar) | Lise | 9–12 | 43 |

* Her türün ders saatleri sınıf bazında `data/cizelgeler.json` dosyasındadır. Her sınıfın satır toplamı, çizelgedeki resmî toplamla karşılaştırılarak doğrulanmıştır.
* Seçmeli ders havuzları (ortaokul: 3 grup, lise: Akademik Çalışmalar + 3 grup) ve ders → branş eşlemesi aynı dosyadadır.

## Menü

**Kurulum**
0. **Genel bakış ve rehberli akış** — açılışta okulun durumunu gösteren genel bakış ekranı vardır: ilerleme çubuğu, sıradaki adım (“Devam et”), özet kutuları, 14 adımın durumu (Tamam / Dikkat / Yapılacak / İsteğe bağlı) ve hızlı işlemler. Yan menüde iş akışı adımları numaralıdır; tamamlanan adım yeşil ✓ ile, sıradaki adım vurguyla gösterilir. Her sayfada “Adım X / 14” etiketi, tek cümlelik açıklama ve **“Nasıl kullanılır?”** paneli (numaralı adımlar + ipucu; sayfaya ilk girişte açık gelir, sonra hatırlanır) bulunur. Sayfa altındaki ← önceki / sonraki → düğmeleriyle adımlar arasında gezilir. Belge bilgileri ve gelişmiş dağıtım ayarları katlanır; telefonda menü yatay kayar.
* **Derslikler ve binalar** (isteğe bağlı) — binalar, derslikler (normal, laboratuvar, spor salonu, bilişim, atölye…), şube derslikleri (“her şubeye sınıf dersliği oluştur”), bina geçiş süreleri (çift bazında, “aynı gün olmaz” seçeneği), ders–derslik türü önerileri.
* **Sosyal kulüpler** (isteğe bağlı) — 40 örnek kulüp + kendi kulübünüz; danışman öğretmen, katılan şubeler (düzey ya da tek tek), haftalık saat, sabit saat ya da otomatik, mekân.
* **Dağıtım kuralları** — tek merkez: motor (CP-SAT/hızlı, süre, işlemci), K01–K16 ayarları, esnetme izinleri, tercih öncelikleri, ders ayarları (derslik türü, dil, etiketler, 1+1), etiket kuralları. Öğretmen tercihleri Kısıtlar → “Tercihler” (tercih günleri, ilk/son ders, en fazla boşluk, kesin gün sınırı, etiketler); ortak öğretmen sağ tık → “Öğretmeni değiştir…”; paralel seçmeli grubu Seçmeli sayfasındaki ∥ düğmesi.
* **Dağıtım** — Otomatik dağıt, CP-SAT ilerlemesi ve Durdur, sonuç bandı (OPTIMAL / FEASIBLE / INFEASIBLE / UNKNOWN), **Dağıtım raporu** (özet, aşamalar, ön denetim, kural ihlalleri, kalite analizi ve puanı), Dağıtımı kontrol et, Excel (.xls: şube/öğretmen çarşafları ve programları, ihlaller, kalite), şube ve öğretmen çarşafı.

1. **Okul ve okul türü** — tür, gün sayısı, günlük ders saati, ders/teneffüs/öğle arası saatleri.
2. **Sınıflar ve şubeler** — hızlı oluşturma (her düzey için şube sayısı, harf/rakam adlandırma, ayraç), şube adlarını tek tek değiştirme, şube ekleme/silme (onaylı), haftalık saat doluluk durumu.

**Dersler**
3. **Sınıflara ders atama** — MEB zorunlu/ortak/meslek/alan dersleri hazır atanır. Ders × şube tablosunda saat düzeltme, dersi düzeyden kaldırma ve geri alma, okula özel ders ekleme (düzeyin tüm şubelerine ya da tek şubeye) ve silme; şube şube listede ders bazında blok düzeni.
4. **Seçmeli ders atama** — sınıf düzeyi sekmeleri (tamamlanan düzey ✓). Solda **seçmeli havuzu** (arama, grup süzgeci, her ders için haftalık saat, kaç şubenin aldığı); sağda **şube kartları** (seçmeliler, saat seçimi, × ile kaldırma, saat doluluğu, “Öner”, şubenin diğer dersleri). Akış: havuzdan dersleri, sağdan şubeleri işaretle → yapışkan seçim çubuğunda **Seçilenleri ata / kaldır**. Tüm şubeler seçiliyse düzey listesine, değilse şubeye özel listeye yazılır. **Manuel seçmeli ekle**: MEB havuzunda olmayan okula özel seçmeli (ad, grup, saat, sınıf düzeyleri) havuza eklenir; silinince atandığı listelerden de çıkar.
5. **Blok düzeni** — her ders için kalıp seçimi (2 / 1+1, 2+2 / 2+1+1 …). Birden çok kalıp seçilirse **VEYA kuralı**: önce 1. kalıp denenir, sığmazsa sıradaki.

**Öğretmenler**
6. **Öğretmen listesi** — tek tek ve toplu ekleme, satır içi düzenleme (ad, branş, üst sınır, kulüp), çoklu seçimle **toplu branş/üst sınır/kulüp değiştirme, toplu atama kaldırma ve toplu silme** (onaylı).
7. **Öğretmen atama** — özet kutuları (atanan/atanmamış saat, üst sınırı aşan, branş dışı atama). *Öğretmen bazında*: aranabilir/branşa göre süzülebilir öğretmen listesi ve yük çubukları, öğretmen profili (ek branş ekleme, yük, istatistik), atanan dersler (öğretmeni değiştir, kaldır), ders atama havuzu: branşına uygun / tüm atanmamışlar / **tüm dersler (başka öğretmenden alma)**, arama, çoklu seçim ve seçilenin yüke etkisi — **branş dışı atama** serbesttir ve turuncu etiketle işaretlenir. *Sınıf bazında*: şube × ders matrisi ve düzeye toplu atama. *Öğretmen × şube çizelgesi*: tüm öğretmenlerin tüm dersleri tek tabloda. *Sınıf ders listeleri*: tüm şubelerin tüm dersleri ve öğretmenleri tek ekranda. *Atanmamış*: branşa göre gruplu hızlı atama.
8. **Kısıtlar ve kilitler** — öğretmen açık/kapalı gün ve saatleri, günlük en fazla ders, haftada en fazla gün; sınıf kapalı saatleri; öğretmen ve sınıf ders kilitleme. Kilitleme dağıtımdan önce de yapılabilir: **saate sağ tıklayın → dersi ve blok uzunluğunu (1–4 sa) seçin**. Uymayan uzunluklar soluk görünür, nedeni üzerine gelince yazar. Kilitli hücrede sağ tık: kilidi kaldır, öğretmeni değiştir, atama sayfasına git.

**Program**
9. **Dağıtım** — şube/öğretmen programı, çarşaf, yükler. **Elle düzenleme** üç kipte:
   * *Taşı / yer değiştir*: derse tıklayıp seçin; uygun boş saatler yeşil kesikli, yer değiştirebileceği dersler yeşil çerçeveli görünür (soluk olanlar çakışma yaratır, nedeni üzerine gelince yazar). Şube/öğretmen çakışması, kapalı saat, günlük sınır, gün sonu ve “aynı gün tek blok” kuralı denetlenir. “Taşınan dersi yerine kilitle” açıksa ders yeni yerine kilitlenir. Seçili blok **programdan çıkarılabilir**; yerleşemeyen dersler **elle yerleştirilebilir**.
   * *Kilitle*: derse tıklayınca bulunduğu yere kilitlenir/kilidi kalkar; **boş saate tıklayınca o saate hangi dersin kilitleneceği seçilir** (uygun olmayan blokların nedeni gösterilir). Bu pencere taşı kipinde seçim yokken de açılır.
   * *Görüntüle*: yalnız bakış.
   * **Sağ tık menüsü** (şube programı, öğretmen programı, çarşaf):
     * *Derste:* bu saate kilitle / kilidi kaldır, taşı, programdan çıkar, **bu saate başka ders kilitle** (şubenin aynı uzunluktaki dersleri; seçilen ders buraya kilitlenir, buradaki ders onun yerine geçer; kilitli dersler yerinden itilmez), **öğretmeni değiştir…**, öğretmen atama sayfasına git, atamayı kaldır, şubenin ders/öğretmen listesine git, şube/öğretmen programını aç.
     * *Boş saatte:* o şubenin ya da öğretmenin dersleri listelenir; seçilen ders buraya taşınıp kilitlenir. Doğrudan konamıyorsa şubedeki dersle yer değiştirerek yerleştirme önerilir. Uygun olmayanların nedeni menüde yazar.
   * **Öğretmeni değiştir penceresi:** branşa uygun öğretmenler önce gelir (isteğe bağlı olarak branş dışındakiler de listelenir). Pencerede arama, yük çubuğu (mevcut → değişince) ve programdaki durum (“programda uygun” / “N blok çakışıyor”) görünür. Uygun öğretmene geçişte program yerinde güncellenir. Çakışma varsa onay alınır ve yeniden dağıtım gerekir.
   Düzenlemeden sonra boşluk/eksik/kilit istatistikleri yeniden hesaplanır. **Kayıtlı dağıtımlar**: yeni kayıt olarak kaydetme, **aç / düzenle**, **üzerine kaydet**, satır içinde yeniden adlandırma, silme (onaylı); açık kayıt ve kaydedilmemiş değişiklikler bantta görünür. Kayıtlar projeyle birlikte üyenin hesabına yazılır.
10. **Resmî çıktılar** — onaylı A4 öğretmen programı (tebliğ) ve şube programları; yerleşim sütunu gerçekleşen blok düzenini gösterir.
11. **Nöbet programı** — öğretmenlerin **görevi** (öğretmen / müdür / müdür başyardımcısı / müdür yardımcısı) Öğretmen listesinde seçilir; müdür ve yardımcıları öğretmen nöbetine girmez, müdür yardımcılarına **idari nöbet** dağıtılır (günlük kişi sayısı, dönemler arası döndürme, elle düzenleme; çıktı ayrı sayfa ya da öğretmen nöbet çizelgesiyle aynı sayfada; tebliğde “İdari Nöbet Günü”). Öğretmen nöbetinde: nöbet yerleri (ve günlük kişi sayısı), dönemler, dağıtım kuralı: *dengeli*, *dersinin en az olduğu gün*, *dersinin en çok olduğu gün*; dersi olmayan güne nöbet vermeme; dönemler arasında gün ve yer döndürme; hücreye tıklayarak gün/yer değiştirme; günlük doluluk özeti; A4 çıktı.

**Sistem**
12. **Kaynaklar** — okul türlerine göre ayrım, seçili türün çizelgesi, MEB TTKB çizelge listesi (PHP sürümünde canlı çekme), seçmeli havuzları, kaynakça ve branş eşlemesi.
13. **Veri ve yedek** — otomatik kayıt durumu, **JSON indir / yükle** (dosyadan ya da metinden), panoya kopyalama, hesaptaki projeler (aç/sil), sıfırlama.

**Haftalık ders saati sınırı:** bir şubenin haftalık toplamı MEB çizelgesindeki toplamı aşamaz. Ders saati artırma, ders ekleme, kaldırılan dersi geri alma ve seçmeli ekleme/saat değiştirme bu sınırla denetlenir; aşacaksa işlem yapılmaz ya da izin verilen en yüksek değere çekilir ve uyarı gösterilir.

Her değişiklik otomatik kaydedilir (1,5 sn içinde üyenin evrakplus.com hesabına); üst çubukta kayıt durumu görünür. Silme ve veri kaybettiren tüm işlemler onay penceresinden geçer. Şubelerin haftalık ders saati MEB toplamından az/fazla ya da açık saatlere sığmıyorsa ilgili sayfalarda **doldurma uyarısı** gösterilir.

## Dağıtım motorları

Üç motor aynı girdiyi (`motorGirdisi()`, sürüm 2) ve aynı merkezi kuralları (**Dağıtım kuralları** sayfası, `durum.kurallar`) kullanır. Hangi motor çalışırsa çalışsın sonuç, bağımsız kural denetiminden (`kuralDenetle`, Python’da `solver/denetim.py: dogrula`) geçmeden **“başarılı” sayılmaz**.

### CP-SAT (OR-Tools) — `solver/` (önerilen, sunucuda)

* **Model:** dersler haftalık saatlerine göre **oturumlara** (bloklara) ayrılır; `x[oturum, gün, başlangıç]` Boolean karar değişkenidir ve yalnız geçerli (açık, uygun, kilitle uyumlu) başlangıçlar için oluşturulur. Her oturum `add_exactly_one` ile tam bir kez yerleşir; öğretmen, şube ve derslik için zaman dilimi kullanımı `add_at_most_one` (tür gerektiren derslerde gerçek oda seçimi ve oda bazında `add_at_most_one`). Kilitli dersler alan kısıtlamasıyla modele baştan girer.
* **Zorunlu kurallar K01–K16:** öğretmen (ortak öğretmenler dahil) ve şube çakışması; paralel seçmeli grupları (alt gruplar aynı saatte); haftalık saat; günlük üst sınır (varsayılan 2; yoğun derslerde otomatik artmaz, yalnız açık esnetme izniyle +1); kesintisiz 3 saat yasağı; varsayılan bloklar (3→2+1, 4→2+2, 5→2+2+1, 6→2+2+2), bloklar farklı günlerde; İngilizce/Yabancı Dil ayrı günlerde (ders kimliğiyle); kapalı saatler; günlük/haftalık sınırlar; derslik türü ve çakışması; bina geçiş süresi; kilitler; sosyal kulüpler (sabit ya da otomatik saat); etiket kuralları.
* **Tercihler:** şube boşluğu, izinli en fazla boşluk, haftada en fazla gün isteği, öğretmen boşluğu, zor ders yığılması, tercih edilen günler, bina değişimi, az gün, günlük denge, ilk/son ders, nöbet günü uyumu, önceki dağıtımı koruma. Her biri Yüksek/Orta/Düşük/Kapalı; **ardışık (leksikografik) optimizasyon**: önce yüksek öncelikliler en iyiye getirilir ve o değer kısıt olarak sabitlenir, sonra orta, sonra düşük. Her seviyede önceki çözüm başlangıç önerisi (hint) olarak verilir.
* **Dört aşama:** 1) tam kurallar, 2) alternatif blok (VEYA kalıpları, bölünebilir 1+1), 3) tercih esnetme (kesin işaretli gün sınırı yumuşar, yalnız geçerli çözüm), 4) yalnız kullanıcının izin verdiği sınırlar (günlük +1, blok yapısı, aynı gün blok). Çakışma, haftalık saat, kapalı saat ve kilitler **hiçbir aşamada** esnetilmez. Her aşamada korunan/esnetilen kurallar raporlanır.
* **Ön denetim** (çözümden önce, kesin gerekli koşullar): gün yeterliliği (ör. 6 saatlik ders için 3 uygun gün), öğretmen kapasitesi, kilit çakışmaları ve kilit–kural çelişkileri, derslik kapasitesi, şube açık saatleri, kulüp saatleri.
* **Durumlar:** `OPTIMAL` (en iyi olduğu kanıtlandı), `FEASIBLE` (geçerli, en iyisi kanıtlanmadı), `INFEASIBLE` (çözüm olmadığı kanıtlandı), `UNKNOWN` (süre içinde kesinleşmedi). Çözüm yoksa: **varsayım literalleriyle çelişki çekirdeği** (birlikte sağlanamayan kurallar, çözücü kanıtı) + zorunlu kuralları çiğnemeden en çok saati yerleştiren **taslak** + yerleşmeyen dersler için olası nedenler. Kanıtlanmamış nedenler “olası” diye belirtilir.
* **Performans:** Süre ve işlemci sınırı ayarlanır; model boyutu raporlanır. Değiştirilen gerçek derslik atama modeli için 100+ öğretmenli performans testi yeniden yapılmalıdır; önceki ölçüm bu yeni model için geçerli kabul edilmemelidir.
* **Çalıştırma:** PHP `index.php?action=dagit-baslat` çözücüyü **arka plan sürecinde** başlatır (`python3 -m solver.cli`), arayüz `dagit-durum` ile ilerlemeyi sorgular (donmaz), `dagit-iptal` durdurur. Komut satırı: `python3 -m solver.cli --girdi girdi.json --cikti sonuc.json --sure 60 --isci 8`.

### Hızlı motor — `assets/scheduler.js` (tarayıcı)

Açgözlü yerleştirme → tabu destekli çıkarma zinciri → yerel iyileştirme. K01–K11, K14 ve sabit saatli kulüpleri uygular; yoğun derslerde aynı gün bitişik olmayan bloklar. Derslik türü, bina geçişi, ortak öğretmen, paralel grup, otomatik kulüp ve etiket kurallarını **uygulayamaz**: bunlar kullanılıyorsa sonuç “başarılı” sayılmaz ve CP-SAT önerilir. (`src/Scheduler.php` PHP sezgisel motoru API uyumluluğu için duruyor.)

## evrakplus.com (WordPress) sürümü

Program `public_html/ders-dagitim/` klasöründe, evrakplus.com'un WordPress üyeliğiyle çalışır. Adım adım kurulum: **CPANEL-KURULUM.txt**.

* **Tek giriş kapısı `index.php` (WordPress köprüsü):** `wp-load.php`'yi yükler, `is_user_logged_in()` ile oturumu denetler. Giriş yapmayan ziyaretçi `https://www.evrakplus.com/giris/` adresine (302) gönderilir; API istekleri 401 döner ve arayüz aynı sayfaya yönlendirir. Ayrı kullanıcı adı/şifre yoktur. Ayarlar `index.php`'nin en üstündedir (giriş adresi, rol sınırı, `dd_erisim_izni` süzgeci).
* **Veri üyenin hesabında:** `wp_usermeta`, anahtar `ders_dagitim_data` (JSON). İçinde üyenin projeleri, her projenin sürüm numarası (`rev`) ve en son açılan proje (`acikId`) vardır; 256 KB'tan büyük projeler sıkıştırılır. Başka cihazdan girildiğinde en son açılan proje yüklenir. Eşzamanlı kayıtlar MySQL `GET_LOCK` ile sıraya girer.
* **İki cihaz:** her kayıt `rev`'i artırır; eski sürümden gelen kayıt 409 ile reddedilir ve arayüz “Hesaptakini aç / Bu ekrandakini kaydet” sorar. Sekmeye/uygulamaya dönüldüğünde güncel sürüm kendiliğinden gelir. İçeriği değişmeyen kayıt gönderilmez.
* **Çevrimdışı:** program açıkken bağlantı koparsa değişiklik cihazda (üyeye özel `localStorage` anahtarı) bekler, bağlantı gelince gönderilir.
* **Güvenlik:** POST istekleri `application/json` + `X-DD-Nonce` (WordPress nonce) ister; süresi dolan nonce kendiliğinden yenilenir. Üyeler yalnız kendi projelerine ve kendi CP-SAT işlerine erişir. `src/ inc/ storage/ data/ solver/ templates/`, `config.php` ve yardımcı dosyalar 403 döner. Sayfa önbelleği eklentileri için `DONOTCACHEPAGE` ve no-cache başlıkları gönderilir.
* **Mobil uygulama kabuğu (≤860 px):** alt gezinti çubuğu, adımlar çekmecesi, alttan açılan hesap/proje menüsü, alttan açılan pencereler, çentik (safe-area) payları; her adım bir geçmiş kaydıdır (`#adım`), geri tuşu önce açık pencereyi kapatır. Manifest kısayolları `./#dagitim` gibi adreslerle doğrudan adıma gider.
* **PWA:** `manifest.webmanifest`, `sw.js`, `offline.html`, `assets/ikon/`. Manifestte ekran görüntüleri (`assets/ekran/`) ve kısayollar var. Program sayfası ve API önbelleğe alınmaz (oturum her açılışta denetlenir), yalnız `assets/` önbellekten açılır. “Uygulamayı yükle” düğmesi; iPhone'da “Ana Ekrana Ekle” yönergesi.
* **Sunucu denetimi:** `index.php?sayfa=kurulum` (yalnız site yöneticileri; üst çubukta “Sunucu”).
* **CP-SAT sınırları** (`config.php`): aynı anda en fazla 2 iş, üye başına 1 iş, en çok 300 sn, 1 işlemci.

## API (`index.php?action=…`)

| İstek | Açıklama |
|---|---|
| `GET nonce` | Yeni güvenlik anahtarı |
| `GET turler` / `GET tur&id=…` | Okul türleri, çizelgeler, havuzlar |
| `GET listele` | Üyenin projeleri |
| `GET yukle&id=…` | Proje durumu (son açılan olarak işaretlenir) |
| `GET surum&id=…` | Projenin hesaptaki sürümü |
| `POST kaydet` | `{id?, rev?, zorla?, ad, turId, durum}` → `{id, rev}`; çakışmada 409 |
| `POST sil` | `{id}` |
| `POST dagit` | `{girdi}` → PHP sezgisel motoru |
| `GET motorlar` | CP-SAT kullanılabilir mi |
| `POST dagit-baslat` / `GET dagit-durum&is=…` / `POST dagit-iptal` | CP-SAT arka plan işi |
| `GET meb-liste` | TTKB'deki güncel çizelge listesi |

## Bilinen sınırlar / sonraki adımlar

* Seçmeli havuzlarındaki varsayılan saatler, çizelgedeki seçeneklerden (ör. “(1)(2)”) en yaygın olanıdır; okul kendi seçimine göre değiştirebilir.
* Güzel Sanatlar Lisesinin Müzik/Türk Müziği/Tiyatro alanları ile Özel Program/Tematik program çizelgeleri henüz veri dosyasına eklenmedi; aynı biçimle `data/cizelgeler.json`'a eklenebilir.
* Mesleki ve Teknik Anadolu Liseleri (alan/dal çizelgeleri) bu TTKB kategorisinde yer almaz.
* Paralel (alt grup) seçmeliler şu an şube içindedir; farklı şubelerin öğrencilerinin karıştığı çatal (birleşik) gruplar henüz yok.
* Hızlı motor tarayıcının ana iş parçacığında çalışır; çok büyük okullarda birkaç saniye bekletebilir (CP-SAT sunucuda ayrı süreçte çalışır).
* JSON yedek dosyası `{"uygulama":"ders-dagitim","surum":2,"durum":{...}}` biçimindedir; eski sürüm kayıtları açılırken otomatik güncellenir.
* Bir MEB çizelgesi güncellendiğinde: “TTKB'den güncel listeyi çek” ile yeni kaydı görün, PDF'teki saatleri `data/cizelgeler.json`'a işleyin ve `node tests/motor_test.js` ile toplamları doğrulayın.

### Otomatik üçlü motor (20 Kasım 2026)

Yeni motor seçimi: **Otomatik (CP-SAT → Genetik → Hızlı)**, CP-SAT, Genetik, Hızlı.
Genetik motor `assets/genetik.js` içinde kromozom/çaprazlama/mutasyon/elitizm kullanır;
`assets/genetik-worker.js` ayrı iş parçacığında çalışır. Mevcut Hızlı motoru,
kromozomun tanımladığı öncelik/gün/saat/kalıp stratejisini programa dönüştürmekte
kullanır. Doğrulanmamış sonuç başarılı ilan edilmez. Gelişmiş K01-K16 özelliklerini
Genetik ve Hızlı motor desteklemiyorsa güvenli geçiş yapılmaz. Ayrıntılar:
`GENETIK-MOTOR-NOTLARI.txt`.

Testler: `node tests/test_genetik.js`, `node tests/test_motor_auto.js`,
`python3 -m unittest discover -s tests -v`.


## Güncelleme: Etkin dağıtımı sıfırla + iki saatlik derslerin görünümü (20.11.2026)

- **Dağıtım → Dağıtımı sıfırla**: Yalnızca açık dağıtım sonucu ve yerleşim kilitlerini onay alarak siler. Şubeler, öğretmenler, ders saatleri/atamaları, kısıtlar, nöbetler, motor ayarları ve kayıtlı dağıtım sürümleri **korunur**. Kayıtlı sürüm sonradan yeniden açılabilir. Tam proje sıfırlama işleminden farklıdır.
- **Ders blokları**: Şube ve öğretmen haftalık programlarında iki saatlik bloklar gerçek iki ders sütununu (`colspan="2"`) kapsar; ders adı/öğretmen blok ortasında, her saat alt şeritte kendi sütununda görünür (örn. **2. saat | 3. saat**). Ders taşıma/kilitlenme eylemi blok bütünlüğünü korur.
- **Motorlar**: Otomatik (CP-SAT → Genetik → Hızlı), CP-SAT, Genetik ve Hızlı seçenekleri korunur.
- **Ek testler**: `node tests/test_program_sifirlama.js` (mevcut dağıtımı ve kilitleri temizlerken derslerin, öğretmenlerin ve kayıtlı dağıtımların korunduğunu doğrular).
- PWA önbellek sürümü artırılmış, `program-araclari.js` yükleme listesine eklenmiştir.

**Kurulum:** Önce mevcut `public_html/ders-dagitim` klasörünüzü yedekleyin. ZIP içindeki aynı adlı klasörü mevcut klasörle birleştirin. `config.php` içindeki kuruma özel ayarlarınızı yedekten kontrol edin. Veritabanını ve kullanıcı kayıtlarını silmeyin. Tarayıcıda Ctrl+F5 ile yenileyin.

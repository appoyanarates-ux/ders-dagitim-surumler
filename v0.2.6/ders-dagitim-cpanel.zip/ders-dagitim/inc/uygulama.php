<?php
declare(strict_types=1);

/** Program sayfası: şablon + çizelge verisi + üyenin kaldığı proje */
defined('DD_KOPRU') || exit;

(function (): void {
    $kok = dirname(__DIR__);
    $u = wp_get_current_user();

    // ?proje=ID ile açılırsa o proje; yoksa üyenin en son çalıştığı proje (başka cihazdan girince kaldığı yerden devam)
    $p = null;
    if (isset($_GET['proje']) && ctype_digit((string)$_GET['proje'])) {
        $p = dd_depo()->getir((int)$_GET['proje']);
        if ($p) dd_depo()->acikIsaretle((int)$p['id']);
    }
    $p = $p ?: dd_depo()->sonAcik();
    $baslangic = $p ? ['id' => $p['id'], 'rev' => $p['rev'], 'guncelleme' => $p['guncelleme'], 'durum' => $p['durum']] : null;

    $json = fn($x) => json_encode($x, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_THROW_ON_ERROR);
    $surum = fn(string $dosya) => 'assets/' . $dosya . '?v=' . filemtime($kok . '/assets/' . $dosya);
    $e = fn($x) => htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8');

    $config = [
        'mod' => 'sunucu',
        'api' => 'index.php',
        'baslangicDurumu' => $baslangic,
        'giris' => true,
        'wp' => true,
        'nonce' => wp_create_nonce('dd_api'),
        'kullanici' => ['id' => (int)$u->ID, 'ad' => $u->display_name ?: $u->user_login],
        'yonetici' => current_user_can('manage_options'),
        // tarayıcıdaki geçici kopya üyeye özel: aynı tarayıcıyı kullanan iki üyenin verisi karışmaz
        'yerelAnahtar' => 'ders-dagitim-durum-v1-' . substr(md5(home_url() . '|' . $u->ID), 0, 12),
        'girisUrl' => dd_giris_url(),
        'cikisUrl' => html_entity_decode(wp_logout_url(DD_CIKIS_DONUS), ENT_QUOTES, 'UTF-8'),
        'anaSayfa' => DD_ANA_SAYFA,
        'kurulumUrl' => 'index.php?sayfa=kurulum',
    ];

    $scriptler = '';
    foreach (['model.js', 'scheduler.js', 'motor-secim.js', 'genetik.js', 'program-araclari.js', 'app.js', 'pwa.js'] as $d) {
        $scriptler .= '<script src="' . $e($surum($d)) . '"></script>' . "\n";
    }
    $basEk = implode("\n", [
        '<meta name="robots" content="noindex, nofollow">',
        '<meta name="theme-color" content="#1e3a5f">',
        '<link rel="manifest" href="manifest.webmanifest">',
        '<meta name="mobile-web-app-capable" content="yes">',
        '<meta name="apple-mobile-web-app-capable" content="yes">',
        '<meta name="apple-mobile-web-app-status-bar-style" content="default">',
        '<meta name="apple-mobile-web-app-title" content="' . $e(DD_KISA_AD) . '">',
        '<link rel="apple-touch-icon" href="assets/ikon/apple-touch-icon.png">',
        '<link rel="icon" type="image/png" sizes="32x32" href="assets/ikon/favicon-32.png">',
    ]);

    // Duyuru bandı: e-posta adresleri mailto bağlantısı olur
    $duyuru = '';
    if (trim(DD_DUYURU) !== '') {
        $metin = preg_replace_callback('/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/', fn($m) =>
            '<a href="mailto:' . $m[0] . '?subject=' . rawurlencode(DD_KISA_AD . ' geri bildirim') . '">' . $m[0] . '</a>', $e(DD_DUYURU));
        $duyuru = '<div class="duyuru-bant" role="note"><span class="duyuru-rozet">TEST</span><span>' . $metin . '</span></div>';
    }

    header('Content-Type: text/html; charset=utf-8');
    echo strtr((string)file_get_contents($kok . '/templates/app.html'), [
        '{{BASLIK}}' => $e(DD_PROGRAM_ADI),
        '{{BAS_EK}}' => $basEk,
        '{{STIL}}' => '<link rel="stylesheet" href="' . $e($surum('app.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v2.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v2-stage2.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v2-stage3.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v2-stage4.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v2-stage5.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v2-menu4-studio.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v2-menu4-v3.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v2-menu4-simple.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v2-menu5-8-local-tabs.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v3-stage1.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v3-stage2.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v3-stage3.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v3-stage4.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v3-stage5.css')) . '">' . "\n" . '<link rel="stylesheet" href="' . $e($surum('design-v3-stage6.css')) . '">',
        '{{MOD_ETIKET}}' => 'EvrakPlus',
        '{{DUYURU}}' => $duyuru,
        '{{VERI}}' => "<script>\nwindow.CIZELGE_VERISI = " . $json(dd_cizelge_deposu()->tumu()) . ";\nwindow.APP_CONFIG = " . $json($config) . ";\n</script>",
        '{{SCRIPTLER}}' => $scriptler,
    ]);
})();

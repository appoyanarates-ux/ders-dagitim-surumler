<?php
declare(strict_types=1);

/**
 * Sunucu kurulum denetimi — index.php?sayfa=kurulum (yalnız WordPress yöneticileri).
 * PHP, eklentiler, WordPress bağlantısı, üye verisi yazma, yazma izinleri, dosya koruması,
 * Python / OR-Tools ve arka plan CP-SAT işi denetlenir; eksikler için ne yapılacağı yazılır.
 */
defined('DD_KOPRU') || exit;

use DersDagitim\CpSatIsleri;

$kok = dirname(__DIR__);
$satirlar = [];
$ekle = function (string $ad, string $durum, string $deger, string $cozum = '') use (&$satirlar) {
    $satirlar[] = compact('ad', 'durum', 'deger', 'cozum');
};

// PHP
$ekle('PHP sürümü', 'iyi', PHP_VERSION . ' (' . PHP_SAPI . ')');
foreach ([
    ['mbstring', true, 'Türkçe karakter işlemleri'],
    ['zlib', false, 'büyük projeleri sıkıştırarak saklamak (isteğe bağlı)'],
    ['json', true, 'JSON'],
    ['curl', false, 'TTKB’den güncel çizelge listesini çekmek (isteğe bağlı)'],
] as [$ek, $zorunlu, $aciklama]) {
    $var = extension_loaded($ek);
    $ekle("Eklenti: $ek", $var ? 'iyi' : ($zorunlu ? 'kotu' : 'uyari'), $var ? 'yüklü' : 'yok — ' . $aciklama,
        $var ? '' : 'cPanel → “Select PHP Version” → Extensions sekmesinde “' . $ek . '” kutusunu işaretleyin.');
}

// Yazma izinleri
foreach (['storage', 'storage/isler'] as $k) {
    $yol = "$kok/$k";
    if (!is_dir($yol)) @mkdir($yol, 0775, true);
    $ok = is_dir($yol) && is_writable($yol);
    $ekle("Yazma izni: $k/", $ok ? 'iyi' : 'kotu', $ok ? 'yazılabilir' : 'yazılamıyor', $ok ? '' : 'Dosya Yöneticisi’nde klasöre sağ tıklayın → “Change Permissions” → 755 yapın.');
}

// WordPress ve üye verisi
global $wp_version;
$ekle('WordPress', 'iyi', 'bağlı · sürüm ' . $wp_version . ' · ' . home_url('/'));
$ekle('Giriş sayfası', 'iyi', 'giriş yapmayanlar şuraya yönlendirilir: ' . dd_giris_url());
try {
    $uid = get_current_user_id();
    $deneme = DD_PROGRAM_KODU . '_deneme';
    $metin = '{"a":"\\u00e7 \\"tırnak\\"","t":' . time() . '}';
    update_user_meta($uid, $deneme, wp_slash($metin));
    $geri = get_user_meta($uid, $deneme, true);
    delete_user_meta($uid, $deneme);
    $ok = $geri === $metin;
    $l = dd_depo()->listele();
    $ekle('Üye verisi (wp_usermeta)', $ok ? 'iyi' : 'kotu', ($ok ? 'yazma/okuma çalışıyor' : 'yazılan veri bozuk okundu') . ' · anahtar: ' . DD_PROGRAM_KODU . '_data · sizin projeleriniz: ' . count($l),
        $ok ? '' : 'Bir eklenti kullanıcı meta verisini değiştiriyor olabilir.');
    global $wpdb;
    $uyeSayisi = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s", DD_PROGRAM_KODU . '_data'));
    $paket = (int)$wpdb->get_var('SELECT @@max_allowed_packet');
    $ekle('Programı kullanan üye', 'iyi', $uyeSayisi . ' üye' . ($paket ? ' · MySQL max_allowed_packet: ' . round($paket / 1048576, 1) . ' MB' : ''));
    if ($paket && $paket < 4 * 1048576) $ekle('MySQL paket sınırı', 'uyari', 'büyük okullarda kayıt başarısız olabilir', 'Barındırma firmanızdan max_allowed_packet değerini en az 16 MB yapmasını isteyin.');
} catch (Throwable $e) {
    $ekle('Üye verisi (wp_usermeta)', 'kotu', $e->getMessage());
}

// Dışarıdan erişim koruması (storage/ ve config.php erişilememeli)
$sema = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$taban = dd_program_url();
if (function_exists('curl_init')) {
    foreach (['storage/isler/', 'config.php', 'src/UyeDeposu.php', 'inc/api.php', 'data/cizelgeler.json'] as $hedef) {
        $c = curl_init($taban . $hedef);
        curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_NOBODY => false, CURLOPT_TIMEOUT => 5, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => 0]);
        $govde = (string)curl_exec($c);
        $kod = (int)curl_getinfo($c, CURLINFO_HTTP_CODE);
        curl_close($c);
        $korunuyor = $kod === 403 || $kod === 404 || ($kod === 200 && str_ends_with($hedef, '.php') && trim($govde) === '');
        if ($kod === 0) $ekle("Koruma: $hedef", 'uyari', 'denetlenemedi (sunucu kendine bağlanamadı)', 'Tarayıcıda ' . $taban . $hedef . ' adresini açın; “403 Forbidden” görmelisiniz.');
        else $ekle("Koruma: $hedef", $korunuyor ? 'iyi' : 'kotu', "HTTP $kod" . ($korunuyor ? ' — dışarıdan erişilemiyor' : ' — DIŞARIDAN ERİŞİLEBİLİYOR'),
            $korunuyor ? '' : 'Klasördeki .htaccess dosyası yüklenmemiş olabilir (gizli dosyalar). Zip’i cPanel Dosya Yöneticisi’nde “Extract” ile açın; “Settings → Show Hidden Files” işaretli olsun.');
    }
} else {
    $ekle('Koruma', 'uyari', 'curl yok; otomatik denetlenemedi', 'Tarayıcıda ' . $taban . 'storage/ adresini açın; “403 Forbidden” görmelisiniz.');
}
$ekle('HTTPS', $sema === 'https' ? 'iyi' : 'uyari', $sema === 'https' ? 'açık' : 'kapalı — oturum çerezi ağda açık gider', $sema === 'https' ? '' : 'cPanel → “SSL/TLS Status” ile ücretsiz AutoSSL sertifikası alın ve siteyi https:// ile açın.');

// CP-SAT
$c = !empty(dd_ayar()['cpsat']['etkin']) ? dd_cpsat()->hazirMi(!empty($_GET['tazele'])) : ['hazir' => false, 'neden' => 'config.php içinde kapalı'];
$ekle('Komut çalıştırma (exec)', CpSatIsleri::komutAcik() ? 'iyi' : 'uyari', CpSatIsleri::komutAcik() ? 'açık' : 'kapalı — CP-SAT çalışmaz, hızlı motor kullanılır',
    CpSatIsleri::komutAcik() ? '' : 'Barındırma firmanızdan exec/shell_exec/popen fonksiyonlarının açılmasını isteyin ya da VPS kullanın.');
if ($c['hazir'] ?? false) {
    $ekle('CP-SAT (Python + OR-Tools)', 'iyi', 'hazır · ' . $c['python'] . ' · OR-Tools ' . trim((string)$c['surum']));
} else {
    $ekle('CP-SAT (Python + OR-Tools)', 'uyari', (string)($c['neden'] ?? 'kullanılamıyor') . ' — program tarayıcıdaki hızlı motorla çalışır.',
        'cPanel → “Setup Python App” → “Create Application”: Python 3.9+ seçin, Application root: <b>ders-dagitim-python</b>, URL boş kalabilir → Create. ' .
        'Ardından sayfanın üstündeki “source …/activate” komutunu kopyalayıp cPanel → “Terminal”de çalıştırın ve <code>pip install ortools</code> yazın. ' .
        'Bitince bu sayfayı “Yeniden denetle” ile yenileyin; Python kendiliğinden bulunur.');
}
$denenen = $c['denenen'] ?? [];
$e = fn($x) => htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8');
$izinli = fn($x) => strip_tags((string)$x, '<b><code>');
$css = 'assets/app.css?v=' . filemtime($kok . '/assets/app.css');
$kotu = count(array_filter($satirlar, fn($s) => $s['durum'] === 'kotu'));
header('Content-Type: text/html; charset=utf-8');
?><!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Sunucu kurulum denetimi · Ders Dağıtım Programı</title>
<link rel="stylesheet" href="<?= $e($css) ?>">
<style>
  main.kd { max-width: 1000px; margin: 0 auto; padding: 28px 20px 60px; }
  .kd td.d { width: 34px; text-align: center; font-size: 16px; }
  .kd tr.r-kotu td { background: var(--err-soft); }
  .kd tr.r-uyari td { background: var(--warn-soft); }
  .kd td:nth-child(2) { width: 240px; }
  .kd td small { display: block; color: var(--ink-3); margin-top: 3px; line-height: 1.45; }
  .kd .ust-satir { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin: 14px 0 18px; }
  #deneme-sonuc { margin-top: 10px; }
</style>
</head>
<body>
<main class="kd">
  <h2 style="margin:0">Sunucu kurulum denetimi</h2>
  <p class="ince">Bu sayfa programın bu sunucuda doğru çalışması için gerekenleri denetler. Kırmızı satırlar düzeltilmelidir; sarılar isteğe bağlıdır.</p>
  <div class="ust-satir">
    <a class="btn ana" href="./"><?= $kotu ? 'Yine de programa geç' : 'Programa geç' ?> →</a>
    <a class="btn" href="index.php?sayfa=kurulum&amp;tazele=1">Yeniden denetle</a>
    <span class="etiket <?= $kotu ? 'kirmizi' : 'yesil' ?>"><?= $kotu ? $kotu . ' sorun var' : 'Zorunlu gereksinimler tamam' ?></span>
  </div>
  <div class="kart"><table class="tablo">
    <?php foreach ($satirlar as $s): ?>
      <tr class="r-<?= $e($s['durum']) ?>"><td class="d"><?= $s['durum'] === 'iyi' ? '✅' : ($s['durum'] === 'kotu' ? '❌' : '⚠️') ?></td>
        <td><b><?= $e($s['ad']) ?></b></td><td><?= $e($s['deger']) ?><?php if ($s['cozum']): ?><small><?= $izinli($s['cozum']) ?></small><?php endif; ?></td></tr>
    <?php endforeach; ?>
  </table></div>
  <?php if ($denenen): ?>
    <details class="kart"><summary><b>Denenen Python yolları</b></summary><table class="tablo sik" style="margin-top:10px">
      <?php foreach ($denenen as $d): ?><tr><td><code><?= $e($d['python']) ?></code></td><td><?= $e($d['sonuc']) ?></td></tr><?php endforeach; ?>
    </table><p class="ince">Python başka bir yerdeyse config.php → <code>cpsat.python</code> değerine tam yolunu yazın.</p></details>
  <?php endif; ?>
  <?php if ($c['hazir'] ?? false): ?>
    <div class="kart"><h3>CP-SAT deneme çözümü</h3><p class="ince">Sunucunun arka planda çözücü çalıştırmasına izin verip vermediğini küçük bir örnekle dener (≈10 sn).</p>
      <button class="btn" id="deneme">Denemeyi başlat</button><div id="deneme-sonuc" class="ince"></div></div>
    <script>
    (function () {
      var b = document.getElementById('deneme'), out = document.getElementById('deneme-sonuc');
      var NONCE = <?= json_encode(wp_create_nonce('dd_api')) ?>;
      function api(e, g) {
        return fetch('index.php?action=' + e, g ? { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-DD-Nonce': NONCE }, body: JSON.stringify(g) } : { credentials: 'same-origin' })
          .then(function (r) { return r.json(); });
      }
      b.onclick = function () {
        b.disabled = true; out.textContent = 'Başlatılıyor…';
        var ders = [], sube = [{ id: 's1', ad: '5-A' }, { id: 's2', ad: '5-B' }], ogr = [{ id: 't1', ad: 'Öğretmen 1' }, { id: 't2', ad: 'Öğretmen 2' }];
        sube.forEach(function (s) { [['Türkçe', 6, 't1'], ['Matematik', 5, 't2'], ['Fen', 4, 't1'], ['Sosyal', 3, 't2']].forEach(function (x) { ders.push({ id: s.id + '|' + x[0], ad: x[0], subeId: s.id, ogretmenler: [x[2]], saat: x[1] }); }); });
        api('dagit-baslat', { girdi: { gunSayisi: 5, gunlukSaat: 7, subeler: sube, ogretmenler: ogr, dersler: ders, cozucu: { sureSn: 8, isci: 1 } } }).then(function (j) {
          if (j.hata) { out.innerHTML = '❌ ' + j.hata; b.disabled = false; return; }
          var bas = Date.now();
          (function sor() {
            api('dagit-durum&is=' + j.is).then(function (d) {
              if (d.durum === 'bitti') { out.innerHTML = '✅ CP-SAT çalışıyor: ' + d.sonuc.cozucu.durum + ' · ' + (d.sonuc.istatistik.sureMs / 1000).toFixed(1) + ' sn · ' + d.sonuc.yerlesim.length + ' blok yerleşti.'; b.disabled = false; return; }
              if (d.durum === 'hata') { out.innerHTML = '❌ ' + (d.mesaj || 'hata') + '<br>Barındırma firmanız arka plan süreçlerine izin vermiyor olabilir; program hızlı motorla çalışmaya devam eder.'; b.disabled = false; return; }
              out.textContent = (d.mesaj || 'Çalışıyor') + ' · ' + Math.round((Date.now() - bas) / 1000) + ' sn';
              if (Date.now() - bas > 60000) { out.textContent = '⚠️ 60 sn içinde bitmedi; sunucu süreçleri yavaş ya da kısıtlı.'; b.disabled = false; return; }
              setTimeout(sor, 1000);
            });
          })();
        });
      };
    })();
    </script>
  <?php endif; ?>
</main>
</body>
</html>

<?php
declare(strict_types=1);

/**
 * JSON API — index.php?action=…  (yalnız giriş yapmış üye; index.php denetler)
 *
 *   GET  nonce                 Yeni güvenlik anahtarı (uzun açık kalan sekmeler için)
 *   GET  turler                Okul türleri, ders çizelgeleri, seçmeli havuzları
 *   GET  tur&id=…              Tek okul türü + sınıf bazında ders saatleri
 *   GET  listele               Üyenin projeleri
 *   GET  yukle&id=…            Proje durumu (son açılan olarak işaretlenir)
 *   GET  surum&id=…            Projenin sunucudaki sürümü (başka cihazda değişti mi?)
 *   POST kaydet                {id?, rev?, zorla?, ad, turId, durum}
 *   POST sil                   {id}
 *   POST dagit                 {girdi}  PHP sezgisel motoru
 *   GET  motorlar              CP-SAT kullanılabilir mi?
 *   POST dagit-baslat          {girdi}  CP-SAT arka plan işi → {is}
 *   GET  dagit-durum&is=…      İlerleme / sonuç
 *   POST dagit-iptal           {is}
 *   GET  meb-liste             TTKB'deki güncel çizelge listesi
 *
 * Bütün POST istekleri application/json olmalı ve X-DD-Nonce başlığı taşımalı (CSRF koruması).
 */
defined('DD_KOPRU') || exit;

use DersDagitim\CizelgeDeposu;
use DersDagitim\Scheduler;

header('Content-Type: application/json; charset=utf-8');

function dd_yanit(array $veri, int $kod = 200): never
{
    http_response_code($kod);
    echo json_encode($veri, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function dd_govde(): array
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') dd_yanit(['hata' => 'POST gerekli'], 405);
    if (stripos((string)($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json') !== 0) dd_yanit(['hata' => 'İçerik türü application/json olmalı'], 415);
    $nonce = (string)($_SERVER['HTTP_X_DD_NONCE'] ?? '');
    if (!wp_verify_nonce($nonce, 'dd_api')) dd_yanit(['hata' => 'Güvenlik anahtarının süresi doldu', 'nonce' => true], 403);
    $ham = file_get_contents('php://input', false, null, 0, 8 * 1024 * 1024 + 1);
    if ($ham === false || strlen($ham) > 8 * 1024 * 1024) dd_yanit(['hata' => 'İstek çok büyük'], 413);
    $j = json_decode($ham, true);
    if (!is_array($j)) dd_yanit(['hata' => 'Geçersiz JSON'], 400);
    return $j;
}

$eylem = (string)$_GET['action'];
$uye = get_current_user_id();

try {
    switch ($eylem) {
        case 'nonce':
            dd_yanit(['nonce' => wp_create_nonce('dd_api')]);

        case 'turler':
            dd_yanit(dd_cizelge_deposu()->tumu());

        case 'tur':
            $t = dd_cizelge_deposu()->tur((string)($_GET['id'] ?? ''));
            if (!$t) dd_yanit(['hata' => 'Okul türü bulunamadı'], 404);
            dd_yanit(['tur' => $t, 'sinifDersleri' => dd_cizelge_deposu()->sinifDersleri($t['id'])]);

        case 'listele':
            dd_yanit(['projeler' => dd_depo()->listele()]);

        case 'yukle':
            $id = (int)($_GET['id'] ?? 0);
            $p = dd_depo()->getir($id);
            if (!$p) dd_yanit(['hata' => 'Proje bulunamadı'], 404);
            dd_depo()->acikIsaretle($id);
            dd_yanit($p);

        case 'surum':
            $s = dd_depo()->surum((int)($_GET['id'] ?? 0));
            dd_yanit($s ?? ['yok' => true]);

        case 'kaydet':
            $g = dd_govde();
            $durum = $g['durum'] ?? null;
            $turId = (string)($g['turId'] ?? '');
            if (!is_array($durum) || !isset($durum['okul'])) dd_yanit(['hata' => 'durum eksik'], 422);
            if (!dd_cizelge_deposu()->tur($turId)) dd_yanit(['hata' => 'Bilinmeyen okul türü'], 422);
            $ad = mb_substr(trim(wp_strip_all_tags((string)($g['ad'] ?? 'Adsız okul'))), 0, 200) ?: 'Adsız okul';
            $s = dd_depo()->kaydet(
                isset($g['id']) && $g['id'] !== null ? (int)$g['id'] : null,
                $ad,
                $turId,
                $durum,
                isset($g['rev']) && $g['rev'] !== null ? (int)$g['rev'] : null,
                !empty($g['zorla'])
            );
            if (!empty($s['cakisma'])) dd_yanit(['hata' => 'Bu proje başka bir cihazda değiştirilmiş.'] + $s, 409);
            dd_yanit($s);

        case 'sil':
            $g = dd_govde();
            dd_yanit(['silindi' => dd_depo()->sil((int)($g['id'] ?? 0))]);

        case 'dagit':
            $g = dd_govde();
            $girdi = $g['girdi'] ?? null;
            if (!is_array($girdi)) dd_yanit(['hata' => 'girdi eksik'], 422);
            $hatalar = Scheduler::dogrula($girdi);
            if ($hatalar) dd_yanit(['hata' => implode('; ', $hatalar)], 422);
            $a = dd_ayar()['dagitim'];
            @set_time_limit((int)ceil($a['sure_limit_ms'] / 1000) + 20);
            $motor = new Scheduler((int)$a['max_iterasyon'], (int)$a['sure_limit_ms']);
            dd_yanit(['sonuc' => $motor->dagit($girdi)]);

        case 'motorlar':
            $c = dd_ayar()['cpsat'] ?? ['etkin' => false];
            $tazele = !empty($_GET['tazele']) && current_user_can('manage_options');
            $h = !empty($c['etkin']) ? dd_cpsat()->hazirMi($tazele) : ['hazir' => false, 'neden' => 'config.php içinde kapalı'];
            unset($h['denenen']);
            if (!current_user_can('manage_options')) unset($h['python']);   // sunucu yolları yalnız yöneticiye
            dd_yanit(['cpsat' => $h + ['varsayilanSure' => min((int)($c['varsayilan_sure_sn'] ?? 60), (int)($c['azami_sure_sn'] ?? 300)), 'azamiSure' => (int)($c['azami_sure_sn'] ?? 300)], 'php' => true]);

        case 'dagit-baslat':
            $g = dd_govde();
            $girdi = $g['girdi'] ?? null;
            if (!is_array($girdi) || !isset($girdi['dersler'])) dd_yanit(['hata' => 'girdi eksik'], 422);
            if (empty(dd_ayar()['cpsat']['etkin']) || !(dd_cpsat()->hazirMi()['hazir'] ?? false)) dd_yanit(['hata' => 'CP-SAT bu sunucuda kullanılamıyor; Hızlı motoru seçin.'], 503);
            try {
                dd_yanit(['is' => dd_cpsat()->baslat($girdi, $uye)]);
            } catch (RuntimeException $e) {
                dd_yanit(['hata' => $e->getMessage()], 429);
            }

        case 'dagit-durum':
            dd_yanit(dd_cpsat()->durum((string)($_GET['is'] ?? ''), $uye));

        case 'dagit-iptal':
            $g = dd_govde();
            dd_yanit(['iptal' => dd_cpsat()->iptal((string)($g['is'] ?? ''), $uye)]);

        case 'meb-liste':
            try {
                dd_yanit(CizelgeDeposu::mebListesiCek(dd_ayar()['meb']));
            } catch (RuntimeException $e) {
                dd_yanit(['hata' => $e->getMessage()], 502);
            }

        default:
            dd_yanit(['hata' => 'Bilinmeyen işlem: ' . $eylem], 400);
    }
} catch (Throwable $e) {
    error_log('[ders-dagitim] ' . $e);
    dd_yanit(['hata' => $e->getMessage()], 500);
}

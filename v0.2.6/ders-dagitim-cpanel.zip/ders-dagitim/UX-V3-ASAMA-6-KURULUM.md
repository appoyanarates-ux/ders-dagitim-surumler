# EvrakPlus Ders Dağıtım — Tasarım 3.0 / Aşama 6

## Kapsam

- 12. Menü — Dağıtım sayfasında **Şube Programı, Öğretmen Programı, Şube Çarşafı, Öğretmen Çarşafı** için ortak hücre işlem paneli.
- Boş, dolu, kilitli veya kapalı hücrelere **sol tık, sağ tık veya klavyeyle Enter** üzerinden erişim.
- Bir ders bloğu taşıma için seçildiğinde önceden var olan hedef hücre tıklaması korunur.
- Ders yerleştirme/ön kilit, programdan çıkarma, öğretmen değiştirme, blok kalıbı düzenleme, kilit aç/kapat, gün/saat kapatma işlemleri için mevcut iş mantığı yeniden kullanılır. Geçersiz işlemler mevcut doğrulayıcı tarafından reddedilir.
- Yanlışlıkla silinmeleri azaltmak için **programdan çıkarma** ile **haftalık ders listesinden kaldırma** ayrı isimlerle gösterilir.
- İki saatlik blokların iki ders sütununu birden kapsayan kart görünümü korunur.
- Mobilde alt panel, masaüstünde sağ işlem paneli; Esc/kapat düğmesi desteği; klavyeyle seçilebilir hücreler.
- Bağımsız etkileşimli HTML laboratuvarı: `tasarim-lab.html` (örnek verilerle; gerçek veri/dağıtım motoru kullanılmaz).

## Kurulum

1. Mevcut `ders-dagitim` klasörünü ve verilerini yedekleyin.
2. ZIP içindeki `ders-dagitim` altındaki güncelleme dosyalarını mevcut kurulumun üzerine yükleyin.
3. Sunucudaki `data` ve `storage` klasörlerini **silmeden** koruyun. Bu pakette okul kayıt verisi (`data/cizelgeler.json`) yer almaz.
4. Tarayıcıyı yenileyin. Eski PWA önbelleğini kullanıyorsa yeniden yükleyin.
5. 12. Menüden dört çizelgeyi deneyin; bir boş hücreye tıklayın, iki saatlik ön kilit koyun, kilidi kaldırın ve saat kapatmayı sınayın.

## İşlevsel ayrım

**Programdan çıkar:** Yalnız yerleşimi boşa alır, haftalık ders tanımı korunur. Bu seçenek dağıtım sonrası kullanılır.

**Haftalık ders listesinden kaldır:** Şubenin ders tanımını siler/0 saat olarak işaretler; diğer atamaları etkileyebileceği için onay ister.

**Blok düzenini değiştir:** Dersin haftalık 2+2/2+1 vb. oturum kalıbını değiştirir; dağıtımın yeniden hesaplanması gerekebilir.

## Test özeti

- Eski JavaScript testleri ve 13 bağımsız Python kural testi geçti.
- Dört görünümde ortak hücre paneli masaüstünde tarayıcıdan test edildi.
- 390 piksel mobil ekranda çarşaf paneli açma, taşma ve JavaScript hata kontrolü başarılı.
- Demo HTML üzerinde dört görünüm, şube/öğretmen hücre işlemleri ve mobil taşma testi yapıldı.
- **Gerçek OR-Tools CP-SAT çözümü, canlı cPanel kurulumu ve tam gerçek okul verisi testi henüz doğrulanmadı.**

# EVRAKPLUS DERS DAĞITIM – TASARIM 3.0 / AŞAMA 5

## Tamamlanan geliştirmeler

1. **Aşama 1 – Tasarım temeli ve HTML laboratuvarı:** Menü numaraları ve bağımsız önizleme.
2. **Aşama 2 – Menü 4:** Şube odaklı zorunlu ve seçmeli ders ekleme, düzenleme ve kaldırma.
3. **Aşama 3 – Menü 5:** Zorunlu ve seçmeli derslerin tek listesi; önerilen veya özel blok kalıpları.
4. **Aşama 4 – Menü 8:** Atanmamış derslerden başlayan birleşik öğretmen atama ekranı.
5. **Aşama 5 – Menü 9 ve 11:** Haftalık uygunluk takvimi, ön kilit sekmesi, temel/gelişmiş/motor kuralları.

## Menü 9 – Kısıtlar ve kilitler

Öğretmenler ve Şubeler iki sekme üzerinden açılır. Bir kişi/şube seçilince pazartesiden okulun açık son gününe kadar ders saatleri **aynı sayfada** listelenir. Açık hücreye tıklanınca kapanır, kapalı hücreye tıklanınca açılır. Gün başlığıyla tüm gün açılır veya kapanır. Dersin ön kilidi veya yerleşimi olan saat kapatılamaz. Öğretmenlere özel günlük ders ve haftalık gün üst sınırları korunmuştur. Ön kilitler sekmesinde eski ders kilitleme altyapısına erişilir. İleri düzey toplu kısıt araçları açılır bölümde tutulmuştur.

## Menü 11 – Dağıtım kuralları

- **Temel kurallar:** K01–K16 zorunlu kural tablosu ve günlük sınırlar.
- **Gelişmiş kurallar:** Yalnız izin verilen esnetmeler, tercih öncelikleri, ders türleri/etiketler ve etiket kuralları.
- **Dağıtım motoru:** Otomatik, OR-Tools CP-SAT (sunucu uygunsa), Genetik ve Hızlı seçenekleri, süre ve işlemci sınırları.

Sekmeler arası geçiş başka menüye yönlendirmez; mevcut kural değerlerini değiştirmez. Ayar değiştiğinde mevcut proje veri modeli üzerinden kaydedilir.

## Kullanım ve kurulum

cPanel güncelleme ZIP'i **mevcut kurulumun üzerine** uygulanır; tek başına yeni WordPress kurulumu değildir. İlk önce mevcut `ders-dagitim` klasörünü ve kullanıcı kayıtlarını yedekleyin. Sunucudaki `data/cizelgeler.json`, `data` ve `storage` klasörlerini silmeyin. Bu ZIP okul kayıtları ve MEB çizelge verilerini içermez. Kurulumdan sonra sayfayı Ctrl+F5 ile yenileyin; PWA kullanıyorsanız uygulamayı yeniden açın.

Bağımsız HTML laboratuvarı örnek veriyle çalışır; gerçek okul verilerini değiştirmez ve OR-Tools motorunu çalıştırmaz.

## Testler ve sınırlamalar

- 16 JavaScript test dosyası başarılı.
- 13 Python kural testi başarılı, 2 gerçek OR-Tools testi kurulum olmadığı için atlandı.
- Bağımsız HTML laboratuvarı masaüstü ve 390 piksel mobil tarayıcıda test edildi.
- Gerçek uygulamanın masaüstü testinde şube bazlı kapanma ve yerel kural sekmeleri doğrulandı.
- Gerçek uygulamanın mobil uçtan uca tarayıcı testi bu ortamda zaman aşımına uğradı.
- Canlı cPanel kurulumu ve sunucuda Python CP-SAT çözümünün çalışması doğrulanmadı.

## Sonraki aşamalar

6. **Menü 12 – Dört çizelge:** Şube/öğretmen programları ve çarşaflarda hücre üzerinden ders ekleme, kaldırma, öğretmen değiştirme, blok düzenleme, sağ tık ve dokunmatik menüler.
7. **Son kalite aşaması:** Diğer menülerin uyumu, mobil, baskı/PDF, gerçek veri testleri, büyük okul performansı ve canlı dağıtım kabul testleri.

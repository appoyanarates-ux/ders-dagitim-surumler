<?php
declare(strict_types=1);

/**
 * Program çekirdeği. WordPress yüklendikten sonra index.php tarafından çağrılır.
 * WordPress eklentileriyle ad çakışması olmasın diye bütün genel işlevler dd_ önekiyle başlar.
 */
spl_autoload_register(function (string $sinif): void {
    $onek = 'DersDagitim\\';
    if (strncmp($sinif, $onek, strlen($onek)) !== 0) return;
    $dosya = __DIR__ . '/src/' . str_replace('\\', '/', substr($sinif, strlen($onek))) . '.php';
    if (is_file($dosya)) require $dosya;
});

$GLOBALS['DD_AYAR'] = require __DIR__ . '/config.php';
mb_internal_encoding('UTF-8');
// WordPress saat dilimini UTC'de tutar; değiştirmek WordPress tarih işlevlerini bozar. Tarihler wp_date() ile yazılır.

function dd_ayar(): array
{
    return $GLOBALS['DD_AYAR'];
}

function dd_cizelge_deposu(): \DersDagitim\CizelgeDeposu
{
    static $d = null;
    return $d ??= new \DersDagitim\CizelgeDeposu(__DIR__ . '/data/cizelgeler.json');
}

function dd_cpsat(): \DersDagitim\CpSatIsleri
{
    static $c = null;
    return $c ??= new \DersDagitim\CpSatIsleri(dd_ayar()['cpsat'], __DIR__);
}

/** Güvenlik başlıkları (çerçeveye gömme, MIME koklama, yönlendiren bilgisi) */
function dd_guvenlik_basliklari(): void
{
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
}

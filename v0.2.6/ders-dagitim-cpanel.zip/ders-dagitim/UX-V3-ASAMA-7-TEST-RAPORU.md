# EvrakPlus Ders Dağıtım — Tasarım 3.0 / Aşama 7

**Tarih:** 21 Kasım 2026

## Genel durum

Aşama 6 paketi temel alınarak son kontrol ve sonuç doğrulama geliştirmeleri yapıldı. Eski işlevler ve üç motor korundu.

## Kodda yapılan iyileştirmeler

- `sonucGuvenliMi` ile eksik/eskimiş/doğrulanmamış sonuçlar ana sayfa ve menü durumunda **başarılı** gösterilmez.
- Dağıtım çalışma merkezinde doğrulanmayan sonuç için uyarı gösterilir.
- Resmî çıktı ekranı doğrulanmayan çizelgeleri **TASLAK** olarak etiketler.
- PWA önbellek sürümü güncellendi.
- JS testleri kullanıcı okul verisi yerine `tests/fixtures/` altındaki izole test referansını kullanır.
- Yeni bağımsız performans ve kural doğrulama testleri eklendi.

## Sentetik motor performans testleri

| Öğretmen | Şube | Ders | Motor | Süre | Yerleşen/Toplam saat | Bağımsız sorun |
|---:|---:|---:|---|---:|---:|---:|
| 10 | 5 | 30 | Hızlı | 10 ms | 120/120 | 0 |
| 10 | 5 | 30 | Genetik | 31 ms | 120/120 | 0 |
| 40 | 18 | 108 | Hızlı | 8 ms | 432/432 | 0 |
| 40 | 18 | 108 | Genetik | 26 ms | 432/432 | 0 |
| 100 | 45 | 270 | Hızlı | 13 ms | 1080/1080 | 0 |
| 100 | 45 | 270 | Genetik | 76 ms | 1080/1080 | 0 |
| 150 | 68 | 408 | Hızlı | 13 ms | 1632/1632 | 0 |
| 150 | 68 | 408 | Genetik | 80 ms | 1632/1632 | 0 |

Bunlar sınırlı ve nispeten kolay **sentetik** senaryolardır; gerçek okul şartları için başarı ve hız garantisi değildir.

## Kısıt doğrulama

- Bağımsız kontroller: öğretmen/şube çakışması; haftalık saat; günlük tekrar; kapalı gün/saat; iki saatlik bloklar; ön kilitler.
- Otomatik motor politikası: CP-SAT kesin `INFEASIBLE` ise güvenli olmayan geçiş yapılmaz; desteklenmeyen gelişmiş kurallarda Hızlı/Genetik devre dışı kalır.
- OR-Tools kurulu olmadığı için **CP-SAT gerçek çözüm testi çalıştırılamadı**.

## Görsel/kullanılabilirlik

- 18 menünün masaüstü temel açılış kontrolü yapıldı.
- Dört çizelgede hücre paneli masaüstü testinde açıldı.
- Bağımsız HTML laboratuvarı örnek veriyle açılır; canlı kullanıcı verisiyle bağlantılı değildir.
- Mobil uzun uçtan uca otomasyon zaman aşımı nedeniyle **tamamlanamadı**.

## Yayına alma öncesi tamamlanması gerekenler

1. Canlı cPanel ortamında WordPress oturumu, kayıt, yedek/geri yükleme, PHP işlem izinleri, `exec` desteği ve CP-SAT kurulumu.
2. OR-Tools kurulu sunucuda 2 CP-SAT testi + 10/40/100/150 öğretmenli gerçek veri tabanlı stres testleri.
3. Zor kısıtlı gerçek okul senaryolarında otomatik motor geçişi ve eksik saat/kural ihlali raporu.
4. A4 resmî çıktı, Excel/CSV içe/dışa aktarma ve yazdırma sonuçlarını gerçek verilerle kontrol.
5. Mobil 18 menü uçtan uca kabul testi ve kullanıcı onayı.

## Kurulum

1. Mevcut uygulamayı ve okul verilerini yedekle.
2. `ders-dagitim` klasöründeki dosyaları mevcut kuruluma aktar. `data` ve `storage` klasörlerini silme.
3. `data/cizelgeler.json` güncelleme paketinde yoktur; önceki kurulumda mevcut olmalıdır.
4. PWA önbelleğini yenile ve WordPress oturumuyla giriş yap.
5. CP-SAT kurulumu ve gerçek dağıtımı canlı ortamda test et.

**Durum:** Sentetik ve kod testleri başarılı; canlı yayına çıkmaya hazır olduğunu kanıtlayan bütün testler henüz tamamlanmadı.

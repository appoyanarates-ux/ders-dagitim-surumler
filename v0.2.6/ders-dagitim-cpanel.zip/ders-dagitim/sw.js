/*
 * Haftalık Ders Dağıtım Programı — service worker (PWA)
 * - Program sayfası (index.php) her zaman ağdan gelir: WordPress oturumu her açılışta denetlenir,
 *   üyeye özel veri önbelleğe yazılmaz. Bağlantı yoksa offline.html gösterilir.
 * - API istekleri (index.php?action=…) hiç önbelleğe alınmaz.
 * - assets/ altındaki sürüm numaralı dosyalar (css, js, ikon) önbellekten hızlı açılır.
 * Yeni sürüm yüklerken SURUM değerini artırın.
 */
// Önceki önbellek: v11-tasarim-2-asama-4
var SURUM = 'v19-ux-v3-kalite-kontrol';
var ONBELLEK = 'ders-dagitim-' + SURUM;
var TEMEL = ['offline.html', 'manifest.webmanifest', 'assets/ikon/ikon-192.png', 'assets/ikon/ikon-512.png', 'assets/ikon/favicon-32.png'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(ONBELLEK).then(function (c) { return c.addAll(TEMEL); }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (adlar) {
    return Promise.all(adlar.filter(function (a) { return a.indexOf('ders-dagitim-') === 0 && a !== ONBELLEK; }).map(function (a) { return caches.delete(a); }));
  }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  var istek = e.request;
  if (istek.method !== 'GET') return;
  var url = new URL(istek.url);
  if (url.origin !== self.location.origin) return;
  var kapsam = new URL(self.registration.scope);
  if (url.pathname.indexOf(kapsam.pathname) !== 0) return;     // WordPress'in diğer sayfalarına karışma
  if (url.searchParams.has('action') || url.searchParams.has('sayfa')) return;   // API ve yönetici sayfaları: yalnız ağ

  // Sayfa açılışı: ağdan (oturum denetimi); bağlantı yoksa çevrimdışı sayfası
  if (istek.mode === 'navigate') {
    e.respondWith(fetch(istek).catch(function () {
      return caches.match('offline.html', { ignoreSearch: true }).then(function (r) { return r || new Response('Bağlantı yok', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } }); });
    }));
    return;
  }

  // Statik dosyalar: önce önbellek, yoksa ağ (ve önbelleğe yaz)
  if (url.pathname.indexOf(kapsam.pathname + 'assets/') === 0 || TEMEL.some(function (t) { return url.pathname === kapsam.pathname + t; })) {
    e.respondWith(caches.open(ONBELLEK).then(function (c) {
      return c.match(istek).then(function (r) {
        if (r) return r;
        return fetch(istek).then(function (yanit) {
          if (yanit.ok && yanit.type === 'basic' && !yanit.redirected) c.put(istek, yanit.clone());
          return yanit;
        });
      });
    }));
  }
});

/*
 * Veri modeli yardımcıları: şube derslerinin çıkarılması, branş eşleme,
 * otomatik öğretmen ataması, önerilen seçmeliler, saat etiketleri.
 * Hem tarayıcıda (window.Model) hem Node'da (module.exports) çalışır.
 */
(function (root) {
  'use strict';

  var HARFLER = 'ABCDEFGHIJKLMNOPRSTUVYZ'.split('');

  function turBul(veri, turId) {
    for (var i = 0; i < veri.okulTurleri.length; i++) if (veri.okulTurleri[i].id === turId) return veri.okulTurleri[i];
    return null;
  }

  function bransBul(dersAd, branslar) {
    if (dersAd === 'Seçmeli Ders') return null;
    for (var b in branslar) if (branslar[b].indexOf(dersAd) >= 0) return b;
    return dersAd; // bilinmeyen ders: dersin kendi adı branş sayılır
  }

  /** Şubelerin haftalık ders listesini (ders x şube) üretir. */
  function dersleriOlustur(durum, veri) {
    var tur = turBul(veri, durum.okul.turId);
    if (!tur) return [];
    var liste = [];
    var degisiklik = durum.saatDegisiklik || {};
    durum.subeler.forEach(function (s) {
      var si = tur.siniflar.indexOf(s.sinif);
      if (si < 0) return;
      var adlar = {};
      tur.dersler.forEach(function (r) {
        var id = s.id + '|' + r[0];
        adlar[r[0]] = true;
        var saat = degisiklik[id] != null ? +degisiklik[id] : r[2][si];
        if (saat > 0) liste.push({ id: id, subeId: s.id, ders: r[0], grup: r[1], saat: saat, mebSaat: r[2][si] });
      });
      // Okulun eklediği dersler (düzeye ya da şubeye)
      (durum.ekDersler || []).forEach(function (e) {
        if (adlar[e.ad]) return;
        if (e.subeId ? e.subeId !== s.id : e.sinif !== s.sinif) return;
        var id = s.id + '|' + e.ad;
        var saat = degisiklik[id] != null ? +degisiklik[id] : +e.saat;
        if (saat > 0) liste.push({ id: id, subeId: s.id, ders: e.ad, grup: e.grup || 'Ek', saat: saat, mebSaat: 0, ekId: e.id });
      });
      var gerekli = tur.secmeliSaat[si] || 0;
      var secilen = subeSecmelileri(durum, s);
      var kullanilan = 0;
      secilen.forEach(function (x) {
        var saat = Math.min(x.saat, Math.max(0, gerekli - kullanilan));
        if (saat <= 0) return;
        kullanilan += saat;
        var id = s.id + '|S:' + x.ad;
        liste.push({ id: id, subeId: s.id, ders: x.ad, grup: 'Seçmeli', saat: saat });
      });
      if (gerekli - kullanilan > 0) {
        liste.push({ id: s.id + '|Seçmeli Ders', subeId: s.id, ders: 'Seçmeli Ders', grup: 'Seçmeli', saat: gerekli - kullanilan });
      }
    });
    var yer = durum.yerlesimler || {}, kural = durum.blokKurallari || {};
    var D = +(durum.okul.gunSayisi || 5), mod = (durum.ayarlar && durum.ayarlar.blok) || 'ikili';
    var subeSinif = {};
    durum.subeler.forEach(function (s) { subeSinif[s.id] = s.sinif; });
    liste.forEach(function (d) {
      d.ogretmenId = durum.atamalar[d.id] || null;
      // Öncelik: dersin kendi ayarı > sınıf düzeyi blok kuralı > otomatik. "2+2|2+1+1" = VEYA kuralı
      var kaynak = yer[d.id] || kural[subeSinif[d.subeId] + '|' + d.ders] || null;
      var secenekler = yerlesimListesiCoz(kaynak, d.saat, D);
      d.yerlesimSecenekleri = secenekler.length ? secenekler : null;
      d.yerlesim = secenekler[0] || null;
      d.yerlesimKaynak = yer[d.id] ? 'ders' : (kural[subeSinif[d.subeId] + '|' + d.ders] ? 'duzey' : 'oto');
      d.yerlesimMetni = secenekler.length ? secenekler.map(function (k) { return k.join('+'); }).join(' veya ') : varsayilanYerlesim(d.saat, D, mod).join('+');
    });
    return liste;
  }

  /** "2+2+1" metnini doğrular; geçersizse null */
  function yerlesimCoz(metin, saat, gunSayisi) {
    if (!metin) return null;
    var p = String(metin).split('+').map(function (x) { return parseInt(x, 10); });
    if (p.some(function (x) { return !(x > 0); })) return null;
    if (p.reduce(function (a, b) { return a + b; }, 0) !== saat || p.length > gunSayisi) return null;
    return p;
  }
  /** "2+2|2+1+1" ya da ["2+2","2+1+1"] -> geçerli kalıplar listesi (sıra = tercih sırası) */
  function yerlesimListesiCoz(kaynak, saat, gunSayisi) {
    if (!kaynak) return [];
    var parcalar = Array.isArray(kaynak) ? kaynak : String(kaynak).split('|');
    var out = [], gorulen = {};
    parcalar.forEach(function (m) {
      var k = yerlesimCoz(m, saat, gunSayisi);
      if (k && !gorulen[k.join('+')]) { gorulen[k.join('+')] = true; out.push(k); }
    });
    return out;
  }
  function varsayilanYerlesim(saat, gunSayisi, mod) {
    var boy = Math.max(mod === 'tekli' ? 1 : 2, Math.ceil(saat / gunSayisi)), out = [];
    while (saat > 0) { out.push(Math.min(boy, saat)); saat -= boy; }
    return out;
  }
  /** Bir saat için önerilen kalıplar (seçim kutusu) */
  function yerlesimSecenekleri(saat, gunSayisi) {
    var sonuc = [];
    function uret(kalan, max, yol) {
      if (sonuc.length > 12) return;
      if (kalan === 0) { if (yol.length <= gunSayisi) sonuc.push(yol.join('+')); return; }
      for (var b = Math.min(max, kalan, 4); b >= 1; b--) uret(kalan - b, b, yol.concat(b));
    }
    uret(saat, saat, []);
    return sonuc;
  }

  /** Şubenin seçmelileri: şubeye özel liste varsa o, yoksa sınıf düzeyinin listesi */
  function subeSecmelileri(durum, s) {
    var ozel = durum.subeSecmeli && durum.subeSecmeli[s.id];
    return ozel || durum.secmeliler[s.sinif] || [];
  }

  /** Varsayılan şubeler: her sınıf düzeyi için n şube (5-A, 5-B ...) */
  function subeleriOlustur(tur, sayilar) {
    var subeler = [];
    tur.siniflar.forEach(function (sinif) {
      var n = sayilar && sayilar[sinif] != null ? sayilar[sinif] : 1;
      for (var i = 0; i < n; i++) {
        var etiket = sinif === 'Hz' ? 'Hz' : sinif;
        subeler.push({ id: 's' + sinif + HARFLER[i], sinif: sinif, ad: etiket + '-' + HARFLER[i] });
      }
    });
    return subeler;
  }

  /** Önerilen seçmeliler: her gruptan en az bir ders, kalan saat dolana kadar. */
  function onerilenSecmeliler(tur, veri, sinif) {
    var si = tur.siniflar.indexOf(sinif);
    var gerekli = tur.secmeliSaat[si] || 0;
    if (!gerekli) return [];
    var havuz = veri.havuzlar[tur.havuz];
    var varsayilan = tur.secmeliVarsayilanSaat || null;
    var uygun = havuz.dersler.filter(function (d) { return d[2].indexOf(sinif) >= 0; });
    // Okulun zorunlu derslerinde zaten olan dersleri seçmeli önerme
    var zorunluAdlar = tur.dersler.filter(function (r) { return r[2][si] > 0; }).map(function (r) { return r[0]; });
    uygun = uygun.filter(function (d) { return zorunluAdlar.indexOf(d[0]) < 0; });
    var secilen = [], kalan = gerekli;
    var gruplar = havuz.gruplar.slice();
    // 11-12. sınıflarda önce akademik çalışmalar
    var tur2 = 0;
    while (kalan > 0 && tur2 < 6) {
      gruplar.forEach(function (g) {
        if (kalan <= 0) return;
        var aday = uygun.filter(function (d) {
          return d[1] === g && !secilen.some(function (x) { return x.ad === d[0]; });
        });
        if (!aday.length) return;
        // Kalan saate en uygun olan
        aday.sort(function (a, b) {
          var sa = varsayilan || a[3], sb = varsayilan || b[3];
          return Math.abs(Math.min(sa, kalan) - sa) - Math.abs(Math.min(sb, kalan) - sb) || sb - sa;
        });
        var d = aday[0];
        var saat = Math.min(varsayilan || d[3], kalan);
        secilen.push({ ad: d[0], grup: d[1], saat: saat });
        kalan -= saat;
      });
      tur2++;
    }
    return secilen;
  }

  /**
   * Otomatik öğretmen ataması.
   * - Ataması olmayan dersleri branşlarına göre gruplar.
   * - Önce mevcut aynı branş öğretmenlerinin boş kapasitesini kullanır,
   *   yetmezse yeni öğretmen oluşturur (ör. "Matematik 2").
   * - Bir şubenin aynı branştaki dersleri mümkünse aynı öğretmene verilir.
   * - Rehberlik ve Yönlendirme dersi, şubeye en çok giren öğretmene (sınıf rehber öğretmeni) verilir.
   */
  /** Öğretmenin ana ya da ek branşı uyuyor mu */
  function bransUygun(o, brans) { return o.brans === brans || (o.ekBranslar || []).indexOf(brans) >= 0; }

  function otomatikAta(durum, veri, secenek) {
    secenek = secenek || {};
    var maxSaat = secenek.maxSaat || 30;
    var dersler = dersleriOlustur(durum, veri);
    var yuk = {};
    durum.ogretmenler.forEach(function (o) { yuk[o.id] = 0; });
    dersler.forEach(function (d) { if (d.ogretmenId && yuk[d.ogretmenId] != null) yuk[d.ogretmenId] += d.saat; });

    var sayac = 0;
    function yeniOgretmen(brans) {
      var ayni = durum.ogretmenler.filter(function (o) { return o.brans === brans; }).length;
      var id;
      do { sayac++; id = 'o' + Date.now().toString(36).slice(-4) + sayac; } while (yuk[id] != null);
      var o = { id: id, ad: brans + ' ' + (ayni + 1), brans: brans, maxSaat: maxSaat, kapali: [] };
      durum.ogretmenler.push(o);
      yuk[id] = 0;
      return o;
    }

    // Branş -> şube -> dersler
    var paket = {};
    dersler.forEach(function (d) {
      if (d.ogretmenId || d.grup === 'Rehberlik' || d.ders === 'Seçmeli Ders') return;
      var b = bransBul(d.ders, veri.branslar);
      paket[b] = paket[b] || {};
      paket[b][d.subeId] = paket[b][d.subeId] || [];
      paket[b][d.subeId].push(d);
    });
    Object.keys(paket).forEach(function (brans) {
      var gruplar = Object.keys(paket[brans]).map(function (sid) {
        var l = paket[brans][sid];
        return { dersler: l, saat: l.reduce(function (a, x) { return a + x.saat; }, 0) };
      });
      gruplar.sort(function (a, b) { return b.saat - a.saat; });
      gruplar.forEach(function (g) {
        var adaylar = durum.ogretmenler.filter(function (o) {
          return bransUygun(o, brans) && yuk[o.id] + g.saat <= (o.maxSaat || maxSaat);
        });
        adaylar.sort(function (a, b) { return yuk[a.id] - yuk[b.id]; });
        var o = adaylar[0] || yeniOgretmen(brans);
        if (yuk[o.id] + g.saat > (o.maxSaat || maxSaat) && g.dersler.length > 1) {
          // Paket sığmıyorsa dersleri tek tek dağıt
          g.dersler.forEach(function (d) {
            var a2 = durum.ogretmenler.filter(function (x) { return bransUygun(x, brans) && yuk[x.id] + d.saat <= (x.maxSaat || maxSaat); });
            a2.sort(function (a, b) { return yuk[a.id] - yuk[b.id]; });
            var oo = a2[0] || yeniOgretmen(brans);
            durum.atamalar[d.id] = oo.id; yuk[oo.id] += d.saat;
          });
          return;
        }
        g.dersler.forEach(function (d) { durum.atamalar[d.id] = o.id; yuk[o.id] += d.saat; });
      });
    });

    // Rehberlik: sınıf rehber öğretmeni
    dersler.forEach(function (d) {
      if (d.grup !== 'Rehberlik' || d.ogretmenId) return;
      var sayim = {};
      dersler.forEach(function (x) {
        var oid = durum.atamalar[x.id];
        if (x.subeId === d.subeId && oid) sayim[oid] = (sayim[oid] || 0) + x.saat;
      });
      function sigar(pay) {
        return Object.keys(sayim).filter(function (oid) {
          var o = durum.ogretmenler.find(function (x) { return x.id === oid; });
          return o && yuk[oid] + d.saat <= (o.maxSaat || maxSaat) + pay;
        });
      }
      var adaylar = sigar(0);
      if (!adaylar.length) adaylar = sigar(2);
      // aynı öğretmen birden fazla şubenin rehberi olmasın
      var rehberler = {};
      dersler.forEach(function (x) { if (x.grup === 'Rehberlik' && durum.atamalar[x.id]) rehberler[durum.atamalar[x.id]] = true; });
      var tercih = adaylar.filter(function (oid) { return !rehberler[oid]; });
      var liste = tercih.length ? tercih : adaylar;
      liste.sort(function (a, b) { return sayim[b] - sayim[a] || yuk[a] - yuk[b]; });
      if (liste[0]) { durum.atamalar[d.id] = liste[0]; yuk[liste[0]] += d.saat; }
    });
    return durum;
  }

  var KISA = {
    'Türkçe': 'TÜR', 'Matematik': 'MAT', 'Fen Bilimleri': 'FEN', 'Sosyal Bilgiler': 'SOS',
    'T.C. İnkılap Tarihi ve Atatürkçülük': 'İNK', 'Yabancı Dil': 'YAB', 'Birinci Yabancı Dil': 'YAB',
    'İkinci Yabancı Dil': 'YB2', 'Din Kültürü ve Ahlak Bilgisi': 'DİN', 'Görsel Sanatlar': 'GÖR',
    'Müzik': 'MÜZ', 'Beden Eğitimi ve Spor': 'BED', 'Teknoloji ve Tasarım': 'TTS',
    'Bilişim Teknolojileri ve Yazılım': 'BİL', 'Rehberlik ve Yönlendirme': 'REH',
    'Türk Dili ve Edebiyatı': 'EDB', 'Tarih': 'TAR', 'Coğrafya': 'COĞ', 'Fizik': 'FİZ', 'Kimya': 'KİM',
    'Biyoloji': 'BİY', 'Felsefe': 'FEL', 'Görsel Sanatlar/Müzik': 'G/M',
    'Beden Eğitimi ve Spor/Görsel Sanatlar/Müzik': 'B/G/M', 'Beden Eğitimi ve Spor/Müzik': 'B/M',
    'Sağlık Bilgisi ve Trafik Kültürü': 'SAĞ', "Kur'an-ı Kerim": 'KUR', 'Arapça': 'ARP',
    'Peygamberimizin Hayatı': 'PEY', 'Temel Dinî Bilgiler': 'TDB', 'Seçmeli Ders': 'SEÇ',
    'Hazırlık Sınıfı Türk Dili ve Edebiyatı': 'HEDB', 'Hazırlık Sınıfı Matematik': 'HMAT'
  };
  var BAGLAC = ['ve', 'ile', 'veya'];
  function kisaltma(ad) {
    if (KISA[ad]) return KISA[ad];
    var temiz = ad.replace(/^Seçmeli\s+/, 'S.').replace(/["“”.]/g, ' ');
    var kel = temiz.split(/[\s\/,-]+/).filter(function (k) { return k && BAGLAC.indexOf(k.toLocaleLowerCase('tr')) < 0; });
    if (kel.length === 1) return kel[0].slice(0, 3).toLocaleUpperCase('tr');
    return kel.slice(0, 4).map(function (k) { return k[0]; }).join('').toLocaleUpperCase('tr');
  }

  function renk(ad) {
    var h = 0;
    for (var i = 0; i < ad.length; i++) h = (h * 31 + ad.charCodeAt(i)) >>> 0;
    return h % 360;
  }

  /** Ders saat aralıkları: "08:30–09:10" */
  function saatEtiketleri(okul, n) {
    function dk(s) { var p = String(s || '08:30').split(':'); return (+p[0]) * 60 + (+p[1] || 0); }
    function yaz(m) { var h = Math.floor(m / 60) % 24, d = m % 60; return (h < 10 ? '0' : '') + h + ':' + (d < 10 ? '0' : '') + d; }
    var t = dk(okul.baslangic), sure = +okul.dersSure || 40, ten = +okul.teneffus || 10;
    var ogleSonra = +okul.ogleSonrasi || 0, ogle = +okul.ogleSure || 40;
    var out = [];
    for (var i = 0; i < n; i++) {
      out.push(yaz(t) + '–' + yaz(t + sure));
      t += sure + ((i + 1) === ogleSonra ? ogle : ten);
    }
    return out;
  }

  var GUNLER = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];

  var api = {
    turBul: turBul, bransBul: bransBul, dersleriOlustur: dersleriOlustur, subeleriOlustur: subeleriOlustur,
    onerilenSecmeliler: onerilenSecmeliler, otomatikAta: otomatikAta, kisaltma: kisaltma, renk: renk,
    saatEtiketleri: saatEtiketleri, GUNLER: GUNLER, HARFLER: HARFLER,
    subeSecmelileri: subeSecmelileri, yerlesimCoz: yerlesimCoz, yerlesimListesiCoz: yerlesimListesiCoz, varsayilanYerlesim: varsayilanYerlesim, yerlesimSecenekleri: yerlesimSecenekleri
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.Model = api;
})(typeof window !== 'undefined' ? window : this);

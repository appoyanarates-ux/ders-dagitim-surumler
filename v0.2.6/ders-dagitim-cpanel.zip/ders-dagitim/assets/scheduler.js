/*
 * Ders Dağıtım Motoru (JavaScript)
 * --------------------------------
 * PHP tarafındaki src/Scheduler.php ile aynı algoritmayı kullanır.
 * Girdi:
 *   {
 *     gunSayisi: 5, gunlukSaat: 8, blok: 'ikili' | 'tekli',
 *     subeler:    [{id, kapali?: ['gün-saat', ...]}],
 *     ogretmenler:[{id, kapali?: ['gün-saat', ...], maxGunluk?: 6, maxGun?: 4}],
 *     dersler:    [{id, subeId, ogretmenId|null, saat,
 *                   yerlesim?: [2,2,1],                       // isteğe bağlı blok kalıbı
 *                   yerlesimSecenekleri?: [[2,2],[2,1,1]],    // VEYA kuralı (tercih sırasıyla)
 *                   kilitli?: [{gun, saat, uzunluk}] }],      // sabitlenmiş (kilitli) bloklar
 *     tohum: 12345, denemeSayisi: 3, maxIterasyon: 300000, sureLimitMs: 6000
 *   }
 *   gün/saat 0 tabanlıdır (0 = Pazartesi, 0 = 1. ders).
 * Çıktı:
 *   { yerlesim: [{dersId, gun, saat, uzunluk, kilitli}], yerlesmeyen: [{dersId, uzunluk, neden}],
 *     istatistik: {...}, ihlaller: [{tip, ogretmenId, ...}] }
 *
 * Kesin kurallar:
 *   - Bir şubenin aynı saatte tek dersi olur; şubenin kapalı saatlerine ders konmaz.
 *   - Bir öğretmen aynı saatte tek şubede olur; kapalı saatlerine ders konmaz.
 *   - Öğretmenin günlük ders saati maxGunluk'u aşmaz.
 *   - Kilitli bloklar verilen yerde kalır, hiçbir zaman taşınmaz.
 *   - Bir dersin blokları farklı günlere dağıtılır; bloklar aynı gün art arda yerleşir.
 * Tercihler (ceza puanı):
 *   - Şube programında boşluk olmaması (ağır), öğretmenin haftada maxGun'dan fazla gün gelmemesi (ağır),
 *     öğretmen boşluklarının az olması.
 */
(function (root) {
  'use strict';

  function rastgele(tohum) {
    var a = tohum >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** Haftalık saati bloklara böler. ör: 5 -> [2,2,1], 20 (5 gün) -> [4,4,4,4,4] */
  function bloklaraBol(saat, gunSayisi, mod, kalip, enBuyuk) {
    if (saat <= 0) return [];
    enBuyuk = enBuyuk || 99;   // K05: üçlü tekrar yasağında bir blok en fazla 2 saat
    if (Array.isArray(kalip) && kalip.length && kalip.length <= gunSayisi &&
        kalip.every(function (x) { return x === Math.floor(x) && x > 0 && x <= enBuyuk; }) &&
        kalip.reduce(function (a, b) { return a + b; }, 0) === saat) {
      return kalip.slice().sort(function (a, b) { return b - a; });
    }
    var boy = mod === 'tekli' ? 1 : 2;
    boy = Math.min(enBuyuk, Math.max(boy, Math.ceil(saat / Math.max(1, gunSayisi))));
    var sonuc = [], kalan = saat;
    while (kalan > 0) { var b = Math.min(boy, kalan); sonuc.push(b); kalan -= b; }
    return sonuc;
  }

  /** Kalıptan kilitli uzunlukları düşer; kalan kalıp (geçersizse null) */
  function kaliptanDus(kalip, kilitler, kalanSaat) {
    if (!Array.isArray(kalip)) return null;
    var k = kalip.slice();
    for (var i = 0; i < kilitler.length; i++) {
      var j = k.indexOf(kilitler[i].uzunluk);
      if (j < 0) return null;
      k.splice(j, 1);
    }
    return k.reduce(function (a, b) { return a + b; }, 0) === kalanSaat ? k : null;
  }

  function slotSeti(liste, D, H) {
    var k = new Uint8Array(D * H);
    (liste || []).forEach(function (x) {
      var p = String(x).split('-'), d = +p[0], h = +p[1];
      if (d >= 0 && d < D && h >= 0 && h < H) k[d * H + h] = 1;
    });
    return k;
  }

  function tekDeneme(girdi, tohum) {
    var R = rastgele(tohum);
    var D = girdi.gunSayisi, Hmax = girdi.gunlukSaat, S = girdi.subeler.length, T = girdi.ogretmenler.length;
    var subeIdx = {}, ogrIdx = {};
    girdi.subeler.forEach(function (s, i) { subeIdx[s.id] = i; });
    girdi.ogretmenler.forEach(function (o, i) { ogrIdx[o.id] = i; });
    var subeH = girdi.subeler.map(function (s) { return Math.min(Hmax, s.gunlukSaat || Hmax); });
    var kapali = girdi.ogretmenler.map(function (o) { return slotSeti(o.kapali, D, Hmax); });
    var subeKapali = girdi.subeler.map(function (s) { return slotSeti(s.kapali, D, Hmax); });
    var maxGunluk = girdi.ogretmenler.map(function (o) { return o.maxGunluk > 0 ? +o.maxGunluk : Hmax; });
    var maxGun = girdi.ogretmenler.map(function (o) { return o.maxGun > 0 ? Math.min(D, +o.maxGun) : D; });

    // Blokları oluştur
    var bloklar = [], dersBloklari = [], kilitHatalari = [];
    var ogrYuk = new Array(T).fill(0);
    var kur = girdi.kurallar || {};
    var enBuyukBlok = kur.ucluTekrarYasak === false ? 99 : 2;
    if (kur.gunlukAyniDersMax === 1) enBuyukBlok = 1;
    var gunlukSinir = +kur.gunlukAyniDersMax || 2;
    var dersYogun = [], dersGunSinir = [], dilDersleri = {};
    girdi.dersler.forEach(function (ders, di) {
      if (kur.dilAyriGun !== false && ders.dil) (dilDersleri[ders.subeId] = dilDersleri[ders.subeId] || []).push(di);
    });
    girdi.dersler.forEach(function (ders, di) {
      var t = ders.ogretmenId != null && ogrIdx[ders.ogretmenId] != null ? ogrIdx[ders.ogretmenId] : -1;
      var si = subeIdx[ders.subeId];
      if (t >= 0) ogrYuk[t] += ders.saat;
      dersBloklari[di] = [];
      var kilitler = [], kilitToplam = 0;
      (ders.kilitli || []).forEach(function (k) {
        var g = +k.gun, s = +k.saat, u = +k.uzunluk;
        if (!(u > 0) || g < 0 || g >= D || s < 0 || s + u > subeH[si] || kilitToplam + u > ders.saat) {
          kilitHatalari.push({ dersId: ders.id, gun: g, saat: s, uzunluk: u, neden: 'geçersiz kilit' });
          return;
        }
        kilitler.push({ gun: g, saat: s, uzunluk: u }); kilitToplam += u;
      });
      kilitler.forEach(function (k) {
        dersBloklari[di].push(bloklar.length);
        bloklar.push({ ders: di, sube: si, ogr: t, boy: k.uzunluk, gun: -1, saat: -1, deneme: 0, gevsek: false, sabit: true, hedef: [k.gun, k.saat] });
      });
      var kalan = ders.saat - kilitToplam;
      var kullanilanGun = kilitler.map(function (k) { return k.gun; }).filter(function (g, i, a) { return a.indexOf(g) === i; }).length;
      var parca = bloklaraBol(kalan, Math.max(1, D - kullanilanGun), girdi.blok, kaliptanDus(ders.yerlesim, kilitler, kalan), enBuyukBlok);
      // Yoğun ders (haftalık saat > gün × günlük sınır): aynı gün birden çok blok olabilir, bitişik olamaz (K05)
      dersYogun[di] = parca.length + kilitler.length > D || ders.saat > D * gunlukSinir;
      dersGunSinir[di] = dersYogun[di] ? Math.ceil(ders.saat / D) : gunlukSinir;
      parca.forEach(function (boy) {
        dersBloklari[di].push(bloklar.length);
        bloklar.push({ ders: di, sube: si, ogr: t, boy: boy, gun: -1, saat: -1, deneme: 0, gevsek: false, sabit: false });
      });
    });

    var subeIzgara = [];
    for (var s0 = 0; s0 < S; s0++) subeIzgara.push(new Int32Array(D * Hmax).fill(-1));
    var ogrIzgara = girdi.ogretmenler.map(function () { return new Int32Array(D * Hmax).fill(-1); });
    var ogrGunYuk = girdi.ogretmenler.map(function () { return new Int32Array(D); });

    function yerlestir(b, d, h) {
      var B = bloklar[b];
      B.gun = d; B.saat = h;
      for (var k = 0; k < B.boy; k++) {
        subeIzgara[B.sube][d * Hmax + h + k] = b;
        if (B.ogr >= 0) ogrIzgara[B.ogr][d * Hmax + h + k] = b;
      }
      if (B.ogr >= 0) ogrGunYuk[B.ogr][d] += B.boy;
    }
    function kaldir(b) {
      var B = bloklar[b];
      if (B.gun < 0) return;
      for (var k = 0; k < B.boy; k++) {
        subeIzgara[B.sube][B.gun * Hmax + B.saat + k] = -1;
        if (B.ogr >= 0) ogrIzgara[B.ogr][B.gun * Hmax + B.saat + k] = -1;
      }
      if (B.ogr >= 0) ogrGunYuk[B.ogr][B.gun] -= B.boy;
      B.gun = -1; B.saat = -1;
    }
    function ogrGunSayisi(t) { var n = 0; for (var d = 0; d < D; d++) if (ogrGunYuk[t][d] > 0) n++; return n; }

    /** Pozisyondaki çakışan blokları döndürür; null => imkânsız (kapalı saat, sınır, kilitli blok, günlük sınır) */
    function catisma(b, d, h) {
      var B = bloklar[b];
      if (h + B.boy > subeH[B.sube]) return null;
      var set = [];
      for (var k = 0; k < B.boy; k++) {
        var i = d * Hmax + h + k;
        if (subeKapali[B.sube][i]) return null;
        if (B.ogr >= 0 && kapali[B.ogr][i]) return null;
        var x = subeIzgara[B.sube][i];
        if (x >= 0 && x !== b) { if (bloklar[x].sabit) return null; if (set.indexOf(x) < 0) set.push(x); }
        if (B.ogr >= 0) {
          var y = ogrIzgara[B.ogr][i];
          if (y >= 0 && y !== b) { if (bloklar[y].sabit) return null; if (set.indexOf(y) < 0) set.push(y); }
        }
      }
      if (dersYogun[B.ders]) {
        // aynı gün izinli; bitişik blok (K05) ya da günlük sınır aşımı çakışmadır
        var kardesY = dersBloklari[B.ders], gunToplam = B.boy;
        for (var jy = 0; jy < kardesY.length; jy++) {
          var xy = kardesY[jy], KY = bloklar[xy];
          if (xy === b || KY.gun !== d) continue;
          var bitisik = KY.saat + KY.boy === h || h + B.boy === KY.saat;
          if (bitisik || gunToplam + KY.boy > dersGunSinir[B.ders]) {
            if (KY.sabit) return null;
            if (set.indexOf(xy) < 0) set.push(xy);
          } else gunToplam += KY.boy;
        }
      } else if (!B.gevsek) {
        var kardes = dersBloklari[B.ders];
        for (var j = 0; j < kardes.length; j++) {
          var x2 = kardes[j], K = bloklar[x2];
          if (x2 !== b && K.gun === d && !K.gevsek) {
            if (K.sabit) return null;
            if (set.indexOf(x2) < 0) set.push(x2);
          }
        }
      }
      // K08: İngilizce ve Yabancı Dil aynı şubede aynı gün olmaz
      var dil = girdi.dersler[B.ders].dil;
      if (dil) {
        var digerleri = dilDersleri[girdi.dersler[B.ders].subeId] || [];
        for (var q = 0; q < digerleri.length; q++) {
          var od = digerleri[q];
          if (od === B.ders || girdi.dersler[od].dil === dil) continue;
          var ob = dersBloklari[od];
          for (var r2 = 0; r2 < ob.length; r2++) {
            var KD = bloklar[ob[r2]];
            if (KD.gun === d) { if (KD.sabit) return null; if (set.indexOf(ob[r2]) < 0) set.push(ob[r2]); }
          }
        }
      }
      if (B.ogr >= 0) {
        var yuk = ogrGunYuk[B.ogr][d] + B.boy;
        for (var m = 0; m < set.length; m++) { var C = bloklar[set[m]]; if (C.ogr === B.ogr && C.gun === d) yuk -= C.boy; }
        if (yuk > maxGunluk[B.ogr]) return null;
      }
      return set;
    }
    /** Öğretmen yeni bir güne geçiyorsa ve gün sınırı doluysa ceza */
    function gunAsimi(B, d) {
      if (B.ogr < 0 || ogrGunYuk[B.ogr][d] > 0) return 0;
      return ogrGunSayisi(B.ogr) >= maxGun[B.ogr] ? 1 : 0;
    }
    function subeGunDolu(si, d) {
      var n = 0, g = subeIzgara[si];
      for (var h = 0; h < Hmax; h++) if (g[d * Hmax + h] >= 0) n++;
      return n;
    }
    function konumPuani(b, d, h) {
      var B = bloklar[b];
      var p = h * 1.0 + subeGunDolu(B.sube, d) * 2.5;
      if (B.ogr >= 0) {
        var od = ogrGunYuk[B.ogr][d];
        p += od * 0.8 + gunAsimi(B, d) * 100;
        var g = ogrIzgara[B.ogr];
        if (od > 0) {
          var komsu = (h > 0 && g[d * Hmax + h - 1] >= 0) || (h + B.boy < Hmax && g[d * Hmax + h + B.boy] >= 0);
          p += komsu ? -2 : 1.5;
        }
      }
      // Genetik kromozom, aramanın yerleştirme tercihini değiştirir; zorunlu kuralları değiştirmez.
      var gene = (girdi.genetik || {})[girdi.dersler[B.ders].id];
      if (gene) {
        var fark = Math.abs(d - gene.gun);
        p += Math.min(fark, D - fark) * 3.5 + Math.abs(h - gene.saat) * 0.7;
      }
      return p + R() * 1.5;
    }

    // 0) Kilitli blokları yerleştir
    var kilitCakisan = [];
    bloklar.forEach(function (B, b) {
      if (!B.sabit) return;
      var d = B.hedef[0], h = B.hedef[1], bos = true;
      for (var k = 0; k < B.boy; k++) {
        var i = d * Hmax + h + k;
        if (subeIzgara[B.sube][i] >= 0 || (B.ogr >= 0 && ogrIzgara[B.ogr][i] >= 0)) bos = false;
      }
      if (bos) yerlestir(b, d, h); else kilitCakisan.push(b);
    });

    // 1) Açgözlü yerleştirme: zor bloklar önce
    function kapaliSayisi(t) { var n = 0; for (var i = 0; i < kapali[t].length; i++) n += kapali[t][i]; return n + (D - maxGun[t]) * Hmax; }
    var sira = [];
    bloklar.forEach(function (B, i) { if (!B.sabit) sira.push(i); });
    var anahtar = sira.map(function (i) {
      var B = bloklar[i];
      var gen = (girdi.genetik || {})[girdi.dersler[B.ders].id];
      return B.boy * 100 + (B.ogr >= 0 ? kapaliSayisi(B.ogr) * 3 + ogrYuk[B.ogr] : 0) +
        (gen ? (gen.oncelik - 0.5) * 140 : 0) + R();
    });
    var sirali = sira.map(function (b, i) { return [b, anahtar[i]]; }).sort(function (a, b) { return b[1] - a[1]; }).map(function (x) { return x[0]; });

    function ayniGunSayisi(b, d) {
      var n = 0, k = dersBloklari[bloklar[b].ders];
      for (var j = 0; j < k.length; j++) if (k[j] !== b && bloklar[k[j]].gun === d) n++;
      return n;
    }
    var kuyruk = [];
    sirali.forEach(function (b) {
      var en = null, enP = Infinity;
      for (var d = 0; d < D; d++) {
        for (var h = 0; h < Hmax; h++) {
          var c = catisma(b, d, h);
          if (c === null || c.length) continue;
          var p = konumPuani(b, d, h);
          if (p < enP) { enP = p; en = [d, h]; }
        }
      }
      if (en) yerlestir(b, en[0], en[1]); else kuyruk.push(b);
    });

    // 2) Onarım: tabu destekli çıkarma zinciri
    var maxIter = girdi.maxIterasyon || 300000;
    var bitis = Date.now() + (girdi.sureLimitMs || 6000);
    var iter = 0;
    var kalici = [];
    var enIyiEksik = kuyruk.length;
    var enIyiYer = bloklar.map(function (B) { return [B.gun, B.saat]; });
    var tabu = new Int32Array(bloklar.length).fill(-1000);
    var TENURE = 12;
    while (kuyruk.length && iter < maxIter && (iter % 512 || Date.now() < bitis)) {
      iter++;
      var bi = Math.floor(R() * kuyruk.length);
      var b = kuyruk[bi];
      kuyruk[bi] = kuyruk[kuyruk.length - 1];
      kuyruk.pop();
      if (++bloklar[b].deneme > 400) bloklar[b].gevsek = true;
      var adaylar = [], enM = Infinity, B0 = bloklar[b];
      for (var d = 0; d < D; d++) {
        for (var h = 0; h < Hmax; h++) {
          var c = catisma(b, d, h);
          if (c === null) continue;
          var m = 0;
          for (var j = 0; j < c.length; j++) {
            m += bloklar[c[j]].boy * 2 + 1 + Math.min(bloklar[c[j]].deneme, 40) * 0.25;
            if (iter - tabu[c[j]] < TENURE) m += 50;
          }
          if (B0.gevsek) m += ayniGunSayisi(b, d) * 4;
          m += gunAsimi(B0, d) * 25;
          m += R() * 2;
          if (m < enM - 0.0001) { enM = m; adaylar = [[d, h, c]]; }
          else if (Math.abs(m - enM) < 0.0001) adaylar.push([d, h, c]);
        }
      }
      if (!adaylar.length) {
        // Hiç aday yok: kilit/kapalı saat/günlük sınır nedeniyle. Birkaç denemeden sonra kalıcı olarak bırak.
        B0.bos = (B0.bos || 0) + 1;
        if (B0.bos > 30) kalici.push(b); else kuyruk.push(b);
        continue;
      }
      var sec = adaylar[Math.floor(R() * adaylar.length)];
      sec[2].forEach(function (x) { kaldir(x); kuyruk.push(x); });
      yerlestir(b, sec[0], sec[1]);
      tabu[b] = iter;
      if (kuyruk.length + kalici.length < enIyiEksik) {
        enIyiEksik = kuyruk.length + kalici.length;
        enIyiYer = bloklar.map(function (B) { return [B.gun, B.saat]; });
        if (enIyiEksik === 0) break;
      }
    }
    if (kuyruk.length + kalici.length > enIyiEksik) {
      bloklar.forEach(function (_, i) { kaldir(i); });
      bloklar.forEach(function (B, i) { if (enIyiYer[i][0] >= 0) yerlestir(i, enIyiYer[i][0], enIyiYer[i][1]); });
    }

    // 3) İyileştirme: boşluklar ve gün sınırı
    function subeBosluk(si) {
      var top = 0, g = subeIzgara[si], sk = subeKapali[si];
      for (var d = 0; d < D; d++) {
        var son = -1, dolu = 0, kap = 0;
        for (var h = 0; h < Hmax; h++) if (g[d * Hmax + h] >= 0) { son = h; dolu++; }
        for (h = 0; h <= son; h++) if (sk[d * Hmax + h]) kap++;
        if (son >= 0) top += (son + 1) - dolu - kap;
      }
      return top;
    }
    function ogrBosluk(t) {
      var top = 0, g = ogrIzgara[t];
      for (var d = 0; d < D; d++) {
        var ilk = -1, son = -1, dolu = 0;
        for (var h = 0; h < Hmax; h++) if (g[d * Hmax + h] >= 0) { if (ilk < 0) ilk = h; son = h; dolu++; }
        if (son >= 0) top += (son - ilk + 1) - dolu;
      }
      return top;
    }
    function gunFazlasi(t) { return Math.max(0, ogrGunSayisi(t) - maxGun[t]); }
    function yerelCeza(B) {
      return subeBosluk(B.sube) * 10 + (B.ogr >= 0 ? ogrBosluk(B.ogr) + gunFazlasi(B.ogr) * 60 : 0);
    }
    var iyilestirme = girdi.iyilestirmeTuru || 4;
    for (var tur = 0; tur < iyilestirme; tur++) {
      var degisti = false;
      var karisik = [];
      bloklar.forEach(function (B, i) { if (!B.sabit) karisik.push(i); });
      karisik.sort(function () { return R() - 0.5; });
      karisik.forEach(function (b) {
        var B = bloklar[b];
        if (B.gun < 0) return;
        var eskiD = B.gun, eskiH = B.saat;
        var once = yerelCeza(B);
        if (once === 0) return;
        kaldir(b);
        var en = [eskiD, eskiH], enC = once;
        for (var d = 0; d < D; d++) {
          for (var h = 0; h < Hmax; h++) {
            var c = catisma(b, d, h);
            if (c === null || c.length) continue;
            yerlestir(b, d, h);
            var cz = yerelCeza(B);
            kaldir(b);
            if (cz < enC) { enC = cz; en = [d, h]; }
          }
        }
        yerlestir(b, en[0], en[1]);
        if (en[0] !== eskiD || en[1] !== eskiH) degisti = true;
      });
      if (!degisti) break;
    }

    // Sonuç
    var yerlesim = [], yerlesmeyen = [];
    bloklar.forEach(function (B, i) {
      var dersId = girdi.dersler[B.ders].id;
      if (B.gun >= 0) yerlesim.push({ dersId: dersId, gun: B.gun, saat: B.saat, uzunluk: B.boy, kilitli: !!B.sabit });
      else yerlesmeyen.push({ dersId: dersId, uzunluk: B.boy, neden: kilitCakisan.indexOf(i) >= 0 ? 'kilit çakışması' : 'yer bulunamadı' });
    });
    kilitHatalari.forEach(function (k) { yerlesmeyen.push({ dersId: k.dersId, uzunluk: k.uzunluk || 0, neden: k.neden }); });
    var sb = 0, ob = 0, ihlaller = [];
    for (var si = 0; si < S; si++) sb += subeBosluk(si);
    for (var t = 0; t < T; t++) {
      ob += ogrBosluk(t);
      var gs = ogrGunSayisi(t);
      if (gs > maxGun[t]) ihlaller.push({ tip: 'gunSayisi', ogretmenId: girdi.ogretmenler[t].id, deger: gs, sinir: maxGun[t] });
    }
    var eksikSaat = yerlesmeyen.reduce(function (a, x) { return a + x.uzunluk; }, 0);
    return {
      yerlesim: yerlesim,
      yerlesmeyen: yerlesmeyen,
      ihlaller: ihlaller,
      istatistik: {
        blokSayisi: bloklar.length,
        kilitliBlok: bloklar.filter(function (B) { return B.sabit; }).length,
        toplamSaat: girdi.dersler.reduce(function (a, x) { return a + x.saat; }, 0),
        eksikSaat: eksikSaat,
        subeBosluk: sb,
        ogretmenBosluk: ob,
        ihlal: ihlaller.length,
        iterasyon: iter,
        ceza: eksikSaat * 1000 + ihlaller.length * 200 + sb * 10 + ob,
        tohum: tohum
      }
    };
  }

  /**
   * Birden çok deneme yapar, en düşük cezalıyı döndürür.
   * VEYA kuralı: ders.yerlesimSecenekleri = [[2,2],[2,1,1]] ise önce ilk kalıp denenir;
   * bir denemede bu dersin bloğu yerleşemezse sonraki denemede bir sonraki kalıba geçilir.
   */
  function dagit(girdi) {
    var bas = Date.now();
    var n = girdi.denemeSayisi || 3;
    var tohum = girdi.tohum || 20261119;
    var enIyi = null;
    var secim = girdi.dersler.map(function () { return 0; });
    var idx = {};
    girdi.dersler.forEach(function (d, j) { idx[d.id] = j; });
    var secenekli = girdi.dersler.some(function (d) { return d.yerlesimSecenekleri && d.yerlesimSecenekleri.length > 1; });
    var toplam = girdi.genetik ? 1 : n + (secenekli ? 4 : 0);
    for (var i = 0; i < toplam; i++) {
      var dersler = girdi.dersler.map(function (d, j) {
        var s = d.yerlesimSecenekleri;
        if (!s || !s.length) return d;
        var kopya = {};
        for (var k in d) kopya[k] = d[k];
        kopya.yerlesim = s[Math.min(secim[j], s.length - 1)];
        return kopya;
      });
      var g2 = {};
      for (var k2 in girdi) g2[k2] = girdi[k2];
      g2.dersler = dersler;
      var r = tekDeneme(g2, tohum + i * 7919);
      r.kullanilanKalip = {};
      dersler.forEach(function (d) { if (d.yerlesimSecenekleri) r.kullanilanKalip[d.id] = d.yerlesim.join('+'); });
      if (!enIyi || r.istatistik.ceza < enIyi.istatistik.ceza) enIyi = r;
      if (enIyi.istatistik.ceza === 0) break;
      if (secenekli) {
        r.yerlesmeyen.forEach(function (y) {
          var j = idx[y.dersId], s = girdi.dersler[j].yerlesimSecenekleri;
          if (s && secim[j] < s.length - 1) secim[j]++;
        });
      }
    }
    enIyi.istatistik.sureMs = Date.now() - bas;
    enIyi.istatistik.motor = 'JavaScript';
    return enIyi;
  }

  var api = { dagit: dagit, bloklaraBol: bloklaraBol };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.DersDagitim = api;
})(typeof window !== 'undefined' ? window : this);

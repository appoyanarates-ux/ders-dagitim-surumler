/*
 * Haftalık Ders Dağıtım Programı — arayüz
 * Çalışma kipleri:
 *   - 'onizleme': tek HTML dosyası; veriler tarayıcıda (localStorage) otomatik kaydedilir, dağıtım JS motoruyla yapılır.
 *   - 'sunucu'  : evrakplus.com'da index.php (WordPress köprüsü) üzerinden açılır; proje index.php?action=kaydet ile
 *                 üyenin WordPress hesabına (wp_usermeta: ders_dagitim_data) otomatik kaydedilir.
 *                 Dağıtım CP-SAT (sunucu) ya da tarayıcıdaki hızlı motorla yapılır.
 */
(function () {
  'use strict';

  var VERI = window.CIZELGE_VERISI;
  var CFG = window.APP_CONFIG || { mod: 'onizleme' };
  var M = window.Model;
  var ProgramAraclari = window.DersProgramAraclari; // Etkin dağıtımı sıfırlama ve blok saat etiketleri
  var YEREL_ANAHTAR = CFG.yerelAnahtar || 'ders-dagitim-durum-v1';
  var DURUM_SURUMU = 2;

  var durum = null;
  var ui = { tasarimGruplar: {}, menuArama: '', adim: 'baslangic', gorunum: 'sube', seciliSube: null, seciliOgr: null, modal: null, onay: null, calisiyor: false, projeler: [], secOgr: {}, kayit: { durum: 'bos', zaman: null } };

  // ---------- Yardımcılar ----------
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function $(sel) { return document.querySelector(sel); }
  function tur() { return M.turBul(VERI, durum.okul.turId); }
  function ogretmen(id) { for (var i = 0; i < durum.ogretmenler.length; i++) if (durum.ogretmenler[i].id === id) return durum.ogretmenler[i]; return null; }
  function sube(id) { for (var i = 0; i < durum.subeler.length; i++) if (durum.subeler[i].id === id) return durum.subeler[i]; return null; }
  /** Okul yönetimindeki görev: müdür ve yardımcıları öğretmen nöbeti tutmaz, müdür yardımcıları idari nöbet tutar */
  var GOREVLER = [['', 'Öğretmen'], ['mudur', 'Okul müdürü'], ['basyrd', 'Müdür başyardımcısı'], ['yrd', 'Müdür yardımcısı']];
  var GOREV_AD = {}; GOREVLER.forEach(function (g) { GOREV_AD[g[0]] = g[1]; });
  function yoneticiMi(o) { return !!(o && o.gorev && o.gorev !== ''); }
  /** Öğretmen nöbet çizelgesine girer mi */
  function nobetTutar(o) { return !!o && !(durum.nobet.yoneticiHaric && yoneticiMi(o)); }
  /** İdari nöbet tutar mı (müdür yardımcısı; ayara göre başyardımcı) */
  function idariNobetci(o) { return !!o && (o.gorev === 'yrd' || (o.gorev === 'basyrd' && durum.nobet.idari.basyrd)); }
  function idariNobetciler() { return durum.ogretmenler.filter(idariNobetci).sort(function (a, b) { return (a.gorev === 'basyrd' ? 0 : 1) - (b.gorev === 'basyrd' ? 0 : 1) || a.ad.localeCompare(b.ad, 'tr'); }); }
  function sinifEtiketi(s) { return s === 'Hz' ? 'Hazırlık' : s + '. Sınıf'; }
  function yeniId(on) { return on + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36); }
  function saatSaniye(d) { return (d.getHours() < 10 ? '0' : '') + d.getHours() + ':' + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes(); }
  var bildirimZaman = null;
  function bildir(metin, tip) {
    var el = $('#bildirim');
    el.textContent = metin;
    el.className = 'bildirim' + (tip ? ' ' + tip : '');
    clearTimeout(bildirimZaman);
    bildirimZaman = setTimeout(function () { el.classList.add('gizli'); }, 3400);
  }

  /** Basit çizgi ikonları (24x24, stroke) */
  var IKON = {
    okul: 'M3 21h18M5 21V9l7-5 7 5v12M9 21v-6h6v6M10 10h4',
    ev: 'M3 11l9-7 9 7M5 10v10h14V10M10 20v-6h4v6',
    cikis: 'M14 4h5v16h-5M10 8l-4 4 4 4M6 12h11',
    yardim: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9.5 9.2a2.5 2.5 0 1 1 3.4 2.3c-.6.3-.9.8-.9 1.4v.6M12 16.8v.2',
    subeler: 'M4 5h16v4H4zM4 11h16v4H4zM4 17h16v3H4z',
    zorunlu: 'M4 4h11a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3zM4 17a3 3 0 0 1 3-3h11',
    secmeli: 'M9 6h11M9 12h11M9 18h11M4 6l1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2',
    ogretmenler: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM2 21v-1a6 6 0 0 1 12 0v1M16 3.5a4 4 0 0 1 0 7M22 21v-1a6 6 0 0 0-4-5.6',
    atama: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1',
    bloklar: 'M3 4h8v7H3zM13 4h8v7h-8zM3 13h5v7H3zM10 13h5v7h-5zM17 13h4v7h-4z',
    kisitlar: 'M6 11V8a6 6 0 0 1 12 0v3M5 11h14v10H5zM12 15v2',
    dagitim: 'M3 5h18v16H3zM3 10h18M8 3v4M16 3v4M7 14h3M12 14h3M7 17h3',
    ciktilar: 'M6 9V3h12v6M6 18H4v-7h16v7h-2M6 14h12v7H6z',
    nobet: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM9 12l2 2 4-4',
    kaynaklar: 'M4 19V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2 2 2 0 0 0 2 2h13M8 7h7',
    veri: 'M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6',
    indir: 'M12 3v12M7 10l5 5 5-5M4 19h16',
    yukle: 'M12 21V9M7 14l5-5 5 5M4 5h16',
    cop: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
    artı: 'M12 5v14M5 12h14',
    kilit: 'M6 11V8a6 6 0 0 1 12 0v3M5 11h14v10H5z',
    oynat: 'M7 4l13 8-13 8z',
    kaydet: 'M5 3h11l3 3v15H5zM8 3v6h8V3M8 21v-7h8v7',
    yazdir: 'M6 9V3h12v6M6 18H4v-7h16v7h-2M6 14h12v7H6z',
    duzenle: 'M4 20h4L19 9l-4-4L4 16zM14 6l4 4',
    uyari: 'M12 3l10 18H2zM12 10v5M12 18v.5',
    tamam: 'M5 12l5 5 9-10'
  };
  function ikon(ad, cls) {
    return '<svg class="ikon ' + (cls || '') + '" viewBox="0 0 24 24" aria-hidden="true"><path d="' + (IKON[ad] || '') + '"/></svg>';
  }

  /** Aşama 7: eksik saat, başarısız doğrulama veya eski sonuç resmî başarı sayılmaz. */
  function sonucGuvenliMi(r) {
    return !!(r && !r.eski && r.istatistik && Number(r.istatistik.eksikSaat) === 0 &&
      r.cozucu && r.cozucu.basarili === true &&
      !(r.cozucu.kuralIhlalleri || []).length && !(r.cozucu.desteklenmeyen || []).length);
  }

  // ---------- Varsayılan durum ve eski kayıtların güncellenmesi ----------
  function varsayilanDurum(turId, eski) {
    var t = M.turBul(VERI, turId) || VERI.okulTurleri[0];
    var sayilar = {};
    t.siniflar.forEach(function (s) { sayilar[s] = s === 'Hz' ? 1 : 2; });
    var d = {
      surum: DURUM_SURUMU,
      okul: {
        ad: (eski && eski.okul.ad && eski.okul.ad.indexOf('Örnek ') !== 0) ? eski.okul.ad : 'Örnek ' + t.ad,
        turId: t.id,
        gunSayisi: 5,
        gunlukSaat: t.gunlukSaat,
        baslangic: (eski && eski.okul.baslangic) || '08:30',
        dersSure: (eski && eski.okul.dersSure) || 40,
        teneffus: (eski && eski.okul.teneffus) || 10,
        ogleSonrasi: (eski && eski.okul.ogleSonrasi) || 5,
        ogleSure: (eski && eski.okul.ogleSure) || 40
      },
      subeAyar: { adlandirma: 'harf', ayrac: '-' },
      subeler: M.subeleriOlustur(t, sayilar),
      secmeliler: {},
      ogretmenler: [],
      atamalar: {},
      ayarlar: { blok: 'ikili', deneme: 10, denemeVarsayilan: 10, maxSaat: 30 },
      belge: eski && eski.belge ? eski.belge : {},
      sonuc: null
    };
    t.siniflar.forEach(function (s) { d.secmeliler[s] = M.onerilenSecmeliler(t, VERI, s); });
    return gocEt(d);
  }
  /** Eksik alanları tamamlar; eski sürüm kayıtlarını bugünkü yapıya getirir. */
  function gocEt(d) {
    d.surum = DURUM_SURUMU;
    d.okul = d.okul || {};
    ['secmeliler', 'subeSecmeli', 'saatDegisiklik', 'yerlesimler', 'blokKurallari', 'kilitler', 'subeKapali', 'atamalar', 'belge'].forEach(function (k) {
      if (!d[k] || typeof d[k] !== 'object' || Array.isArray(d[k])) d[k] = {};
    });
    ['subeler', 'ogretmenler', 'ekDersler', 'dagitimKayitlari', 'ozelSecmeliler', 'binalar', 'derslikler', 'binaGecis', 'kulupler', 'etiketKurallari'].forEach(function (k) { if (!Array.isArray(d[k])) d[k] = []; });
    ['dersAyar', 'ortakOgretmen', 'paralelGrup', 'kurallar'].forEach(function (k) { if (!d[k] || typeof d[k] !== 'object' || Array.isArray(d[k])) d[k] = {}; });
    d.subeAyar = d.subeAyar || { adlandirma: 'harf', ayrac: '-' };
    d.ayarlar = d.ayarlar || {};
    if (!d.ayarlar.blok) d.ayarlar.blok = 'ikili';
    if (d.ayarlar.denemeVarsayilan !== 10) {   // varsayılan 3'ten 10'a çıktı: eski varsayılanda kalan projeler bir kez güncellenir
      if (!d.ayarlar.deneme || +d.ayarlar.deneme === 3) d.ayarlar.deneme = 10;
      d.ayarlar.denemeVarsayilan = 10;
    }
    if (!d.ayarlar.deneme) d.ayarlar.deneme = 10;
    if (!d.ayarlar.maxSaat) d.ayarlar.maxSaat = 30;
    if (!d.ayarlar.motor) d.ayarlar.motor = 'otomatik';
    if (!d.ayarlar.cpsatSure) d.ayarlar.cpsatSure = 60;
    d.nobet = d.nobet || {};
    if (!Array.isArray(d.nobet.donemler) || !d.nobet.donemler.length) {
      d.nobet.donemler = ['1. Dönem — 1. kısım', '1. Dönem — 2. kısım', '2. Dönem — 1. kısım', '2. Dönem — 2. kısım'].map(function (a) { return { aralik: a, atama: {}, alan: {} }; });
    }
    d.nobet.donemler.forEach(function (dn) { dn.atama = dn.atama || {}; dn.alan = dn.alan || {}; if (!dn.idari || typeof dn.idari !== 'object' || Array.isArray(dn.idari)) dn.idari = {}; });
    if (!Array.isArray(d.nobet.alanlar) || !d.nobet.alanlar.length) d.nobet.alanlar = [{ ad: 'Okul bahçesi', kisi: 1 }, { ad: 'Koridorlar', kisi: 1 }];
    d.nobet.strateji = d.nobet.strateji || 'dengeli';
    if (d.nobet.yoneticiHaric == null) d.nobet.yoneticiHaric = true;   // müdür ve yardımcıları öğretmen nöbeti tutmaz
    d.nobet.idari = d.nobet.idari || {};
    if (!d.nobet.idari.gunlukKisi) d.nobet.idari.gunlukKisi = 1;
    if (d.nobet.idari.basyrd == null) d.nobet.idari.basyrd = true;
    if (['ayri', 'alt', 'yok'].indexOf(d.nobet.idari.cikti) < 0) d.nobet.idari.cikti = 'ayri';
    if (d.nobet.bosGunVerme == null) d.nobet.bosGunVerme = true;
    d.dagitimKayitlari.forEach(function (k, i) { if (!k.id) k.id = 'k' + Date.now().toString(36) + i; });
    d.ogretmenler.forEach(function (o) { if (!GOREV_AD[o.gorev || '']) o.gorev = ''; o.kapali = o.kapali || []; o.ekBranslar = o.ekBranslar || []; if (!o.maxSaat) o.maxSaat = d.ayarlar.maxSaat; });
    return d;
  }

  // ---------- Kalıcılık ve otomatik kayıt ----------
  // EvrakPlus (WordPress) sürümü: proje üyenin WordPress hesabına kaydedilir (index.php?action=kaydet).
  // Tarayıcıdaki kopya yalnız bağlantı kesilirse kayıp olmasın diye tutulur ve üyeye özeldir (CFG.yerelAnahtar).
  // "bekleyen" işareti: sunucuya henüz gitmemiş değişiklik var demektir; bağlantı gelince ya da sonraki açılışta gönderilir.
  var BEKLEYEN_ANAHTAR = YEREL_ANAHTAR + '-bekleyen';
  var yerelZaman = null, sunucuZaman = null, kayitSuruyor = false, kayitTekrar = false;
  function bekleyenIsaretle(var_) { try { if (var_) localStorage.setItem(BEKLEYEN_ANAHTAR, '1'); else localStorage.removeItem(BEKLEYEN_ANAHTAR); } catch (e) { /* depolama kapalı */ } }
  function bekleyenVar() { try { return localStorage.getItem(BEKLEYEN_ANAHTAR) === '1'; } catch (e) { return false; } }
  /** Her değişiklikte çağrılır: tarayıcıya hemen, sunucuya kısa gecikmeyle otomatik kayıt. */
  function degisti(sonucuEskit) {
    if (sonucuEskit) ui.veriSurum = (ui.veriSurum || 0) + 1;
    if (sonucuEskit && durum.sonuc) durum.sonuc.eski = true;
    kayitDurumu('bekliyor');
    if (CFG.mod === 'sunucu') bekleyenIsaretle(true);
    clearTimeout(yerelZaman);
    yerelZaman = setTimeout(function () {
      var ok = yerelKaydet();
      if (CFG.mod !== 'sunucu') kayitDurumu(ok ? 'kaydedildi' : 'hata');
    }, 350);
    if (CFG.mod === 'sunucu') {
      clearTimeout(sunucuZaman);
      sunucuZaman = setTimeout(function () { sunucuKaydet(true); }, 1500);
    }
  }
  function kayitDurumu(d) {
    ui.kayit = { durum: d, zaman: d === 'kaydedildi' ? new Date() : ui.kayit.zaman };
    var el = $('#kayit-durum');
    if (!el) return;
    var metin = { bos: 'Otomatik kayıt açık', bekliyor: 'Kaydediliyor…', kaydedildi: 'Kaydedildi ' + (ui.kayit.zaman ? saatSaniye(ui.kayit.zaman) : ''), hata: navigator.onLine === false ? 'Çevrimdışı — bağlantı gelince kaydedilecek' : 'Kaydedilemedi', cakisma: 'Başka cihazda değişti' }[d];
    el.className = 'kayit-durum ' + (d === 'cakisma' ? 'hata' : d);
    el.innerHTML = (d === 'kaydedildi' ? ikon('tamam') : (d === 'hata' || d === 'cakisma' ? ikon('uyari') : '<span class="nokta"></span>')) + '<span>' + esc(metin) + '</span>';
    el.title = CFG.mod === 'sunucu' ? 'Her değişiklik evrakplus.com hesabınıza otomatik kaydedilir; başka cihazdan girdiğinizde kaldığınız yerden devam edersiniz.' : 'Her değişiklik bu tarayıcıya otomatik kaydedilir. Başka cihaza taşımak için Veri ve yedek > JSON indir.';
  }
  function yerelKaydet() {
    try { localStorage.setItem(YEREL_ANAHTAR, JSON.stringify(durum)); return true; } catch (e) { return false; }
  }
  function yerelYukle() {
    try {
      var s = localStorage.getItem(YEREL_ANAHTAR);
      if (s) { var d = JSON.parse(s); if (d && d.okul && M.turBul(VERI, d.okul.turId)) { var pid = d.projeId, rev = d.projeRev; d = gocEt(d); if (pid) d.projeId = pid; if (rev != null) d.projeRev = rev; return d; } }
    } catch (e) { /* yok say */ }
    return null;
  }
  /** Projenin içeriği (proje no/sürüm hariç): değişmeyen içerik yeniden gönderilmez, sürüm boşuna artmaz */
  var sonGonderilen = null;
  function durumMetni() {
    return JSON.stringify(durum, function (k, v) { return this === durum && (k === 'projeId' || k === 'projeRev') ? undefined : v; });
  }
  function bekleyenKayitlariIptal() { clearTimeout(sunucuZaman); clearTimeout(yerelZaman); kayitTekrar = false; }
  function apiHatasi(mesaj, kod, j) { var e = new Error(mesaj); e.kod = kod; e.veri = j || {}; return e; }
  function api(eylem, govde, ikinciDeneme) {
    var url = CFG.api + '?action=' + eylem;
    var secenek = govde ? { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-DD-Nonce': CFG.nonce || '' }, body: JSON.stringify(govde) } : {};
    secenek.credentials = 'same-origin';
    return fetch(url, secenek).then(function (r) {
      if (r.status === 401) {
        yerelKaydet();
        bildir('Oturumunuz kapanmış; giriş sayfasına yönlendiriliyorsunuz. Değişiklikleriniz bu cihazda saklandı.', 'hata');
        setTimeout(function () { window.location.href = CFG.girisUrl || 'giris.php'; }, 1200);
        throw apiHatasi('Oturum süresi doldu; giriş sayfasına yönlendiriliyorsunuz.', 401);
      }
      return r.json().catch(function () { return { hata: 'Sunucudan beklenmeyen yanıt (HTTP ' + r.status + ')' }; }).then(function (j) {
        // Sayfa uzun süre açık kaldıysa güvenlik anahtarı yenilenir ve istek bir kez daha gönderilir
        if (r.status === 403 && j.nonce && govde && !ikinciDeneme) {
          return fetch(CFG.api + '?action=nonce', { credentials: 'same-origin' }).then(function (r2) { return r2.json(); })
            .then(function (n) { if (!n.nonce) throw apiHatasi(j.hata, 403, j); CFG.nonce = n.nonce; return api(eylem, govde, true); });
        }
        if (!r.ok || j.hata) throw apiHatasi(j.hata || ('HTTP ' + r.status), r.status, j);
        return j;
      });
    });
  }
  function sunucuKaydet(sessiz, zorla) {
    if (kayitSuruyor) { kayitTekrar = true; return Promise.resolve(); }   // aynı anda iki kayıt kendi kendine çakışmasın
    var metin = durumMetni();
    if (!zorla && durum.projeId && metin === sonGonderilen) {   // içerik hesaptakiyle aynı
      bekleyenIsaretle(false); kayitDurumu('kaydedildi'); if (!sessiz) bildir('Kaydedildi.');
      return Promise.resolve();
    }
    kayitSuruyor = true; kayitTekrar = false;
    kayitDurumu('bekliyor');
    return api('kaydet', { id: durum.projeId || null, rev: durum.projeId && durum.projeRev != null ? durum.projeRev : null, zorla: !!zorla, ad: durum.okul.ad, turId: durum.okul.turId, durum: durum })
      .then(function (j) {
        var yeni = !durum.projeId || String(durum.projeId) !== String(j.id);
        durum.projeId = j.id; durum.projeRev = j.rev; sonGonderilen = metin; yerelKaydet();
        if (!kayitTekrar) bekleyenIsaretle(false);
        kayitDurumu('kaydedildi');
        if (!sessiz) bildir('Kaydedildi.');
        if (yeni || !sessiz) projeleriGetir();
      })
      .catch(function (e) {
        if (e.kod === 409) { kayitTekrar = false; cakismaGoster(e.veri); return; }
        kayitDurumu('hata'); if (!sessiz) bildir('Kaydedilemedi: ' + e.message, 'hata');
      })
      .then(function () {
        kayitSuruyor = false;
        if (kayitTekrar) { kayitTekrar = false; sunucuKaydet(true); }
      });
  }
  /** Aynı proje başka bir cihazda (ya da sekmede) daha yeni kaydedilmiş */
  function cakismaGoster(j) {
    kayitDurumu('cakisma');
    if (ui.onay && ui.onay.cakisma) return;
    onayla('Bu proje başka bir cihazda değiştirildi',
      'Projenin hesabınızdaki sürümü' + (j && j.guncelleme ? ' (<b>' + esc(j.guncelleme) + '</b>)' : '') + ' bu ekrandakinden daha yeni. ' +
      '<b>Hesaptakini aç</b> derseniz son kaydedilen sürüm yüklenir ve bu ekrandaki kaydedilmemiş değişiklikler bırakılır. ' +
      '<b>Bu ekrandakini kaydet</b> derseniz hesaptaki sürümün üzerine yazılır.',
      'Hesaptakini aç', function () { bekleyenIsaretle(false); projeAc(durum.projeId, true); }, true);
    ui.onay.cakisma = true;
    ui.onay.ikinci = { metin: 'Bu ekrandakini kaydet', islem: function () { sunucuKaydet(false, true); } };
    onayCiz();
  }
  function projeleriGetir() {
    return api('listele').then(function (j) { ui.projeler = j.projeler || []; ustCiz(); if (ui.adim === 'veri') ciz(); }).catch(function () { });
  }
  function projeAc(id, sessiz) {
    return api('yukle&id=' + encodeURIComponent(id)).then(function (j) {
      bekleyenKayitlariIptal();
      durum = gocEt(j.durum); durum.projeId = j.id; durum.projeRev = j.rev; sonGonderilen = durumMetni(); yerelKaydet(); bekleyenIsaretle(false);
      if (!sessiz) ui.adim = 'okul';
      ciz(); kayitDurumu('kaydedildi');
      bildir(sessiz ? 'Hesabınızdaki son sürüm yüklendi.' : '“' + durum.okul.ad + '” açıldı.');
    }).catch(function (e) { bildir('Açılamadı: ' + e.message, 'hata'); });
  }
  /** Sekmeye / uygulamaya geri dönüldüğünde: proje başka cihazda değiştiyse güncel sürümü getir */
  var sonSurumDenetimi = 0;
  function surumDenetle() {
    if (CFG.mod !== 'sunucu' || !durum || !durum.projeId || ui.calisiyor || kayitSuruyor) return;
    if (Date.now() - sonSurumDenetimi < 2000) return;
    sonSurumDenetimi = Date.now();
    api('surum&id=' + encodeURIComponent(durum.projeId)).then(function (j) {
      if (j.yok || j.rev == null || durum.projeRev == null || j.rev <= durum.projeRev) {
        if (bekleyenVar()) sunucuKaydet(true);
        return;
      }
      if (bekleyenVar()) cakismaGoster(j);
      else if (!ui.modal && !ui.onay) projeAc(durum.projeId, true);
    }).catch(function () { });
  }

  // ---------- Mobil uygulama kabuğu: alt gezinti, adımlar çekmecesi, hesap menüsü, geri tuşu ----------
  var ALT_GEZINTI = [
    { id: 'baslangic', ad: 'Genel', ikon: 'ev', grup: ['baslangic'] },
    { id: 'ogretmenler', ad: 'Öğretmen', ikon: 'ogretmenler', grup: ['ogretmenler', 'atama', 'kisitlar', 'kulupler'] },
    { id: 'dagitim', ad: 'Dağıtım', ikon: 'dagitim', grup: ['dagitim', 'kurallar'] },
    { id: 'ciktilar', ad: 'Çıktılar', ikon: 'ciktilar', grup: ['ciktilar', 'raporlar', 'nobet'] },
    { id: '', ad: 'Adımlar', ikon: 'bloklar', grup: [] }
  ];
  function sayfaVarMi(id) { return MENU.some(function (g) { return g.adimlar.some(function (a) { return a.id === id; }); }) || id === 'veri' || id === 'kaynaklar'; }
  function altGezintiCiz() {
    var el = $('#alt-gezinti'); if (!el) return;
    var bulundu = false;
    el.innerHTML = ALT_GEZINTI.map(function (x) {
      var aktif = x.grup.indexOf(ui.adim) >= 0; if (aktif) bulundu = true;
      if (!x.id) aktif = !bulundu;
      return '<button type="button" class="' + (aktif ? 'aktif' : '') + '" data-a="' + (x.id ? 'adim' : 'adimlar-ac') + '"' + (x.id ? ' data-v="' + x.id + '"' : '') + '>' + ikon(x.ikon) + '<span>' + x.ad + '</span></button>';
    }).join('');
  }
  function yanKapat() { if (document.body.classList.contains('yan-acik')) { document.body.classList.remove('yan-acik'); gecmisPlanla(); } }
  function mobilMenuCiz() {
    var kok = $('#mobil-kok'); if (!kok) return;
    if (!ui.mobilMenu) { kok.innerHTML = ''; gecmisPlanla(); return; }
    var h = '<div class="mobil-perde" data-a="mobil-kapat"></div><div class="mobil-sayfa" role="dialog" aria-label="Hesap ve proje"><div class="tutamac"></div>';
    if (CFG.kullanici) h += '<div class="ms-uye">' + ikon('ogretmenler') + '<div><b>' + esc(CFG.kullanici.ad) + '</b><small>evrakplus.com hesabı · ' + esc(($('#kayit-durum') || {}).textContent || '') + '</small></div></div>';
    if (CFG.mod === 'sunucu') {
      h += '<div class="ms-baslik">Projelerim</div><div class="ms-projeler">' + (ui.projeler.length ? ui.projeler.map(function (p) {
        var acik = durum.projeId == p.id;
        return '<button type="button" class="ms-proje' + (acik ? ' acik' : '') + '"' + (acik ? '' : ' data-a="proje-ac" data-v="' + esc(p.id) + '"') + '>' + ikon('okul') + '<span>' + esc(p.ad) + '<small>' + (acik ? 'Açık' : esc(p.guncelleme)) + '</small></span></button>';
      }).join('') : '<p class="ince">Henüz kayıtlı proje yok; ilk değişiklikte oluşur.</p>') + '<button type="button" class="ms-proje yeni" data-a="yeni">' + ikon('artı') + '<span>Yeni proje</span></button></div>';
    }
    h += '<div class="ms-izgara">';
    if (CFG.mod === 'sunucu') h += '<button type="button" data-a="kaydet">' + ikon('kaydet') + '<span>Kaydet</span></button>';
    h += '<button type="button" data-a="adim" data-v="veri">' + ikon('indir') + '<span>Yedek</span></button>';
    if (window.PWA && window.PWA.kurulabilir()) h += '<button type="button" data-a="pwa-yukle" class="vurgu">' + ikon('yukle') + '<span>Telefona yükle</span></button>';
    if (CFG.wp) h += '<a href="' + esc(CFG.anaSayfa) + '">' + ikon('ev') + '<span>evrakplus.com</span></a>';
    if (CFG.yonetici) h += '<a href="' + esc(CFG.kurulumUrl) + '">' + ikon('kisitlar') + '<span>Sunucu</span></a>';
    if (CFG.cikisUrl) h += '<a href="' + esc(CFG.cikisUrl) + '" class="tehlike">' + ikon('cikis') + '<span>Çıkış</span></a>';
    h += '</div><button type="button" class="btn ms-kapat" data-a="mobil-kapat">Kapat</button></div>';
    kok.innerHTML = h;
    gecmisPlanla();
  }
  /*
   * Tarayıcı geçmişi: her adım bir geçmiş kaydıdır (#adım). Pencere/çekmece/menü açılınca bir kayıt daha eklenir.
   * Böylece telefondaki geri tuşu önce açık pencereyi kapatır, sonra bir önceki adıma döner (uygulamadan çıkmaz).
   */
  var gecmisBekliyor = false, geriYoksay = 0;
  function katmanAcik() { return !!(ui.modal || (ui.onay && !ui.onay.ikinci) || ui.mobilMenu || document.body.classList.contains('yan-acik')); }
  function gecmisPlanla() { if (gecmisBekliyor) return; gecmisBekliyor = true; setTimeout(function () { gecmisBekliyor = false; gecmisEsitle(); }, 0); }
  function gecmisEsitle() {
    if (!window.history || !history.pushState) return;
    var st = history.state || {}, katman = katmanAcik() ? 1 : 0;
    try {
      if (st.adim !== ui.adim) {
        if (st.katman) history.replaceState({ adim: ui.adim, katman: 0 }, '', '#' + ui.adim);
        else history.pushState({ adim: ui.adim, katman: 0 }, '', '#' + ui.adim);
        if (katman) history.pushState({ adim: ui.adim, katman: 1 }, '', '#' + ui.adim);
      } else if (katman && !st.katman) {
        history.pushState({ adim: ui.adim, katman: 1 }, '', '#' + ui.adim);
      } else if (!katman && st.katman) {
        geriYoksay++; history.back();   // pencere düğmeyle kapandı: fazladan kaydı geri al
      }
    } catch (e) { /* yok say */ }
  }
  function geriTusu(e) {
    if (geriYoksay > 0) { geriYoksay--; return; }
    var st = e.state || { adim: (location.hash || '').replace('#', '') || 'baslangic', katman: 0 };
    if (katmanAcik() && !st.katman) {
      // önce açık olanı kapat
      if (ui.onay && !ui.onay.ikinci) { ui.onay = null; onayCiz(); }
      else if (ui.mobilMenu) { ui.mobilMenu = false; mobilMenuCiz(); }
      else if (document.body.classList.contains('yan-acik')) document.body.classList.remove('yan-acik');
      else if (ui.modal) { ui.modal = null; ciz(); }
      if (st.adim && st.adim !== ui.adim && sayfaVarMi(st.adim)) { ui.adim = st.adim; ciz(); window.scrollTo(0, 0); }
      gecmisPlanla();
      return;
    }
    if (st.adim && st.adim !== ui.adim && sayfaVarMi(st.adim)) { ui.adim = st.adim; ciz(); window.scrollTo(0, 0); }
    gecmisPlanla();
  }

  // ---------- Onay penceresi (silme işlemleri) ----------
  /** Kalıcı ya da veri kaybettiren işlemlerden önce sorar. */
  function onayla(baslik, mesaj, buton, islem, tehlikesiz) {
    ui.onay = { baslik: baslik, mesaj: mesaj, buton: buton || 'Sil', islem: islem, tehlikesiz: !!tehlikesiz };
    onayCiz();
  }
  function onayCiz() {
    gecmisPlanla();
    var kok = $('#onay-kok');
    if (!ui.onay) { kok.innerHTML = ''; return; }
    var o = ui.onay;
    kok.innerHTML = '<div class="modal-arka onay-arka" data-a="onay-hayir"><div class="modal onay" data-durdur="1" role="alertdialog" aria-labelledby="onay-baslik">' +
      '<div class="onay-ikon' + (o.tehlikesiz ? ' bilgi' : '') + '">' + ikon(o.tehlikesiz ? 'uyari' : 'cop') + '</div>' +
      '<h3 id="onay-baslik">' + esc(o.baslik) + '</h3><p>' + o.mesaj + '</p>' +
      '<div class="satir sag">' + (o.ikinci ? '<button class="btn" data-a="onay-ikinci">' + esc(o.ikinci.metin) + '</button>' : '<button class="btn" data-a="onay-hayir">Vazgeç</button>') + '<button class="btn ' + (o.tehlikesiz ? 'ana' : 'tehlike-dolu') + '" data-a="onay-evet" id="onay-evet">' + esc(o.buton) + '</button></div></div></div>';
    setTimeout(function () { var b = $('#onay-evet'); if (b) b.focus(); }, 20);
  }

  // ---------- Hesaplar ----------
  function dersListesi() { return M.dersleriOlustur(durum, VERI); }
  function secmeliListesi(kapsam, anahtar) {
    if (kapsam === 'sube') {
      durum.subeSecmeli = durum.subeSecmeli || {};
      if (!durum.subeSecmeli[anahtar]) { var sb0 = sube(anahtar); durum.subeSecmeli[anahtar] = JSON.parse(JSON.stringify((sb0 && durum.secmeliler[sb0.sinif]) || [])); }
      return durum.subeSecmeli[anahtar];
    }
    return (durum.secmeliler[anahtar] = durum.secmeliler[anahtar] || []);
  }
  function ogretmenYukleri(dersler) {
    var y = {};
    durum.ogretmenler.forEach(function (o) { y[o.id] = 0; });
    dersler.forEach(function (d) { if (d.ogretmenId && y[d.ogretmenId] != null) y[d.ogretmenId] += d.saat; });
    return y;
  }
  /** Şube bazında haftalık saat doluluğu: MEB toplamı ve açık saat kapasitesiyle karşılaştırma */
  function subeDoluluk(dersler) {
    var t = tur(), D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat;
    dersler = dersler || dersListesi();
    var top = {};
    dersler.forEach(function (d) { top[d.subeId] = (top[d.subeId] || 0) + d.saat; });
    return durum.subeler.map(function (s) {
      var si = t.siniflar.indexOf(s.sinif);
      var meb = t.toplam[si] || 0, acik = D * H - ((durum.subeKapali || {})[s.id] || []).length, saat = top[s.id] || 0;
      return { sube: s, saat: saat, meb: meb, acik: acik, eksik: Math.max(0, meb - saat), fazla: Math.max(0, saat - meb), tasma: Math.max(0, saat - acik) };
    });
  }
  /** Şubenin haftalık ders toplamı ve MEB sınırı */
  function subeSaatleri(subeId, dersler) {
    var t = tur(), sb = sube(subeId);
    var top = (dersler || dersListesi()).filter(function (d) { return d.subeId === subeId; }).reduce(function (a, d) { return a + d.saat; }, 0);
    return { toplam: top, sinir: sb ? (t.toplam[t.siniflar.indexOf(sb.sinif)] || 0) : 0 };
  }
  /** Seçmeli listesinin saat toplamı */
  function secmeliToplam(liste, haric) { return liste.reduce(function (a, x, i) { return a + (i === haric ? 0 : (+x.saat || 0)); }, 0); }
  function secmeliGerekli(kapsam, anahtar) {
    var t = tur(), sinif = kapsam === 'sube' ? sube(anahtar).sinif : anahtar;
    return t.secmeliSaat[t.siniflar.indexOf(sinif)] || 0;
  }
  function doldurmaUyarisi(dersler) {
    var l = subeDoluluk(dersler);
    var eksik = l.filter(function (x) { return x.eksik; }), fazla = l.filter(function (x) { return x.fazla; }), tasma = l.filter(function (x) { return x.tasma; });
    if (!eksik.length && !fazla.length && !tasma.length) {
      return l.length ? '<div class="uyari basari">' + ikon('tamam') + '<div>Tüm şubelerin haftalık ders saati MEB toplamıyla uyumlu ve açık saatlere sığıyor.</div></div>' : '';
    }
    var h = '<div class="uyari dikkat">' + ikon('uyari') + '<div><b>Haftalık ders saati doldurma uyarısı</b><ul>';
    eksik.forEach(function (x) { h += '<li><b>' + esc(x.sube.ad) + '</b>: ' + x.saat + ' / ' + x.meb + ' saat — <b>' + x.eksik + ' saat eksik</b> (ders ekleyin, saat artırın ya da seçmeli seçin)</li>'; });
    fazla.forEach(function (x) { h += '<li><b>' + esc(x.sube.ad) + '</b>: ' + x.saat + ' / ' + x.meb + ' saat — ' + x.fazla + ' saat fazla</li>'; });
    tasma.forEach(function (x) { h += '<li><b>' + esc(x.sube.ad) + '</b>: ' + x.saat + ' saat ders, açık saat ' + x.acik + ' — <b>' + x.tasma + ' saat sığmaz</b></li>'; });
    return h + '</ul></div></div>';
  }
  function kontroller() {
    var dersler = dersListesi(), out = { hatalar: [], uyarilar: [], bilgiler: [] };
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat;
    subeDoluluk(dersler).forEach(function (x) {
      if (x.tasma) out.hatalar.push(x.sube.ad + ': haftalık ' + x.saat + ' saat, açık saat ' + x.acik + ' (' + D + ' gün × ' + H + ' ders' + (x.acik < D * H ? ', kapalı saatler düşüldü' : '') + ').');
      else if (x.eksik) out.uyarilar.push(x.sube.ad + ': haftalık ' + x.saat + '/' + x.meb + ' saat — ' + x.eksik + ' saat eksik.');
    });
    var kulupSaat = {};
    (durum.kulupler || []).forEach(function (k0) { (k0.subeIds || []).forEach(function (sid) { kulupSaat[sid] = (kulupSaat[sid] || 0) + (+k0.saat || 1); }); });
    subeDoluluk(dersler).forEach(function (x) {
      if (kulupSaat[x.sube.id] && !x.tasma && x.saat + kulupSaat[x.sube.id] > x.acik) out.hatalar.push(x.sube.ad + ': ' + x.saat + ' saat ders + ' + kulupSaat[x.sube.id] + ' saat kulüp, açık saat ' + x.acik + ' (K11/K15). Kulübü bu şubeden çıkarın ya da günlük ders saatini artırın.');
    });
    var yuk = ogretmenYukleri(dersler);
    durum.ogretmenler.forEach(function (o) {
      var kp = ogretmenKapasite(o);
      if (yuk[o.id] > kp.kesin) out.hatalar.push(o.ad + ': ' + yuk[o.id] + ' saat ders, açık saat ve günlük sınırla en fazla ' + kp.kesin + ' saat verilebilir.');
      else if (yuk[o.id] > kp.gunSiniriyla) out.uyarilar.push(o.ad + ': haftada en fazla ' + o.maxGun + ' gün isteği bu yükle sağlanamaz (en fazla ' + kp.gunSiniriyla + ' saat).');
      if (yuk[o.id] > (o.maxSaat || 30)) out.uyarilar.push(o.ad + ': ' + yuk[o.id] + ' saat (üst sınır ' + (o.maxSaat || 30) + ').');
    });
    var atanmamis = dersler.filter(function (d) { return !d.ogretmenId && d.ders !== 'Seçmeli Ders'; });
    if (atanmamis.length) out.uyarilar.push(atanmamis.length + ' derse öğretmen atanmamış; bu dersler öğretmen kısıtı olmadan yerleştirilir.');
    var sec = dersler.filter(function (d) { return d.ders === 'Seçmeli Ders'; });
    if (sec.length) out.bilgiler.push(sec.reduce(function (a, d) { return a + d.saat; }, 0) + ' saatlik seçmeli için ders seçilmemiş; “Seçmeli Ders” olarak yer ayrılır.');
    var ks = kilitSayisi();
    if (ks) out.bilgiler.push(ks + ' kilitli blok dağıtımda yerinde kalacak.');
    var veya = dersler.filter(function (d) { return d.yerlesimSecenekleri && d.yerlesimSecenekleri.length > 1; }).length;
    if (veya) out.bilgiler.push(veya + ' derste VEYA blok kuralı var; ilk kalıp sığmazsa sıradaki denenir.');
    if (!durum.subeler.length) out.hatalar.push('Hiç şube yok.');
    return out;
  }

  // ---------- Menü ----------
  var MENU = [
    { baslik: 'Başlangıç', adimlar: [
      { id: 'baslangic', ad: 'Genel bakış', ikon: 'ev' }] },
    { baslik: 'Kurulum', adimlar: [
      { id: 'okul', ad: 'Okul ve okul türü', ikon: 'okul' },
      { id: 'subeler', ad: 'Sınıflar ve şubeler', ikon: 'subeler' }] },
    { baslik: 'Dersler', adimlar: [
      { id: 'zorunlu', ad: 'Dersler ve şube atamaları', ikon: 'zorunlu' },
      { id: 'bloklar', ad: 'Blok düzeni', ikon: 'bloklar' },
      { id: 'derslikler', ad: 'Derslikler ve binalar', ikon: 'okul' }] },
    { baslik: 'Öğretmenler', adimlar: [
      { id: 'ogretmenler', ad: 'Öğretmen listesi', ikon: 'ogretmenler' },
      { id: 'atama', ad: 'Öğretmen atama', ikon: 'atama' },
      { id: 'kisitlar', ad: 'Kısıtlar ve kilitler', ikon: 'kisitlar' },
      { id: 'kulupler', ad: 'Sosyal kulüpler', ikon: 'secmeli' }] },
    { baslik: 'Program', adimlar: [
      { id: 'kurallar', ad: 'Dağıtım kuralları', ikon: 'bloklar' },
      { id: 'dagitim', ad: 'Dağıtım', ikon: 'dagitim' },
      { id: 'ciktilar', ad: 'Resmî çıktılar', ikon: 'ciktilar' },
      { id: 'raporlar', ad: 'Rapor merkezi', ikon: 'dagitim' },
      { id: 'nobet', ad: 'Nöbet programı', ikon: 'nobet' }] },
    { baslik: 'Sistem', adimlar: [
      { id: 'kaynaklar', ad: 'Kaynaklar', ikon: 'kaynaklar' },
      { id: 'veri', ad: 'Veri ve yedek', ikon: 'veri' },
      { id: 'ayarlar', ad: 'Ayarlar merkezi', ikon: 'kisitlar' }] }
  ];
  function adimDurumlari() {
    var dersler = dersListesi(), dol = subeDoluluk(dersler);
    var atanmamis = dersler.filter(function (d) { return !d.ogretmenId && d.ders !== 'Seçmeli Ders'; }).length;
    return {
      okul: { tamam: true },
      subeler: { tamam: durum.subeler.length > 0, sayi: durum.subeler.length },
      zorunlu: { tamam: dol.every(function (x) { return !x.eksik && !x.tasma; }), uyari: dol.some(function (x) { return x.eksik || x.tasma; }) },
      secmeli: { tamam: !dersler.some(function (d) { return d.ders === 'Seçmeli Ders'; }) },
      bloklar: {},
      ogretmenler: { tamam: durum.ogretmenler.length > 0, sayi: durum.ogretmenler.length },
      atama: { tamam: dersler.length > 0 && !atanmamis, uyari: atanmamis > 0, sayi: atanmamis || null },
      kisitlar: { sayi: kilitSayisi() || null },
      dagitim: { tamam: sonucGuvenliMi(durum.sonuc), uyari: !!(durum.sonuc && !sonucGuvenliMi(durum.sonuc)) },
      ciktilar: {}, nobet: {}, kaynaklar: {}, veri: {}
    };
  }
  // ---------- Kullanılabilirlik: adım akışı, yardım, genel bakış ----------
  /** İş akışındaki adımlar (sırası önemli) */
  var AKIS = ['okul', 'subeler', 'zorunlu', 'bloklar', 'derslikler', 'ogretmenler', 'atama', 'kisitlar', 'kulupler', 'kurallar', 'dagitim', 'ciktilar', 'nobet'];
  var ISTEGE_BAGLI = { derslikler: 1, bloklar: 1, kisitlar: 1, kulupler: 1, kurallar: 1, nobet: 1 };
  /** Her sayfa için kısa özet + adım adım kullanım */
  var YARDIM = {
    baslangic: { ozet: 'Okulunuzun hazır olma durumunu ve hızlı işlemleri tek ekranda takip edin.' },
    raporlar: { ozet: 'Dağıtımın kalitesini, motor denemelerini, kuralları ve performansı inceleyin.' },
    ayarlar: { ozet: 'Motor ve görünüm tercihlerini ayarlayın; veri, belge ve okul ayarlarına erişin.' },
    okul: { ozet: 'Okulunuzu ve türünü seçin; MEB ders çizelgesi otomatik gelir.',
      adimlar: ['Okul adını yazın.', 'Okul türünü seçin — dersler ve seçmeli havuzu buna göre gelir.', 'Haftalık gün ve günlük ders saati sayısını girin.', 'Ders başlangıç saati, süre ve teneffüsleri ayarlayın (çıktılarda görünür).'],
      ipucu: 'Denemek için “Örnek veriyle hızlı başla”ya basın: şubeler, öğretmenler ve program tek tıkla hazırlanır.' },
    subeler: { ozet: 'Her sınıf düzeyinde kaç şube olduğunu yazın ve “Oluştur”a basın.',
      adimlar: ['Her sınıf düzeyi için şube sayısını yazın.', 'Adlandırmayı seçin (A, B, C… ya da 1, 2, 3…).', '“Oluştur”a basın; şubelere MEB dersleri otomatik atanır.', 'Şube adını kutuya yazarak değiştirebilir, tek şube ekleyip silebilirsiniz.'],
      ipucu: 'Şube kartındaki “35/35” şubenin haftalık ders saatini gösterir; yeşil “tam” her şeyin yolunda olduğunu belirtir.' },
    zorunlu: { ozet: 'Önce sınıf düzeyini belirleyin; zorunlu ve seçmeli havuzlarından şubelere ders atayın.',
      adimlar: ['Tabloda her şubenin ders saatlerini kontrol edin.', 'Saati değiştirmek için kutuya yeni sayıyı yazın.', 'Dersi kaldırmak için çöp kutusuna basın; geri almak için “Geri al”.', 'Okula özel ders için tablonun altındaki “Ders ekle” bölümünü kullanın.'],
      ipucu: 'Haftalık toplam MEB sınırını aşamaz; aşarsa program sizi uyarır ve değeri düzeltir.' },
    secmeli: { ozet: 'Havuzdan seçmeli dersleri işaretleyip şubelere atayın.',
      adimlar: ['Üstten sınıf düzeyini seçin.', 'Soldaki havuzdan bir ya da birkaç ders işaretleyin (saatini yanından ayarlayın).', 'Sağdan şubeleri işaretleyin ya da “Tüm şubeler”i seçin.', 'Üstteki çubukta “Seçilenleri ata”ya basın.'],
      ipucu: 'Havuzda olmayan bir ders için “Manuel seçmeli ekle”yi kullanın. Şube kartındaki × dersi o şubeden kaldırır.' },
    bloklar: { ozet: 'İsteğe bağlı: derslerin haftaya nasıl bölüneceğini seçin (ör. 2+2 ya da 2+1+1).',
      adimlar: ['Varsayılan düzeni sağ üstten seçin (çoğu okul için “İkili bloklar” uygundur).', 'Bir derse özel düzen için kalıplara tıklayın; tıklama sırası öncelik sırasıdır.', 'Birden çok kalıp seçerseniz program önce ilkini dener, sığmazsa sonrakini kullanır (VEYA kuralı).'],
      ipucu: 'Emin değilseniz bu adımı atlayın; “oto” düzen çoğu durumda en iyi sonucu verir.' },
    ogretmenler: { ozet: 'Öğretmenleri ekleyin ya da branş ihtiyacına göre otomatik oluşturun.',
      adimlar: ['Ad soyad ve branş seçip “Ekle”ye basın; çok sayıda öğretmen için “Toplu ekle”yi açın.', 'Ya da sağ üstteki düğmeyle branş ihtiyacına göre öğretmenleri otomatik oluşturun.', 'Haftalık üst sınırı (ör. 30 saat) ve sosyal kulübü satırdan düzenleyin.', 'Birden çok öğretmeni işaretleyip toplu düzenleyebilir ya da silebilirsiniz.'],
      ipucu: 'Öğretmenlerin derslerini bir sonraki adımda (“Öğretmen atama”) belirlersiniz.' },
    atama: { ozet: 'Her derse bir öğretmen atayın; atanmamış ders kalmasın.',
      adimlar: ['“Eksikleri otomatik ata” ile tüm dersleri branşa göre hızlıca dağıtın.', 'Soldan bir öğretmen seçip ders havuzundan ona ders ekleyin.', 'Atanan dersin öğretmenini satırdaki listeden değiştirin.', '“Atanmamış” sekmesinde açıkta kalan dersleri tamamlayın.'],
      ipucu: 'Diğer sekmeler tüm atamaları tek ekranda gösterir. Herhangi bir derse sağ tıklayarak öğretmenini değiştirebilirsiniz.' },
    kisitlar: { ozet: 'İsteğe bağlı: öğretmenlerin gelemeyeceği gün ve saatleri belirleyin, dersleri saate kilitleyin.',
      adimlar: ['“Öğretmen kısıtları”nda gün düğmesine basarak o günü kapatın; saat saat ayar için “Saatler”.', '“Günde en fazla” ve “Haftada en fazla gün” sınırlarını girin.', 'Bir dersi belirli bir saate sabitlemek için “Sınıf/Öğretmen ders kilitleme” sekmesinde saate sağ tıklayıp dersi seçin.'],
      ipucu: '“Günde en fazla” kesin kuraldır; “haftada en fazla gün” (boş gün isteği) mümkün olduğunca sağlanır. Kilitli dersler dağıtımda yerinden oynamaz; çok fazla kısıt dağıtımı zorlaştırır.' },
    dagitim: { ozet: 'Programı oluşturun, raporu inceleyin; sonra dersleri taşıyıp kilitleyerek düzenleyin.',
      adimlar: ['“Dağıtımı başlat”a basın; program birkaç saniyede hazırlanır.', 'Şube ya da öğretmen programını seçip kontrol edin.', 'Bir derse tıklayıp boş saate (taşı) ya da başka derse (yer değiştir) tıklayın.', 'Beğendiğiniz programı “Dağıtımı kaydet” ile saklayın.'],
      ipucu: 'Bir hücreye sağ tıklayınca kilitleme, taşıma ve öğretmen değiştirme menüsü açılır.' },
    ciktilar: { ozet: 'Öğretmen ve şube programlarını resmî biçimde yazdırın ya da PDF alın.',
      adimlar: ['“Belge bilgileri”ni açıp müdür adı, öğretim yılı ve tarihi doldurun.', 'Öğretmen ya da şube programlarını seçin; tek kişi ya da tümü.', '“Yazdır / PDF”e basın.'],
      ipucu: 'Belge bilgileri bütün çıktılarda ortaktır; bir kez doldurmanız yeterli.' },
    nobet: { ozet: 'İsteğe bağlı: nöbet yerlerini ve dönemleri belirleyip nöbetleri otomatik dağıtın.',
      adimlar: ['Nöbet yerlerini ve her yerde günlük kaç öğretmen olacağını girin.', 'Dönemleri (tarih aralıkları) düzenleyin.', 'Dağıtım kuralını seçin (dengeli, dersin en az ya da en çok olduğu gün).', '“Nöbetleri otomatik dağıt”a basın; gerekirse tablodan elle değiştirin.'],
      ipucu: 'Nöbet dağıtımı ders programına göre yapılır; önce dağıtımı tamamlayın.' },
    kaynaklar: { ozet: 'MEB TTKB haftalık ders çizelgeleri, okul türleri ve ders havuzları.' },
    derslikler: { ozet: 'İsteğe bağlı: binaları, derslikleri ve özel derslik gerektiren dersleri tanımlayın (K12, K13).',
      adimlar: ['Birden çok binanız varsa binaları ekleyin.', '“Her şubeye sınıf dersliği oluştur” ile şube dersliklerini tek tıkla hazırlayın.', 'Laboratuvar, spor salonu, atölye gibi özel derslikleri ekleyin.', '“Önerilen eşleşmeleri uygula” ile dersleri uygun derslik türüne bağlayın.'],
      ipucu: 'Bina geçiş süresi teneffüsten uzunsa öğretmen farklı binalarda art arda derse girmez.' },
    kulupler: { ozet: 'İsteğe bağlı: sosyal kulüpleri öğretmen, şube ve saatiyle tanımlayın (K15).',
      adimlar: ['“Kulüp ekle”ye basın; ad kutusunda örnek kulüpler listelenir.', 'Danışman öğretmeni ve haftalık saati seçin.', 'Sabit bir saat seçin ya da “Otomatik” bırakın (CP-SAT bulur).', 'Katılan şubeleri tek tek ya da sınıf düzeyiyle seçin.'],
      ipucu: 'Kulüp saatinde öğretmen, katılan şubeler ve mekân başka derse verilmez.' },
    kurallar: { ozet: 'Bütün dağıtım kuralları tek yerde: zorunlu kurallar, esnetme izinleri, tercih öncelikleri, ders ayarları ve motor.',
      adimlar: ['Motoru seçin: Otomatik (CP-SAT → Genetik → Hızlı) veya tek motor.', 'Zorunlu kuralların ayarlarını kontrol edin (ör. günde en fazla 2 saat).', 'Tercihlerin önceliğini belirleyin: Yüksek → Orta → Düşük sırayla iyileştirilir.', 'Gerekirse esnetme izinlerini açın; ders ayarlarında dil, etiket ve derslik türü verin.'],
      ipucu: 'Çakışma, haftalık saat, kapalı saat ve kilit kuralları asla esnetilmez; program bunları çiğneyerek “başarılı” demez.' },
    veri: { ozet: 'Veriler kendiliğinden kaydedilir. Yedek almak ya da başka bilgisayara taşımak için JSON kullanın.',
      adimlar: ['“JSON indir” ile tüm projeyi tek dosya olarak yedekleyin.', 'Başka bilgisayarda “Dosya seç” ile bu dosyayı yükleyin.'],
      ipucu: 'Tarayıcı verisi silinirse önizleme kayıtları da silinir; düzenli yedek alın.' }
  };
  function menuAdimi(id) {
    for (var i = 0; i < MENU.length; i++) for (var j = 0; j < MENU[i].adimlar.length; j++) if (MENU[i].adimlar[j].id === id) return MENU[i].adimlar[j];
    return null;
  }
  /** Her adım için durum ve tek satırlık açıklama */
  function adimOzetleri() {
    var t = tur(), dersler = dersListesi(), dol = subeDoluluk(dersler), r = durum.sonuc;
    var atanmamis = dersler.filter(function (d) { return !d.ogretmenId && d.ders !== 'Seçmeli Ders'; });
    var yuk = ogretmenYukleri(dersler), asim = durum.ogretmenler.filter(function (o) { return (yuk[o.id] || 0) > (o.maxSaat || 30); });
    var sorunlu = dol.filter(function (x) { return x.eksik || x.tasma; }).length;
    var secEksik = durum.subeler.filter(function (s) { return dersler.some(function (d) { return d.subeId === s.id && d.ders === 'Seçmeli Ders'; }); }).length;
    var ozelBlok = Object.keys(durum.blokKurallari || {}).length + Object.keys(durum.yerlesimler || {}).length;
    var kisitli = durum.ogretmenler.filter(function (o) { return (o.kapali || []).length || o.maxGunluk || o.maxGun; }).length;
    var nobetSay = 0;
    (durum.nobet.donemler || []).forEach(function (d) { nobetSay += Object.keys(d.atama || {}).filter(function (k) { return d.atama[k] != null && nobetTutar(ogretmen(k)); }).length; });
    var o = {};
    o.okul = { durum: 'tamam', metin: (t ? t.ad : '') + ' · ' + durum.okul.gunSayisi + ' gün × ' + durum.okul.gunlukSaat + ' saat' };
    o.subeler = durum.subeler.length ? { durum: 'tamam', metin: durum.subeler.length + ' şube' } : { durum: 'eksik', metin: 'Henüz şube yok' };
    o.zorunlu = !durum.subeler.length ? { durum: 'bekliyor', metin: 'Önce şube oluşturun' } : (sorunlu ? { durum: 'uyari', metin: sorunlu + ' şubede haftalık saat MEB toplamıyla uyuşmuyor' } : { durum: 'tamam', metin: 'Tüm şubeler MEB saatinde' });
    o.secmeli = !durum.subeler.length ? { durum: 'bekliyor', metin: 'Önce şube oluşturun' } : (secEksik ? { durum: 'uyari', metin: secEksik + ' şubede seçmeli saati boş' } : { durum: 'tamam', metin: 'Seçmeliler tamam' });
    o.bloklar = { durum: 'istege', metin: ozelBlok ? ozelBlok + ' özel blok kuralı' : 'Varsayılan düzen kullanılıyor' };
    o.ogretmenler = durum.ogretmenler.length ? { durum: asim.length ? 'uyari' : 'tamam', metin: durum.ogretmenler.length + ' öğretmen' + (asim.length ? ' · ' + asim.length + ' öğretmen üst sınırı aşıyor' : '') } : { durum: 'eksik', metin: 'Henüz öğretmen yok' };
    o.atama = !durum.ogretmenler.length ? { durum: 'bekliyor', metin: 'Önce öğretmen ekleyin' } : (atanmamis.length ? { durum: 'uyari', metin: atanmamis.length + ' ders atanmamış (' + atanmamis.reduce(function (a, d) { return a + d.saat; }, 0) + ' saat)' } : { durum: 'tamam', metin: 'Tüm derslere öğretmen atandı' });
    o.derslikler = { durum: 'istege', metin: (durum.derslikler || []).length ? durum.derslikler.length + ' derslik · ' + (durum.binalar || []).length + ' bina' : 'Derslik tanımlı değil' };
    o.kulupler = { durum: 'istege', metin: (durum.kulupler || []).length ? durum.kulupler.length + ' kulüp' : 'Kulüp yok' };
    o.kurallar = { durum: 'istege', metin: 'Günde en fazla ' + kurallar().gunlukAyniDersMax + ' saat · motor: ' + (secilenMotor() === 'cpsat' ? 'CP-SAT' : secilenMotor() === 'genetik' ? 'Genetik' : secilenMotor() === 'otomatik' ? 'Otomatik' : 'Hızlı') };
    o.kisitlar = { durum: 'istege', metin: (kisitli ? kisitli + ' öğretmende kısıt' : 'Kısıt yok') + ' · ' + kilitSayisi() + ' kilit' };
    if (!r) o.dagitim = { durum: 'eksik', metin: 'Henüz dağıtılmadı' };
    else if (r.eski) o.dagitim = { durum: 'uyari', metin: 'Dersler/atamalar değişti — yeniden dağıtın' };
    else if (r.istatistik.eksikSaat) o.dagitim = { durum: 'uyari', metin: r.istatistik.eksikSaat + ' saat yerleşmedi' };
    else if (r.cozucu && r.cozucu.basarili === false) o.dagitim = { durum: 'uyari', metin: 'Kurallar sağlanamadı — raporu inceleyin' };
    else if (!sonucGuvenliMi(r)) o.dagitim = { durum: 'uyari', metin: 'Kural doğrulaması gerekli — raporu inceleyin' };
    else o.dagitim = { durum: 'tamam', metin: 'Program hazır · ' + r.istatistik.toplamSaat + ' saat yerleşti' };
    o.ciktilar = !r ? { durum: 'bekliyor', metin: 'Önce dağıtım yapın' } : sonucGuvenliMi(r) ? { durum: 'hazir', metin: 'Yazdırmaya hazır · ' + durum.ogretmenler.length + ' öğretmen, ' + durum.subeler.length + ' şube' } : { durum: 'uyari', metin: 'Taslak program — kural denetimi gerekli' };
    o.nobet = { durum: nobetSay ? 'tamam' : 'istege', metin: nobetSay ? nobetSay + ' nöbet ataması' : 'Nöbet dağıtılmadı' };
    return o;
  }
  /** Tamamlanmamış ilk zorunlu adım */
  function siradakiAdim(oz) {
    oz = oz || adimOzetleri();
    for (var i = 0; i < AKIS.length; i++) { var x = oz[AKIS[i]]; if (!ISTEGE_BAGLI[AKIS[i]] && (x.durum === 'eksik' || x.durum === 'uyari')) return AKIS[i]; }
    return null;
  }
  var DURUM_ETIKET = { tamam: ['yesil', 'Tamam'], uyari: ['sari', 'Dikkat'], eksik: ['kirmizi', 'Yapılacak'], bekliyor: ['', 'Bekliyor'], istege: ['', 'İsteğe bağlı'], hazir: ['mavi', 'Hazır'] };
  function yardimGoruldu(id) { try { return JSON.parse(localStorage.getItem('ders-dagitim-yardim') || '{}')[id]; } catch (e) { return true; } }
  function yardimIsaretle(id) { try { var g = JSON.parse(localStorage.getItem('ders-dagitim-yardim') || '{}'); g[id] = 1; localStorage.setItem('ders-dagitim-yardim', JSON.stringify(g)); } catch (e) { /* depolama kapalı */ } }
  /** Sayfa başlığının altındaki katlanır "Nasıl kullanılır?" paneli */
  function yardimPaneli() {
    var y = YARDIM[ui.adim];
    if (!y || !y.adimlar) return '';
    ui.yardimAcik = ui.yardimAcik || {};
    if (ui.yardimAcik[ui.adim] == null) { ui.yardimAcik[ui.adim] = !yardimGoruldu(ui.adim); yardimIsaretle(ui.adim); }
    if (!ui.yardimAcik[ui.adim]) return '';
    return '<section class="yardim-panel yazdirma-gizle" aria-label="Nasıl kullanılır"><ol class="yardim-adimlar">' +
      y.adimlar.map(function (x, i) { return '<li><span class="ya-no">' + (i + 1) + '</span><span>' + x + '</span></li>'; }).join('') + '</ol>' +
      (y.ipucu ? '<p class="yardim-ipucu">' + ikon('yardim') + '<span>' + y.ipucu + '</span></p>' : '') +
      '<button class="yardim-kapat" data-a="yardim-ac" title="Yardımı gizle" aria-label="Yardımı gizle">×</button></section>';
  }
  /** Sayfa altı: önceki / sonraki adım */
  function adimGezinti() {
    var i = AKIS.indexOf(ui.adim);
    if (i < 0) return '';
    var oz = adimOzetleri(), on = AKIS[i - 1], son = AKIS[i + 1], bu = oz[ui.adim];
    var ad = function (id) { return (AKIS.indexOf(id) + 1) + '. ' + menuAdimi(id).ad; };
    var h = '<nav class="adim-gezinti yazdirma-gizle" aria-label="Adımlar arasında gezin">';
    h += on ? '<button class="btn" data-a="adim" data-v="' + on + '">← ' + esc(ad(on)) + '</button>' : '<span></span>';
    h += '<span class="ag-orta">Adım ' + (i + 1) + ' / ' + AKIS.length + ' · <span class="etiket ' + DURUM_ETIKET[bu.durum][0] + '">' + DURUM_ETIKET[bu.durum][1] + '</span></span>';
    h += son ? '<button class="btn' + (bu.durum === 'tamam' || bu.durum === 'istege' || bu.durum === 'hazir' ? ' ana' : '') + '" data-a="adim" data-v="' + son + '">' + esc(ad(son)) + ' →</button>' : '<span></span>';
    return h + '</nav>';
  }
  /** Tasarım 2.0 / Aşama 4: gerçeğe bağlı, veri değiştirmeyen ana sayfa. */
  function dd4Metrik(ikonAd, bas, say, alt, ton) {
    return '<div class="dd4-metrik dd4-ton-' + (ton || 'mavi') + '"><div class="dd4-metrik-simge">' + ikon(ikonAd) + '</div>' +
      '<div class="dd4-metrik-kopya"><span>' + esc(bas) + '</span><b>' + esc(say) + '</b><small>' + esc(alt || '') + '</small></div></div>';
  }
  function baslangicCiz() {
    var t = tur(), oz = adimOzetleri(), sira = siradakiAdim(oz), dersler = dersListesi(), r = durum.sonuc;
    var zorunlu = AKIS.filter(function (id) { return !ISTEGE_BAGLI[id] && id !== 'ciktilar'; });
    var biten = zorunlu.filter(function (id) { return oz[id].durum === 'tamam'; }).length;
    var yuzde = zorunlu.length ? Math.round(biten / zorunlu.length * 100) : 0;
    var atanmamis = dersler.filter(function (d) { return !d.ogretmenId && d.ders !== 'Seçmeli Ders'; }).length;
    var toplam = dersler.reduce(function (n, d) { return n + (+d.saat || 0); }, 0);
    var yerlesen = r && r.istatistik ? (+r.istatistik.toplamSaat || 0) - (+r.istatistik.eksikSaat || 0) : 0;
    var tam = !!(r && r.istatistik && !r.eski && !r.istatistik.eksikSaat && !(r.cozucu && r.cozucu.kuralIhlalleri || []).length && !(r.cozucu && r.cozucu.basarili === false));
    var durumAd = !r ? 'Henüz dağıtım yok' : (r.eski ? 'Yeniden kontrol gerekli' : (tam ? 'Dağıtım hazır' : 'Dağıtım eksik'));
    var h = '<div class="dd4-page dd4-home"><section class="dd4-hero"><div class="dd4-hero-metin"><span class="dd4-eyebrow">OKUL PLANLAMA MERKEZİ <i></i> GENEL BAKIŞ</span>' +
      '<h2>' + esc(durum.okul.ad || 'Okulunuz') + '</h2><p>' + esc(t ? t.ad : 'Okul türü seçilmedi') + '</p>' +
      '<div class="dd4-hero-islemler"><button class="dd4-beyaz-btn" data-a="adim" data-v="dagitim">' + ikon('dagitim') + 'Dağıtım merkezine git</button>' +
      '<button class="dd4-seffaf-btn" data-a="adim" data-v="ayarlar">' + ikon('kisitlar') + 'Ayarlar</button></div></div>' +
      '<div class="dd4-hero-ilerleme"><span>Hazırlık durumu</span><strong>' + yuzde + '%</strong><div class="dd4-progress"><i style="width:' + yuzde + '%"></i></div><small>' + biten + ' / ' + zorunlu.length + ' temel adım tamamlandı</small></div></section>';
    h += '<div class="dd4-metrikler">' + dd4Metrik('subeler', 'Şubeler', durum.subeler.length, (t ? t.siniflar.length : 0) + ' sınıf düzeyi') +
      dd4Metrik('ogretmenler', 'Öğretmenler', durum.ogretmenler.length, 'Kayıtlı öğretmen') +
      dd4Metrik('zorunlu', 'Haftalık ders yükü', toplam, 'Toplam ders saati') +
      dd4Metrik('kisitlar', 'Ön kilit', kilitSayisi(), 'Sabit yerleştirme', 'mor') +
      dd4Metrik('uyari', 'Öğretmen bekleyen', atanmamis, 'Ders ataması eksik', atanmamis ? 'sari' : 'yesil') +
      dd4Metrik('dagitim', 'Yerleşen saat', r ? yerlesen + '/' + (+r.istatistik.toplamSaat || toplam) : '—', durumAd, tam ? 'yesil' : 'sari') + '</div>';
    h += '<div class="dd4-home-grid"><section class="dd4-yuzey dd4-gorevler"><div class="dd4-bolum-ust"><div><span class="dd4-kicker">HAZIRLIK</span><h3>Çalışma adımları</h3></div>' +
      (sira ? '<button class="btn ana" data-a="adim" data-v="' + sira + '">Sıradaki adıma geç ' + ikon('oynat') + '</button>' : '<button class="btn" data-a="adim" data-v="ciktilar">Çıktılara git</button>') + '</div>' +
      '<div class="dd4-gorev-liste">' + ['subeler','ogretmenler','atama','kisitlar','dagitim','ciktilar'].map(function (id) {
         var a = menuAdimi(id), x = oz[id] || {durum:'hazir',metin:''};
         return '<button class="dd4-gorev" data-a="adim" data-v="' + id + '"><span class="dd4-gorev-ikon">' + ikon(a.ikon) + '</span><span class="dd4-gorev-ad"><b>' + esc(a.ad) + '</b><small>' + esc(x.metin || '') + '</small></span><span class="dd4-gorev-durum ' + (x.durum === 'tamam' ? 'tamam' : '') + '">' + (x.durum === 'tamam' ? 'Tamam' : x.durum === 'uyari' ? 'Kontrol et' : 'Aç') + '</span></button>';
      }).join('') + '</div></section>';
    h += '<div class="dd4-home-sag"><section class="dd4-yuzey"><div class="dd4-bolum-ust"><div><span class="dd4-kicker">SON DAĞITIM</span><h3>Program durumu</h3></div><span class="dd4-durum ' + (tam ? 'iyi' : '') + '">' + esc(durumAd) + '</span></div>' +
      '<div class="dd4-rapor-ozet"><p>' + (r ? 'Yerleştirilen ders: ' + yerlesen + ' saat' + (r.eski ? ' · Ders verileri değişti' : '') : 'Henüz dağıtım çalıştırılmadı.') + '</p></div>' +
      '<button class="dd4-duz-link" data-a="adim" data-v="' + (r ? 'raporlar' : 'dagitim') + '">' + (r ? 'Raporu incele' : 'Boş çizelgeyi aç') + ' →</button></section>' +
      '<section class="dd4-yuzey"><div class="dd4-bolum-ust"><div><span class="dd4-kicker">HIZLI ERİŞİM</span><h3>Sık kullanılan işlemler</h3></div></div>' +
      '<div class="dd4-hizli-grid">' + [['ogretmenler','Öğretmen ekle','ogretmenler'],['subeler','Şube yönetimi','subeler'],['kisitlar','Gün / saat kapat','kisitlar'],['ciktilar','A4 çıktı','ciktilar'],['raporlar','Rapor merkezi','dagitim'],['veri','Yedekle','indir']].map(function (x) {
        return '<button class="dd4-hizli" data-a="adim" data-v="' + x[0] + '">' + ikon(x[2]) + '<span>' + x[1] + '</span></button>'; }).join('') + '</div></section></div></div></div>';
    return h;
  }

  /** Tasarım 2.0: menüde arama / bölüm aç-kapat; ders ve dağıtım durumundan bağımsızdır. */
  function menuAraUygula() {
    var q = String(ui.menuArama || '').trim().toLocaleLowerCase('tr-TR');
    var input = $('#menu-ara');
    if (input && input.value !== ui.menuArama) input.value = ui.menuArama;
    document.querySelectorAll('#yan .menu-grup').forEach(function (g) {
      var baslik = (g.getAttribute('data-baslik') || '').toLocaleLowerCase('tr-TR');
      var tumu = !!q && baslik.indexOf(q) >= 0;
      var bulunan = 0;
      g.querySelectorAll('.adim').forEach(function (a) {
        var uyuyor = !q || tumu || a.textContent.toLocaleLowerCase('tr-TR').indexOf(q) >= 0;
        a.hidden = !uyuyor;
        if (uyuyor) bulunan++;
      });
      g.hidden = !!q && !bulunan;
      g.classList.toggle('arama-var', !!q);
    });
    var yok = $('#menu-sonuc-yok');
    if (yok) yok.hidden = !q || !!document.querySelector('#yan .menu-grup:not([hidden])');
  }
  function yanCiz() {
    var dur = adimDurumlari(), oz = adimOzetleri(), sira = siradakiAdim(oz);
    var numaraliMenu = 0;
    var h = '<div class="yan-kimlik"><div class="yan-kimlik-ikon">' + ikon('dagitim') + '</div><div class="yan-kimlik-yazi"><b>Çalışma alanı</b><small>Okul planlama araçları</small></div></div>' +
      '<div class="yan-ara"><label for="menu-ara" class="ekran-okuyucu">Menülerde ara</label><svg class="ikon" viewBox="0 0 24 24" aria-hidden="true"><path d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14M16 16l5 5"/></svg>' +
      '<input id="menu-ara" type="search" placeholder="Menü ara..." autocomplete="off" value="' + esc(ui.menuArama) + '"></div>';
    h += MENU.map(function (g, gi) {
      var acik = ui.tasarimGruplar[gi] !== false;
      return '<div class="menu-grup' + (acik ? '' : ' dar') + '" data-grup="' + gi + '" data-baslik="' + esc(g.baslik) + '">' +
        '<button class="menu-baslik" type="button" data-a="tasarim-grup" data-v="' + gi + '" aria-expanded="' + acik + '"><span>' + esc(g.baslik) + '</span><svg viewBox="0 0 24 24" class="ikon" aria-hidden="true"><path d="M7 10l5 5 5-5"/></svg></button>' +
        '<div class="menu-icerik">' + g.adimlar.map(function (a) {
        var d = dur[a.id] || {}, n = AKIS.indexOf(a.id), x = oz[a.id], menuSira = ++numaraliMenu;
        var rozet = d.sayi ? '<span class="menu-sayi' + (d.uyari ? ' sari' : '') + '">' + d.sayi + '</span>' : (x && x.durum === 'uyari' ? '<span class="menu-sayi sari" title="' + esc(x.metin) + '">!</span>' : '');
        var sol = '<span class="dd5-menu-numara">' + menuSira + '</span>';
        var ipucu = x ? menuSira + '. menü — ' + x.metin + (ISTEGE_BAGLI[a.id] ? ' (isteğe bağlı)' : '') : a.ad;
        return '<button type="button" class="adim' + (ui.adim === a.id ? ' aktif' : '') + (a.id === sira ? ' sirada' : '') + '" data-a="adim" data-v="' + a.id + '" title="' + esc(ipucu) + '"' + (ui.adim === a.id ? ' aria-current="page"' : '') + '>' + sol + '<span class="adim-ad">' + a.ad + (ISTEGE_BAGLI[a.id] ? '<small>isteğe bağlı</small>' : '') + '</span>' + rozet + '</button>';
      }).join('') + '</div></div>';
    }).join('');
    h += '<p id="menu-sonuc-yok" class="yan-bos-sonuc" hidden>Aramanıza uygun menü bulunamadı.</p>' +
      '<div class="yan-alt"><b>EVRAKPLUS</b><span>Sürüm ' + esc(VERI.surum) + ' · ' + (CFG.mod === 'sunucu' ? 'Hesabınıza bağlı' : 'Önizleme') + '</span>' +
      '<button type="button" data-a="adim" data-v="veri">' + ikon('indir') + ' Verileri yedekle</button></div>';
    $('#yan').innerHTML = h;
    menuAraUygula();
  }
  function ustCiz() {
    var el = $('#ust-eylemler');
    var h = '';
    if (CFG.mod === 'sunucu') {
      h += '<select id="proje-sec" class="ust-sec" title="Kayıtlı projeler"><option value="">Projeler…</option>' +
        ui.projeler.map(function (p) { return '<option value="' + esc(p.id) + '"' + (durum.projeId == p.id ? ' selected' : '') + '>' + esc(p.ad) + '</option>'; }).join('') + '</select>';
      h += '<button class="btn ust" data-a="kaydet">' + ikon('kaydet') + 'Kaydet</button>';
    }
    h += '<button class="btn ust" data-a="adim" data-v="veri">' + ikon('indir') + 'Yedek</button>';
    if (CFG.mod === 'sunucu' && CFG.wp) {
      h = '<a class="btn ust site-don" href="' + esc(CFG.anaSayfa || 'https://www.evrakplus.com/') + '" title="evrakplus.com ana sayfasına dön">' + ikon('ev') + '<span>evrakplus.com</span></a>' + h;
      if (CFG.yonetici) h += '<a class="btn ust" href="' + esc(CFG.kurulumUrl) + '" title="Sunucu kurulum denetimi (yalnız site yöneticileri görür)">Sunucu</a>';
      h += '<span class="ust-uye" title="evrakplus.com hesabı">' + ikon('ogretmenler') + '<span>' + esc(CFG.kullanici ? CFG.kullanici.ad : '') + '</span></span>';
      h += '<a class="btn ust" href="' + esc(CFG.cikisUrl) + '" title="evrakplus.com oturumunu kapat">Çıkış</a>';
    } else if (CFG.mod === 'sunucu' && CFG.giris) h += '<a class="btn ust" href="kurulum.php" title="Sunucu kurulum denetimi">Sunucu</a><a class="btn ust" href="cikis.php" title="Oturumu kapat">Çıkış</a>';
    el.innerHTML = h;
    var t = tur();
    $('#ust-okul').textContent = durum.okul.ad + (t ? ' · ' + t.ad : '');
    var kabukMenu = $('#tasarim-menu-dug');
    if (kabukMenu) kabukMenu.setAttribute('aria-pressed', String(document.body.classList.contains('yan-dar')));
    kayitDurumu(ui.kayit.durum);
  }
  /** Sayfa başlığı */
  function sayfaBasi(baslik, aciklama, eylemler) {
    var menuNo = 0, menuToplam = 0;
    MENU.forEach(function (grup) { grup.adimlar.forEach(function (a) { menuToplam++; if (a.id === ui.adim) menuNo = menuToplam; }); });
    var ust = menuNo ? '<span class="sayfa-ust">Menü ' + menuNo + ' / ' + menuToplam + (ISTEGE_BAGLI[ui.adim] ? ' · isteğe bağlı' : '') + '</span>' : '';
    return '<header class="sayfa-basi"><div>' + ust + '<div class="baslik-satir"><h2>' + baslik + '</h2></div></div>' +
      (eylemler ? '<div class="sayfa-eylem">' + eylemler + '</div>' : '') + '</header>';
  }
  function sekmeler(eylem, secili, liste) {
    return '<div class="sekme">' + liste.map(function (x) {
      return '<button data-a="' + eylem + '" data-v="' + x[0] + '" class="' + (secili === x[0] ? 'aktif' : '') + '">' + x[1] + '</button>';
    }).join('') + '</div>';
  }

  // ---- Tasarım 2.0 / Aşama 3: veri giriş ekranları için yerel görünüm katmanı ----
  // Bu özet ve filtreler kayıtlı proje verilerini değiştirmez.
  function dd3Panel(adim) {
    var ozetler = {
      ogretmenler: { baslik: 'Öğretmen yönetimi', alt: 'Öğretmen ekleyin, kapasiteyi kontrol edin ve ders atamasına geçin.', ikon: 'ogretmenler' },
      subeler: { baslik: 'Şube yönetimi', alt: 'Şubeleri oluşturun ve haftalık ders yüklerini denetleyin.', ikon: 'subeler' },
      zorunlu: { baslik: 'Ders yükleri', alt: 'MEB ders saatlerini şube bazında yönetin.', ikon: 'zorunlu' },
      secmeli: { baslik: 'Seçmeli dersler', alt: 'Ders havuzunu ve şube seçimlerini aynı ekranda yönetin.', ikon: 'secmeli' },
      bloklar: { baslik: 'Blok ders düzeni', alt: 'Haftalık ders saatlerinin bloklara bölünmesini denetleyin.', ikon: 'bloklar' },
      atama: { baslik: 'Öğretmen atamaları', alt: 'Derslerin öğretmen ve şubelere dağılımını yönetin.', ikon: 'atama' },
      kisitlar: { baslik: 'Uygunluk ve kilitler', alt: 'Kapalı günleri, saatleri ve ön kilitleri denetleyin.', ikon: 'kisitlar' },
      derslikler: { baslik: 'Yerleşke yönetimi', alt: 'Binaları, derslikleri ve geçiş kurallarını düzenleyin.', ikon: 'okul' }
    };
    var cfg = ozetler[adim];
    if (!cfg) return '';
    var dersler = dersListesi(), yuk = ogretmenYukleri(dersler), toplamSaat = dersler.reduce(function (a, d) { return a + d.saat; }, 0);
    var atanmamis = dersler.filter(function (d) { return !d.ogretmenId && d.ders !== 'Seçmeli Ders'; });
    var kısıtlıOgr = durum.ogretmenler.filter(function (o) { return (o.kapali || []).length || o.maxGunluk || o.maxGun; }).length;
    var saatAsan = durum.ogretmenler.filter(function (o) { return (yuk[o.id] || 0) > (o.maxSaat || durum.ayarlar.maxSaat || 30); }).length;
    var dol = subeDoluluk(dersler), tamSube = dol.filter(function (d) { return !d.eksik && !d.fazla && !d.tasma; }).length;
    var sinifDersliksiz = durum.subeler.filter(function (sb) { return !sb.derslikId; }).length;
    var sayilar = {
      ogretmenler: [[durum.ogretmenler.length,'Öğretmen'],[toplamSaat,'Haftalık ders saati'],[saatAsan,'Sınırı aşan']],
      subeler: [[durum.subeler.length,'Şube'],[tamSube,'Saati tamam'],[durum.subeler.length-tamSube,'Kontrol gereken']],
      zorunlu: [[durum.subeler.length,'Şube'],[toplamSaat,'Toplam ders saati'],[durum.ekDersler.length,'Ek ders tanımı']],
      secmeli: [[durum.subeler.length,'Şube'],[dersler.filter(function (d) { return d.grup === 'Seçmeli'; }).length,'Seçmeli ders'],[toplamSaat,'Toplam saat']],
      bloklar: [[dersler.length,'Ders kaydı'],[dersler.filter(function (d) { return d.saat >= 2; }).length,'Blok adayı'],[durum.subeler.length,'Şube']],
      atama: [[dersler.length,'Ders kaydı'],[atanmamis.length,'Atanmamış ders'],[durum.ogretmenler.length,'Öğretmen']],
      kisitlar: [[kısıtlıOgr,'Kısıtlı öğretmen'],[kilitSayisi(),'Ön kilit'],[durum.subeler.length,'Şube']],
      derslikler: [[(durum.binalar || []).length,'Bina'],[(durum.derslikler || []).length,'Derslik'],[sinifDersliksiz,'Dersliği atanmayan şube']]
    }[adim];
    var baglantilar = adim === 'ogretmenler' ? [['atama','Ders ata'],['kisitlar','Uygunluk']] :
      adim === 'subeler' ? [['zorunlu','Ders yükleri'],['kisitlar','Kapalı günler']] :
      adim === 'derslikler' ? [['kurallar','Ders kuralları'],['dagitim','Dağıtım']] :
      adim === 'kisitlar' ? [['dagitim','Boş çizelgeler'],['ogretmenler','Öğretmenler']] :
      [['zorunlu','Zorunlu'],['secmeli','Seçmeli'],['bloklar','Bloklar'],['atama','Atama']].filter(function (x) { return x[0] !== adim; });
    var ara = ['ogretmenler','subeler','kisitlar','derslikler'].indexOf(adim) >= 0;
    var h = '<section class="dd3-ust" aria-label="' + esc(cfg.baslik) + ' özeti">' +
      '<div class="dd3-ust-sol"><div class="dd3-eyebrow">EVRAKPLUS <span>/</span> VERİ YÖNETİMİ</div><div class="dd3-ust-kimlik">' + ikon(cfg.ikon) + '<div><strong>' + esc(cfg.baslik) + '</strong></div></div></div>' +
      '<div class="dd3-metrikler">' + sayilar.map(function (x,i) { return '<div class="dd3-metrik' + (i === 2 && +x[0] > 0 && ['ogretmenler','subeler','atama','derslikler'].indexOf(adim) >= 0 ? ' dd3-dikkat' : '') + '"><b>' + x[0] + '</b><span>' + esc(x[1]) + '</span></div>'; }).join('') + '</div></section>';
    // 5. ve 8. menülerin üstündeki düğmeler sayfa bağlantısı değil, gerçek yerel sekmelerdir.
    var yerelSekmeler = null;
    var kisaYol = adim === 'bloklar' ? '<div class="dd6-all-indicator">Zorunlu + Seçmeli · Tüm dersler tek ekranda</div>' : adim === 'atama' ? '<div class="dd6-all-indicator">Zorunlu + Seçmeli · Öğretmen atamaları tek listede</div>' : yerelSekmeler ?
      '<div class="dd3-kisayollar dd3-yerel-sekmeler" role="tablist" aria-label="' + (adim === 'bloklar' ? 'Blok düzeni' : 'Öğretmen atama') + ' alt bölümleri">' +
      yerelSekmeler.map(function (b) {
        var aktif = (adim === 'bloklar' ? (ui.blokYerelSekme || 'zorunlu') : (ui.atamaYerelSekme || 'zorunlu')) === b[0];
        return '<button type="button" role="tab" aria-selected="' + aktif + '" class="dd3-kisayol dd3-yerel-sekme' + (aktif ? ' aktif' : '') + '" data-a="dd3-yerel-sekme" data-v="' + b[0] + '">' + esc(b[1]) + '</button>';
      }).join('') + '</div>' :
      '<div class="dd3-kisayollar" aria-label="İlgili ekranlar">' + baglantilar.map(function (b) { return '<button type="button" class="dd3-kisayol" data-a="adim" data-v="' + b[0] + '">' + esc(b[1]) + '</button>'; }).join('') + '</div>';
    h += '<div class="dd3-araclar">' + kisaYol;
    if (ara) {
      ui.dd3Aramalar = ui.dd3Aramalar || {};
      ui.dd3Filtreler = ui.dd3Filtreler || {};
      var dd3Secim = ui.dd3Filtreler[adim] || '';
      h += '<div class="dd3-arama-kutu">' + ikon('ogretmenler') + '<input type="search" data-a="dd3-ara" aria-label="Bu sayfada ara" placeholder="' + (adim==='ogretmenler' ? 'Öğretmen veya branş ara…' : adim==='subeler' ? 'Şube veya sınıf ara…' : adim==='kisitlar' ? 'Öğretmen veya şube ara…' : 'Derslik, bina veya tür ara…') + '" value="' + esc(ui.dd3Aramalar[adim] || '') + '"></div>';
      if (adim === 'ogretmenler') h += '<select class="dd3-yerel-filtre" data-a="dd3-durum" aria-label="Öğretmen kapasitesi filtrele">' + [['','Tüm öğretmenler'],['bos','Ders atanmayanlar'],['asim','Sınırı aşanlar']].map(function (x) { return '<option value="' + x[0] + '"' + (x[0] === dd3Secim ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select>';
      if (adim === 'derslikler') h += '<select class="dd3-yerel-filtre" data-a="dd3-tur" aria-label="Derslik türü filtrele">' + [['','Tüm derslik türleri']].concat(DERSLIK_TURLERI).map(function (t) { return '<option value="' + esc(t[0]) + '"' + (t[0] === dd3Secim ? ' selected' : '') + '>' + esc(t[1]) + '</option>'; }).join('') + '</select>';
      h += '<span class="dd3-sonuc" id="dd3-sonuc" role="status" aria-live="polite"></span>';
    }
    return h + '</div>';
  }
  function dd3FiltreUygula() {
    var kok = document.querySelector('#icerik .dd3-page'); if (!kok) return;
    var aramaEl = kok.querySelector('[data-a="dd3-ara"]'); if (!aramaEl) return;
    var q = (aramaEl.value || '').toLocaleLowerCase('tr').trim();
    var durumEl = kok.querySelector('[data-a="dd3-durum"]');
    var turEl = kok.querySelector('[data-a="dd3-tur"]');
    var durumSec = durumEl ? durumEl.value : '', turSec = turEl ? turEl.value : '';
    var sayi = 0, tum = 0;
    kok.querySelectorAll('[data-dd3-ara]').forEach(function (el) {
      var metin = (el.getAttribute('data-dd3-ara') || '').toLocaleLowerCase('tr');
      var uygun = !q || metin.indexOf(q) >= 0;
      if (durumSec) uygun = uygun && el.getAttribute('data-dd3-durum') === durumSec;
      if (turSec) uygun = uygun && el.getAttribute('data-dd3-tur') === turSec;
      el.hidden = !uygun; tum++; if (uygun) sayi++;
    });
    kok.querySelectorAll('.dd3-grup').forEach(function (grup) {
      var satirlar = grup.querySelectorAll('[data-dd3-ara]');
      if (!satirlar.length) { grup.hidden = !!q && (grup.getAttribute('data-dd3-baslik') || '').toLocaleLowerCase('tr').indexOf(q) < 0; return; }
      var baslikUyuyor = !!q && (grup.getAttribute('data-dd3-baslik') || '').toLocaleLowerCase('tr').indexOf(q) >= 0;
      if (baslikUyuyor) satirlar.forEach(function (el) { if (el.hidden) { el.hidden = false; sayi++; } });
      grup.hidden = !Array.prototype.some.call(satirlar, function (el) { return !el.hidden; });
    });
    var sonuc = kok.querySelector('#dd3-sonuc'); if (sonuc) sonuc.textContent = (q || durumSec || turSec) ? sayi + ' / ' + tum + ' kayıt' : '';
    var bos = kok.querySelector('#dd3-arama-bos'); if (bos) bos.hidden = !(tum > 0 && sayi === 0);
  }
  function ciz() {
    dd6PanelKapat();
    ustCiz();
    yanCiz();
    altGezintiCiz();
    var sayfalar = { raporlar: dd4RaporlarCiz, ayarlar: dd4AyarlarCiz, kurallar: kurallarCiz, derslikler: dersliklerCiz, kulupler: kuluplerCiz, baslangic: baslangicCiz, okul: okulCiz, subeler: subelerCiz, zorunlu: dd5DersHavuzlariCiz, secmeli: dd5DersHavuzlariCiz, bloklar: bloklarCiz, ogretmenler: ogretmenlerCiz, atama: atamaCiz, kisitlar: kisitlarCiz, dagitim: dagitimCiz, ciktilar: ciktilarCiz, nobet: nobetCiz, kaynaklar: kaynaklarCiz, veri: veriCiz };
    var f = sayfalar[ui.adim] || baslangicCiz;
    // Sekmeler, menüyü değiştirmek yerine yalnızca menünün içeriğini değiştirir.
    var dd3Icerik;
    if (ui.adim === 'bloklar') {
      dd3Icerik = bloklarCiz('hepsi');
    } else if (ui.adim === 'atama') {
      dd3Icerik = atamaCiz();
    } else dd3Icerik = f();
    var dd3Aktif = ['ogretmenler','subeler','bloklar','atama','kisitlar','derslikler'].indexOf(ui.adim) >= 0;
    $('#icerik').innerHTML = (dd3Aktif ? '<div class="dd3-page dd3-' + ui.adim + '">' + dd3Panel(ui.adim) : '') + dd3Icerik + (dd3Aktif ? '<p id="dd3-arama-bos" class="dd3-bos-sonuc" hidden>Aramanızla eşleşen kayıt bulunamadı.</p></div>' : '') + adimGezinti();
    if (dd3Aktif) dd3FiltreUygula();
    if (ui.adim === 'zorunlu' || ui.adim === 'secmeli') {
      dd8Filtrele();
      var q6 = (ui.dd6ZorAra || '').toLocaleLowerCase('tr-TR').trim();
      document.querySelectorAll('.dd6-zor-oge').forEach(function (btn) { btn.hidden = (btn.getAttribute('data-dd6-search') || '').indexOf(q6) < 0; });
    }
    if (ui.adim === 'dagitim') {
      document.querySelectorAll('#icerik td[data-dd5-slot]').forEach(function (td) {
        td.tabIndex = 0;
        td.setAttribute('role', 'button');
        td.setAttribute('aria-haspopup', 'dialog');
        td.setAttribute('aria-label', (td.getAttribute('aria-label') || td.getAttribute('title') || td.textContent.trim() || 'Boş saat') + ' — düzenleme menüsünü aç');
      });
      dd2CarsafFiltrele(ui.dd2CarsafAra);
    }
    aramaUygula();
    modalCiz();
    onayCiz();
  }
  /** Öğretmen listesi ve ders havuzu aramalarını yeniden çizmeden uygular (odak korunur) */
  function aramaUygula() {
    var q1 = (ui.ogrAra || '').toLocaleLowerCase('tr').trim();
    document.querySelectorAll('.liste-oge[data-ara]').forEach(function (el) { el.style.display = !q1 || el.getAttribute('data-ara').indexOf(q1) >= 0 ? '' : 'none'; });
    var q2 = (ui.havuzAra || '').toLocaleLowerCase('tr').trim();
    document.querySelectorAll('.havuz-satir').forEach(function (el) { el.style.display = !q2 || el.getAttribute('data-ara').indexOf(q2) >= 0 ? '' : 'none'; });
    var q4 = (ui.ogrDegAra || '').toLocaleLowerCase('tr').trim();
    document.querySelectorAll('.ogr-deg-satir[data-ara]').forEach(function (el) { el.style.display = !q4 || el.getAttribute('data-ara').indexOf(q4) >= 0 ? '' : 'none'; });
    var q3 = (ui.secmeliAra || '').toLocaleLowerCase('tr').trim();
    document.querySelectorAll('.havuz-oge[data-ara]').forEach(function (el) { el.style.display = !q3 || el.getAttribute('data-ara').indexOf(q3) >= 0 ? '' : 'none'; });
    havuzOzeti();
  }
  function havuzOzeti() {
    var el = $('#havuz-ozet'); if (!el) return;
    var sec = document.querySelectorAll('.havuz-sec:checked'), saat = 0;
    sec.forEach(function (x) { saat += +x.getAttribute('data-saat') || 0; });
    var o = ogretmen(ui.atamaOgr), y = o ? ogretmenYukleri(dersListesi())[o.id] || 0 : 0, m = o ? o.maxSaat || 30 : 30;
    el.innerHTML = sec.length ? '<b>' + sec.length + ' ders · ' + saat + ' saat seçili</b> — yük ' + y + ' → <b class="' + (y + saat > m ? 'asim-yazi' : '') + '">' + (y + saat) + '</b> / ' + m : 'Seçili ders yok';
  }

  // ---------- Okul ----------
  function okulCiz() {
    var t = tur(), o = durum.okul;
    var gruplar = {};
    VERI.okulTurleri.forEach(function (x) { (gruplar[x.kademe] = gruplar[x.kademe] || []).push(x); });
    var secim = Object.keys(gruplar).map(function (k) {
      return '<optgroup label="' + esc(k) + '">' + gruplar[k].map(function (x) {
        return '<option value="' + x.id + '"' + (x.id === o.turId ? ' selected' : '') + '>' + esc(x.ad) + '</option>';
      }).join('') + '</optgroup>';
    }).join('');
    var h = sayfaBasi('Okul ve okul türü', 'Okul türü seçildiğinde ders çizelgesi, sınıf düzeyleri ve seçmeli havuzu MEB TTKB çizelgesine göre otomatik gelir.',
      '<button class="btn ana" data-a="demo">' + ikon('oynat') + 'Örnek veriyle hızlı başla</button>');
    h += '<div class="kart"><h3>Okul bilgileri</h3><div class="form">' +
      '<label class="alan">Okul adı<input type="text" data-okul="ad" value="' + esc(o.ad) + '"></label>' +
      '<label class="alan">Okul türü<select data-a="tur-sec">' + secim + '</select></label>' +
      '<label class="alan">Haftalık gün sayısı<input type="number" min="5" max="6" data-okul="gunSayisi" value="' + o.gunSayisi + '"></label>' +
      '<label class="alan">Günlük ders saati<input type="number" min="4" max="12" data-okul="gunlukSaat" value="' + o.gunlukSaat + '"></label>' +
      '</div></div>';
    h += '<div class="izgara2">';
    h += '<div class="kart"><h3>' + esc(t.ad) + ' <span class="ek">' + esc(t.kademe) + '</span></h3>' +
      '<table class="tablo bilgi-tablo"><tr><th>Sınıf düzeyleri</th><td>' + t.siniflar.map(sinifEtiketi).join(', ') + '</td></tr>' +
      '<tr><th>Haftalık toplam</th><td>' + t.siniflar.map(function (s, i) { return s + ': <b>' + t.toplam[i] + '</b>'; }).join(' · ') + ' saat</td></tr>' +
      '<tr><th>Seçmeli saati</th><td>' + t.siniflar.map(function (s, i) { return s + ': ' + t.secmeliSaat[i]; }).join(' · ') + '</td></tr>' +
      '<tr><th>Kaynak</th><td><a href="' + esc(t.kaynakUrl) + '" target="_blank" rel="noopener">' + esc(t.kaynakBaslik) + '</a> (' + esc(t.kararTarihi) + ')</td></tr></table>' +
      (t.notlar.length ? '<ul class="ince">' + t.notlar.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul>' : '') +
      '<div id="kapasite">' + kapasiteHtml() + '</div>' +
      '<p class="ince">Diğer okul türleri ve kaynaklar için <a href="#" data-a="adim" data-v="kaynaklar">Kaynaklar</a> bölümüne bakın.</p></div>';
    h += '<div class="kart"><h3>Ders saatleri <span class="ek">programda ve çıktılarda gösterilir</span></h3><div class="form">' +
      '<label class="alan">İlk ders<input type="time" data-okul="baslangic" value="' + esc(o.baslangic) + '"></label>' +
      '<label class="alan">Ders süresi (dk)<input type="number" data-okul="dersSure" value="' + o.dersSure + '"></label>' +
      '<label class="alan">Teneffüs (dk)<input type="number" data-okul="teneffus" value="' + o.teneffus + '"></label>' +
      '<label class="alan">Öğle arası (kaçıncı dersten sonra)<input type="number" data-okul="ogleSonrasi" value="' + o.ogleSonrasi + '"></label>' +
      '<label class="alan">Öğle arası (dk)<input type="number" data-okul="ogleSure" value="' + o.ogleSure + '"></label>' +
      '</div><p class="ince saat-satiri" id="saat-etiketleri">' + saatEtiketHtml() + '</p></div>';
    h += '</div>';
    return h;
  }
  function kapasiteHtml() {
    var t = tur(), o = durum.okul, maxToplam = Math.max.apply(null, t.toplam), kap = o.gunSayisi * o.gunlukSaat;
    return maxToplam > kap ? '<div class="uyari hata">' + ikon('uyari') + '<div>Kapasite yetersiz: ' + o.gunSayisi + ' × ' + o.gunlukSaat + ' = ' + kap + ' saat, en yüksek haftalık toplam ' + maxToplam + ' saat.</div></div>'
      : '<div class="uyari basari">' + ikon('tamam') + '<div>Kapasite uygun: ' + kap + ' saatlik haftada en yüksek toplam ' + maxToplam + ' saat.</div></div>';
  }
  function saatEtiketHtml() {
    return M.saatEtiketleri(durum.okul, durum.okul.gunlukSaat).map(function (s, i) { return '<span><b>' + (i + 1) + '.</b> ' + s + '</span>'; }).join(' ');
  }

  // ---------- Sınıflar ve şubeler ----------
  function subeAdi(sinif, sira) {
    var A = durum.subeAyar || { adlandirma: 'harf', ayrac: '-' };
    var ek = A.adlandirma === 'rakam' ? String(sira + 1) : M.HARFLER[sira];
    return (sinif === 'Hz' ? 'Hz' : sinif) + (A.ayrac == null ? '-' : A.ayrac) + ek;
  }
  /** Şubeyi ve ona bağlı tüm verileri siler */
  function subeSil(id) {
    durum.subeler = durum.subeler.filter(function (x) { return x.id !== id; });
    [durum.atamalar, durum.saatDegisiklik, durum.yerlesimler, durum.kilitler].forEach(function (obj) {
      Object.keys(obj).forEach(function (key) { if (key.indexOf(id + '|') === 0) delete obj[key]; });
    });
    delete durum.subeSecmeli[id];
    delete durum.subeKapali[id];
    durum.ekDersler = durum.ekDersler.filter(function (e) { return e.subeId !== id; });
  }
  function subeEkle(sinif) {
    var t = tur(), mevcut = durum.subeler.filter(function (x) { return x.sinif === sinif; });
    if (mevcut.length >= M.HARFLER.length) return null;
    var harf = M.HARFLER.find(function (h) { return !mevcut.some(function (x) { return x.id === 's' + sinif + h; }); });
    var yeni = { id: 's' + sinif + harf, sinif: sinif, ad: subeAdi(sinif, mevcut.length) };
    var son = -1;
    durum.subeler.forEach(function (x, i) { if (t.siniflar.indexOf(x.sinif) <= t.siniflar.indexOf(sinif)) son = i; });
    durum.subeler.splice(son + 1, 0, yeni);
    return yeni;
  }
  function subelerCiz() {
    var t = tur(), dol = {};
    subeDoluluk().forEach(function (x) { dol[x.sube.id] = x; });
    var A = durum.subeAyar;
    var h = sayfaBasi('Sınıflar ve şubeler', 'Şube sayılarını belirleyin, adlarını düzenleyin ve ders saatlerini kontrol edin.',
      '<button class="btn" data-a="sube-excel-ac">' + ikon('artı') + 'Excel / Liste yapıştır</button>');
    h += '<div class="kart"><h3>Hızlı oluşturma</h3><div class="hizli-sube">' +
      t.siniflar.map(function (s) {
        var n = durum.subeler.filter(function (x) { return x.sinif === s; }).length;
        return '<label class="alan">' + sinifEtiketi(s) + '<input type="number" min="0" max="20" class="hizli-sayi" data-sinif="' + s + '" value="' + n + '"></label>';
      }).join('') +
      '<label class="alan">Adlandırma<select data-a="sube-adlandirma"><option value="harf"' + (A.adlandirma !== 'rakam' ? ' selected' : '') + '>Harf (A, B, C)</option><option value="rakam"' + (A.adlandirma === 'rakam' ? ' selected' : '') + '>Rakam (1, 2, 3)</option></select></label>' +
      '<label class="alan">Ayraç<select data-a="sube-ayrac">' + [['-', '9-A'], ['/', '9/A'], ['', '9A']].map(function (x) { return '<option value="' + x[0] + '"' + (A.ayrac === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></label>' +
      '<div class="alan"><span>&nbsp;</span><button class="btn ana" data-a="sube-olustur">' + ikon('tamam') + 'Oluştur</button></div></div>' +
      '<p class="ince" style="margin:8px 0 0">Sayı azaltılırsa sondaki şubeler ve onlara ait atama, kilit ve seçmeliler silinir (önce onay istenir). Adlandırma değişikliği tüm şube adlarını yeniden yazar.</p></div>';
    h += '<div id="doldurma">' + doldurmaUyarisi() + '</div>';
    h += '<div class="izgara2">';
    t.siniflar.forEach(function (s, si) {
      var subeler = durum.subeler.filter(function (x) { return x.sinif === s; });
      h += '<div class="kart dd3-grup dd3-sube-grup" data-dd3-baslik="' + esc(sinifEtiketi(s)) + '"><div class="kart-ust"><h3>' + sinifEtiketi(s) + ' <span class="ek">' + subeler.length + ' şube · MEB ' + t.toplam[si] + ' saat</span></h3>' +
        '<button class="btn kucuk" data-a="sube-arti" data-v="' + s + '">' + ikon('artı') + 'Şube ekle</button></div>';
      if (!subeler.length) h += '<p class="ince">Bu düzeyde şube yok.</p>';
      else {
        h += '<table class="tablo"><tr><th>Şube adı</th><th class="s">Haftalık</th><th class="s">Durum</th><th></th></tr>' + subeler.map(function (x) {
          var d = dol[x.id] || { saat: 0, meb: 0 };
          var durumEt = d.tasma ? '<span class="etiket kirmizi">' + d.tasma + ' saat sığmaz</span>' : (d.eksik ? '<span class="etiket sari">' + d.eksik + ' eksik</span>' : (d.fazla ? '<span class="etiket sari">' + d.fazla + ' fazla</span>' : '<span class="etiket yesil">tam</span>'));
          return '<tr class="dd3-sube-satir" data-dd3-ara="' + esc(x.ad + ' ' + sinifEtiketi(x.sinif)) + '"><td><input type="text" class="sube-ad" data-a="sube-ad" data-v="' + x.id + '" value="' + esc(x.ad) + '"></td><td class="s"><b>' + d.saat + '</b>/' + d.meb + '</td><td class="s">' + durumEt + '</td>' +
            '<td class="s"><button class="btn ikon-btn tehlike" data-a="sube-sil" data-v="' + x.id + '" title="Şubeyi sil">' + ikon('cop') + '</button></td></tr>';
        }).join('') + '</table>';
      }
      h += '</div>';
    });
    h += '</div>';
    return h;
  }

  // ---------- Sınıflara ders atama (zorunlu + ek dersler) ----------
  function bilinenDersler() {
    var adlar = {};
    VERI.okulTurleri.forEach(function (t) { t.dersler.forEach(function (r) { adlar[r[0]] = true; }); });
    Object.keys(VERI.havuzlar).forEach(function (k) { VERI.havuzlar[k].dersler.forEach(function (d) { adlar[d[0]] = true; }); });
    return Object.keys(adlar).sort(function (a, b) { return a.localeCompare(b, 'tr'); });
  }
  function zorunluCiz(gomulu) {
    var t = tur(), dersler = dersListesi(), gorunum = ui.zorunluGorunum || 'tablo';
    var degisiklikSayisi = Object.keys(durum.saatDegisiklik).length + durum.ekDersler.length;
    var h = gomulu ? '<div class="dd5-ic-ust"><h3>Zorunlu dersler · şube matrisi</h3>' + sekmeler('zorunlu-gorunum', gorunum, [['tablo', 'Ders × şube tablosu'], ['sube', 'Şube şube liste']]) + '</div>' : sayfaBasi('Sınıflara ders atama', 'MEB çizelgesindeki zorunlu, ortak, meslek ve alan dersleri her şubeye hazır atanır. Saatleri düzeltebilir, dersi kaldırabilir ya da okula özel ders ekleyebilirsiniz.',
      sekmeler('zorunlu-gorunum', gorunum, [['tablo', 'Ders × şube tablosu'], ['sube', 'Şube şube liste']]));
    h += '<datalist id="ders-adlari">' + bilinenDersler().map(function (a) { return '<option value="' + esc(a) + '">'; }).join('') + '</datalist>';
    if (degisiklikSayisi) h += '<div class="uyari bilgi">' + ikon('duzenle') + '<div class="satir" style="flex:1">MEB çizelgesinden ' + Object.keys(durum.saatDegisiklik).length + ' saat değişikliği ve ' + durum.ekDersler.length + ' eklenen ders var (sarı/“Ek”).<span class="bosluk"></span><button class="btn kucuk" data-a="zorunlu-sifirla">MEB çizelgesine döndür</button></div></div>';
    h += '<div id="doldurma">' + doldurmaUyarisi(dersler) + '</div>';
    var bySube = {};
    dersler.forEach(function (d) { (bySube[d.subeId] = bySube[d.subeId] || []).push(d); });

    t.siniflar.forEach(function (s, si) {
      if (gomulu && ui.dd6Sinif && s !== ui.dd6Sinif) return;
      var subeler = durum.subeler.filter(function (x) { return x.sinif === s; });
      if (!subeler.length) return;
      var ekler = durum.ekDersler.filter(function (e) { return e.sinif === s; });
      h += '<div class="kart"><div class="kart-ust"><h3>' + sinifEtiketi(s) + ' <span class="ek">' + subeler.length + ' şube · MEB zorunlu toplamı ' + (t.toplam[si] - t.secmeliSaat[si]) + ' saat</span></h3></div>';
      if (gorunum === 'tablo') {
        h += '<div class="kaydirma"><table class="tablo matris"><tr><th>Ders</th><th>Grup</th><th class="s">MEB</th>' + subeler.map(function (sb) { return '<th class="s">' + esc(sb.ad) + '</th>'; }).join('') + '<th></th></tr>';
        var satirlar = t.dersler.map(function (r) { return { ad: r[0], grup: r[1], meb: r[2][si], ek: null }; })
          .filter(function (r) { return r.meb > 0 || subeler.some(function (sb) { return durum.saatDegisiklik[sb.id + '|' + r.ad] > 0; }); });
        ekler.forEach(function (e) { if (!satirlar.some(function (r) { return r.ad === e.ad; })) satirlar.push({ ad: e.ad, grup: 'Ek', meb: 0, ek: e }); });
        satirlar.forEach(function (r) {
          var hepsiSifir = subeler.every(function (sb) { var ov = durum.saatDegisiklik[sb.id + '|' + r.ad]; return ov === 0; });
          h += '<tr class="' + (hepsiSifir ? 'kaldirildi' : '') + '"><td>' + esc(r.ad) + (r.ek && r.ek.subeId ? ' <span class="ince">(' + esc((sube(r.ek.subeId) || {}).ad) + ')</span>' : '') + '</td><td><span class="etiket ' + esc(r.grup) + '">' + esc(r.grup) + '</span></td><td class="s">' + (r.meb || '–') + '</td>' +
            subeler.map(function (sb) {
              if (r.ek && r.ek.subeId && r.ek.subeId !== sb.id) return '<td class="s sifir">–</td>';
              var id = sb.id + '|' + r.ad, ov = durum.saatDegisiklik[id];
              var temel = r.ek ? +r.ek.saat : r.meb;
              var deger = ov != null ? ov : temel;
              return '<td class="s"><input type="number" min="0" max="20" class="saat-giris' + (ov != null ? ' degisik' : '') + '" data-a="zorunlu-saat" data-v="' + esc(id) + '" data-meb="' + temel + '" value="' + deger + '" title="Çizelge: ' + temel + ' saat · 0 yazarsanız bu şubeden kaldırılır"></td>';
            }).join('') +
            '<td class="s">' + (r.ek
              ? '<button class="btn ikon-btn tehlike" data-a="ek-ders-sil" data-v="' + esc(r.ek.id) + '" title="Eklenen dersi sil">' + ikon('cop') + '</button>'
              : (hepsiSifir ? '<button class="btn kucuk" data-a="ders-geri-al" data-v="' + esc(s + '|' + r.ad) + '">Geri al</button>'
                : '<button class="btn ikon-btn tehlike" data-a="ders-kaldir" data-v="' + esc(s + '|' + r.ad) + '" title="Bu dersi tüm ' + esc(sinifEtiketi(s)) + ' şubelerinden kaldır">' + ikon('cop') + '</button>')) + '</td></tr>';
        });
        h += '<tr class="toplam"><td colspan="3">Haftalık toplam (seçmeli dahil) / MEB ' + t.toplam[si] + '</td>' + subeler.map(function (sb) {
          var top = (bySube[sb.id] || []).reduce(function (a, d) { return a + d.saat; }, 0);
          return '<td class="s" id="top-' + sb.id + '"' + (top !== t.toplam[si] ? ' style="color:var(--err)"' : '') + '>' + top + '</td>';
        }).join('') + '<td></td></tr></table></div>';
      } else {
        h += '<div class="ogr-ders-listesi">' + subeler.map(function (sb) {
          var l = (bySube[sb.id] || []).filter(function (d) { return d.grup !== 'Seçmeli'; });
          return '<div class="sinif-blok"><h4>' + esc(sb.ad) + ' <span class="ince">' + l.reduce(function (a, d) { return a + d.saat; }, 0) + ' saat zorunlu</span></h4>' +
            '<div class="sd baslik-satir"><span>Ders</span><span>Saat</span><span>Blok</span><span>Öğretmen</span></div>' +
            l.map(function (d) { var o = ogretmen(d.ogretmenId); return '<div class="sd"><span>' + esc(d.ders) + (d.grup === 'Ek' ? ' <span class="etiket Ek">Ek</span>' : '') + '</span><span class="ince">' + d.saat + '</span>' + yerlesimSecimi(d) + '<span class="ince">' + esc(o ? o.ad : '— atanmamış —') + '</span></div>'; }).join('') + '</div>';
        }).join('') + '</div>';
      }
      // Birleşik yönetimde özel ders, sade modal üzerinden eklenir.
      if (!gomulu) h += '<div class="ders-ekle"><b>' + ikon('artı') + 'Ders ekle</b>' +
        '<input type="text" list="ders-adlari" placeholder="Ders adı (listeden seçin ya da yazın)" id="ek-ad-' + s + '">' +
        '<input type="number" min="1" max="20" value="2" id="ek-saat-' + s + '" title="Haftalık saat" style="width:70px">' +
        '<select id="ek-hedef-' + s + '"><option value="">Tüm ' + esc(sinifEtiketi(s)) + ' şubeleri</option>' + subeler.map(function (sb) { return '<option value="' + sb.id + '">Yalnız ' + esc(sb.ad) + '</option>'; }).join('') + '</select>' +
        '<button class="btn" data-a="ek-ders-ekle" data-v="' + s + '">Ekle</button></div>';
      h += '</div>';
    });
    return h;
  }
  function yerlesimSecimi(d) {
    var D = +durum.okul.gunSayisi;
    var elle = durum.yerlesimler[d.id];
    var kural = durum.blokKurallari[(sube(d.subeId) || {}).sinif + '|' + d.ders];
    var oto = kural ? (Array.isArray(kural) ? kural.join(' / ') : kural) : M.varsayilanYerlesim(d.saat, D, durum.ayarlar.blok).join('+');
    return '<select data-a="yerlesim" data-v="' + esc(d.id) + '" title="Blok düzeni: dersin günlere bölünüşü">' +
      '<option value="">' + (kural ? 'düzey: ' : 'oto ') + esc(oto) + '</option>' +
      M.yerlesimSecenekleri(d.saat, D).map(function (k) { return '<option' + (elle === k ? ' selected' : '') + '>' + k + '</option>'; }).join('') + '</select>';
  }

  // ---------- Menü 4 / Ders Yönetim Stüdyosu ----------
  // Bütün veri işlemleri mevcut doğrulama / model işlevlerini kullanır;
  // bu fonksiyonlar yalnızca görünümü ve kontrollere erişimi değiştirir.
  function dd6DersYonetimiGelismisCiz() {
    var t = tur(), sinif = ui.dd6Sinif || ui.dd5ZorSinif || ui.secmeliSinif || t.siniflar[0];
    if (t.siniflar.indexOf(sinif) < 0) sinif = t.siniflar[0];
    ui.dd6Sinif = ui.dd5ZorSinif = ui.secmeliSinif = sinif;
    if (ui.adim === 'secmeli') ui.dd5Havuz = 'secmeli';
    var sekme = ui.dd5Havuz === 'secmeli' ? 'secmeli' : 'zorunlu';
    var sinifInd = t.siniflar.indexOf(sinif), subeler = durum.subeler.filter(function (x) { return x.sinif === sinif; });
    var mebHavuz = t.dersler.filter(function (r) { return (+r[2][sinifInd] || 0) > 0; });
    ui.dd7ZorSec = ui.dd7ZorSec || {};
    if (!ui.dd7ZorSubeler) { ui.dd7ZorSubeler = {}; subeler.forEach(function (sb) { ui.dd7ZorSubeler[sb.id] = true; }); }
    var dd7ZorN = mebHavuz.filter(function (r) { return !!ui.dd7ZorSec[r[0]]; }).length;
    var dd7SubeN = subeler.filter(function (sb) { return !!ui.dd7ZorSubeler[sb.id]; }).length;
    var secHavuz = secmeliHavuzu().filter(function (r) { return r[2].indexOf(sinif) >= 0; });
    var hedefSaat = t.secmeliSaat[sinifInd] || 0;
    var ozelAdet = durum.ozelSecmeliler.filter(function (r) { return r.siniflar.indexOf(sinif) >= 0; }).length;
    var dolu = subeler.filter(function (sb) { return secmeliToplam(M.subeSecmelileri(durum, sb)) === hedefSaat; }).length;
    var toplam = subeler.reduce(function (a, sb) { return a + subeSaatleri(sb.id).toplam; }, 0);
    var h = '<div class="dd6-studio">' +
      '<header class="dd6-hero"><div><span class="dd6-kicker">4. MENÜ · DERS YÖNETİMİ</span><h2>Dersler ve şube atamaları</h2><p>Bir sınıf seçin, ders havuzundan atayın. Değişiklikleri aşağıdaki şube tablosundan düzenleyin.</p></div>' +
      '<div class="dd6-hero-stats"><span><b>' + subeler.length + '</b> Şube</span><span><b>' + toplam + '</b> Toplam saat</span><span><b>' + ozelAdet + '</b> Özel seçmeli</span></div></header>';
    h += '<section class="dd6-grade-card" aria-label="Sınıf düzeyi seçimi"><div class="dd6-section-label"><span class="dd6-step">1</span><div><b>Sınıf düzeyini seç</b><small>İşlemler yalnız seçtiğiniz sınıf ve şubelerde yapılır</small></div></div><div class="dd6-grade-list">' +
      t.siniflar.map(function (x) { var ss = durum.subeler.filter(function (z) { return z.sinif === x; }); return '<button type="button" class="dd6-grade' + (x === sinif ? ' aktif' : '') + '" data-a="dd6-sinif" data-v="' + esc(x) + '" aria-pressed="' + (x === sinif) + '"><b>' + esc(sinifEtiketi(x)) + '</b><small>' + ss.length + ' şube</small></button>'; }).join('') + '</div></section>';
    h += '<section class="dd6-pool-selector" aria-label="Ders türü"><button class="dd6-pool-tab' + (sekme === 'zorunlu' ? ' aktif' : '') + '" type="button" data-a="dd5-havuz-sek" data-v="zorunlu" aria-pressed="' + (sekme === 'zorunlu') + '"><span class="dd6-tab-symbol">' + ikon('zorunlu') + '</span><span><b>Zorunlu dersler</b><small>MEB’den hazır · ' + mebHavuz.length + ' ders</small></span></button>' +
      '<button class="dd6-pool-tab' + (sekme === 'secmeli' ? ' aktif' : '') + '" type="button" data-a="dd5-havuz-sek" data-v="secmeli" aria-pressed="' + (sekme === 'secmeli') + '"><span class="dd6-tab-symbol">' + ikon('secmeli') + '</span><span><b>Seçmeli dersler</b><small>' + secHavuz.length + ' havuz dersi · ' + dolu + '/' + subeler.length + ' şube tamam</small></span></button></section>';
    if (!subeler.length) return h + '<div class="dd6-empty"><b>' + esc(sinifEtiketi(sinif)) + ' için henüz şube yok.</b><p>Ders atayabilmek için önce bu sınıf düzeyine bir şube oluşturun.</p><button class="btn ana" data-a="adim" data-v="subeler">Şubeler menüsüne git</button></div></div>';
    if (sekme === 'zorunlu') {
      var selected = mebHavuz.find(function (r) { return r[0] === ui.dd5ZorDers; }) || mebHavuz[0];
      var ad = selected ? selected[0] : '';
      ui.dd5ZorDers = ad;
      var meb = selected ? +selected[2][sinifInd] : 0;
      h += '<section class="dd6-workspace dd6-mandatory" aria-label="Zorunlu ders çalışma alanı"><aside class="dd6-course-panel"><div class="dd6-panel-head"><span class="dd6-step">2</span><div><h3>Zorunlu ders havuzu</h3><small>Tikleyerek çoklu seç · derse tıklayarak düzenle</small></div><span class="dd6-count">' + mebHavuz.length + '</span></div>' +
        '<label class="dd6-search"><span>⌕</span><input type="search" data-a="dd6-zor-ara" placeholder="Ders adı veya grup ara" value="' + esc(ui.dd6ZorAra || '') + '" aria-label="Zorunlu ders ara"></label>' +
        '<div class="dd7-pool-tools"><span class="dd7-small-count">' + dd7ZorN + ' ders işaretli</span><button class="dd7-text-action" data-a="dd7-zor-gorunen">Görünenleri seç</button><button class="dd7-text-action" data-a="dd7-zor-temizle">Temizle</button></div><div class="dd6-course-list">' +
        mebHavuz.map(function (r) { var sec = !!ui.dd7ZorSec[r[0]]; return '<div class="dd7-zor-satir dd6-zor-oge' + (r[0] === ad ? ' aktif' : '') + (sec ? ' dd7-checked' : '') + '" data-dd6-search="' + esc((r[0] + ' ' + r[1]).toLocaleLowerCase('tr-TR')) + '"><label class="dd7-check-wrap" title="Bu dersi toplu işlem için seç"><input type="checkbox" data-a="dd7-zor-sec" value="' + esc(r[0]) + '"' + (sec ? ' checked' : '') + ' aria-label="' + esc(r[0]) + ' seç"></label><button type="button" class="dd7-zor-open" data-a="dd6-zor-ders" data-v="' + esc(r[0]) + '" aria-label="' + esc(r[0]) + ' ayrıntısını aç"><span class="dd6-course-dot"></span><span class="dd6-course-title"><b>' + esc(r[0]) + '</b><small>' + esc(r[1]) + '</small></span><span class="dd6-hours">' + (+r[2][sinifInd]) + ' sa</span></button></div>'; }).join('') + '</div>' +
        '<button class="dd6-add-link" data-a="dd6-zor-ozel-ac">' + ikon('artı') + ' Okula özel zorunlu ders ekle</button></aside>';
      h += '<div class="dd6-main-area"><div class="dd7-batch-card"><div class="dd7-batch-title"><div><span class="dd7-mini-kicker">TOPLU DERS ATAMA</span><h3>İşaretlediğin dersleri şubelere uygula</h3><p>MEB saatlerini seçilen şubelere geri yükler; okul verilerini veya diğer şubeleri silmez.</p></div><strong>' + dd7ZorN + ' ders · ' + dd7SubeN + ' şube</strong></div>' +
        '<div class="dd7-target-head"><b>Hedef şubeler</b><div><button class="dd7-text-action" data-a="dd7-zor-sube-tum">Tümünü seç</button><button class="dd7-text-action" data-a="dd7-zor-sube-temizle">Temizle</button></div></div><div class="dd7-target-grid">' + subeler.map(function (sb) { return '<label class="dd7-target' + (ui.dd7ZorSubeler[sb.id] ? ' secili' : '') + '"><input type="checkbox" data-a="dd7-zor-sube" value="' + esc(sb.id) + '"' + (ui.dd7ZorSubeler[sb.id] ? ' checked' : '') + '><span>' + esc(sb.ad) + '</span><small>' + subeSaatleri(sb.id).toplam + '/' + subeSaatleri(sb.id).sinir + ' sa</small></label>'; }).join('') + '</div><div class="dd7-batch-footer"><span>Seçili dersler MEB çizelgesindeki kendi haftalık saatleriyle uygulanır.</span><button class="btn ana" data-a="dd7-zor-toplu"' + (dd7ZorN && dd7SubeN ? '' : ' disabled') + '>' + ikon('tamam') + ' Seçilen dersleri uygula</button></div></div><div class="dd6-action-card dd7-single-card"><div class="dd6-action-heading"><span class="dd6-step">3</span><div><h3>Tek dersi düzenle</h3><small><b>' + esc(ad || 'Ders seçilmedi') + '</b> · MEB ' + meb + ' saat</small></div></div><div class="dd6-action-fields">' +
        '<label>Hedef şube<select id="dd5-zor-hedef"><option value="">Bu sınıftaki tüm şubeler</option>' + subeler.map(function (sb) { return '<option value="' + esc(sb.id) + '">' + esc(sb.ad) + '</option>'; }).join('') + '</select></label>' +
        '<label>Haftalık saat<input type="number" id="dd5-zor-saat" min="1" max="20" value="' + meb + '"></label>' +
        '<button class="btn ana" data-a="dd5-zor-ata"' + (ad ? '' : ' disabled') + '>' + ikon('tamam') + ' Şubelere uygula</button></div><p class="dd6-action-note">Hazır MEB dersleri korunur. Saatleri değiştirebilir, 0 yaparak şubeden kaldırabilir veya geri alabilirsiniz.</p></div>' +
        '<div class="dd6-matrix-head"><div class="dd6-section-label"><span class="dd6-step">4</span><div><b>' + esc(sinifEtiketi(sinif)) + ' · şube ders çizelgesi</b><small>Her şubenin saatini doğrudan değiştir</small></div></div><button class="btn kucuk" data-a="dd6-zor-ozel-ac">' + ikon('artı') + ' Yeni ders</button></div><div class="dd6-matrix-wrap"><p class="dd6-scroll-hint">Tablonun diğer şubelerini görmek için sağa kaydırın →</p>' + zorunluCiz(true) + '</div></div></section>';
    } else if (!hedefSaat) {
      h += '<div class="dd6-empty"><b>' + esc(sinifEtiketi(sinif)) + ' için seçmeli ders saati tanımlı değil.</b><p>Bu düzeyde seçmeli ders ataması gerekmiyorsa herhangi bir işlem yapmanız gerekmez. Farklı bir sınıf düzeyi seçebilirsiniz.</p></div>';
    } else {
      h += '<section class="dd6-elective-title"><div class="dd6-section-label"><span class="dd6-step">2</span><div><b>Havuzdan seçmeli dersleri seç ve şubelere ata</b><small>' + esc(sinifEtiketi(sinif)) + ' · ' + hedefSaat + ' saatlik seçmeli hakkı · ' + subeler.length + ' şube</small></div></div>' +
        '<button class="btn ana" data-a="ozel-secmeli-ac">' + ikon('artı') + ' Yeni seçmeli ders ekle</button></section>' +
        '<div class="dd6-help-strip"><b>Nasıl atanır?</b> <span>1. Soldan dersleri işaretle</span><span>2. Sağdan şubeleri seç</span><span>3. Seçilenleri ata</span></div>' +
        '<div class="dd6-elective-work">' + secmeliCiz(true) + '</div><details class="dd6-advanced"><summary><span><b>Şube bazında toplu saat tablosu</b><small>İleri düzenleme: Tüm seçmelileri ders × şube matrisiyle görüntüle</small></span><span class="dd6-summary-chevron">⌄</span></summary>' + dd5SecmeliMatrisCiz() + '</details>';
    }
    return h + '</div>';
  }

  // MENÜ 4 / Sade görünüm: bir sınıf + bir şube + bir ders türü.
  // Gelişmiş toplu işlemler korunur, yalnız istenirse açılır.
  function dd8Filtrele() {
    var q = (ui.dd8Ara || '').toLocaleLowerCase('tr-TR').trim();
    document.querySelectorAll('.dd8-pool-row[data-search]').forEach(function (row) {
      row.hidden = !!q && (row.getAttribute('data-search') || '').indexOf(q) < 0;
    });
  }
  // UX 3.0 / Aşama 2: tek şube, tek görev, tek çalışma alanı.
  // Mevcut veri modeli ve ders/saat değiştirme olayları aynen kullanılır.
  function dd6DersYonetimiCiz() {
    if (ui.dd8Gelismis) {
      return '<div class="ux3-backbar"><button class="btn" data-a="dd8-gelismis">← Sade ders ekranına dön</button><span>Toplu işlemler ve ayrıntılı şube matrisi</span></div>' + dd6DersYonetimiGelismisCiz();
    }
    var t = tur(), sb = sube(ui.dd8Sube) || durum.subeler[0];
    if (!sb) return '<section class="ux3-lesson-page"><div class="ux3-page-head"><h2>4. Dersler ve Şube Atamaları</h2></div><div class="ux3-empty"><strong>Henüz şube eklenmemiş.</strong><p>Dersleri yönetmek için önce bir şube oluştur.</p><button class="btn ana" data-a="adim" data-v="subeler">Şubeler menüsünü aç</button></div></section>';
    ui.dd8Sube = sb.id;
    ui.dd6Sinif = ui.dd5ZorSinif = ui.secmeliSinif = sb.sinif;
    var sekme = ui.dd5Havuz === 'secmeli' ? 'secmeli' : 'zorunlu';
    var list = dersListesi().filter(function (d) { return d.subeId === sb.id && d.ders !== 'Seçmeli Ders' && (sekme === 'secmeli' ? d.grup === 'Seçmeli' : d.grup !== 'Seçmeli'); });
    list.sort(function (x,y) { return x.ders.localeCompare(y.ders, 'tr'); });
    var tot = subeSaatleri(sb.id), sec = secmeliToplam(M.subeSecmelileri(durum,sb)), limit = secmeliGerekli('sube',sb.id);
    var all = dersListesi().filter(function (d) { return d.subeId === sb.id; });
    var mandatory = all.filter(function (d) { return d.grup !== 'Seçmeli' && d.ders !== 'Seçmeli Ders'; }).reduce(function (n,d) { return n + d.saat; }, 0);
    var left = tot.sinir - tot.toplam;
    var h = '<section class="ux3-lesson-page dd8-page" aria-label="Dersler ve şube atamaları">' +
      '<div class="ux3-page-head"><div><div class="ux3-kicker">MENÜ 4 · DERS YÖNETİMİ</div><h2>Dersler ve Şube Atamaları</h2><p>Şubeyi seç, dersleri düzenle. Tüm değişiklikler yalnız bu şubeye uygulanır.</p></div><button type="button" class="ux3-advanced-link" data-a="dd8-gelismis">Gelişmiş işlemler</button></div>' +
      '<div class="ux3-branch-panel"><label class="ux3-branch-label" for="ux3-sube-sec"><span>Çalışma şubesi</span><select id="ux3-sube-sec" data-a="dd8-sube" class="dd8-sube">' +
      t.siniflar.map(function (s) { var branches=durum.subeler.filter(function (x) {return x.sinif===s;}); return branches.length ? '<optgroup label="'+esc(sinifEtiketi(s))+'">' + branches.map(function (x) {return '<option value="'+esc(x.id)+'"'+(x.id===sb.id?' selected':'')+'>'+esc(x.ad)+'</option>';}).join('')+'</optgroup>':''; }).join('')+
      '</select></label><div class="ux3-branch-metrics"><div><small>Zorunlu</small><b>'+mandatory+' sa</b></div><div><small>Seçmeli</small><b>'+sec+' / '+limit+' sa</b></div><div class="'+(left<0?'ux3-metric-alert':'')+'"><small>Toplam</small><b>'+tot.toplam+' / '+tot.sinir+' sa</b></div></div></div>' +
      '<div class="ux3-progress-track" aria-label="Haftalık ders yükü"><span style="width:'+ (tot.sinir?Math.max(0,Math.min(100,tot.toplam/tot.sinir*100)):0) + '%"></span></div>' +
      '<div class="ux3-tabbar dd8-section-tabs" role="tablist" aria-label="Ders türü"><button type="button" role="tab" aria-selected="'+(sekme==='zorunlu')+'" class="'+(sekme==='zorunlu'?'active':'')+'" data-a="dd5-havuz-sek" data-v="zorunlu">Zorunlu dersler</button><button type="button" role="tab" aria-selected="'+(sekme==='secmeli')+'" class="'+(sekme==='secmeli'?'active':'')+'" data-a="dd5-havuz-sek" data-v="secmeli">Seçmeli dersler <span>'+sec+'/'+limit+'</span></button></div>' +
      '<div class="ux3-course-panel"><div class="ux3-list-header"><div><h3>'+esc(sb.ad)+' · '+(sekme==='zorunlu'?'Zorunlu':'Seçmeli')+' dersler</h3><p>'+(sekme==='zorunlu'?'MEB dersleri hazır gelir. Gerektiğinde düzenleyebilir veya kaldırabilirsin.':'Seçmeli dersleri havuzdan ekleyebilir ve saatlerini değiştirebilirsin.')+'</p></div><button type="button" class="ux3-primary-btn dd8-havuz" data-a="ux3-pool-open">+ Ders ekle</button></div>' +
      '<div class="ux3-course-list">';
    if (!list.length) h += '<div class="ux3-empty"><strong>Bu şubede henüz '+(sekme==='zorunlu'?'zorunlu':'seçmeli')+' ders yok.</strong><p>Başlamak için “Ders ekle” düğmesini kullan.</p></div>';
    list.forEach(function (d) {
      h += '<div class="ux3-course-row dd8-assigned-row"><div class="ux3-course-initial '+(sekme==='secmeli'?'ux3-purple':'')+'">'+esc(d.ders.substring(0,1).toLocaleUpperCase('tr-TR'))+'</div>'+
        '<div class="ux3-course-text"><strong>'+esc(d.ders)+'</strong><small>'+ (d.ogretmenId ? esc((ogretmen(d.ogretmenId)||{}).ad||'Öğretmen atanmadı') : 'Öğretmen atanmamış') +'</small></div>'+
        '<span class="ux3-course-hours">'+d.saat+' saat</span><button type="button" class="ux3-edit-btn" data-a="ux3-hours-open" data-v="'+esc(d.id)+'">Düzenle</button>'+
        '<button type="button" class="ux3-remove-btn" data-a="'+(sekme==='secmeli'?'dd8-sec-kaldir':'dd8-zor-kaldir')+'" data-v="'+esc(d.ders)+'" title="Yalnız '+esc(sb.ad)+' şubesinden kaldır" aria-label="'+esc(d.ders)+' kaldır">'+ikon('cop')+'</button></div>';
    });
    h += '</div><footer class="ux3-list-footer"><span><b>'+list.length+'</b> ders listeleniyor</span><span>'+(left < 0 ? 'Haftalık kapasite '+(-left)+' saat aşıldı' : (left===0?'Haftalık saatler tamamlandı':left+' saat eksik'))+'</span></footer></div>'+
      '<p class="ux3-safe-note">Bu ekrandan yaptığın işlemler diğer şubelerin derslerini değiştirmez. Ders havuzu silinmez.</p></section>';
    return h;
  }

  function ux3PoolModal() {
    var sb=sube(ui.dd8Sube), t=tur();
    if (!sb) return '';
    var sekme=ui.dd5Havuz==='secmeli'?'secmeli':'zorunlu', ix=t.siniflar.indexOf(sb.sinif);
    var havuz= sekme==='zorunlu'
      ? t.dersler.filter(function (r) {return (+r[2][ix]||0)>0;}).map(function(r){return {ad:r[0],saat:+r[2][ix],grup:r[1]};})
      : secmeliHavuzu().filter(function(r){return r[2].indexOf(sb.sinif)>=0;}).map(function(r){return {ad:r[0],saat:+r[3]||2,grup:r[1]};});
    if (sekme==='zorunlu') (durum.ekDersler||[]).filter(function(e){return e.subeId?e.subeId===sb.id:e.sinif===sb.sinif;}).forEach(function(e){if(!havuz.some(function(x){return x.ad===e.ad;})) havuz.push({ad:e.ad,saat:+e.saat||1,grup:e.grup||'Okula özel'});});
    var adlar=dersListesi().filter(function(d){return d.subeId===sb.id && (sekme==='secmeli'?d.grup==='Seçmeli':d.grup!=='Seçmeli');}).map(function(d){return d.ders;});
    var available = sekme==='secmeli' ? Math.max(0, Math.min(secmeliGerekli('sube',sb.id)-secmeliToplam(M.subeSecmelileri(durum,sb)),subeSaatleri(sb.id).sinir-subeSaatleri(sb.id).toplam)) : Math.max(0,subeSaatleri(sb.id).sinir-subeSaatleri(sb.id).toplam);
    var h='<div class="modal-arka ux3-modal-back" data-a="modal-kapat"><div class="modal ux3-pool-modal" data-durdur="1" role="dialog" aria-modal="true" aria-labelledby="ux3-pool-title"><div class="ux3-modal-head"><div><div class="ux3-kicker">'+esc(sb.ad)+' · DERS HAVUZU</div><h3 id="ux3-pool-title">'+(sekme==='zorunlu'?'Zorunlu':'Seçmeli')+' ders ekle</h3><p>Bir dersi seçtiğinde yalnızca '+esc(sb.ad)+' şubesine eklenir.</p></div><button type="button" data-a="modal-kapat" class="ux3-icon-close" aria-label="Kapat">×</button></div><label class="ux3-pool-search"><span>Ders ara</span><input type="search" data-a="ux3-pool-search" id="ux3-pool-search" autocomplete="off" placeholder="Ders adı yaz..."></label><div class="ux3-pool-items">';
    havuz.sort(function(a,b){return a.ad.localeCompare(b.ad,'tr');}).forEach(function(d){var assigned=adlar.indexOf(d.ad)>=0;h+='<div class="ux3-pool-item" data-search="'+esc((d.ad+' '+d.grup).toLocaleLowerCase('tr-TR'))+'"><div><strong>'+esc(d.ad)+'</strong><small>'+esc(d.grup)+' · '+d.saat+' saat</small></div>'+(assigned?'<span class="ux3-already">✓ Eklendi</span>':(d.saat>available?'<span class="ux3-not-enough" title="Bu ders için yeterli boş saat yok">'+(available===0?'Saat dolu':available+' sa boş')+'</span>':'<button class="ux3-pool-add" data-a="'+(sekme==='zorunlu'?'dd8-zor-ekle':'dd8-sec-ekle')+'" data-v="'+esc(d.ad)+'">+ Ekle</button>'))+'</div>';});
    h+='</div><div class="ux3-modal-foot"><button type="button" class="btn" data-a="modal-kapat">Kapat</button><button type="button" class="btn ana" data-a="'+(sekme==='zorunlu'?'dd6-zor-ozel-ac':'ozel-secmeli-ac')+'">Yeni ders oluştur</button></div></div></div>';
    return h;
  }

  function ux3HoursModal() {
    var m=ui.modal, d=dersListesi().find(function(x){return x.id===m.dersId;}), sb=d&&sube(d.subeId);
    if (!d || !sb) return '<div class="modal-arka" data-a="modal-kapat"><div class="modal" data-durdur="1"><p>Ders artık mevcut değil.</p><button class="btn" data-a="modal-kapat">Kapat</button></div></div>';
    return '<div class="modal-arka ux3-modal-back" data-a="modal-kapat"><div class="modal ux3-hours-modal" data-durdur="1" role="dialog" aria-modal="true" aria-labelledby="ux3-hours-title"><div class="ux3-kicker">'+esc(sb.ad)+' · DERS DÜZENLEME</div><h3 id="ux3-hours-title">'+esc(d.ders)+'</h3><p>Yalnızca '+esc(sb.ad)+' şubesinin haftalık ders saatini değiştiriyorsun.</p><label class="ux3-hours-label">Haftalık ders saati<input type="number" id="ux3-new-hours" min="1" max="20" value="'+d.saat+'" inputmode="numeric"></label><div class="ux3-modal-foot"><button class="btn" data-a="modal-kapat">Vazgeç</button><button class="btn ana" data-a="ux3-hours-save">Değişikliği kaydet</button></div></div></div>';
  }

  function dd5DersHavuzlariCiz() { return dd6DersYonetimiCiz(); }
  function dd6ZorEkleModal() {
    var sinif = ui.dd6Sinif || tur().siniflar[0], subeler = durum.subeler.filter(function (x) { return x.sinif === sinif; });
    return '<div class="modal-arka" data-a="modal-kapat"><div class="modal dd6-custom-modal" data-durdur="1" role="dialog" aria-modal="true" aria-label="Yeni zorunlu ders"><div class="dd6-modal-header"><span class="dd6-step">+</span><div><h3>Okula özel ders ekle</h3><p>MEB havuzunda olmayan dersi ' + esc(sinifEtiketi(sinif)) + ' şubelerine ekleyin.</p></div></div><div class="dd6-modal-fields"><label>Ders adı<input id="ek-ad-' + esc(sinif) + '" type="text" list="ders-adlari" placeholder="Örn. Proje Atölyesi" autocomplete="off"></label><datalist id="ders-adlari">' + bilinenDersler().map(function (a) { return '<option value="' + esc(a) + '">'; }).join('') + '</datalist>' +
      '<label>Haftalık saat<input id="ek-saat-' + esc(sinif) + '" type="number" min="1" max="20" value="2"></label><label>Hedef şube<select id="ek-hedef-' + esc(sinif) + '"><option value="">Bu sınıfın tüm şubeleri</option>' + subeler.map(function (x) { return '<option value="' + esc(x.id) + '">' + esc(x.ad) + '</option>'; }).join('') + '</select></label></div><p class="dd6-modal-hint">MEB dersleri zaten yüklüdür. Saat sınırı doluysa önce mevcut derslerin saatini azaltın.</p><div class="dd6-modal-actions"><button class="btn" data-a="modal-kapat">Vazgeç</button><button class="btn ana" data-a="ek-ders-ekle" data-v="' + esc(sinif) + '">' + ikon('artı') + ' Dersi ekle</button></div></div></div>';
  }
  /** Seçmeli derslere zorunlu ders tablosundaki gibi şube x ders matrisi. */
  function dd5SecmeliMatrisCiz() {
    var t = tur(), s = ui.secmeliSinif;
    if (t.siniflar.indexOf(s) < 0) s = t.siniflar[0];
    var l = durum.subeler.filter(function (x) { return x.sinif === s; });
    var isimler = [];
    l.forEach(function (sb) { M.subeSecmelileri(durum, sb).forEach(function (x) { if (isimler.indexOf(x.ad) < 0) isimler.push(x.ad); }); });
    if (!l.length || !isimler.length) return '<section class="kart dd5-sec-matris"><h3>Seçmeli ders × şube matrisi</h3><p class="ince">Bu düzeyde henüz seçmeli ders bulunmuyor. Aşağıdaki havuzdan ders seçip şubelere atayın.</p></section>';
    var limit = t.secmeliSaat[t.siniflar.indexOf(s)] || 0;
    var h = '<section class="kart dd5-sec-matris"><div class="dd5-ic-ust"><h3>Seçmeli ders × şube matrisi</h3><span class="ince">Her hücrede saat düzenleyin veya şubeden kaldırın</span></div><div class="kaydirma"><table class="tablo matris"><thead><tr><th>Ders</th>' + l.map(function (sb) { return '<th class="s">' + esc(sb.ad) + '</th>'; }).join('') + '</tr></thead><tbody>';
    isimler.sort(function (a, b) { return a.localeCompare(b, 'tr'); }).forEach(function (ad) {
      h += '<tr><th>' + esc(ad) + '</th>' + l.map(function (sb) {
        var liste = M.subeSecmelileri(durum, sb), ix = liste.findIndex(function (x) { return x.ad === ad; });
        if (ix < 0) return '<td class="s sifir">—</td>';
        // Şubeye özel listeye geçiş yapıldığı anda düğme değişikliği yalnız o şubeyi etkiler.
        var row = liste[ix];
        return '<td><div class="dd5-matris-hucre"><select data-a="dd5-secmeli-saat" data-v="' + esc(sb.id + '|' + ad) + '" aria-label="' + esc(sb.ad + ' ' + ad + ' saat') + '">' +
          Array.from({length:limit}, function (_, i) { return i + 1; }).map(function (n) { return '<option value="' + n + '"' + (+row.saat === n ? ' selected' : '') + '>' + n + ' sa</option>'; }).join('') + '</select>' +
          '<button class="btn ikon-btn tehlike" data-a="dd5-secmeli-sil" data-v="' + esc(sb.id + '|' + ad) + '" title="Bu şubeden seçmeli dersi kaldır" aria-label="' + esc(sb.ad + ' ' + ad + ' kaldır') + '">' + ikon('cop') + '</button></div></td>';
      }).join('') + '</tr>';
    });
    h += '</tbody><tfoot><tr class="toplam"><th>Seçmeli saat toplamı / sınır</th>' + l.map(function (sb) { return '<td class="s"><b>' + secmeliToplam(M.subeSecmelileri(durum, sb)) + '</b> / ' + limit + '</td>'; }).join('') + '</tr></tfoot></table></div></section>';
    return h;
  }
  function dd5SecmeliDegistir(sid, ad, yeni, sil) {
    var sb = sube(sid); if (!sb) return 'Şube bulunamadı.';
    var liste = M.subeSecmelileri(durum, sb), old = liste.findIndex(function (x) { return x.ad === ad; });
    if (old < 0) return 'Ders şubeye atanmış değil.';
    var limit = secmeliGerekli('sube', sid);
    if (!sil && (yeni < 1 || yeni + secmeliToplam(liste, old) > limit)) return 'Seçmeli ders toplamı ' + limit + ' saati aşamaz.';
    // Ana sınıf düzeyi listesini değiştirmeden, yalnız seçilen şubeyi özelleştir.
    var hedef = secmeliListesi('sube', sid), ix = hedef.findIndex(function (x) { return x.ad === ad; });
    if (sil) hedef.splice(ix, 1); else hedef[ix].saat = yeni;
    kilitleriTemizle(); degisti(true); ciz();
    return null;
  }

  // ---------- Blok düzeni: bütün zorunlu ve seçmeli dersler tek sayfada ----------
  function ux3BlokOnerileri(saat, gunSayisi) {
    saat = +saat; gunSayisi = +gunSayisi;
    if (!Number.isInteger(saat) || saat < 1 || !Number.isInteger(gunSayisi) || gunSayisi < 1) return [];
    var out = [];
    // K05 gereği iki saatlik blok sınırını aşmayan sıralı kalıplar.
    for (var ikili = Math.floor(saat / 2); ikili >= 0; ikili--) {
      var birli = saat - 2 * ikili;
      if (ikili + birli > gunSayisi) continue;
      out.push(Array(ikili).fill(2).concat(Array(birli).fill(1)).join('+'));
    }
    return out;
  }
  function ux3BlokDogrula(metin, saat, gunSayisi, kilitler) {
    var norm = String(metin || '').replace(/\s+/g, '');
    if (!/^\d+(\+\d+)*$/.test(norm)) return 'Bloklar 2+2+1 biçiminde tam sayılarla yazılmalı.';
    var p = norm.split('+').map(Number);
    if (p.some(function(x) { return !Number.isInteger(x) || x < 1 || x > 2; })) return 'K05: Bir blok en fazla 2 ders saati olabilir.';
    if (p.reduce(function(a,b){return a+b;},0) !== +saat) return 'Blokların toplamı haftalık ' + saat + ' saat olmalı.';
    if (p.length > +gunSayisi) return 'Her blok farklı gün olacağından, ' + gunSayisi + ' günden fazla blok kullanılamaz.';
    var yedek = p.slice();
    if ((kilitler || []).some(function(k) { var i = yedek.indexOf(+k.uzunluk); if (i < 0) return true; yedek.splice(i, 1); return false; })) return 'Bu blok düzeni mevcut kilitli ders saatleriyle uyuşmuyor.';
    return '';
  }
  function bloklarCiz(filtre, gomulu) {
    var l = dersListesi().slice().sort(function(a,b) {
      var sa = sube(a.subeId) || {}, sb = sube(b.subeId) || {};
      var ga = +sa.sinif || 0, gb = +sb.sinif || 0;
      return ga-gb || (sa.ad || '').localeCompare(sb.ad || '', 'tr') || (a.grup==='Seçmeli') - (b.grup==='Seçmeli') || a.ders.localeCompare(b.ders,'tr');
    });
    var D = +durum.okul.gunSayisi;
    var cZ = l.filter(function(d) { return d.grup !== 'Seçmeli'; }).length;
    var cS = l.length - cZ;
    var cO = l.filter(function(d) { return !!durum.yerlesimler[d.id]; }).length;
    var h = gomulu ? '<div class="kart"><h3>Blok düzenleri</h3><p class="ince">Zorunlu ve seçmeli derslerin tamamı burada düzenlenir. Öğretmen Atama menüsünden çıkılmaz.</p></div>' :
      sayfaBasi('Blok düzeni', 'Zorunlu ve seçmeli bütün dersler aynı ekranda. Hazır blok seçin ya da kendiniz oluşturun.');
    h += '<div class="dd6-block-shell"><div class="dd6-block-metrics">' +
      '<div><b>' + l.length + '</b><small>Toplam şube-ders</small></div><div><b>' + cZ + '</b><small>Zorunlu</small></div><div><b>' + cS + '</b><small>Seçmeli</small></div><div><b>' + cO + '</b><small>Özelleştirilmiş</small></div></div>' +
      '<div class="dd6-block-toolbar"><label for="dd6-blok-ara">Ders veya şube ara</label><input id="dd6-blok-ara" type="search" autocomplete="off" placeholder="Örn. Matematik veya 5-A" data-a="dd6-blok-ara" aria-label="Bütün blok derslerinde ara">' +
      '<span class="dd6-block-hint">Her satırdaki <b>Bloku düzenle</b> düğmesi yalnız o şubenin dersini değiştirir.</span></div>';
    if (!l.length) return h + '<div class="kart bos-durum">Henüz ders yok. Önce 4. menüden ders ekleyin.</div></div>';
    var sections = {}, order = [];
    l.forEach(function(d) {
      var sb = sube(d.subeId) || {}, grade = String(sb.sinif || 'Diğer');
      if (!sections[grade]) { sections[grade] = []; order.push(grade); }
      sections[grade].push(d);
    });
    order.forEach(function(grade) {
      h += '<section class="dd6-block-group"><div class="dd6-block-group-head"><h3>' + esc(sinifEtiketi(grade)) + '</h3><span>' + sections[grade].length + ' ders</span></div>' +
        '<div class="dd6-block-scroll"><table class="dd6-block-table"><thead><tr><th>Şube</th><th>Ders</th><th>Tür</th><th>Saat</th><th>Hazır öneri</th><th>Etkin blok</th><th></th></tr></thead><tbody>';
      sections[grade].forEach(function(d) {
        var sb = sube(d.subeId) || {}, isS = d.grup === 'Seçmeli';
        var öneriler = ux3BlokOnerileri(d.saat,D);
        var kendi = !!durum.yerlesimler[d.id];
        var mevcut = d.yerlesimMetni || (öneriler[0] || 'Kural gerekli');
        var arama = ((sb.ad || '')+' '+d.ders+' '+d.grup).toLocaleLowerCase('tr-TR');
        var placeholder = d.ders === 'Seçmeli Ders';
        h += '<tr class="dd6-block-row" data-dd6-search="'+esc(arama)+'"><td class="dd6-class">'+esc(sb.ad||'')+'</td>'+
          '<td><strong>'+esc(d.ders)+'</strong>' + (placeholder ? '<small>Henüz seçmeli ders tanımlanmadı</small>' : '') + '</td>' +
          '<td><span class="dd6-type '+(isS?'elective':'compulsory')+'">'+(isS?'Seçmeli':'Zorunlu')+'</span></td>'+
          '<td><b>'+d.saat+' sa</b></td><td class="dd6-recommend">'+(öneriler.length ? esc(öneriler[0]) : '<span class="dd6-warning">Özel kural gerekli</span>')+'</td>'+
          '<td><span class="dd6-pattern">'+esc(mevcut)+'</span>'+(kendi?'<small class="dd6-custom">Şubeye özel</small>':'<small class="dd6-auto">'+(d.yerlesimKaynak==='duzey'?'Sınıf kuralı':'Otomatik')+'</small>')+'</td>'+
          '<td><button type="button" class="btn kucuk dd6-edit" data-a="dd5-blok-ac" data-v="'+esc(d.id)+'"'+(placeholder?' disabled title="Önce seçmeli ders seçin"':'')+'>Bloku düzenle</button></td></tr>';
      });
      h += '</tbody></table></div></section>';
    });
    h += '<p class="dd6-block-footnote">Hazır öneriler haftalık ders saatinden üretilir. Bir blok en fazla 2 ders saatidir ve farklı bloklar farklı günlere yerleşir. Kilitli saatlerle çelişen düzen kaydedilmez.</p>';
    if (!gomulu) h += '<details class="dd6-block-assign"><summary>Öğretmen atamalarını da görüntüle</summary>'+blokAtamaCiz()+'</details>';
    return h + '</div>';
  }

  // 5. menünün Atama sekmesi: başka sayfaya gitmeden dersin öğretmenini değiştirir.
  function blokAtamaCiz() {
    var l = dersListesi().filter(function (d) { return d.ders !== 'Seçmeli Ders'; });
    var yuk = ogretmenYukleri(l), t = tur();
    var h = sayfaBasi('Blokların öğretmenleri', 'Bu menüde kalarak blokların hangi öğretmene ait olduğunu kontrol edip değiştirebilirsiniz.');
    if (!l.length) return h + '<div class="kart bos-durum">Öğretmen ataması yapılacak ders yok.</div>';
    t.siniflar.forEach(function (s) {
      var dizi = l.filter(function (d) { return (sube(d.subeId) || {}).sinif === s; });
      if (!dizi.length) return;
      h += '<section class="kart"><h3>' + esc(sinifEtiketi(s)) + '</h3><div class="kaydirma"><table class="tablo"><thead><tr><th>Şube</th><th>Ders</th><th>Saat</th><th>Blok</th><th>Öğretmen ata / değiştir</th></tr></thead><tbody>';
      dizi.forEach(function (d) {
        h += '<tr><td>' + esc((sube(d.subeId) || {}).ad || '') + '</td><td>' + esc(d.ders) + '</td><td>' + d.saat + '</td><td>' + esc(d.yerlesimMetni || '') + '</td><td>' + ogretmenSecimi(d, 'data-a="atama" data-v="' + esc(d.id) + '"', yuk) + '</td></tr>';
      });
      h += '</tbody></table></div></section>';
    });
    return h;
  }

  // ---------- Seçmeli ders atama ----------
  /** MEB havuzu + okulun elle eklediği seçmeliler: [ad, grup, sınıflar, saat, seçenek, okulaOzel] */
  function secmeliHavuzu() {
    var t = tur(), l = VERI.havuzlar[t.havuz].dersler.slice();
    durum.ozelSecmeliler.forEach(function (e) { l.push([e.ad, e.grup, e.siniflar, e.saat, 'okula özel', true]); });
    return l;
  }
  function secmeliGruplari() {
    var g = VERI.havuzlar[tur().havuz].gruplar.slice();
    durum.ozelSecmeliler.forEach(function (e) { if (g.indexOf(e.grup) < 0) g.push(e.grup); });
    return g;
  }
  function secmeliCiz(gomulu) {
    var t = tur(), dersler = dersListesi();
    var duzeyler = t.siniflar.filter(function (s, si) { return (t.secmeliSaat[si] || 0) > 0 && durum.subeler.some(function (x) { return x.sinif === s; }); });
    var secmeliIslemler = '<button class="btn" data-a="ozel-secmeli-ac">' + ikon('artı') + 'Manuel seçmeli ekle</button><button class="btn" data-a="secmeli-oner-tum">Tüm şubelere öner</button>';
    var h = gomulu ? '' : sayfaBasi('Seçmeli ders atama', 'Soldaki havuzdan dersleri, sağdan şubeleri işaretleyip “Ata”ya basın. Şube kartlarında saatleri düzenleyebilir, dersi × ile kaldırabilirsiniz. Seçmeli saati çizelgedeki sınırı aşamaz.', secmeliIslemler);
    h += '<div id="doldurma">' + doldurmaUyarisi(dersler) + '</div>';
    if (!duzeyler.length) return h + '<div class="kart bos-durum">Bu okul türünde ya da açılan şubelerde seçmeli ders saati yok.</div>';
    if (duzeyler.indexOf(ui.secmeliSinif) < 0) { ui.secmeliSinif = duzeyler[0]; ui.secDers = {}; ui.secSube = {}; }
    ui.secDers = ui.secDers || {}; ui.secSube = ui.secSube || {}; ui.secDersSaat = ui.secDersSaat || {};
    var s = ui.secmeliSinif, si = t.siniflar.indexOf(s), gerekli = t.secmeliSaat[si];
    var subeler = durum.subeler.filter(function (x) { return x.sinif === s; });
    var zorunluAdlar = {};
    dersler.forEach(function (d) { if (d.grup !== 'Seçmeli' && sube(d.subeId).sinif === s) zorunluAdlar[d.ders] = true; });
    var havuz = secmeliHavuzu().filter(function (d) { return d[2].indexOf(s) >= 0; });
    var kullanim = {};
    subeler.forEach(function (sb) { M.subeSecmelileri(durum, sb).forEach(function (x) { kullanim[x.ad] = (kullanim[x.ad] || 0) + 1; }); });
    var grupF = ui.secGrup || '';
    var secDersSay = Object.keys(ui.secDers).filter(function (k) { return ui.secDers[k]; }).length;
    var secSubeSay = subeler.filter(function (x) { return ui.secSube[x.id]; }).length;

    if (!gomulu) h += '<div class="arac-cubugu">' + sekmeler('secmeli-sinif', s, duzeyler.map(function (x) {
      var subeX = durum.subeler.filter(function (y) { return y.sinif === x; });
      var tam = subeX.every(function (y) { return M.subeSecmelileri(durum, y).reduce(function (a, z) { return a + (+z.saat || 0); }, 0) === t.secmeliSaat[t.siniflar.indexOf(x)]; });
      return [x, sinifEtiketi(x) + (tam ? ' ✓' : '')];
    })) + '<span class="ince">' + sinifEtiketi(s) + ': haftada <b>' + gerekli + ' saat</b> seçmeli · ' + subeler.length + ' şube</span></div>';

    h += '<div class="secmeli-cerceve">';
    // Sol: havuz
    h += '<aside class="kart havuz-panel"><div class="kart-ust"><h3>Seçmeli havuzu <span class="ek">' + havuz.length + ' ders</span></h3></div>' +
      '<input type="search" placeholder="Ders ara…" data-a="secmeli-ara" value="' + esc(ui.secmeliAra || '') + '" class="tam">' +
      '<div class="dd7-pool-actions"><span>' + secDersSay + ' seçili</span><button type="button" class="dd7-text-action" data-a="dd7-sec-gorunen">Görünenleri seç</button><button type="button" class="dd7-text-action" data-a="dd7-sec-temizle">Temizle</button></div>' +
      '<div class="dd7-elective-filter"><button class="dd7-switch' + (ui.secSadeceSecili ? ' aktif' : '') + '" data-a="dd7-sec-sadece">' + (ui.secSadeceSecili ? '✓ ' : '') + 'Yalnız seçilenler</button></div>' +
      '<div class="filtre-cipleri"><button class="fcip' + (!grupF ? ' aktif' : '') + '" data-a="sec-grup" data-v="">Tümü</button>' + secmeliGruplari().map(function (g) {
        return havuz.some(function (d) { return d[1] === g; }) ? '<button class="fcip' + (grupF === g ? ' aktif' : '') + '" data-a="sec-grup" data-v="' + esc(g) + '" style="--h:' + M.renk(g) + '"><i></i>' + esc(g) + '</button>' : '';
      }).join('') + '</div><div class="havuz-liste">';
    havuz.filter(function (d) { return (!grupF || d[1] === grupF) && (!ui.secSadeceSecili || ui.secDers[d[0]]); }).forEach(function (d) {
      var ad = d[0], pasif = zorunluAdlar[ad], secili = !!ui.secDers[ad];
      var saat = ui.secDersSaat[ad] || Math.min(t.secmeliVarsayilanSaat || d[3], gerekli);
      h += '<div class="havuz-oge' + (secili ? ' secili' : '') + (pasif ? ' pasif' : '') + '" data-ara="' + esc(ad.toLocaleLowerCase('tr')) + '" style="--h:' + M.renk(d[1]) + '">' +
        '<label class="ho-sol"><input type="checkbox" data-a="sec-ders-sec" value="' + esc(ad) + '"' + (secili ? ' checked' : '') + (pasif ? ' disabled' : '') + '><span class="ho-ad"><b>' + esc(ad) + '</b>' +
        '<small><i class="grup-nokta"></i>' + esc(d[1]) + (d[5] ? ' · <span class="etiket Ek">okula özel</span>' : '') + (pasif ? ' · zorunlu derslerde var' : '') + '</small></span></label>' +
        '<span class="ho-sag">' + (kullanim[ad] ? '<span class="etiket yesil" title="Bu dersi alan şube sayısı">' + kullanim[ad] + '/' + subeler.length + '</span>' : '') +
        '<select data-a="sec-ders-saat" data-v="' + esc(ad) + '" title="Haftalık saat"' + (pasif ? ' disabled' : '') + '>' + [1, 2, 3, 4, 5, 6].filter(function (n) { return n <= gerekli; }).map(function (n) { return '<option' + (n === saat ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select><span class="ince">sa</span>' +
        (d[5] ? '<button class="btn ikon-btn tehlike" data-a="ozel-secmeli-sil" data-v="' + esc(ad) + '" title="Okula özel dersi sil">' + ikon('cop') + '</button>' : '') + '</span></div>';
    });
    h += '</div></aside>';

    // Sağ: seçim çubuğu + şube kartları
    var tumSecili = subeler.length && secSubeSay === subeler.length;
    h += '<div class="secmeli-sag"><div class="secim-cubugu' + (secDersSay && secSubeSay ? ' hazir' : '') + '">' +
      '<label class="satir-alan"><input type="checkbox" data-a="sec-sube-hepsi"' + (tumSecili ? ' checked' : '') + '> Tüm şubeler</label>' +
      '<span class="secim-metni"><b>' + secDersSay + '</b> ders · <b>' + secSubeSay + '</b> şube seçili</span><span class="bosluk"></span>' +
      (secDersSay || secSubeSay ? '<button class="btn kucuk" data-a="secim-temizle">Seçimi temizle</button>' : '') +
      '<button class="btn tehlike" data-a="secmeli-kaldir"' + (secDersSay && secSubeSay ? '' : ' disabled') + '>Seçilenleri kaldır</button>' +
      '<button class="btn ana" data-a="secmeli-ata"' + (secDersSay && secSubeSay ? '' : ' disabled') + '>' + ikon('artı') + 'Seçilenleri ata</button></div>';
    if (!secDersSay || !secSubeSay) h += '<p class="ince ipucu">' + (secDersSay ? 'Şimdi ders atanacak şubeleri işaretleyin.' : 'Soldaki havuzdan bir ya da birden çok ders işaretleyin.') + '</p>';
    h += '<div class="dd7-branch-overview"><div class="dd7-overview-title"><div><b>Şubeleri seç</b><small>İşaretlediğin dersler yalnızca seçilen şubelere atanır.</small></div><button type="button" class="dd7-text-action" data-a="dd7-sec-bos-sube">Boş saati olanları seç</button></div><div class="dd7-branch-grid">' + subeler.map(function (sb) { var bos = gerekli - secmeliToplam(M.subeSecmelileri(durum, sb)); return '<label class="dd7-branch-chip' + (ui.secSube[sb.id] ? ' aktif' : '') + '"><input type="checkbox" data-a="sec-sube-sec" value="' + esc(sb.id) + '"' + (ui.secSube[sb.id] ? ' checked' : '') + '><span>' + esc(sb.ad) + '</span><small class="' + (bos <= 0 ? 'dd7-full' : '') + '">' + (bos > 0 ? bos + ' sa boş' : (bos === 0 ? 'Tamam' : Math.abs(bos) + ' sa fazla')) + '</small></label>'; }).join('') + '</div></div><div class="dd7-list-heading"><b>Şube dersleri</b><span>Atanmış seçmelileri düzenle veya kaldır</span></div><div class="sube-kartlari">';
    subeler.forEach(function (sb) {
      var ozel = !!durum.subeSecmeli[sb.id];
      var l = M.subeSecmelileri(durum, sb), top = l.reduce(function (a, x) { return a + (+x.saat || 0); }, 0);
      var diger = dersler.filter(function (d) { return d.subeId === sb.id && d.grup !== 'Seçmeli'; });
      var digerSaat = diger.reduce(function (a, d) { return a + d.saat; }, 0);
      var durumCls = top === gerekli ? 'tam' : (top > gerekli ? 'fazla' : 'eksik');
      h += '<div class="kart sube-karti' + (ui.secSube[sb.id] ? ' secili' : '') + '">' +
        '<div class="sk-ust"><label class="satir-alan"><input type="checkbox" data-a="sec-sube-sec" value="' + sb.id + '"' + (ui.secSube[sb.id] ? ' checked' : '') + '><b class="sk-ad">' + esc(sb.ad) + '</b></label>' +
        '<span class="sk-saat ' + durumCls + '">' + top + ' / ' + gerekli + ' saat</span></div>' +
        '<div class="ilerleme ince-cubuk' + (top < gerekli ? ' eksik' : '') + '"><i style="width:' + Math.min(100, Math.round(top / gerekli * 100)) + '%"></i></div>';
      if (!l.length) h += '<div class="sk-bos">Henüz seçmeli yok</div>';
      else {
        h += '<div class="sk-liste">' + l.map(function (x, i) {
          return '<div class="sk-satir" style="--h:' + M.renk(x.grup || '') + '"><i class="grup-nokta"></i><span class="sk-ders" title="' + esc(x.grup || '') + '">' + esc(x.ad) + '</span>' +
            '<select data-a="secmeli-saat" data-k="sube" data-v="' + sb.id + '" data-i="' + i + '">' + [1, 2, 3, 4, 5, 6].filter(function (n) { return n <= gerekli; }).map(function (n) { return '<option' + (n === +x.saat ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select>' +
            '<button class="paralel-dug' + ((durum.paralelGrup || {})[sb.id + '|S:' + x.ad] ? ' aktif' : '') + '" data-a="paralel-ac" data-v="' + esc(sb.id + '|S:' + x.ad) + '" title="Paralel (alt grup): işaretli seçmeliler aynı saatte, öğrenciler gruplara ayrılarak okutulur">∥</button>' +
            '<button class="cip-sil" data-a="secmeli-sil" data-k="sube" data-v="' + sb.id + '" data-i="' + i + '" title="Kaldır">×</button></div>';
        }).join('') + '</div>';
      }
      if (top < gerekli) h += '<div class="sk-not">' + (gerekli - top) + ' saat boş — programda “Seçmeli Ders” olarak ayrılır</div>';
      h += '<div class="sk-alt"><details><summary>Diğer dersleri · ' + diger.length + ' ders, ' + digerSaat + ' saat</summary><div class="sk-diger">' +
        diger.map(function (d) { var o = ogretmen(d.ogretmenId); return '<span class="cip kucuk" title="' + esc(o ? o.ad : 'atanmamış') + '">' + esc(d.ders) + ' <b>' + d.saat + '</b></span>'; }).join('') + '</div></details>' +
        '<span class="satir">' + (ozel ? '<span class="etiket Seçmeli" title="Bu şubenin listesi düzeyden ayrı">şubeye özel</span><button class="btn kucuk" data-a="secmeli-duzeye" data-v="' + sb.id + '" title="Düzey listesine döndür">Düzeye döndür</button>' : '<span class="etiket" title="Sınıf düzeyinin ortak listesi">düzey listesi</span>') +
        '<button class="btn kucuk" data-a="secmeli-oner" data-k="sube" data-v="' + sb.id + '">Öner</button></span></div></div>';
    });
    h += '</div></div></div>';
    return h;
  }
  /** Seçili derslerin seçili şubelere atanması / kaldırılması */
  function secmeliTopluUygula(kaldir) {
    var t = tur(), s = ui.secmeliSinif, gerekli = t.secmeliSaat[t.siniflar.indexOf(s)];
    var subeler = durum.subeler.filter(function (x) { return x.sinif === s; });
    var hedefler = subeler.filter(function (x) { return ui.secSube[x.id]; });
    var havuz = secmeliHavuzu();
    var secilen = Object.keys(ui.secDers).filter(function (k) { return ui.secDers[k]; }).map(function (ad) {
      var d = havuz.filter(function (x) { return x[0] === ad; })[0] || [ad, '', [], 2];
      return { ad: ad, grup: d[1], saat: +(ui.secDersSaat[ad] || Math.min(t.secmeliVarsayilanSaat || d[3], gerekli)) };
    });
    var tum = hedefler.length === subeler.length && !hedefler.some(function (x) { return durum.subeSecmeli[x.id]; });
    var listeler = tum ? [{ ad: sinifEtiketi(s) + ' (tüm şubeler)', liste: secmeliListesi('duzey', s) }]
      : hedefler.map(function (x) { return { ad: x.ad, liste: secmeliListesi('sube', x.id) }; });
    // Toplu seçim atomiktir: sınırı aşan tek bir şube varsa hiçbir şubenin dersleri değişmez.
    if (!kaldir) {
      var engeller = [];
      hedefler.forEach(function (sb) {
        var mevcut = M.subeSecmelileri(durum, sb);
        var ekSaat = secilen.reduce(function (top, x) { return top + (mevcut.some(function (m) { return m.ad === x.ad; }) ? 0 : x.saat); }, 0);
        if (secmeliToplam(mevcut) + ekSaat > gerekli) engeller.push(sb.ad + ': ' + (secmeliToplam(mevcut) + ekSaat) + '/' + gerekli + ' saat');
      });
      if (engeller.length) { bildir('Atama yapılmadı; önce ders saati veya şube seçimini düzeltin: ' + engeller.join(', '), 'hata'); return; }
    }
    var n = 0, zaten = 0, sigmayan = [];
    listeler.forEach(function (h) {
      secilen.forEach(function (x) {
        var j = h.liste.map(function (y) { return y.ad; }).indexOf(x.ad);
        if (kaldir) { if (j >= 0) { h.liste.splice(j, 1); n++; } return; }
        if (j >= 0) { zaten++; return; }
        if (secmeliToplam(h.liste) + x.saat > gerekli) { sigmayan.push(h.ad + ': ' + x.ad); return; }
        h.liste.push({ ad: x.ad, grup: x.grup, saat: x.saat }); n++;
      });
    });
    kilitleriTemizle(); degisti(true);
    if (kaldir || !sigmayan.length) { ui.secDers = {}; }
    ciz();
    if (kaldir) bildir(n + ' seçmeli kaldırıldı.');
    else bildir(n + ' seçmeli atandı' + (zaten ? ' (' + zaten + ' atama zaten vardı)' : '') + (sigmayan.length ? '. Saat sınırı (' + gerekli + ' saat) nedeniyle eklenemeyen: ' + sigmayan.slice(0, 4).join(', ') + (sigmayan.length > 4 ? ' …' : '') + '. Önce şube kartından bir seçmeliyi kaldırın ya da saatini azaltın.' : '.'), sigmayan.length ? 'hata' : '');
  }

  // ---------- Öğretmen listesi (toplu işlemler) ----------
  function ogretmenSil(ids) {
    var sil = {};
    ids.forEach(function (id) { sil[id] = true; });
    durum.ogretmenler = durum.ogretmenler.filter(function (o) { return !sil[o.id]; });
    Object.keys(durum.atamalar).forEach(function (k) { if (sil[durum.atamalar[k]]) delete durum.atamalar[k]; });
    ids.forEach(function (id) { delete ui.secOgr[id]; });
  }
  function seciliOgretmenler() { return durum.ogretmenler.filter(function (o) { return ui.secOgr[o.id]; }); }
  function ogretmenlerCiz() {
    var dersler = dersListesi(), yuk = ogretmenYukleri(dersler);
    var verdigi = {};
    dersler.forEach(function (d) { if (d.ogretmenId) { var sb = sube(d.subeId); (verdigi[d.ogretmenId] = verdigi[d.ogretmenId] || []).push((sb ? sb.ad.replace(/[-\/]/, '') : '') + ' ' + M.kisaltma(d.ders)); } });
    var branslar = Object.keys(VERI.branslar);
    var secili = seciliOgretmenler();
    var h = sayfaBasi('Öğretmen listesi', 'Öğretmen ekleyin, branş ve ders yüklerini düzenleyin.',
      '<button class="btn" data-a="ogr-excel-ac">' + ikon('artı') + 'Excel / CSV içe aktar</button>' +
      '<button class="btn ana" data-a="oto-ata">' + ikon('ogretmenler') + 'Branş ihtiyacına göre oluştur ve ata</button>');
    h += '<div class="kart"><h3>Öğretmen ekle</h3><div class="satir">' +
      '<input type="text" id="yeni-ogr-ad" placeholder="Ad Soyad" style="min-width:220px">' +
      '<select id="yeni-ogr-brans">' + branslar.map(function (b) { return '<option>' + esc(b) + '</option>'; }).join('') + '</select>' +
      '<input type="number" id="yeni-ogr-max" value="' + durum.ayarlar.maxSaat + '" min="1" max="40" title="Haftalık üst sınır" style="width:80px">' +
      '<button class="btn ana" data-a="ogr-ekle">' + ikon('artı') + 'Ekle</button>' +
      '</div>' +
      '<details style="margin-top:10px"><summary>Toplu ekle</summary><div class="satir" style="margin-top:8px;align-items:flex-start"><textarea id="toplu-ogr" rows="4" placeholder="Ayşe YILMAZ&#10;Mehmet KAYA" style="min-width:300px"></textarea>' +
      '<button class="btn" data-a="ogr-toplu-ekle">Seçili branşla toplu ekle</button></div></details></div>';

    h += '<div class="kart"><div class="kart-ust"><h3>Öğretmenler <span class="ek">' + durum.ogretmenler.length + ' öğretmen · ' + dersler.filter(function (d) { return d.ogretmenId; }).reduce(function (a, d) { return a + d.saat; }, 0) + ' saat atanmış</span></h3></div>';
    if (secili.length) {
      h += '<div class="toplu-cubuk"><b>' + secili.length + ' öğretmen seçili</b>' +
        '<select id="toplu-brans"><option value="">Branş değiştir…</option>' + branslar.map(function (b) { return '<option>' + esc(b) + '</option>'; }).join('') + '</select>' +
        '<input type="number" id="toplu-max" placeholder="Üst sınır" min="1" max="40" style="width:96px">' +
        '<input type="text" id="toplu-kulup" placeholder="Sosyal kulüp" style="width:150px">' +
        '<button class="btn" data-a="ogr-toplu-uygula">Uygula</button>' +
        '<button class="btn" data-a="ogr-atamalari-kaldir">Atamalarını kaldır</button>' +
        '<button class="btn tehlike" data-a="ogr-toplu-sil">' + ikon('cop') + 'Seçilenleri sil</button>' +
        '<button class="btn kucuk" data-a="ogr-secim-temizle">Seçimi kaldır</button></div>';
    }
    if (!durum.ogretmenler.length) {
      h += '<div class="bos-durum">Henüz öğretmen yok. Yukarıdan ekleyin ya da “Branş ihtiyacına göre oluştur ve ata”ya basın.</div>';
    } else {
      var hepsi = durum.ogretmenler.every(function (o) { return ui.secOgr[o.id]; });
      h += '<div class="kaydirma"><table class="tablo"><tr><th class="s"><input type="checkbox" data-a="ogr-hepsini-sec"' + (hepsi ? ' checked' : '') + ' title="Tümünü seç"></th><th>Ad Soyad</th><th>Branş</th><th title="Müdür ve müdür yardımcıları öğretmen nöbeti tutmaz; müdür yardımcıları idari nöbet tutar">Görev</th><th class="s">Saat</th><th class="s">Üst sınır</th><th>Verdiği dersler</th><th>Sosyal kulüp</th><th></th></tr>' +
        durum.ogretmenler.slice().sort(function (a, b) { return a.brans.localeCompare(b.brans, 'tr') || a.ad.localeCompare(b.ad, 'tr'); }).map(function (o) {
          var asim = yuk[o.id] > (o.maxSaat || 30);
          return '<tr class="dd3-ogretmen-satir ' + (ui.secOgr[o.id] ? 'secili-satir' : '') + '" data-dd3-ara="' + esc(o.ad + ' ' + o.brans + ' ' + (GOREV_AD[o.gorev || ''] || '')) + '" data-dd3-durum="' + (asim ? 'asim' : ((yuk[o.id] || 0) === 0 ? 'bos' : 'dolu')) + '"><td class="s"><input type="checkbox" data-a="ogr-sec" data-v="' + o.id + '"' + (ui.secOgr[o.id] ? ' checked' : '') + '></td>' +
            '<td><div class="dd3-kisi"><span class="dd3-avatar">' + esc(basHarfleri(o.ad)) + '</span><input type="text" aria-label="Öğretmen adı" data-a="ogr-ad" data-v="' + o.id + '" value="' + esc(o.ad) + '"></div></td>' +
            '<td><select data-a="ogr-brans" data-v="' + o.id + '">' + branslar.concat(branslar.indexOf(o.brans) < 0 ? [o.brans] : []).map(function (b) { return '<option' + (b === o.brans ? ' selected' : '') + '>' + esc(b) + '</option>'; }).join('') + '</select></td>' +
            '<td><select data-a="ogr-gorev" data-v="' + o.id + '" class="' + (yoneticiMi(o) ? 'gorev-yonetici' : '') + '">' + GOREVLER.map(function (g) { return '<option value="' + g[0] + '"' + ((o.gorev || '') === g[0] ? ' selected' : '') + '>' + g[1] + '</option>'; }).join('') + '</select></td>' +
            '<td class="s"><span class="yuk-cubuk' + (asim ? ' asim' : '') + '" title="' + yuk[o.id] + ' / ' + (o.maxSaat || 30) + '"><i style="width:' + Math.min(100, Math.round(yuk[o.id] / (o.maxSaat || 30) * 100)) + '%"></i></span><b class="yuk' + (asim ? ' asim' : '') + '">' + yuk[o.id] + '</b></td>' +
            '<td class="s"><input type="number" data-a="ogr-max" data-v="' + o.id + '" value="' + (o.maxSaat || 30) + '" style="width:62px"></td>' +
            '<td class="ince kirp" title="' + esc((verdigi[o.id] || []).join(', ')) + '">' + esc((verdigi[o.id] || []).join(', ') || '—') + '</td>' +
            '<td><input type="text" data-a="ogr-kulup" data-v="' + o.id + '" value="' + esc(o.kulup || '') + '" placeholder="—" style="width:140px"></td>' +
            '<td class="s nowrap"><button class="btn kucuk" data-a="ogr-git" data-v="' + o.id + '" title="Derslerini görüntüle ve değiştir">Dersler</button> <button class="btn ikon-btn tehlike" data-a="ogr-sil" data-v="' + o.id + '" title="Sil">' + ikon('cop') + '</button></td></tr>';
        }).join('') + '</table></div>';
    }
    return h + '</div>';
  }

  // ---------- Öğretmen atama ----------
  /** 'brans' | 'ek' | 'disi' : öğretmenin derse uygunluğu */
  function bransUyumu(o, dersAd) {
    if (dersAd === 'Rehberlik ve Yönlendirme') return 'brans';   // sınıf rehber öğretmeni: her branştan olabilir
    var b = M.bransBul(dersAd, VERI.branslar);
    if (!o || !b) return 'brans';
    if (o.brans === b) return 'brans';
    if ((o.ekBranslar || []).indexOf(b) >= 0) return 'ek';
    return 'disi';
  }
  function uyumEtiketi(u) {
    return u === 'disi' ? '<span class="etiket turuncu" title="Öğretmenin branşı dışında">branş dışı</span>' : (u === 'ek' ? '<span class="etiket mor" title="Öğretmenin ek branşı">ek branş</span>' : '');
  }
  function basHarfleri(ad) {
    return String(ad || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(function (k) { return k[0]; }).join('').toLocaleUpperCase('tr');
  }
  function avatar(o) { return '<span class="avatar" style="--h:' + M.renk(o.brans || o.ad) + '">' + esc(basHarfleri(o.ad)) + '</span>'; }
  function ogretmenSecimi(d, ek, yuk) {
    var brans = M.bransBul(d.ders, VERI.branslar);
    var uygun = function (o) { return o.brans === brans || (o.ekBranslar || []).indexOf(brans) >= 0; };
    var adaylar = durum.ogretmenler.filter(function (o) { return uygun(o) || o.id === d.ogretmenId; });
    var digerleri = durum.ogretmenler.filter(function (o) { return adaylar.indexOf(o) < 0; });
    var etiket = function (o) { return esc(o.ad) + (yuk ? ' (' + (yuk[o.id] || 0) + '/' + (o.maxSaat || 30) + ')' : ''); };
    return '<select ' + ek + '><option value="">— atanmamış —</option>' +
      (adaylar.length ? '<optgroup label="' + esc(brans || '') + '">' + adaylar.map(function (o) { return '<option value="' + o.id + '"' + (o.id === d.ogretmenId ? ' selected' : '') + '>' + etiket(o) + (uygun(o) ? '' : ' · branş dışı') + '</option>'; }).join('') + '</optgroup>' : '') +
      (digerleri.length ? '<optgroup label="Diğer branşlar (branş dışı atama)">' + digerleri.map(function (o) { return '<option value="' + o.id + '">' + etiket(o) + ' · ' + esc(o.brans) + '</option>'; }).join('') + '</optgroup>' : '') + '</select>';
  }
  // UX V3 Aşama 4: zorunlu ve seçmeli derslerin tamamı tek çalışma alanında.
  function ux3AtamaAdaylari(d) {
    var yuk = ogretmenYukleri(dersListesi());
    var br = M.bransBul(d.ders, VERI.branslar) || '';
    return durum.ogretmenler.map(function(o) {
      var uyum = o.brans === br || (o.ekBranslar || []).indexOf(br) >= 0;
      var mevcut = o.id === d.ogretmenId;
      var yukSonra = (yuk[o.id] || 0) + (mevcut ? 0 : d.saat);
      var sinir = +(o.maxSaat || durum.ayarlar.maxSaat || 30);
      var kilitler = durum.kilitler[d.id] || [];
      var kapali = kilitler.some(function(k) {
        for (var i=0; i<k.uzunluk; i++) if ((o.kapali || []).indexOf(k.gun + '-' + (k.saat+i)) >= 0) return true;
        return false;
      });
      return {o:o,uyum:uyum,mevcut:mevcut,yuk:yuk[o.id]||0,sonra:yukSonra,sinir:sinir,kapali:kapali,asin:yukSonra>sinir};
    }).sort(function(a,b) {return (+b.mevcut)-(+a.mevcut) || (+b.uyum)-(+a.uyum) || (+a.asin)-(+b.asin) || a.yuk-b.yuk || a.o.ad.localeCompare(b.o.ad,'tr');});
  }
  function ux3AtamaModal() {
    var d = dersBul(ui.modal && ui.modal.dersId); if(!d) {ui.modal=null;return '';}
    var sb = sube(d.subeId), secilen = d.ogretmenId ? ogretmen(d.ogretmenId) : null;
    var diger = !!ui.ux3AtamaDiger;
    var aday = ux3AtamaAdaylari(d);
    var goster = aday.filter(function(x) {return x.uyum || x.mevcut || diger;});
    return '<div class="modal-arka" data-a="modal-kapat"><div class="modal ux3a-modal" role="dialog" aria-modal="true" aria-label="Derse öğretmen ata" data-durdur="1">' +
      '<div class="ux3a-modal-top"><div><small>ÖĞRETMEN ATAMA</small><h3>'+esc(d.ders)+'</h3><p>'+esc(sb ? sb.ad : '')+' · '+d.saat+' saat · '+(d.grup==='Seçmeli'?'Seçmeli':'Zorunlu')+'</p></div><button type="button" class="btn" data-a="modal-kapat" aria-label="Pencereyi kapat">Kapat</button></div>'+
      '<div class="ux3a-selected">Şu an: <strong>'+esc(secilen?secilen.ad:'Öğretmen atanmadı')+'</strong></div>'+
      '<input type="search" id="ux3a-aday-ara" aria-label="Öğretmen ara" placeholder="Öğretmen veya branş ara…" autocomplete="off">'+
      '<label class="ux3a-more"><input type="checkbox" data-a="ux3a-diger"'+(diger?' checked':'')+'> Diğer branş öğretmenlerini de göster</label>'+
      '<div class="ux3a-aday-listesi" role="list" aria-label="Aday öğretmenler">' + (goster.length ? goster.map(function(x) {
         var sorun = x.kapali ? 'Kilitli ders saatinde uygun değil' : x.asin ? 'Haftalık saat sınırı aşılır' : '';
         return '<div class="ux3a-aday" role="listitem" data-ux3a-search="'+esc((x.o.ad+' '+x.o.brans).toLocaleLowerCase('tr-TR'))+'"><div class="ux3a-aday-adi"><b>'+esc(x.o.ad)+'</b><small>'+esc(x.o.brans)+(x.uyum?' · Branş uygun':' · Branş dışı')+'</small></div><div class="ux3a-aday-yuk"><b>'+x.sonra+' / '+x.sinir+' saat</b><small>'+(x.mevcut?'Mevcut öğretmen':sorun||'Atama sonrası')+'</small></div><button type="button" class="btn '+(x.mevcut?'':'ana')+'" data-a="ux3a-sec" data-v="'+esc(x.o.id)+'"'+(x.kapali||x.asin?' disabled title="'+esc(sorun)+'"':'')+'>'+(x.mevcut?'Seçili':'Ata')+'</button></div>';
       }).join('') : '<div class="ux3a-empty">Bu dersin branşında öğretmen bulunamadı. Diğer branşları gösterebilirsin.</div>') + '</div><p class="ux3a-no-match" hidden>Aramanıza uygun öğretmen bulunamadı.</p>'+
       '<div class="ux3a-modal-foot">'+(secilen?'<button class="btn tehlike" data-a="ux3a-kaldir" data-v="'+esc(d.id)+'">Atamayı kaldır</button>':'')+'<span>Branş dışı atama onay ister; kilit ve kapasite çelişen adaylar seçilemez.</span></div></div></div>';
  }
  function ux3AtamaFiltrele() {
    var ar=document.querySelector('#ux3a-aday-ara');if(!ar)return;
    var q=(ar.value||'').toLocaleLowerCase('tr-TR').trim(); var n=0;
    document.querySelectorAll('.ux3a-aday').forEach(function(r){ r.hidden=!!q && (r.getAttribute('data-ux3a-search')||'').indexOf(q)<0; if(!r.hidden)n++;});
    var bos=document.querySelector('.ux3a-no-match');if(bos)bos.hidden=n>0;
  }
  function atamaCiz() {
    if (ui.ux3AtamaGelismis) return '<div class="ux3a-back"><button class="btn" data-a="ux3a-gelismis">← Sade atama ekranına dön</button></div>' + ux3AtamaGelismisCiz();
    var dersler=dersListesi().filter(function(d){return d.ders!=='Seçmeli Ders';});
    var yuk=ogretmenYukleri(dersler);
    var atanmis=dersler.filter(function(d){return !!d.ogretmenId;});
    var bos=dersler.length-atanmis.length;
    var saat=dersler.reduce(function(a,d){return a+d.saat;},0);
    var atanmisSaat=atanmis.reduce(function(a,d){return a+d.saat;},0);
    var dis=atanmis.filter(function(d){return bransUyumu(ogretmen(d.ogretmenId),d.ders)==='disi';}).length;
    var asim=durum.ogretmenler.filter(function(o){return (yuk[o.id]||0)>(o.maxSaat||durum.ayarlar.maxSaat||30);}).length;
    var durumFiltre=ui.ux3AtamaDurum||'hepsi',turFiltre=ui.ux3AtamaTur||'hepsi',sid=ui.ux3AtamaSube||'hepsi';
    var sirali=dersler.slice().sort(function(a,b){return (+!!a.ogretmenId)-(+!!b.ogretmenId) || (sube(a.subeId)||{}).ad.localeCompare((sube(b.subeId)||{}).ad,'tr') || a.ders.localeCompare(b.ders,'tr');});
    var gorunen=sirali.filter(function(d){return (sid==='hepsi'||d.subeId===sid) && (turFiltre==='hepsi'||(turFiltre==='secmeli' ? d.grup==='Seçmeli' : d.grup!=='Seçmeli')) && (durumFiltre==='hepsi'||(durumFiltre==='bos' ? !d.ogretmenId : !!d.ogretmenId));});
    var h='<section class="ux3a-page">'+
      '<div class="ux3a-head"><div><small>8. MENÜ / ÖĞRETMEN ATAMALARI</small><h2>Her dersin öğretmeni tek ekranda</h2><p>Zorunlu ve seçmeli dersleri birlikte gör. Atanmamış dersler listenin başında.</p></div><button type="button" class="btn" data-a="ux3a-gelismis">Gelişmiş görünüm</button></div>'+
      '<div class="ux3a-stats"><div><small>Atanan ders saatleri</small><strong>'+atanmisSaat+' / '+saat+'</strong></div><div><small>Atanmamış dersler</small><strong>'+bos+'</strong></div><div><small>Öğretmen sayısı</small><strong>'+durum.ogretmenler.length+'</strong></div><div><small>Branş dışı / sınır aşan</small><strong>'+dis+' / '+asim+'</strong></div></div>'+
      '<div class="ux3a-work"><div class="ux3a-work-top"><div><h3>Ders–öğretmen listesi</h3><p>Dersin yanındaki düğmeden öğretmen ata veya değiştir.</p></div><span>'+gorunen.length+' ders gösteriliyor</span></div>'+
      '<div class="ux3a-filter"><input type="search" id="ux3a-ders-ara" aria-label="Ders, şube veya öğretmen ara" placeholder="Ders, şube veya öğretmen ara…" autocomplete="off">'+
      '<select id="ux3a-sube" data-a="ux3a-sube" aria-label="Şube filtrele"><option value="hepsi">Tüm şubeler</option>'+durum.subeler.map(function(s){return '<option value="'+esc(s.id)+'"'+(sid===s.id?' selected':'')+'>'+esc(s.ad)+'</option>';}).join('')+'</select>'+
      '<select id="ux3a-tur" data-a="ux3a-tur" aria-label="Ders türü filtrele">'+[['hepsi','Zorunlu + seçmeli'],['zorunlu','Zorunlu dersler'],['secmeli','Seçmeli dersler']].map(function(t){return '<option value="'+t[0]+'"'+(turFiltre===t[0]?' selected':'')+'>'+t[1]+'</option>';}).join('')+'</select>'+
      '<select id="ux3a-durum" data-a="ux3a-durum" aria-label="Atama durumu filtrele">'+[['hepsi','Bütün dersler'],['bos','Atanmamış'],['atanmis','Atanmış']].map(function(t){return '<option value="'+t[0]+'"'+(durumFiltre===t[0]?' selected':'')+'>'+t[1]+'</option>';}).join('')+'</select></div>'+
      '<div class="ux3a-table-wrap"><table class="ux3a-table"><thead><tr><th>Şube</th><th>Ders</th><th>Tür</th><th>Saat</th><th>Öğretmen</th><th>İşlem</th></tr></thead><tbody>';
    gorunen.forEach(function(d){var o=d.ogretmenId ? ogretmen(d.ogretmenId) : null;var bransiDis=o&&bransUyumu(o,d.ders)==='disi';var sb=sube(d.subeId);
      h+='<tr class="ux3a-row'+(!o?' ux3a-unset':'')+'" data-ux3a-search="'+esc(((sb?sb.ad:'')+' '+d.ders+' '+(o?o.ad:'')).toLocaleLowerCase('tr-TR'))+'"><td class="ux3a-class">'+esc(sb?sb.ad:'')+'</td><td><strong>'+esc(d.ders)+'</strong></td><td><span class="ux3a-type '+(d.grup==='Seçmeli'?'elective':'compulsory')+'">'+(d.grup==='Seçmeli'?'Seçmeli':'Zorunlu')+'</span></td><td>'+d.saat+'</td><td>'+(o?'<b class="ux3a-teacher">'+esc(o.ad)+'</b>'+(bransiDis?'<small class="ux3a-alert">Branş dışı</small>':''):'<span class="ux3a-missing">Atanmadı</span>')+'</td><td><button type="button" class="btn '+(!o?'ana':'')+'" data-a="ux3a-ac" data-v="'+esc(d.id)+'">'+(o?'Değiştir':'Öğretmen ata')+'</button></td></tr>'; });
    h+='</tbody></table></div><div class="ux3a-empty" '+(gorunen.length?'hidden':'')+'>Bu filtrelere uygun ders bulunamadı.</div><div id="ux3a-search-empty" class="ux3a-empty" hidden>Aramanızla eşleşen ders bulunamadı.</div></div>'+
      '<div class="ux3a-foot">Branş dışı ve yük sınırını aşan öğretmenlere ilişkin uyarılar atama penceresinde gösterilir. Toplu atama ve detaylı çizelgeler <b>Gelişmiş görünüm</b> içindedir.</div></section>';
    return h;
  }
  function ux3AtamaSatirAra(){var input=document.querySelector('#ux3a-ders-ara');if(!input)return;var q=(input.value||'').toLocaleLowerCase('tr-TR').trim(),n=0;document.querySelectorAll('.ux3a-row').forEach(function(row){row.hidden=!!q&&(row.getAttribute('data-ux3a-search')||'').indexOf(q)<0;if(!row.hidden)n++;});var msg=document.querySelector('#ux3a-search-empty');if(msg)msg.hidden=n>0;}

  function ux3AtamaGelismisCiz() {
    var gorunum = ui.atamaGorunum || 'ogretmen';
    var dersler = dersListesi(), yuk = ogretmenYukleri(dersler);
    var gercek = dersler.filter(function (d) { return d.ders !== 'Seçmeli Ders'; });
    var toplam = gercek.reduce(function (a, d) { return a + d.saat; }, 0);
    var atanan = gercek.filter(function (d) { return d.ogretmenId; });
    var atananSaat = atanan.reduce(function (a, d) { return a + d.saat; }, 0);
    var atanmamis = gercek.filter(function (d) { return !d.ogretmenId; });
    var disi = atanan.filter(function (d) { return bransUyumu(ogretmen(d.ogretmenId), d.ders) === 'disi'; });
    var asim = durum.ogretmenler.filter(function (o) { return (yuk[o.id] || 0) > (o.maxSaat || 30); });
    var oran = toplam ? Math.round(atananSaat / toplam * 100) : 0;
    var h = sayfaBasi('Öğretmen atama', 'Derslere öğretmen atayın, atanan öğretmeni değiştirin, öğretmene branşı dışında da ders verin; tüm atamaları öğretmen ya da sınıf bazında tek ekranda görün.',
      '<button class="btn" data-a="atama-temizle">Tüm atamaları temizle</button><button class="btn ana" data-a="oto-ata">' + ikon('ogretmenler') + 'Eksikleri otomatik ata</button>');
    h += '<div class="ozet">' +
      '<div class="k"><span>Atanan ders saati</span><b>' + atananSaat + ' / ' + toplam + '</b><div class="ilerleme ince-cubuk"><i style="width:' + oran + '%"></i></div></div>' +
      '<div class="k ' + (atanmamis.length ? 'kotu' : 'iyi') + '"><span>Atanmamış ders</span><b>' + atanmamis.length + '</b><small>' + atanmamis.reduce(function (a, d) { return a + d.saat; }, 0) + ' saat</small></div>' +
      '<div class="k"><span>Öğretmen</span><b>' + durum.ogretmenler.length + '</b><small>ort. ' + (durum.ogretmenler.length ? Math.round(atananSaat / durum.ogretmenler.length) : 0) + ' saat</small></div>' +
      '<div class="k ' + (asim.length ? 'kotu' : '') + '"><span>Üst sınırı aşan</span><b>' + asim.length + '</b><small>öğretmen</small></div>' +
      '<div class="k"><span>Branş dışı atama</span><b>' + disi.length + '</b><small>' + disi.reduce(function (a, d) { return a + d.saat; }, 0) + ' saat</small></div></div>';
    h += '<div class="arac-cubugu">' + sekmeler('atama-gorunum', gorunum, [
      ['ogretmen', 'Öğretmen bazında'], ['sinif', 'Sınıf bazında'], ['genel', 'Öğretmen × şube çizelgesi'], ['siniflar', 'Sınıf ders listeleri'], ['havuz', 'Atanmamış' + (atanmamis.length ? ' (' + atanmamis.length + ')' : '')]]) +
      '<span class="bosluk"></span><label class="satir-alan ince">Öğretmen başına en fazla<input type="number" min="10" max="40" data-a="max-saat" value="' + durum.ayarlar.maxSaat + '" style="width:66px"> saat (otomatik atama)</label></div>';
    if (gorunum === 'sinif') return h + atamaMatrisCiz();
    if (gorunum === 'genel') return h + ogretmenSubeCizelgesi(dersler, yuk);
    if (gorunum === 'siniflar') return h + sinifDersListeleri(dersler, false);
    if (gorunum === 'havuz') return h + atamaHavuzCiz(dersler, yuk);
    return h + atamaOgretmenCiz(dersler, yuk);
  }

  function atamaOgretmenCiz(dersler, yuk) {
    if (!durum.ogretmenler.length) return '<div class="kart bos-durum">Önce “Öğretmen listesi” sayfasında öğretmen ekleyin ya da “Eksikleri otomatik ata”ya basın.</div>';
    var branslar = Object.keys(VERI.branslar);
    var filtre = ui.ogrBransFiltre || '';
    var liste = durum.ogretmenler.slice().sort(function (a, b) { return a.brans.localeCompare(b.brans, 'tr') || a.ad.localeCompare(b.ad, 'tr'); });
    if (!ui.atamaOgr || !ogretmen(ui.atamaOgr)) ui.atamaOgr = liste[0].id;
    var o = ogretmen(ui.atamaOgr);
    var benim = dersler.filter(function (d) { return d.ogretmenId === o.id; });
    benim.sort(function (a, b) { return durum.subeler.indexOf(sube(a.subeId)) - durum.subeler.indexOf(sube(b.subeId)); });
    var benimSaat = benim.reduce(function (a, d) { return a + d.saat; }, 0);
    var disiSaat = benim.filter(function (d) { return bransUyumu(o, d.ders) === 'disi'; }).reduce(function (a, d) { return a + d.saat; }, 0);
    var subeSayisi = {}; benim.forEach(function (d) { subeSayisi[d.subeId] = 1; });
    var mx = o.maxSaat || 30, oran = Math.min(100, Math.round(benimSaat / mx * 100));

    // Sol: öğretmen listesi
    var h = '<div class="iki-panel"><aside class="kart panel-liste"><div class="panel-arama">' +
      '<input type="search" placeholder="Öğretmen ara…" data-a="ogr-ara" value="' + esc(ui.ogrAra || '') + '">' +
      '<select data-a="ogr-brans-filtre"><option value="">Tüm branşlar</option>' + branslar.filter(function (b) { return durum.ogretmenler.some(function (x) { return x.brans === b; }); }).map(function (b) { return '<option' + (b === filtre ? ' selected' : '') + '>' + esc(b) + '</option>'; }).join('') + '</select></div>' +
      '<div class="liste-kaydir">' + liste.filter(function (x) { return !filtre || x.brans === filtre; }).map(function (x) {
        var y = yuk[x.id] || 0, m = x.maxSaat || 30;
        return '<button class="liste-oge' + (x.id === o.id ? ' aktif' : '') + '" data-a="atama-ogr" data-v="' + x.id + '" data-ara="' + esc((x.ad + ' ' + x.brans).toLocaleLowerCase('tr')) + '">' + avatar(x) +
          '<span class="lo-metin"><b>' + esc(x.ad) + '</b><small>' + esc(x.brans) + ((x.ekBranslar || []).length ? ' +' + x.ekBranslar.length : '') + '</small></span>' +
          '<span class="lo-yuk"><span class="yuk-kucuk' + (y > m ? ' asim' : '') + '"><i style="width:' + Math.min(100, Math.round(y / m * 100)) + '%"></i></span><small class="' + (y > m ? 'asim-yazi' : '') + '">' + y + '/' + m + '</small></span></button>';
      }).join('') + '</div></aside><div class="panel-icerik">';

    // Profil kartı
    h += '<div class="kart profil"><div class="profil-ust">' + avatar(o).replace('class="avatar"', 'class="avatar buyuk"') +
      '<div class="profil-ad"><h3>' + esc(o.ad) + '</h3><div class="satir">' +
      '<span class="etiket Ortak">' + esc(o.brans) + '</span>' +
      (o.ekBranslar || []).map(function (b, i) { return '<span class="etiket mor">' + esc(b) + ' <button class="cip-sil" data-a="ek-brans-sil" data-v="' + o.id + '" data-i="' + i + '" title="Ek branşı kaldır">×</button></span>'; }).join('') +
      '<select data-a="ek-brans-ekle" data-v="' + o.id + '" class="kucuk-sec"><option value="">+ Ek branş</option>' + branslar.filter(function (b) { return b !== o.brans && (o.ekBranslar || []).indexOf(b) < 0; }).map(function (b) { return '<option>' + esc(b) + '</option>'; }).join('') + '</select>' +
      '</div></div><div class="profil-yuk"><div class="satir"><b class="buyuk-sayi' + (benimSaat > mx ? ' asim-yazi' : '') + '">' + benimSaat + '</b><span class="ince">/ ' + mx + ' saat</span></div>' +
      '<div class="ilerleme' + (benimSaat > mx ? ' asim' : '') + '"><i style="width:' + oran + '%"></i></div></div></div>' +
      '<div class="profil-istat"><div><b>' + benim.length + '</b><span>ders</span></div><div><b>' + Object.keys(subeSayisi).length + '</b><span>şube</span></div><div><b>' + disiSaat + '</b><span>branş dışı saat</span></div><div><b>' + Math.max(0, mx - benimSaat) + '</b><span>boş kapasite</span></div></div>' +
      (benim.length ? '<div class="satir profil-eylem"><span class="ince">Tüm derslerini aktar:</span><select data-a="ogr-aktar" data-v="' + o.id + '"><option value="">Öğretmen seçin…</option>' +
        durum.ogretmenler.filter(function (x) { return x.id !== o.id; }).map(function (x) { return '<option value="' + x.id + '">' + esc(x.ad) + ' (' + (yuk[x.id] || 0) + '/' + (x.maxSaat || 30) + ')</option>'; }).join('') + '</select>' +
        '<button class="btn kucuk tehlike" data-a="ogr-derslerini-kaldir" data-v="' + o.id + '">Tüm atamalarını kaldır</button></div>' : '') + '</div>';

    // Atanan dersler
    h += '<div class="kart"><div class="kart-ust"><h3>Atanan dersler <span class="ek">' + benim.length + ' ders · ' + benimSaat + ' saat</span></h3></div>';
    if (!benim.length) h += '<div class="bos-durum kucuk">Bu öğretmene atanmış ders yok. Aşağıdan ders seçip atayın.</div>';
    else {
      h += '<table class="tablo"><tr><th>Şube</th><th>Ders</th><th class="s">Saat</th><th>Blok</th><th>Öğretmeni değiştir</th><th></th></tr>' + benim.map(function (d) {
        return '<tr><td><b>' + esc((sube(d.subeId) || {}).ad) + '</b></td><td>' + esc(d.ders) + ' <span class="etiket ' + esc(d.grup) + '">' + esc(d.grup) + '</span> ' + uyumEtiketi(bransUyumu(o, d.ders)) + '</td>' +
          '<td class="s">' + d.saat + '</td><td class="ince">' + esc(d.yerlesimMetni) + '</td>' +
          '<td>' + ogretmenSecimi(d, 'data-a="atama" data-v="' + esc(d.id) + '"', yuk) + '</td>' +
          '<td class="s"><button class="btn ikon-btn" data-a="atama-kaldir" data-v="' + esc(d.id) + '" title="Atamayı kaldır">' + ikon('cop') + '</button></td></tr>';
      }).join('') + '</table>';
    }
    h += '</div>';

    // Ders ata (havuz)
    var kapsam = ui.havuzKapsam || 'brans';
    var aday = dersler.filter(function (d) {
      if (d.ders === 'Seçmeli Ders' || d.ogretmenId === o.id) return false;
      if (kapsam === 'brans') return !d.ogretmenId && bransUyumu(o, d.ders) !== 'disi';
      if (kapsam === 'atanmamis') return !d.ogretmenId;
      return true;
    });
    aday.sort(function (a, b) {
      var ua = bransUyumu(o, a.ders) === 'disi' ? 1 : 0, ub = bransUyumu(o, b.ders) === 'disi' ? 1 : 0;
      return ua - ub || durum.subeler.indexOf(sube(a.subeId)) - durum.subeler.indexOf(sube(b.subeId));
    });
    h += '<div class="kart"><div class="kart-ust"><h3>Ders ata <span class="ek">' + aday.length + ' ders listeleniyor</span></h3>' +
      sekmeler('havuz-kapsam', kapsam, [['brans', 'Branşına uygun, atanmamış'], ['atanmamis', 'Tüm atanmamışlar'], ['hepsi', 'Tüm dersler (başkasından al)']]) + '</div>' +
      '<div class="satir" style="margin-bottom:10px"><input type="search" placeholder="Şube ya da ders ara…" data-a="havuz-ara" value="' + esc(ui.havuzAra || '') + '" style="min-width:260px">' +
      '<span class="ince">Branş dışı dersler turuncu etiketle gösterilir; seçip atayabilirsiniz.</span></div>';
    if (!aday.length) h += '<div class="bos-durum kucuk">Bu filtrede ders yok. “Tüm atanmamışlar” ya da “Tüm dersler” sekmesini deneyin.</div>';
    else {
      h += '<div class="kaydirma havuz-kutu"><table class="tablo"><tr><th class="s"><input type="checkbox" data-a="havuz-hepsi" title="Görünenlerin tümünü seç"></th><th>Şube</th><th>Ders</th><th class="s">Saat</th><th>Uygunluk</th><th>Şu anki öğretmen</th></tr>' + aday.map(function (d) {
        var u = bransUyumu(o, d.ders), mevcut = ogretmen(d.ogretmenId);
        return '<tr class="havuz-satir" data-ara="' + esc(((sube(d.subeId) || {}).ad + ' ' + d.ders).toLocaleLowerCase('tr')) + '"><td class="s"><input type="checkbox" class="havuz-sec" value="' + esc(d.id) + '" data-saat="' + d.saat + '"></td>' +
          '<td><b>' + esc((sube(d.subeId) || {}).ad) + '</b></td><td>' + esc(d.ders) + ' <span class="etiket ' + esc(d.grup) + '">' + esc(d.grup) + '</span></td><td class="s">' + d.saat + '</td>' +
          '<td>' + (u === 'disi' ? uyumEtiketi(u) : (u === 'ek' ? uyumEtiketi(u) : '<span class="etiket yesil">branşı</span>')) + '</td>' +
          '<td class="ince">' + (mevcut ? esc(mevcut.ad) : '<span class="etiket sari">atanmamış</span>') + '</td></tr>';
      }).join('') + '</table></div>' +
        '<div class="atama-alt"><span id="havuz-ozet" class="ince">Seçili ders yok</span><button class="btn ana" data-a="havuzdan-ata" data-v="' + o.id + '">' + ikon('atama') + 'Seçilenleri ' + esc(o.ad) + ' öğretmenine ata</button></div>';
    }
    return h + '</div></div></div>';
  }

  /** Tüm öğretmenlerin derslerini tek tabloda gösterir (satır: öğretmen, sütun: şube) */
  function ogretmenSubeCizelgesi(dersler, yuk) {
    if (!durum.ogretmenler.length) return '<div class="kart bos-durum">Öğretmen yok.</div>';
    var harita = {}, subeTop = {};
    dersler.forEach(function (d) {
      if (d.ders === 'Seçmeli Ders') return;
      if (d.ogretmenId) (harita[d.ogretmenId + '|' + d.subeId] = harita[d.ogretmenId + '|' + d.subeId] || []).push(d);
      subeTop[d.subeId] = subeTop[d.subeId] || { top: 0, atanan: 0 };
      subeTop[d.subeId].top += d.saat; if (d.ogretmenId) subeTop[d.subeId].atanan += d.saat;
    });
    var liste = durum.ogretmenler.slice().sort(function (a, b) { return a.brans.localeCompare(b.brans, 'tr') || a.ad.localeCompare(b.ad, 'tr'); });
    var h = '<div class="kart"><div class="kart-ust"><h3>Öğretmen × şube ders çizelgesi <span class="ek">her hücre: ders kısaltması ve haftalık saat · öğretmen adına tıklayarak düzenleyin</span></h3></div>' +
      '<div class="kaydirma cizelge-kutu"><table class="cizelge"><thead><tr><th class="yapis">Öğretmen</th><th class="s">Saat</th>' + durum.subeler.map(function (s) { return '<th>' + esc(s.ad) + '</th>'; }).join('') + '</tr></thead><tbody>';
    liste.forEach(function (o) {
      var y = yuk[o.id] || 0, m = o.maxSaat || 30;
      h += '<tr><th class="yapis"><button class="link-btn" data-a="ogr-git" data-v="' + o.id + '">' + esc(o.ad) + '</button><small>' + esc(o.brans) + '</small></th>' +
        '<td class="s"><b class="' + (y > m ? 'asim-yazi' : '') + '">' + y + '</b><small>/' + m + '</small></td>' +
        durum.subeler.map(function (s) {
          var l = harita[o.id + '|' + s.id] || [];
          return '<td>' + l.map(function (d) { var u = bransUyumu(o, d.ders); return '<span class="hucre-cip' + (u === 'disi' ? ' disi' : '') + '" data-ders="' + esc(d.id) + '" style="--h:' + M.renk(d.ders) + '" title="' + esc(d.ders + ' — ' + d.saat + ' saat' + (u === 'disi' ? ' (branş dışı)' : '')) + '">' + esc(M.kisaltma(d.ders)) + ' <b>' + d.saat + '</b></span>'; }).join('') + '</td>';
        }).join('') + '</tr>';
    });
    h += '</tbody><tfoot><tr><th class="yapis">Atanan / toplam</th><td></td>' + durum.subeler.map(function (s) {
      var x = subeTop[s.id] || { top: 0, atanan: 0 };
      return '<td class="s"><b class="' + (x.atanan < x.top ? 'asim-yazi' : '') + '">' + x.atanan + '</b>/' + x.top + '</td>';
    }).join('') + '</tr></tfoot></table></div></div>';
    return h;
  }

  /** Her şubenin tüm derslerini (zorunlu + seçmeli) öğretmenleriyle birlikte tek ekranda gösterir */
  function sinifDersListeleri(dersler, sadeceDiger, filtreSinif) {
    var t = tur(), dol = {};
    subeDoluluk(dersler).forEach(function (x) { dol[x.sube.id] = x; });
    var h = '<div class="sinif-kartlari">';
    durum.subeler.filter(function (s) { return !filtreSinif || s.sinif === filtreSinif; }).forEach(function (s) {
      var l = dersler.filter(function (d) { return d.subeId === s.id; });
      var x = dol[s.id] || { saat: 0, meb: 0 };
      h += '<div class="kart sinif-karti" id="sdl-' + s.id + '"><div class="kart-ust"><h3>' + esc(s.ad) + '</h3><span class="etiket ' + (x.saat === x.meb ? 'yesil' : (x.saat > x.meb ? 'kirmizi' : 'sari')) + '">' + x.saat + ' / ' + x.meb + ' saat</span></div>' +
        '<table class="tablo sik"><tr><th>Ders</th><th class="s">Saat</th><th>Öğretmen</th></tr>' + l.map(function (d) {
          var o = ogretmen(d.ogretmenId);
          return '<tr' + (d.ders !== 'Seçmeli Ders' ? ' data-ders="' + esc(d.id) + '" title="Sağ tık: öğretmeni değiştir"' : '') + '><td>' + esc(d.ders) + (d.grup === 'Seçmeli' ? ' <span class="etiket Seçmeli">S</span>' : (d.grup === 'Ek' ? ' <span class="etiket Ek">Ek</span>' : '')) + '</td><td class="s">' + d.saat + '</td><td class="ince">' + (o ? esc(o.ad) + (bransUyumu(o, d.ders) === 'disi' ? ' ' + uyumEtiketi('disi') : '') : (d.ders === 'Seçmeli Ders' ? '—' : '<span class="etiket sari">atanmamış</span>')) + '</td></tr>';
        }).join('') + '</table></div>';
    });
    void t; void sadeceDiger;
    return h + '</div>';
  }

  function atamaHavuzCiz(dersler, yuk) {
    var l = dersler.filter(function (d) { return !d.ogretmenId && d.ders !== 'Seçmeli Ders'; });
    if (!l.length) return '<div class="kart bos-durum">' + ikon('tamam') + ' Tüm dersler atanmış.</div>';
    var gruplar = {};
    l.forEach(function (d) { var b = M.bransBul(d.ders, VERI.branslar) || 'Diğer'; (gruplar[b] = gruplar[b] || []).push(d); });
    return Object.keys(gruplar).sort(function (a, b) { return a.localeCompare(b, 'tr'); }).map(function (b) {
      var g = gruplar[b];
      return '<div class="kart"><h3>' + esc(b) + ' <span class="ek">' + g.length + ' ders · ' + g.reduce(function (a, d) { return a + d.saat; }, 0) + ' saat</span></h3><table class="tablo"><tr><th>Şube</th><th>Ders</th><th class="s">Saat</th><th>Öğretmen</th></tr>' +
        g.map(function (d) { return '<tr><td><b>' + esc((sube(d.subeId) || {}).ad) + '</b></td><td>' + esc(d.ders) + '</td><td class="s">' + d.saat + '</td><td>' + ogretmenSecimi(d, 'data-a="atama" data-v="' + esc(d.id) + '"', yuk) + '</td></tr>'; }).join('') + '</table></div>';
    }).join('');
  }

  function atamaMatrisCiz() {
    var t = tur(), dersler = dersListesi(), yuk = ogretmenYukleri(dersler), sekme = ui.atamaSekme || 'zorunlu';
    var kategori = function (d) { return d.grup === 'Seçmeli' ? 'secmeli' : 'zorunlu'; };
    var atanmamis = { zorunlu: 0, secmeli: 0 };
    dersler.forEach(function (d) { if (!d.ogretmenId && d.ders !== 'Seçmeli Ders') atanmamis[kategori(d)]++; });
    var h = '';
    if (ui.adim !== 'atama') h += '<div class="satir" style="margin-bottom:12px"><div class="sekme">' + [['zorunlu', 'Zorunlu dersler'], ['secmeli', 'Seçmeli dersler']].map(function (x) {
      return '<button data-a="atama-sekme" data-v="' + x[0] + '" class="' + (sekme === x[0] ? 'aktif' : '') + '">' + x[1] + (atanmamis[x[0]] ? ' <span class="rozet-k">' + atanmamis[x[0]] + '</span>' : ' ✓') + '</button>';
    }).join('') + '</div><span class="ince">' + (atanmamis[sekme] ? atanmamis[sekme] + ' ders atanmamış' : 'Bu bölümdeki tüm dersler atanmış') + '</span></div>';

    function secim(d, ek) { return ogretmenSecimi(d, ek, yuk); }

    t.siniflar.forEach(function (s) {
      var subeler = durum.subeler.filter(function (x) { return x.sinif === s; });
      if (!subeler.length) return;
      var l = dersler.filter(function (d) { return kategori(d) === sekme && sube(d.subeId).sinif === s; });
      if (!l.length) return;
      var sutunlar = [];
      l.forEach(function (d) { if (sutunlar.indexOf(d.ders) < 0) sutunlar.push(d.ders); });
      var harita = {};
      l.forEach(function (d) { harita[d.subeId + '|' + d.ders] = d; });
      h += '<div class="kart"><h3>' + sinifEtiketi(s) + ' <span class="ek">' + (sekme === 'zorunlu' ? 'zorunlu dersler' : 'seçmeli dersler') + '</span></h3><div class="kaydirma"><table class="tablo matris atama"><tr><th class="yapis">Şube</th>' +
        sutunlar.map(function (ad) {
          var ornek = l.filter(function (d) { return d.ders === ad; })[0];
          return '<th title="' + esc(ad) + '"><div class="sut-bas"><b>' + esc(M.kisaltma(ad)) + '</b><span>' + esc(ad) + '</span></div>' +
            (ad === 'Seçmeli Ders' ? '' : secim({ ders: ad, ogretmenId: null }, 'data-a="toplu-ata" data-v="' + esc(s + '|' + ad) + '" title="Tüm ' + esc(sinifEtiketi(s)) + ' şubelerine ata" class="toplu"')) + '</th>';
          void ornek;
        }).join('') + '</tr>';
      subeler.forEach(function (sb) {
        h += '<tr><td class="yapis"><b>' + esc(sb.ad) + '</b></td>' + sutunlar.map(function (ad) {
          var d = harita[sb.id + '|' + ad];
          if (!d) return '<td class="s sifir">–</td>';
          if (d.ders === 'Seçmeli Ders') return '<td class="ince">' + d.saat + ' saat (ders seçilmedi)</td>';
          var dis = d.ogretmenId && bransUyumu(ogretmen(d.ogretmenId), d.ders) === 'disi';
          return '<td class="' + (d.ogretmenId ? (dis ? 'disi-atama' : '') : 'bos-atama') + '" title="' + (dis ? 'Branş dışı atama' : '') + '"><span class="ince">' + d.saat + ' sa</span> ' + secim(d, 'data-a="atama" data-v="' + esc(d.id) + '"') + '</td>';
        }).join('') + '</tr>';
      });
      h += '</table></div></div>';
    });
    if (sekme === 'secmeli' && !dersler.some(function (d) { return d.grup === 'Seçmeli'; })) h += '<div class="kart bos-durum">Şubelerde seçmeli ders yok.</div>';
    return h;
  }

  // ---------- Kısıt ve kilit yardımcıları ----------
  /** 'ogretmen' | 'sube' için kapalı saat listesi (dizi referansı) */
  function kapaliListesi(tip, id) {
    if (tip === 'sube') {
      durum.subeKapali = durum.subeKapali || {};
      return (durum.subeKapali[id] = durum.subeKapali[id] || []);
    }
    var o = ogretmen(id);
    if (!o) return [];
    return (o.kapali = o.kapali || []);
  }
  /** Bir günün durumu: 'acik' | 'kapali' | 'kismi' */
  function gunDurumu(liste, d, H) {
    var n = 0;
    for (var s = 0; s < H; s++) if (liste.indexOf(d + '-' + s) >= 0) n++;
    return n === 0 ? 'acik' : (n === H ? 'kapali' : 'kismi');
  }
  function gunAcKapa(liste, d, H) {
    var kapat = gunDurumu(liste, d, H) !== 'kapali';
    for (var s = 0; s < H; s++) {
      var k = d + '-' + s, j = liste.indexOf(k);
      if (kapat && j < 0) liste.push(k);
      if (!kapat && j >= 0) liste.splice(j, 1);
    }
  }
  /** Öğretmenin uygun ders saati kapasitesi (kapalı saatler + günlük sınır; gün sınırı ayrı) */
  function ogretmenKapasite(o) {
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, gunluk = o.maxGunluk > 0 ? +o.maxGunluk : H;
    var gunler = [];
    for (var d = 0; d < D; d++) {
      var acik = 0;
      for (var s = 0; s < H; s++) if ((o.kapali || []).indexOf(d + '-' + s) < 0) acik++;
      gunler.push(Math.min(acik, gunluk));
    }
    var toplam = gunler.reduce(function (a, b) { return a + b; }, 0);
    var gunSiniri = o.maxGun > 0 ? Math.min(D, +o.maxGun) : D;
    var enIyi = gunler.slice().sort(function (a, b) { return b - a; }).slice(0, gunSiniri).reduce(function (a, b) { return a + b; }, 0);
    return { kesin: toplam, gunSiniriyla: enIyi };
  }
  function kilitler() { return (durum.kilitler = durum.kilitler || {}); }
  function kilitSayisi() { var n = 0, K = kilitler(); for (var k in K) n += K[k].length; return n; }
  /** Kilit ekler; hata varsa metin döndürür */
  function kilitEkle(dersId, gun, saat, uzunluk) {
    var dersler = dersListesi(), d = dersler.filter(function (x) { return x.id === dersId; })[0];
    var H = +durum.okul.gunlukSaat;
    if (!d) return 'Ders bulunamadı.';
    if (saat + uzunluk > H) return 'Blok günün son dersini aşıyor.';
    var K = kilitler(), mevcut = K[dersId] || [];
    var kilitli = mevcut.reduce(function (a, k) { return a + k.uzunluk; }, 0);
    if (kilitli + uzunluk > d.saat) return d.ders + ' haftada ' + d.saat + ' saat; ' + kilitli + ' saati zaten kilitli.';
    if (mevcut.some(function (k) { return k.gun === gun; })) return 'Bu dersin o gün başka kilitli bloğu var (bir ders aynı gün iki ayrı blok olamaz).';
    for (var i = 0; i < uzunluk; i++) {
      var slot = gun + '-' + (saat + i);
      if (kapaliListesi('sube', d.subeId).indexOf(slot) >= 0) return (sube(d.subeId) || {}).ad + ' şubesinin bu saati kapalı.';
      var o = d.ogretmenId && ogretmen(d.ogretmenId);
      if (o && (o.kapali || []).indexOf(slot) >= 0) return o.ad + ' bu saatte kapalı.';
    }
    // Aynı şube ya da aynı öğretmenin başka kilidiyle çakışma
    var harita = {};
    dersler.forEach(function (x) { harita[x.id] = x; });
    for (var id in K) {
      var x = harita[id];
      if (!x) continue;
      var ayniSube = x.subeId === d.subeId, ayniOgr = d.ogretmenId && x.ogretmenId === d.ogretmenId;
      if (!ayniSube && !ayniOgr) continue;
      for (var j = 0; j < K[id].length; j++) {
        var k = K[id][j];
        if (k.gun === gun && k.saat < saat + uzunluk && saat < k.saat + k.uzunluk) {
          return 'Çakışma: ' + (sube(x.subeId) || {}).ad + ' ' + x.ders + ' bu saate kilitli.';
        }
      }
    }
    (K[dersId] = mevcut).push({ gun: gun, saat: saat, uzunluk: uzunluk });
    return null;
  }
  function kilitSil(dersId, gun, saat) {
    var K = kilitler();
    if (!K[dersId]) return false;
    var n = K[dersId].length;
    K[dersId] = K[dersId].filter(function (k) { return !(k.gun === gun && k.saat === saat); });
    if (!K[dersId].length) delete K[dersId];
    return n !== (K[dersId] || []).length;
  }
  /** Ders listesinde artık olmayan derslerin kilitlerini temizler */
  function kilitleriTemizle() {
    var var_ = {};
    dersListesi().forEach(function (d) { var_[d.id] = true; });
    var K = kilitler();
    Object.keys(K).forEach(function (id) { if (!var_[id]) delete K[id]; });
  }

  // ---------- UX V3 Aşama 5 — Kısıtlar tek haftalık takvim ----------
  function ux5KisitSecenekleri(tip) {
    return tip === 'sube' ? durum.subeler : durum.ogretmenler.slice().sort(function(a,b){ return a.ad.localeCompare(b.ad, 'tr'); });
  }
  function ux5KisitTakvim(tip, id) {
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat;
    var liste = kapaliListesi(tip,id), gunler = M.GUNLER.slice(0,D), saatler = M.saatEtiketleri(durum.okul,H);
    var on = ProgramAraclari.onYerlesimler(dersListesi(),durum.kilitler);
    if (durum.sonuc) on = on.concat(durum.sonuc.yerlesim || []);
    var harita = {};
    on.forEach(function(y){
      var ders = dersBul(y.dersId);
      if (!ders || !(tip === 'sube' ? ders.subeId === id : dersOgretmenleri(ders).indexOf(id) >= 0)) return;
      for (var j=0;j<y.uzunluk;j++) harita[y.gun+'-'+(y.saat+j)] = ders.ders;
    });
    var h = '<div class="ux5-calendar-wrap"><table class="ux5-calendar" aria-label="Haftalık uygunluk takvimi"><thead><tr><th class="ux5-time-head">Ders saati</th>';
    gunler.forEach(function(g,d){
      var st=gunDurumu(liste,d,H);
      h += '<th><button type="button" class="ux5-day '+st+'" data-a="ux5-kisit-gun" data-v="'+d+'" aria-label="'+esc(g)+' gününü aç veya kapat">'+esc(g)+'<small>'+(st==='kapali'?'Tamamı kapalı':st==='kismi'?'Kısmen kapalı':'Açık')+'</small></button></th>';
    });
    h += '</tr></thead><tbody>';
    for (var s=0;s<H;s++) {
      h += '<tr><th class="ux5-hour"><b>'+(s+1)+'. ders</b><small>'+esc(saatler[s] || '')+'</small></th>';
      for (var d=0;d<D;d++) {
        var anahtar=d+'-'+s, kapali=liste.indexOf(anahtar)>=0, ders=harita[anahtar];
        h += '<td><button type="button" class="ux5-slot '+(kapali?'kapali':ders?'kilitli':'acik')+'" data-a="ux5-kisit-hucre" data-v="'+anahtar+'" title="'+esc(ders ? 'Yerleşmiş veya kilitli ders: '+ders : kapali ? 'Açmak için tıkla':'Kapatmak için tıkla')+'" aria-pressed="'+(kapali?'true':'false')+'">'+(kapali?'✕ <span>Kapalı</span>':ders?'🔒 <span>'+esc(ders)+'</span>':'<span>Açık</span>')+'</button></td>';
      }
      h += '</tr>';
    }
    return h+'</tbody></table></div>';
  }
  function ux5KisitKisiAraci(tip, id) {
    var varlik=tip==='sube'?sube(id):ogretmen(id), D=+durum.okul.gunSayisi,H=+durum.okul.gunlukSaat;
    if (!varlik) return '<div class="kart bos-durum">Lütfen önce bir '+(tip==='sube'?'şube':'öğretmen')+' ekleyin.</div>';
    var kapali=kapaliListesi(tip,id).length, acik=D*H-kapali;
    var dersler=dersListesi(), yuk=tip==='sube'?dersler.filter(function(d){return d.subeId===id}).reduce(function(t,d){return t+d.saat},0):(ogretmenYukleri(dersler)[id]||0);
    var yukSorun=tip==='sube'?yuk>acik:yuk>ogretmenKapasite(varlik).kesin;
    var h = '<div class="ux5-person-head"><div><span class="ux5-label">HAFTALIK UYGUNLUK</span><h3>'+esc(varlik.ad)+'</h3><p>Gün başlığıyla bütün günü, hücreye tıklayarak tek saati aç veya kapat.</p></div><div class="ux5-counts"><div><small>Açık saat</small><strong>'+acik+'</strong></div><div><small>Kapalı saat</small><strong>'+kapali+'</strong></div><div><small>Ders yükü</small><strong>'+yuk+'</strong></div></div></div>';
    if(yukSorun) h += '<div class="ux5-notice bad">Ders yükü mevcut açık saatleri veya günlük ders sınırını aşıyor. Dağıtım öncesinde uygunluğu kontrol edin.</div>';
    h += ux5KisitTakvim(tip,id);
    h += '<div class="ux5-footer"><span><i class="ux5-legend-open"></i>Açık &nbsp; <i class="ux5-legend-closed"></i>Kapalı &nbsp; 🔒 Yerleşmiş / kilitli</span><button class="btn kucuk" data-a="ux5-kisit-ac-hepsi">Bu kişide tüm saatleri aç</button></div>';
    if (tip==='ogretmen') {
      h += '<div class="ux5-teacher-options"><div><label>Günlük en fazla ders <input type="number" min="1" max="'+H+'" placeholder="'+H+'" data-a="ogr-gunluk" data-v="'+esc(id)+'" value="'+(varlik.maxGunluk||'')+'"></label><label>Haftada en fazla gün <input type="number" min="1" max="'+D+'" placeholder="'+D+'" data-a="ogr-gun" data-v="'+esc(id)+'" value="'+(varlik.maxGun||'')+'"></label></div><button class="btn kucuk" data-a="ogr-tercih-ac" data-v="'+esc(id)+'">İlk/son saat ve gün tercihleri</button></div>';
    }
    return h;
  }
  function kisitlarCiz() {
    kilitleriTemizle();
    var sekme=ui.ux5KisitSekme||'ogretmen', tip=sekme==='sube'?'sube':'ogretmen';
    var h=sayfaBasi('Kısıtlar ve kilitler','Öğretmen ve şube uygunluğunu tek haftalık takvim üzerinden belirleyin.');
    h += '<section class="ux5-page"><div class="ux5-summary"><div><small>Öğretmen</small><strong>'+durum.ogretmenler.length+'</strong></div><div><small>Şube</small><strong>'+durum.subeler.length+'</strong></div><div><small>Ön kilitli blok</small><strong>'+kilitSayisi()+'</strong></div></div>';
    h += '<div class="ux5-tabs" role="tablist" aria-label="Kısıt yönetimi">'+[['ogretmen','Öğretmenler'],['sube','Şubeler'],['kilit','Ön kilitler']].map(function(x){return '<button type="button" role="tab" aria-selected="'+(sekme===x[0]?'true':'false')+'" class="'+(sekme===x[0]?'aktif':'')+'" data-a="ux5-kisit-sekme" data-v="'+x[0]+'">'+x[1]+'</button>'}).join('')+'</div>';
    if (sekme==='kilit') {
      var kt=ui.ux5KilitTip||'sube';
      h += '<div class="ux5-panel"><div class="ux5-toolbar"><div><h3>Ön kilit yerleştirme</h3><p>Dağıtımdan önce dersleri sabitle. Kilitli dersler yeniden dağıtımda korunur.</p></div><div class="ux5-inline-tabs">'+[['sube','Şube üzerinden'],['ogretmen','Öğretmen üzerinden']].map(function(x){return '<button class="'+(kt===x[0]?'aktif':'')+'" data-a="ux5-kilit-tip" data-v="'+x[0]+'">'+x[1]+'</button>'}).join('')+'</div></div>'+kilitEkraniCiz(kt)+'</div>';
    } else {
      var secenekler=ux5KisitSecenekleri(tip), secimAnahtari=tip==='sube'?'ux5KisitSube':'ux5KisitOgretmen', secili=ui[secimAnahtari];
      if (!secili || !secenekler.some(function(o){return o.id===secili})) secili=ui[secimAnahtari]=secenekler.length?secenekler[0].id:'';
      h += '<section class="ux5-panel"><div class="ux5-toolbar"><div><h3>'+(tip==='sube'?'Şube uygunluğu':'Öğretmen uygunluğu')+'</h3><p>İşlem yapmak için kişi veya şube seçin; diğer kayıtlar değişmez.</p></div><label class="ux5-picker">'+(tip==='sube'?'Şube':'Öğretmen')+' seç<select data-a="ux5-kisit-kisi">'+secenekler.map(function(o){return '<option value="'+esc(o.id)+'"'+(o.id===secili?' selected':'')+'>'+esc(o.ad)+'</option>'}).join('')+'</select></label></div>'+ux5KisitKisiAraci(tip,secili)+'</section>';
    }
    h += '<details class="ux5-legacy"><summary>Gelişmiş toplu kısıt araçları</summary><p>Öğretmen/sınıf toplu tablosu, tercihler ve saatleri topluca yönetmek için açın.</p>'+(sekme==='sube'?subeKisitlariCiz():ogretmenKisitlariCiz())+'</details></section>';
    return h;
  }

  function gunDugmeleri(tip, id) {
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, liste = kapaliListesi(tip, id);
    var etiket = { acik: 'Açık', kapali: 'Kapalı', kismi: 'Kısmi' };
    var h = '';
    for (var d = 0; d < D; d++) {
      var g = gunDurumu(liste, d, H);
      h += '<td class="s"><button class="gun-dugme ' + g + '" data-a="gun-ackapa" data-k="' + tip + '" data-v="' + esc(id) + '" data-i="' + d + '" title="' + M.GUNLER[d] + ': ' + etiket[g] + ' (tıklayınca bütün gün açılır/kapanır)">' + etiket[g] + '</button></td>';
    }
    return h;
  }

  function ogretmenKisitlariCiz() {
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat;
    if (!durum.ogretmenler.length) return '<div class="kart bos-durum">Önce “Öğretmenler” adımında öğretmen oluşturun.</div>';
    var yuk = ogretmenYukleri(dersListesi());
    var h = '<div class="kart"><div class="satir" style="margin-bottom:10px"><b>Toplu işlemler:</b>' +
      '<button class="btn kucuk" data-a="bos-gun-ver">Uygun herkese 1 boş gün iste (haftada en fazla ' + (D - 1) + ' gün)</button>' +
      '<button class="btn kucuk" data-a="kisit-temizle-ogr">Tüm öğretmen kısıtlarını temizle</button></div>' +
      '' +
      '<div class="kaydirma"><table class="tablo kisit-tablo"><tr><th>Öğretmen</th><th class="s">Ders saati</th>' +
      M.GUNLER.slice(0, D).map(function (g) { return '<th class="s">' + g.slice(0, 3) + '</th>'; }).join('') +
      '<th>Saatler</th><th class="s">Günde en fazla</th><th class="s">Haftada en fazla gün</th><th class="s">Kapasite</th></tr>';
    durum.ogretmenler.slice().sort(function (a, b) { return a.brans.localeCompare(b.brans, 'tr') || a.ad.localeCompare(b.ad, 'tr'); }).forEach(function (o) {
      var kap = ogretmenKapasite(o), y = yuk[o.id] || 0;
      var durumEt = y > kap.kesin ? '<span class="etiket" style="background:var(--err-soft);color:var(--err)">yetersiz ' + kap.kesin + '</span>'
        : (y > kap.gunSiniriyla ? '<span class="etiket" style="background:var(--warn-soft);color:var(--warn)">gün sınırı dar ' + kap.gunSiniriyla + '</span>' : '<span class="ince">' + kap.gunSiniriyla + '</span>');
      h += '<tr class="dd3-kisit-satir" data-dd3-ara="' + esc(o.ad + ' ' + o.brans) + '"><td><div class="dd3-kisit-kisi"><b>' + esc(o.ad) + '</b><span class="ince">' + esc(o.brans) + '</span></div></td><td class="s"><b>' + y + '</b></td>' + gunDugmeleri('ogretmen', o.id) +
        '<td class="nowrap"><button class="btn kucuk" data-a="uygunluk" data-k="ogretmen" data-v="' + o.id + '">' + ((o.kapali || []).length ? o.kapali.length + ' kapalı' : 'Saatler') + '</button> <button class="btn kucuk" data-a="ogr-tercih-ac" data-v="' + o.id + '" title="Tercih günleri, ilk/son ders, boşluk sınırı, etiketler">' + ((o.tercihGunler || []).length || o.ilkSaatIstemez || o.sonSaatIstemez || o.maxBosluk != null || (o.etiketler || []).length || o.maxGunKesin ? 'Tercihler ●' : 'Tercihler') + '</button></td>' +
        '<td class="s"><input type="number" min="1" max="' + H + '" placeholder="' + H + '" data-a="ogr-gunluk" data-v="' + o.id + '" value="' + (o.maxGunluk || '') + '" style="width:62px"></td>' +
        '<td class="s"><input type="number" min="1" max="' + D + '" placeholder="' + D + '" data-a="ogr-gun" data-v="' + o.id + '" value="' + (o.maxGun || '') + '" style="width:62px"></td>' +
        '<td class="s">' + durumEt + '</td></tr>';
    });
    return h + '</table></div></div>';
  }

  function subeKisitlariCiz() {
    var t = tur(), D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat;
    var saat = {};
    dersListesi().forEach(function (d) { saat[d.subeId] = (saat[d.subeId] || 0) + d.saat; });
    var h = '<div class="kart"><p class="ince" style="margin:0 0 10px">Sınıfın ders yapılamayacak saatlerini kapatın (ör. Cuma son saat, ortak etkinlik). Kapalı saatler şube programında boşluk sayılmaz. Haftalık ders saati açık saatlerden fazla olursa dağıtım yapılamaz.</p>' +
      '<div class="kaydirma"><table class="tablo kisit-tablo"><tr><th>Şube</th><th class="s">Ders saati</th>' +
      M.GUNLER.slice(0, D).map(function (g) { return '<th class="s">' + g.slice(0, 3) + '</th>'; }).join('') + '<th>Saatler</th><th class="s">Açık saat</th></tr>';
    durum.subeler.forEach(function (sb) {
      var acik = D * H - kapaliListesi('sube', sb.id).length, y = saat[sb.id] || 0;
      h += '<tr class="dd3-kisit-satir" data-dd3-ara="' + esc(sb.ad + ' ' + sinifEtiketi(sb.sinif)) + '"><td><b>' + esc(sb.ad) + '</b></td><td class="s">' + y + '</td>' + gunDugmeleri('sube', sb.id) +
        '<td><button class="btn kucuk" data-a="uygunluk" data-k="sube" data-v="' + sb.id + '">' + (kapaliListesi('sube', sb.id).length ? kapaliListesi('sube', sb.id).length + ' kapalı' : 'Saatler') + '</button></td>' +
        '<td class="s"' + (y > acik ? ' style="color:var(--err);font-weight:700"' : '') + '>' + acik + '</td></tr>';
    });
    void t;
    return h + '</table></div></div>';
  }

  /** Öğretmen ya da sınıf için kilitleme ekranı */
  function kilitEkraniCiz(tip) {
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, dersler = dersListesi();
    var liste = tip === 'ogretmen' ? durum.ogretmenler.slice().sort(function (a, b) { return a.ad.localeCompare(b.ad, 'tr'); }) : durum.subeler;
    if (!liste.length) return '<div class="kart bos-durum">' + (tip === 'ogretmen' ? 'Önce öğretmen oluşturun.' : 'Önce şube açın.') + '</div>';
    var anahtar = tip === 'ogretmen' ? 'kilitOgr' : 'kilitSube';
    if (!ui[anahtar] || !liste.some(function (x) { return x.id === ui[anahtar]; })) ui[anahtar] = liste[0].id;
    var id = ui[anahtar];
    var benim = dersler.filter(function (d) { return tip === 'ogretmen' ? d.ogretmenId === id : d.subeId === id; });
    if (!benim.some(function (d) { return d.id === ui.kilitDers; })) ui.kilitDers = null;
    var K = kilitler();
    var h = '<div class="kart"><div class="satir" style="margin-bottom:10px"><b>' + (tip === 'ogretmen' ? 'Öğretmen' : 'Şube') + ':</b><select data-a="kilit-sec" data-k="' + tip + '">' +
      liste.map(function (x) { return '<option value="' + x.id + '"' + (x.id === id ? ' selected' : '') + '>' + esc(x.ad) + '</option>'; }).join('') + '</select>' +
      '<span class="ince"><b>En kolayı:</b> tablodaki saate sağ tıklayın, açılan menüden dersi ve blok uzunluğunu seçin. Ya da 1) soldan dersi seçin, blok uzunluğunu belirleyin, 2) tablodaki boş hücreye tıklayın. Kilitli hücreye tıklamak kilidi kaldırır. Gri yazılar mevcut programdır; ders seçmeden tıklarsanız o yerleşim olduğu gibi kilitlenir.</span></div>';
    h += '<div class="kilit-duzen"><div><table class="tablo"><tr><th></th><th>Ders</th><th class="s">Saat</th><th class="s">Kilitli</th><th class="s">Blok</th></tr>';
    benim.forEach(function (d) {
      var kl = (K[d.id] || []).reduce(function (a, k) { return a + k.uzunluk; }, 0), kalan = d.saat - kl;
      var secili = ui.kilitDers === d.id;
      var uz = Math.min(ui.kilitUzunluk || 2, Math.max(1, kalan));
      var etiket = tip === 'ogretmen' ? (sube(d.subeId) || {}).ad + ' · ' + d.ders : d.ders + (d.ogretmenId && ogretmen(d.ogretmenId) ? ' · ' + ogretmen(d.ogretmenId).ad : '');
      h += '<tr class="' + (secili ? 'secili-satir' : '') + '"><td><button class="btn kucuk' + (secili ? ' ana' : '') + '" data-a="kilit-ders" data-v="' + esc(d.id) + '"' + (kalan <= 0 ? ' disabled' : '') + '>' + (secili ? 'Seçili' : 'Seç') + '</button></td>' +
        '<td style="--h:' + M.renk(d.ders) + '"><span class="renk-nokta"></span>' + esc(etiket) + '</td><td class="s">' + d.saat + '</td><td class="s">' + (kl ? '🔒 ' + kl : '–') + '</td>' +
        '<td class="s">' + (secili ? '<select data-a="kilit-uzunluk">' + [1, 2, 3, 4].filter(function (n) { return n <= kalan; }).map(function (n) { return '<option' + (n === uz ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select>' : '') + '</td></tr>';
    });
    if (!benim.length) h += '<tr><td colspan="5" class="ince">Bu ' + (tip === 'ogretmen' ? 'öğretmene atanmış ders yok.' : 'şubede ders yok.') + '</td></tr>';
    h += '</table></div>';

    // Izgara: kilitler + mevcut program (hayalet) + kapalı saatler
    var hucre = {};
    benim.forEach(function (d) {
      (K[d.id] || []).forEach(function (k) {
        for (var i = 0; i < k.uzunluk; i++) hucre[k.gun + '-' + (k.saat + i)] = { kilit: true, d: d, k: k, bas: i === 0 };
      });
    });
    if (durum.sonuc) {
      var r = durum.sonuc, benimId = {};
      benim.forEach(function (d) { benimId[d.id] = d; });
      r.yerlesim.forEach(function (y) {
        var d = benimId[y.dersId]; if (!d) return;
        for (var i = 0; i < y.uzunluk; i++) { var key = y.gun + '-' + (y.saat + i); if (!hucre[key]) hucre[key] = { hayalet: true, d: d, y: y }; }
      });
    }
    var kapali = kapaliListesi(tip, id);
    var saatler = M.saatEtiketleri(durum.okul, H);
    h += '<div class="kaydirma"><table class="program kilit-izgara" data-tip="' + tip + '" data-id="' + esc(id) + '"><colgroup><col class="gun-sutun">' + new Array(H + 1).join('<col>') + '</colgroup><tr><th></th>';
    for (var s = 0; s < H; s++) h += '<th class="saat-bas"><b>' + (s + 1) + '</b><span>' + saatler[s].replace('–', '<br>') + '</span></th>';
    h += '</tr>';
    for (var d = 0; d < D; d++) {
      h += '<tr><th class="gun">' + M.GUNLER[d] + '</th>';
      for (s = 0; s < H; s++) {
        var c = hucre[d + '-' + s], key = d + '-' + s;
        if (c && c.kilit) {
          if (!c.bas) continue;
          h += '<td class="dolu kilitli" colspan="' + c.k.uzunluk + '" style="--h:' + M.renk(c.d.ders) + '" data-a="kilit-kaldir" data-v="' + esc(c.d.id + '|' + c.k.gun + '|' + c.k.saat) + '" title="Kilidi kaldır">' +
            '<div class="k1">🔒 ' + esc(tip === 'ogretmen' ? (sube(c.d.subeId) || {}).ad : M.kisaltma(c.d.ders)) + '</div><div class="k2">' + esc(c.d.ders) + '</div></td>';
        } else if (kapali.indexOf(key) >= 0) {
          h += '<td class="kapali" title="Kapalı saat"></td>';
        } else if (c && c.hayalet) {
          h += '<td class="hayalet" data-a="kilit-hucre" data-v="' + d + '|' + s + '" data-y="' + esc(c.y.dersId + '|' + c.y.gun + '|' + c.y.saat + '|' + c.y.uzunluk) + '" title="Programdaki yer — ders seçmeden tıklarsanız bu yerleşim kilitlenir">' +
            '<div class="k2">' + esc(tip === 'ogretmen' ? (sube(c.d.subeId) || {}).ad + ' ' + M.kisaltma(c.d.ders) : M.kisaltma(c.d.ders)) + '</div></td>';
        } else {
          h += '<td class="bos-hucre" data-a="kilit-hucre" data-v="' + d + '|' + s + '"></td>';
        }
      }
      h += '</tr>';
    }
    h += '</table></div></div></div>';
    return h;
  }

  // Aşama 2: arayüzün filtre/odak ayarları kalıcı ders verisini değiştirmez.
  function dd2CarsafKarti(tip) {
    var etiket = tip === 'sube' ? 'Şube çarşafı' : 'Öğretmen çarşafı';
    var sayi = tip === 'sube' ? durum.subeler.length : durum.ogretmenler.length;
    return '<section class="kart dd2-program-kart dd2-carsaf-kart"><div class="dd2-carsaf-ust"><div><h3>' + etiket + ' <span class="ek">' + sayi + ' satır</span></h3></div>' +
      '<label class="dd2-carsaf-arama yazdirma-gizle"><span class="ekran-okuyucu">' + etiket + ' içinde ara</span>' + ikon('ogretmenler') + '<input type="search" id="dd2-carsaf-ara" data-a="dd2-carsaf-ara" placeholder="' + (tip === 'sube' ? 'Şube ara…' : 'Öğretmen ara…') + '" value="' + esc(ui.dd2CarsafAra || '') + '" autocomplete="off"></label></div>' +
      '<div class="kaydirma dd2-carsaf-kaydirma">';
  }
  function dd2CarsafFiltrele(girdi) {
    var q = String(girdi || '').toLocaleLowerCase('tr').trim();
    var toplam = 0, gorunen = 0;
    document.querySelectorAll('.dd2-carsaf-kaydirma .carsaf tr[data-dd2-ara]').forEach(function (tr) {
      toplam++;
      var metin = (tr.getAttribute('data-dd2-ara') || '').toLocaleLowerCase('tr');
      var goster = !q || metin.indexOf(q) >= 0;
      tr.hidden = !goster;
      if (goster) gorunen++;
    });
    var sonuc = $('#dd2-carsaf-sonuc');
    if (sonuc) sonuc.textContent = gorunen + ' / ' + toplam + ' satır gösteriliyor' + (q && !gorunen ? ' · Aramayla eşleşen kayıt bulunamadı.' : '');
  }
  // ---------- Dağıtım ----------
  function dagitimCiz() {
    var k = kontroller();
    var h = sayfaBasi('Dağıtım', 'Dersleri dağıtın, dört çizelgeyi düzenleyin ve kuralları tek merkezden yönetin.');
    var oz0 = adimOzetleri();
    var dd2Sonuc = durum.sonuc;
    var dd2Toplam = dersListesi().reduce(function (t, x) { return t + (+x.saat || 0); }, 0);
    var dd2Durum = !dd2Sonuc ? 'Ön hazırlık' : dd2Sonuc.eski ? 'Yeniden kontrol gerekli' : dd2Sonuc.istatistik.eksikSaat ? 'Eksik yerleşim var' : sonucGuvenliMi(dd2Sonuc) ? 'Dağıtım doğrulandı' : 'Kural denetimi gerekli';
    h += '<div class="dd2-ust-bolum' + (ui.dagitimOdak ? ' dd2-sakli' : '') + '">';
    h += '<section class="dd2-ozet-kabuk yazdirma-gizle" aria-label="Dağıtım özeti"><div class="dd2-ozet-baslik"><div><span class="dd2-ustetiket">ÇALIŞMA MERKEZİ</span><strong>Haftalık ders planı</strong></div><span class="dd2-durum-chip' + (sonucGuvenliMi(dd2Sonuc) ? ' tamamlandi' : '') + '">' + esc(dd2Durum) + '</span></div>' +
      '<div class="dd2-ozet-sayilar"><div><span>Şube</span><b>' + durum.subeler.length + '</b></div><div><span>Öğretmen</span><b>' + durum.ogretmenler.length + '</b></div><div><span>Planlanan ders</span><b>' + dd2Toplam + ' <small>saat</small></b></div><div><span>Ön kilit / kilit</span><b>' + kilitSayisi() + ' <small>blok</small></b></div></div></section>';

    h += '<div class="kart dagit-kart yazdirma-gizle"><div class="satir">' +
      '<button class="btn ana buyuk" data-a="dagit"' + (ui.calisiyor || k.hatalar.length ? ' disabled' : '') + '>' + ikon('oynat') + (ui.calisiyor ? 'Dağıtılıyor…' : (durum.sonuc ? 'Yeniden dağıt' : 'Otomatik dağıt')) + '</button>' +
      (durum.sonuc && CFG.mod === 'sunucu' && ui.cpsat && ui.cpsat.hazir ? '<button class="btn" data-a="dagit-min-deg"' + (ui.calisiyor || k.hatalar.length ? ' disabled' : '') + ' title="Mevcut programı mümkün olduğunca koruyarak sadece değişen/yeni kısımları yeniden oturtur (CP-SAT)">Minimum değişiklikle güncelle</button>' : '') +
      '<label class="motor-cip" title="Dağıtım motoru — ayrıntılar Dağıtım kuralları sayfasında"><span>Motor</span><select data-a="motor-sec"><option value="otomatik"' + (secilenMotor() === 'otomatik' ? ' selected' : '') + '>Otomatik</option><option value="cpsat"' + (secilenMotor() === 'cpsat' ? ' selected' : '') + (CFG.mod === 'sunucu' && ui.cpsat && ui.cpsat.hazir ? '' : ' disabled') + '>CP-SAT</option><option value="genetik"' + (secilenMotor() === 'genetik' ? ' selected' : '') + '>Genetik</option><option value="hizli"' + (secilenMotor() === 'hizli' ? ' selected' : '') + '>Hızlı</option></select></label>' +
      '<div class="dagit-durum"><b>' + esc(oz0.dagitim.metin) + '</b><small>' + (k.hatalar.length ? 'Aşağıdaki sorunları giderin.' : (durum.sonuc ? 'Yeniden dağıtımda kilitli dersler yerinde kalır.' : 'Program birkaç saniyede hazırlanır.')) + '</small></div>' +
      '<span class="bosluk"></span>' +
      (durum.sonuc ? '<button class="btn" data-a="kayitlar-goster" title="Programı sisteme kaydedin; sonra açıp düzenleyebilirsiniz">' + ikon('kaydet') + 'Dağıtımı kaydet</button>' : '') +
      (durum.sonuc ? '<button class="btn" data-a="excel-indir" title="Şube ve öğretmen çarşaf listelerini Excel (.xls) olarak indir">' + ikon('indir') + 'Excel İndir</button>' : '') +
      (durum.sonuc ? '<button class="btn tehlike dagitim-sifirla" data-a="dagitim-sifirla"' + (ui.calisiyor ? ' disabled' : '') + ' title="Yalnızca ekrandaki dağıtılmış programı ve konum kilitlerini temizler; öğretmenler, dersler ve kayıtlı dağıtımlar korunur">' + ikon('cop') + 'Dağıtımı sıfırla</button>' : '') +
      (durum.sonuc ? '<button class="btn" data-a="adim" data-v="ciktilar">' + ikon('ciktilar') + 'Resmî çıktılar</button>' : '') + '</div>' +
      '<details class="gelismis"' + (ui.gelismisAcik ? ' open' : '') + '><summary data-a="gelismis-ac">Gelişmiş: deneme sayısı, kilitler' + (CFG.mod === 'sunucu' ? ', CSV' : '') + '</summary><div class="satir">' +
      '<label class="alan satir-alan" title="Program birden çok kez denenir, en iyisi seçilir. Sayı arttıkça sonuç iyileşir ama süre uzar.">Deneme sayısı<input type="number" min="1" max="20" data-a="deneme" value="' + (durum.ayarlar.deneme || 10) + '" style="width:64px"></label>' +
      '<span class="ince">Daha çok deneme = daha az boşluk, daha uzun süre.</span><span class="bosluk"></span>' +
      (durum.sonuc ? '<button class="btn" data-a="tumunu-kilitle" title="Mevcut programdaki tüm dersleri yerine kilitler">' + ikon('kilit') + 'Tüm programı kilitle</button>' : '') +
      (kilitSayisi() ? '<button class="btn" data-a="kilit-hepsini-sil">Kilitleri kaldır (' + kilitSayisi() + ')</button>' : '') +
      (durum.sonuc && CFG.mod === 'sunucu' ? '<button class="btn" data-a="csv">' + ikon('indir') + 'CSV</button>' : '') + '</div></details></div>';
    if (ui.calisiyor && ui.is) h += '<div class="kart is-kart yazdirma-gizle" id="is-ilerleme">' + isIlerlemeIc() + '</div>';
    if (k.hatalar.length) h += '<div class="uyari hata">' + ikon('uyari') + '<div><b>Dağıtım yapılamaz:</b><ul>' + k.hatalar.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div></div>';
    if (k.uyarilar.length) h += '<div class="uyari dikkat yazdirma-gizle">' + ikon('uyari') + '<div><ul>' + k.uyarilar.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div></div>';
    if (k.bilgiler.length) h += '<div class="uyari bilgi yazdirma-gizle">' + ikon('bloklar') + '<div>' + k.bilgiler.map(esc).join('<br>') + '</div></div>';

    h += kayitliDagitimlarCiz();
    var r = durum.sonuc;
    if (!r) {
      h += '<div class="uyari bilgi yazdirma-gizle hazirlik-bandi">' + ikon('kilit') + '<div><b>Dağıtım öncesi çizelge hazır.</b> ' +
        'Şube ve öğretmen programları ile iki çarşaf görünümü aşağıdadır. <b>Boş saate tıklayıp dersi 1 veya 2 saatlik blok olarak önceden kilitleyebilirsiniz.</b> ' +
        'Günü kapatmak için gün başlığına, saatleri düzenlemek için “Gün / saat kapat” düğmesine tıklayın. ' +
        'Önceden kilitlediğiniz bloklar otomatik dağıtım sırasında korunur. ' + kilitSayisi() + ' blok kilitli.</div></div>';
    } else {
    var ist = r.istatistik, yerlesen = ist.toplamSaat - ist.eksikSaat;
    h += raporBandi(r) + raporKarti(r);
    var akt = aktifKayit();
    if (akt || r.duzenlendi) {
      h += '<div class="uyari ' + (r.kayitDegisti ? 'dikkat' : 'bilgi') + ' yazdirma-gizle kayit-bandi">' + ikon('duzenle') + '<div>' +
        (akt ? 'Düzenlenen kayıt: <b>“' + esc(akt.ad) + '”</b>' : 'Bu program <b>elle düzenlendi</b>') +
        (r.kayitDegisti ? ' · <b>kaydedilmemiş değişiklikler var</b>' : (akt ? ' · kayıtla aynı' : '')) + '</div><span class="bosluk"></span>' +
        (akt ? '<button class="btn kucuk ana" data-a="dagitim-guncelle" data-v="' + akt.id + '"' + (r.kayitDegisti ? '' : ' disabled') + '>' + ikon('kaydet') + 'Üzerine kaydet</button>' : '') +
        '<button class="btn kucuk" data-a="kayitlar-goster">' + (akt ? 'Yeni kayıt olarak…' : 'Kaydet…') + '</button></div>';
    }
    h += '<div class="ozet yazdirma-gizle">' +
      '<div class="k ' + ((r.cozucu || {}).kuralIhlalleri && r.cozucu.kuralIhlalleri.length ? 'kotu' : 'iyi') + '"><span>Kural ihlali</span><b>' + (((r.cozucu || {}).kuralIhlalleri || []).length) + '</b></div>' +
      '<div class="k ' + (ist.eksikSaat ? 'kotu' : 'iyi') + '"><span>Yerleşen ders saati</span><b>' + yerlesen + ' / ' + ist.toplamSaat + '</b></div>' +
      '<div class="k ' + (ist.subeBosluk ? 'kotu' : 'iyi') + '"><span>Şube boş saati</span><b>' + ist.subeBosluk + '</b></div>' +
      '<div class="k"><span>Öğretmen boş saati</span><b>' + ist.ogretmenBosluk + '</b></div>' +
      '<div class="k"><span>Kilitli blok</span><b>' + (ist.kilitliBlok || 0) + '</b></div>' +
      (ist.korunanSaat || ist.degisenSaat ? '<div class="k iyi"><span>Korunan / Değişen</span><b>' + (ist.korunanSaat || 0) + ' / ' + (ist.degisenSaat || 0) + ' sa</b></div>' : '') +
      '<div class="k"><span>Hesaplama süresi</span><b>' + (ist.sureMs / 1000).toFixed(2) + ' sn</b><small>' + esc(ist.motor || '') + ' motoru</small></div></div>';
    if (ist.zumreOzet && ist.zumreOzet.length) {
      h += '<div class="uyari bilgi yazdirma-gizle">' + ikon('ogretmenler') + '<div><b>Zümre ortak boş saatleri:</b> ' + ist.zumreOzet.map(function (z) {
        return esc(z.ad) + ': ' + (z.bulundu ? '<b>' + esc((z.ornekler || []).slice(0, 2).join(', ')) + ' ✓</b>' : '<span style="color:var(--err)">bulunamadı</span>');
      }).join(' · ') + '</div></div>';
    }
    if (r.yerlesmeyen.length) {
      h += '<div class="uyari dikkat yazdirma-gizle">' + ikon('uyari') + '<div><b>Yerleşemeyen dersler (' + ist.eksikSaat + ' saat) — elle yerleştirebilirsiniz:</b><ul>' + r.yerlesmeyen.map(function (y) {
        var d = r.dersler[y.dersId] || {}; var s = sube(d.subeId) || {}; var o = ogretmen(d.ogretmenId);
        return '<li>' + esc(s.ad) + ' · ' + esc(d.ders) + ' (' + y.uzunluk + ' saat)' + (o ? ' · ' + esc(o.ad) : '') + (y.neden && y.neden !== 'yer bulunamadı' ? ' — <b>' + esc(y.neden) + '</b>' : '') +
          (y.uzunluk ? ' <button class="btn kucuk" data-a="bekleyen-sec" data-v="' + r.yerlesmeyen.indexOf(y) + '">Elle yerleştir</button>' : '') + '</li>';
      }).join('') + '</ul>Öneri: kapalı saatleri azaltın, blok düzenine VEYA kalıbı ekleyin (ör. 2+2 VEYA 2+1+1), öğretmen sayısını artırın ya da kilitleri gözden geçirin.</div></div>';
    }
    if (r.ihlaller && r.ihlaller.length) {
      h += '<div class="uyari dikkat yazdirma-gizle">' + ikon('uyari') + '<div><b>Sağlanamayan istekler:</b><ul>' + r.ihlaller.map(function (x) {
        var o = ogretmen(x.ogretmenId);
        return '<li>' + esc(o ? o.ad : x.ogretmenId) + ': haftada en fazla ' + x.sinir + ' gün istendi, ' + x.deger + ' güne yayıldı.</li>';
      }).join('') + '</ul></div></div>';
    }
    }
    h += '</div>'; // Dağıtım denetimleri odak görünümünde kapatılabilir.
    if (!r && ui.gorunum === 'yuk') ui.gorunum = 'sube';
    var dd2Sekmeler = [['sube', 'Şube programı', 'subeler'], ['ogretmen', 'Öğretmen programı', 'ogretmenler'], ['carsaf', 'Şube çarşafı', 'bloklar'], ['ogrCarsaf', 'Öğretmen çarşafı', 'bloklar']].concat(r ? [['yuk', 'Öğretmen yükleri', 'ogretmenler']] : []);
    h += '<section class="dd2-calisma-alani" aria-label="Program çalışma alanı"><div class="dd2-calisma-ust yazdirma-gizle">' +
      '<div class="dd2-calisma-kimlik"><span class="dd2-calisma-ustetiket">PROGRAM ÇALIŞMA ALANI</span><h3>Çizelgeler</h3></div>' +
      '<div class="dd2-hizli-arac"><button type="button" class="btn kucuk dd2-odak-dug" data-a="dd2-odak" aria-pressed="' + !!ui.dagitimOdak + '">' + (ui.dagitimOdak ? 'Kontrolleri göster' : 'Çizelgeye odaklan') + '</button>' +
      '<button type="button" class="btn kucuk" data-a="dd2-yazdir">' + ikon('yazdir') + 'Yazdır</button>' +
      '<button type="button" class="btn kucuk" data-a="adim" data-v="kisitlar">' + ikon('kisitlar') + 'Kısıtlar</button></div></div>' +
      '<nav class="dd2-gorunum-sekmeleri yazdirma-gizle" aria-label="Çizelge görünümü" role="tablist">' + dd2Sekmeler.map(function (x) {
        return '<button type="button" role="tab" data-a="gorunum" data-v="' + x[0] + '" aria-selected="' + (ui.gorunum === x[0]) + '" class="dd2-gorunum-tab' + (ui.gorunum === x[0] ? ' aktif' : '') + '">' + ikon(x[2]) + '<span>' + x[1] + '</span></button>';
      }).join('') + '</nav>' +
      '<div class="dd2-secim-seridi yazdirma-gizle"><div class="dd2-secim-sol">' +
      '<span class="dd2-alan-adi">' + (ui.gorunum === 'sube' ? 'Şube' : ui.gorunum === 'ogretmen' ? 'Öğretmen' : 'Toplu görünüm') + '</span>';

    if (ui.gorunum === 'sube') {
      if (!ui.seciliSube || !sube(ui.seciliSube)) ui.seciliSube = durum.subeler[0] && durum.subeler[0].id;
      h += '<select aria-label="Görüntülenecek şube" data-a="sec-sube">' + durum.subeler.map(function (s) { return '<option value="' + s.id + '"' + (s.id === ui.seciliSube ? ' selected' : '') + '>' + esc(s.ad) + '</option>'; }).join('') + '</select>';
    } else if (ui.gorunum === 'ogretmen') {
      if (!ui.seciliOgr || !ogretmen(ui.seciliOgr)) ui.seciliOgr = durum.ogretmenler[0] && durum.ogretmenler[0].id;
      h += '<select aria-label="Görüntülenecek öğretmen" data-a="sec-ogr">' + durum.ogretmenler.slice().sort(function (a, b) { return a.ad.localeCompare(b.ad, 'tr'); }).map(function (o) { return '<option value="' + o.id + '"' + (o.id === ui.seciliOgr ? ' selected' : '') + '>' + esc(o.ad) + '</option>'; }).join('') + '</select>';
    }
    h += '</div><div class="dd2-secim-sag"><span class="dd2-legend"><i class="dd2-nokta yerlesti"></i>Yerleşen</span><span class="dd2-legend"><i class="dd2-nokta on-kilit"></i>Kilitli</span><span class="dd2-legend"><i class="dd2-nokta kapandi"></i>Kapalı</span><span class="dd2-legend"><i class="dd2-nokta bos"></i>Boş</span></div></div>' +
      (ui.gorunum === 'sube' || ui.gorunum === 'ogretmen' ? '<details class="dd6-advanced-modes yazdirma-gizle"><summary>Gelişmiş: hızlı taşıma ve kilitleme modları</summary>' + duzenCubugu() + '</details>' : '') + '<div role="tabpanel" class="dd2-gorunum-icerik" aria-label="Seçili çizelge">';
    if (ui.gorunum === 'sube' && ui.seciliSube) {
      h += '<section class="kart dd2-program-kart"><div class="hazirlik-kart-baslik"><h3>' + esc(sube(ui.seciliSube).ad) + ' <span class="dd2-kart-altbaslik">· Haftalık ders programı</span></h3><button class="btn kucuk" data-a="program-kisit-ac" data-v="sube|' + esc(ui.seciliSube) + '">Gün / saat kapat</button></div>' + programTablosu('sube', ui.seciliSube) + '</section>';
    } else if (ui.gorunum === 'ogretmen' && ui.seciliOgr) {
      var o = ogretmen(ui.seciliOgr);
      var sayi = (r ? r.yerlesim : ProgramAraclari.onYerlesimler(dersListesi(), durum.kilitler)).filter(function (y) { var dd = r ? (r.dersler[y.dersId] || {}) : (dersBul(y.dersId) || {}); return (dd.ogretmenler || [dd.ogretmenId]).indexOf(o.id) >= 0; }).reduce(function (a, y) { return a + y.uzunluk; }, 0);
      h += '<section class="kart dd2-program-kart"><div class="hazirlik-kart-baslik"><h3>' + esc(o.ad) + ' <span class="ek">' + esc(o.brans) + ' · ' + sayi + ' yerleştirilmiş saat</span></h3><button class="btn kucuk" data-a="program-kisit-ac" data-v="ogretmen|' + esc(o.id) + '">Gün / saat kapat</button></div>' + programTablosu('ogretmen', o.id) + '</section>';
    } else if (ui.gorunum === 'sube') {
      h += '<div class="dd2-bos-gorunum">Henüz şube eklenmemiş. <button class="btn" data-a="adim" data-v="subeler">Şube ekle</button></div>';
    } else if (ui.gorunum === 'ogretmen') {
      h += '<div class="dd2-bos-gorunum">Henüz öğretmen eklenmemiş. <button class="btn" data-a="adim" data-v="ogretmenler">Öğretmen ekle</button></div>';
    } else if (ui.gorunum === 'carsaf') {
      h += dd2CarsafKarti('sube') + carsafTablosu() + '</div><p class="dd2-tablosonuc" id="dd2-carsaf-sonuc" aria-live="polite"></p></section>';
    } else if (ui.gorunum === 'ogrCarsaf') {
      h += dd2CarsafKarti('ogretmen') + ogretmenCarsafTablosu() + '</div><p class="dd2-tablosonuc" id="dd2-carsaf-sonuc" aria-live="polite"></p></section>';
    } else if (ui.gorunum === 'yuk') {
      h += '<div class="kart kaydirma">' + yukTablosu() + '</div>';
    }
    return h + '</div></section>';
  }
  function aktifKayit() {
    var r = durum.sonuc;
    return r && r.kayitId ? durum.dagitimKayitlari.filter(function (k) { return k.id === r.kayitId; })[0] || null : null;
  }
  function kayitliDagitimlarCiz() {
    var l = durum.dagitimKayitlari, akt = aktifKayit();
    var h = '<details class="kart yazdirma-gizle" id="kayitli-dagitimlar"' + (ui.kayitlarAcik ? ' open' : '') + '><summary data-a="kayitlar-ac"><b>Kayıtlı dağıtımlar</b> <span class="ince">' + l.length + ' kayıt — programı sisteme kaydedin, sonra açıp düzenleyin ve üzerine kaydedin</span></summary><div style="margin-top:12px">';
    h += '<div class="satir"><input type="text" id="kayit-ad" placeholder="Kayıt adı (ör. 1. sürüm, Eylül)" value="" style="min-width:260px">' +
      '<button class="btn ana" data-a="dagitim-kaydet"' + (durum.sonuc ? '' : ' disabled') + '>' + ikon('kaydet') + 'Yeni kayıt olarak kaydet</button>' +
      '<span class="ince">' + (CFG.mod === 'sunucu' ? 'Kayıtlar projeyle birlikte evrakplus.com hesabınızda saklanır.' : 'Kayıtlar bu tarayıcıda ve JSON yedeğinde saklanır.') + '</span></div>';
    if (l.length) {
      var puanlar = l.map(function (k) {
        try { return kaliteAnalizi(k.sonuc).puan; } catch (e) { return null; }
      });
      var enYuksek = Math.max.apply(null, puanlar.map(function (p) { return p == null ? -1 : p; }));
      h += '<div class="kaydirma"><table class="tablo kayit-tablo" style="margin-top:10px"><tr><th>Senaryo / Kayıt Adı</th><th>Son kayıt</th><th class="s">Kalite Puanı</th><th class="s">Şube Boş</th><th class="s">Öğr. Pencere</th><th class="s">Yerleşen</th><th class="s">Kilit</th><th></th></tr>' + l.map(function (k, i) {
        var ist = k.sonuc.istatistik || {}, acik = akt && akt.id === k.id, puan = puanlar[i];
        var enIyi = l.length > 1 && puan != null && puan === enYuksek && !(ist.eksikSaat > 0);
        return '<tr' + (acik ? ' class="aktif-satir"' : '') + '><td><input type="text" class="satir-ici" data-a="kayit-ad-degis" data-v="' + i + '" value="' + esc(k.ad) + '" title="Yeniden adlandırmak için yazın">' +
          (acik ? ' <span class="etiket yesil">açık</span>' : '') + (enIyi ? ' <span class="etiket yesil" title="Kayıtlı senaryolar arasında en yüksek kalite puanı">★ En iyi</span>' : '') + (k.sonuc.duzenlendi ? ' <span class="etiket mor" title="Elle düzenlenmiş">elle düzenlendi</span>' : '') + '</td>' +
          '<td class="ince">' + esc(new Date(k.tarih).toLocaleString('tr-TR')) + '</td>' +
          '<td class="s">' + (puan != null ? '<span class="etiket ' + (puan >= 85 ? 'yesil' : (puan >= 65 ? 'sari' : 'kirmizi')) + '">' + puan + ' / 100</span>' : '—') + '</td>' +
          '<td class="s">' + (ist.subeBosluk != null ? ist.subeBosluk : '—') + '</td>' +
          '<td class="s">' + (ist.ogretmenBosluk != null ? ist.ogretmenBosluk : '—') + '</td>' +
          '<td class="s">' + ((ist.toplamSaat || 0) - (ist.eksikSaat || 0)) + '/' + (ist.toplamSaat || 0) + '</td><td class="s">' + (k.kilitler ? Object.keys(k.kilitler).length : 0) + '</td>' +
          '<td class="s nowrap">' + (acik
            ? '<button class="btn kucuk ana" data-a="dagitim-guncelle" data-v="' + k.id + '"' + (durum.sonuc.kayitDegisti ? '' : ' disabled') + '>' + ikon('kaydet') + 'Üzerine kaydet</button>'
            : '<button class="btn kucuk" data-a="dagitim-geri" data-v="' + i + '">' + ikon('duzenle') + 'Aç / düzenle</button>') +
          ' <button class="btn ikon-btn tehlike" data-a="dagitim-kayit-sil" data-v="' + i + '" title="Kaydı sil">' + ikon('cop') + '</button></td></tr>';
      }).join('') + '</table></div>';
    }
    return h + '</div></details>';
  }
  function duzenCubugu() {
    var r = durum.sonuc, mod = r ? (ui.duzenMod || 'tasi') : (ui.duzenMod === 'bak' ? 'bak' : 'kilit'), metin = r ? seciliBlokMetni() : '';
    var aciklama = {
      tasi: metin ? '<b>Seçili:</b> ' + esc(metin) + ' → yeşil boş saate (taşı) ya da yeşil çerçeveli derse (yer değiştir) tıklayın.' : '① Derse tıklayın → ② boş saate ya da başka derse tıklayın.',
      kilit: r ? 'Derse tıklayınca yerine kilitlenir 🔒; boş saate tıklayınca oraya ders seçersiniz.' : 'Dağıtımdan önce boş saate tıklayın → ders ve blok uzunluğunu seçip kilitleyin. Gün başlığından günü kapatın.',
      bak: 'Yalnız görüntüleme.'
    }[mod] + ' <span class="ince">· Sağ tık: tüm işlemler</span>';
    var h = '<div class="kart duzen-cubugu yazdirma-gizle"><div class="satir">' + sekmeler('duzen-mod', mod, (r ? [['tasi', '✥ Taşı / yer değiştir']] : []).concat([['kilit', '🔒 Kilitle'], ['bak', 'Görüntüle']])) +
      (mod === 'tasi' ? '<label class="satir-alan"><input type="checkbox" data-a="tasi-kilitle"' + (ui.tasiKilitle !== false ? ' checked' : '') + '> Taşınan dersi yerine kilitle</label>' : '') +
      '<span class="bosluk"></span>' +
      (metin ? (ui.secBlok.tip !== 'bekleyen' ? '<button class="btn kucuk tehlike" data-a="blok-cikar">Programdan çıkar</button>' : '') + '<button class="btn kucuk" data-a="secim-iptal">Seçimi bırak</button>' : '') +
      (r && r.duzenlendi ? '<span class="etiket mor">elle düzenlendi</span>' : '') + '</div><p class="ince" style="margin:8px 0 0">' + aciklama + '</p></div>';
    return h;
  }
  // ---------- Dağıtımı elle düzenleme ----------
  function yerlesimIndeksi(dersId, gun, saat) {
    var r = durum.sonuc;
    for (var i = 0; i < r.yerlesim.length; i++) { var y = r.yerlesim[i]; if (y.dersId === dersId && y.gun === gun && y.saat === saat) return i; }
    return -1;
  }
  /** Bloğun verilen yere konabilirliği; hata metni ya da null. haric: yok sayılacak yerleşim indeksleri */
  function yerDogrula(dersId, uzunluk, gun, saat, haric) {
    var r = durum.sonuc, d = r.dersler[dersId], H = +durum.okul.gunlukSaat, D = +durum.okul.gunSayisi;
    if (!d) return 'Ders bulunamadı.';
    if (d.paralel) return 'Paralel (alt grup) dersler birlikte yerleşir; tek başına taşınamaz. Kilitleyip yeniden dağıtın.';
    if (gun < 0 || gun >= D || saat < 0 || saat + uzunluk > H) return uzunluk + ' saatlik blok bu saatten başlarsa günün son dersini aşar.';
    var sk = durum.subeKapali[d.subeId] || [], o = ogretmen(d.ogretmenId), ok = o ? o.kapali || [] : [];
    for (var k = 0; k < uzunluk; k++) {
      var slot = gun + '-' + (saat + k);
      if (sk.indexOf(slot) >= 0) return (sube(d.subeId) || {}).ad + ' şubesinin ' + M.GUNLER[gun] + ' ' + (saat + k + 1) + '. ders saati kapalı.';
      if (ok.indexOf(slot) >= 0) return o.ad + ' ' + M.GUNLER[gun] + ' ' + (saat + k + 1) + '. derste kapalı (uygun değil).';
    }
    for (var i = 0; i < r.yerlesim.length; i++) {
      if (haric.indexOf(i) >= 0) continue;
      var y = r.yerlesim[i];
      if (y.gun !== gun || !(y.saat < saat + uzunluk && saat < y.saat + y.uzunluk)) continue;
      var x = r.dersler[y.dersId];
      if (!x) continue;
      if (x.subeId === d.subeId) return (sube(x.subeId) || {}).ad + ' bu saatte ' + x.ders + ' dersinde.';
      if (d.ogretmenId && x.ogretmenId === d.ogretmenId) return (o ? o.ad : 'Öğretmen') + ' bu saatte ' + (sube(x.subeId) || {}).ad + ' şubesinde ' + x.ders + ' dersinde.';
    }
    // ortak öğretmenler (K01) ve kulüp saatleri (K15)
    var ogrler = (d.ogretmenler || []).filter(function (t) { return t !== d.ogretmenId; });
    for (var oi = 0; oi < ogrler.length; oi++) {
      var oo = ogretmen(ogrler[oi]); if (!oo) continue;
      for (var kk = 0; kk < uzunluk; kk++) if ((oo.kapali || []).indexOf(gun + '-' + (saat + kk)) >= 0) return oo.ad + ' (ortak öğretmen) bu saatte kapalı.';
      for (var yi = 0; yi < r.yerlesim.length; yi++) {
        if (haric.indexOf(yi) >= 0) continue;
        var yy = r.yerlesim[yi], dx = r.dersler[yy.dersId];
        if (dx && yy.gun === gun && yy.saat < saat + uzunluk && saat < yy.saat + yy.uzunluk && (dx.ogretmenler || [dx.ogretmenId]).indexOf(oo.id) >= 0) return oo.ad + ' (ortak öğretmen) bu saatte ' + (sube(dx.subeId) || {}).ad + ' şubesinde.';
      }
    }
    var kulupHata = null;
    (r.kulupYerlesim || []).forEach(function (ky) {
      if (kulupHata || ky.gun !== gun || !(ky.saat < saat + uzunluk && saat < ky.saat + ky.uzunluk)) return;
      var kb = (r.kulupBilgi || {})[ky.kulupId] || {};
      if ((kb.subeIds || []).indexOf(d.subeId) >= 0) kulupHata = (sube(d.subeId) || {}).ad + ' bu saatte ' + kb.ad + ' kulübünde.';
      else if ((d.ogretmenler || [d.ogretmenId]).some(function (t) { return (kb.ogretmenler || []).indexOf(t) >= 0; })) kulupHata = 'Öğretmen bu saatte ' + kb.ad + ' kulübünde.';
    });
    if (kulupHata) return kulupHata;
    // K04: aynı dersten günde en fazla N saat; K08: İngilizce / Yabancı Dil ayrı günlerde
    var kur = kurallar(), L = +kur.gunlukAyniDersMax || 2, sinir = d.saat > D * L ? Math.ceil(d.saat / D) : L, gunToplam = uzunluk;
    var dDil = dersDili(d), dilHata = null;
    r.yerlesim.forEach(function (y2, j2) {
      if (haric.indexOf(j2) >= 0 || y2.gun !== gun) return;
      if (y2.dersId === dersId) gunToplam += y2.uzunluk;
      var dy = r.dersler[y2.dersId];
      if (kur.dilAyriGun && dDil && dy && dy.subeId === d.subeId && y2.dersId !== dersId) { var dl2 = dersDili(dy); if (dl2 && dl2 !== dDil) dilHata = 'K08: ' + dy.ders + ' aynı gün; İngilizce ve Yabancı Dil ayrı günlerde olmalı.'; }
    });
    if (gunToplam > sinir) return 'K04: ' + d.ders + ' bir günde en fazla ' + sinir + ' saat olabilir.';
    if (dilHata) return dilHata;
    if (o && o.maxGunluk) {
      var gunluk = uzunluk;
      r.yerlesim.forEach(function (y, j) { if (haric.indexOf(j) < 0 && y.gun === gun && (r.dersler[y.dersId] || {}).ogretmenId === o.id) gunluk += y.uzunluk; });
      if (gunluk > o.maxGunluk) return o.ad + ' için günlük en fazla ' + o.maxGunluk + ' ders sınırı aşılır.';
    }
    return null;
  }
  function ayniGunVar(dersId, gun, haric) {
    return durum.sonuc.yerlesim.some(function (y, i) { return haric.indexOf(i) < 0 && y.dersId === dersId && y.gun === gun; });
  }
  /** Yer denetimi + "bir ders aynı gün iki ayrı blok olamaz" kuralı */
  function yerHatasi(dersId, uzunluk, gun, saat, haric) {
    var h = yerDogrula(dersId, uzunluk, gun, saat, haric);
    if (h) return h;
    if (ayniGunVar(dersId, gun, haric)) { var d = durum.sonuc.dersler[dersId] || {}; return d.ders + ' dersinin ' + M.GUNLER[gun] + ' günü başka bloğu var (bir ders aynı gün iki ayrı blok olamaz).'; }
    return null;
  }
  function kilitTasi(dersId, eskiG, eskiS, yeniG, yeniS, uzunluk, kilitle) {
    var K = durum.kilitler, l = K[dersId] || [], vardi = false;
    l = l.filter(function (k) { if (k.gun === eskiG && k.saat === eskiS) { vardi = true; return false; } return true; });
    if (vardi || kilitle) l.push({ gun: yeniG, saat: yeniS, uzunluk: uzunluk });
    if (l.length) K[dersId] = l; else delete K[dersId];
  }
  /** Elle düzenlemeden sonra boşluk, eksik ve kilit sayılarını yeniden hesaplar */
  function istatistikYenile(sadeceKilit) {
    var r = durum.sonuc, D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat;
    var subeG = {}, ogrG = {};
    r.yerlesim.forEach(function (y) {
      var d = r.dersler[y.dersId]; if (!d) return;
      y.kilitli = ((durum.kilitler[y.dersId] || []).some(function (k) { return k.gun === y.gun && k.saat === y.saat; }));
      for (var k = 0; k < y.uzunluk; k++) {
        (subeG[d.subeId] = subeG[d.subeId] || {})[y.gun * H + y.saat + k] = 1;
        if (d.ogretmenId) (ogrG[d.ogretmenId] = ogrG[d.ogretmenId] || {})[y.gun * H + y.saat + k] = 1;
      }
    });
    var sb = 0, ob = 0;
    Object.keys(subeG).forEach(function (id) {
      var g = subeG[id], kap = durum.subeKapali[id] || [];
      for (var d = 0; d < D; d++) {
        var son = -1, dolu = 0, kp = 0;
        for (var h = 0; h < H; h++) if (g[d * H + h]) { son = h; dolu++; }
        for (h = 0; h <= son; h++) if (kap.indexOf(d + '-' + h) >= 0) kp++;
        if (son >= 0) sb += son + 1 - dolu - kp;
      }
    });
    Object.keys(ogrG).forEach(function (id) {
      var g = ogrG[id];
      for (var d = 0; d < D; d++) {
        var ilk = -1, son = -1, dolu = 0;
        for (var h = 0; h < H; h++) if (g[d * H + h]) { if (ilk < 0) ilk = h; son = h; dolu++; }
        if (son >= 0) ob += son - ilk + 1 - dolu;
      }
    });
    var ist = r.istatistik;
    ist.subeBosluk = sb; ist.ogretmenBosluk = ob;
    ist.eksikSaat = r.yerlesmeyen.reduce(function (a, y) { return a + y.uzunluk; }, 0);
    ist.kilitliBlok = r.yerlesim.filter(function (y) { return y.kilitli; }).length;
    ist.ceza = ist.eksikSaat * 1000 + sb * 10 + ob;
    if (!sadeceKilit) r.duzenlendi = true;
    r.kayitDegisti = true;
    r.cozucu = r.cozucu || {};
    r.cozucu.kuralIhlalleri = kuralDenetle(r);
    if (!sadeceKilit) r.cozucu.basarili = !r.cozucu.kuralIhlalleri.length && !(r.cozucu.desteklenmeyen || []).length;
  }
  /** Bir bloğu başka saate taşır; hata metni ya da { uyari } döndürür */
  function blokTasi(idx, gun, saat, kilitle) {
    var r = durum.sonuc, y = r.yerlesim[idx];
    var hata = yerHatasi(y.dersId, y.uzunluk, gun, saat, [idx]);
    if (hata) return hata;
    var uyari = '';
    kilitTasi(y.dersId, y.gun, y.saat, gun, saat, y.uzunluk, kilitle);
    y.gun = gun; y.saat = saat;
    istatistikYenile();
    return { uyari: uyari };
  }
  function blokDegistir(i1, i2) {
    var r = durum.sonuc, a = r.yerlesim[i1], b = r.yerlesim[i2];
    if (a.uzunluk !== b.uzunluk) return 'Farklı uzunlukta bloklar (' + a.uzunluk + ' ve ' + b.uzunluk + ' saat) yer değiştiremez; dersi boş bir saate taşıyın.';
    if (a.dersId === b.dersId) return 'Aynı dersin iki bloğu yer değiştirmez; dersi boş bir saate taşıyın.';
    var h1 = yerHatasi(a.dersId, a.uzunluk, b.gun, b.saat, [i1, i2]); if (h1) return h1;
    var h2 = yerHatasi(b.dersId, b.uzunluk, a.gun, a.saat, [i1, i2]); if (h2) return h2;
    var ag = a.gun, as = a.saat, kilitle = ui.tasiKilitle !== false;
    kilitTasi(a.dersId, ag, as, b.gun, b.saat, a.uzunluk, kilitle);
    kilitTasi(b.dersId, b.gun, b.saat, ag, as, b.uzunluk, kilitle);
    a.gun = b.gun; a.saat = b.saat; b.gun = ag; b.saat = as;
    istatistikYenile();
    return null;
  }
  function bekleyeniYerlestir(i, gun, saat, kilitle) {
    var r = durum.sonuc, y = r.yerlesmeyen[i];
    if (!y || !y.uzunluk) return 'Yerleştirilecek blok bulunamadı.';
    var hata = yerHatasi(y.dersId, y.uzunluk, gun, saat, []);
    if (hata) return hata;
    r.yerlesmeyen.splice(i, 1);
    r.yerlesim.push({ dersId: y.dersId, gun: gun, saat: saat, uzunluk: y.uzunluk, kilitli: false });
    if (kilitle) kilitTasi(y.dersId, -1, -1, gun, saat, y.uzunluk, true);
    istatistikYenile();
    return { uyari: '' };
  }
  function programdanCikar(idx) {
    var r = durum.sonuc, y = r.yerlesim.splice(idx, 1)[0];
    kilitTasi(y.dersId, y.gun, y.saat, -1, -1, y.uzunluk, false);
    var K = durum.kilitler[y.dersId];
    if (K) { durum.kilitler[y.dersId] = K.filter(function (k) { return k.gun >= 0; }); if (!durum.kilitler[y.dersId].length) delete durum.kilitler[y.dersId]; }
    r.yerlesmeyen.push({ dersId: y.dersId, uzunluk: y.uzunluk, neden: 'elle çıkarıldı' });
    istatistikYenile();
  }
  function seciliBlokMetni() {
    var r = durum.sonuc, s = ui.secBlok;
    if (!s || !r) return '';
    var y = s.tip === 'bekleyen' ? r.yerlesmeyen[s.i] : r.yerlesim[yerlesimIndeksi(s.dersId, s.gun, s.saat)];
    if (!y) { ui.secBlok = null; return ''; }
    var d = r.dersler[y.dersId] || {};
    return (sube(d.subeId) || {}).ad + ' · ' + d.ders + ' (' + y.uzunluk + ' saat' + (s.tip === 'bekleyen' ? ', yerleşmemiş' : ', ' + M.GUNLER[y.gun] + ' ' + (y.saat + 1) + '. ders') + ')';
  }
  /** Dağıtım sonucu yokken boş bir hücreye önceden ders kilitleme. */
  function hazirlikKilitModal() {
    var m = ui.modal, H = +durum.okul.gunlukSaat;
    var ad = m.tip2 === 'sube' ? (sube(m.id) || {}).ad : (ogretmen(m.id) || {}).ad;
    var baslik = ad + ' · ' + saatMetni(m.gun, m.saat, 1);
    var liste = dersListesi().filter(function (d) { return m.tip2 === 'sube' ? d.subeId === m.id : (d.ogretmenler || [d.ogretmenId]).indexOf(m.id) >= 0; });
    var kapali = kapaliListesi(m.tip2, m.id).indexOf(m.gun + '-' + m.saat) >= 0;
    var h = '<div class="modal-arka" data-a="modal-kapat"><div class="modal" data-durdur="1"><h3>Dağıtım öncesi ders kilitle</h3><p class="ince">' + esc(baslik) + ' · Seçilen ders otomatik dağıtımda yerinde kalır. Dersler önceden kilitlenmeden de boş çizelgeyi görebilirsiniz.</p>';
    if (kapali) h += '<div class="uyari dikkat">Bu saat kapalı. Önce açın, sonra ders kilitleyin.</div>';
    h += '<div class="secenek-listesi">';
    var n = 0;
    liste.sort(function (a, b) { return a.ders.localeCompare(b.ders, 'tr'); }).forEach(function (d) {
      var kilitlenmis = (durum.kilitler[d.id] || []).reduce(function (top, x) { return top + x.uzunluk; }, 0);
      var kalan = d.saat - kilitlenmis;
      if (kalan < 1) return;
      n++;
      var o = ogretmen(d.ogretmenId), ad2 = m.tip2 === 'sube' ? d.ders : (sube(d.subeId) || {}).ad + ' · ' + d.ders;
      h += '<div class="secenek" style="--h:' + M.renk(d.ders) + '"><div class="sec-bas"><i class="grup-nokta"></i><b>' + esc(ad2) + '</b><span class="ince">' + esc(o ? o.ad : 'Öğretmen atanmadı') + ' · ' + kalan + ' saat kaldı</span></div><div class="satir">';
      [1, 2].forEach(function (uz) {
        if (uz > kalan || m.saat + uz > H) return;
        var hata = kilitDene(d.id, m.gun, m.saat, uz);
        h += '<button class="btn kucuk" data-a="hazirlik-kilit-ekle" data-v="' + esc(d.id + '|' + m.gun + '|' + m.saat + '|' + uz) + '"' + (hata ? ' disabled title="' + esc(hata) + '"' : '') + '>' + uz + ' saat kilitle</button>';
      });
      h += '</div></div>';
    });
    if (!n) h += '<p class="ince">Bu şube veya öğretmene atanmış kilitlenebilecek ders bulunamadı. Önce öğretmen atamalarını kontrol edin.</p>';
    h += '</div><div class="satir sag"><button class="btn" data-a="program-saat-toggle" data-v="' + esc(m.tip2 + '|' + m.id + '|' + m.gun + '|' + m.saat) + '">' + (kapali ? 'Saati aç' : 'Bu saati kapat') + '</button><button class="btn ana" data-a="modal-kapat">Kapat</button></div></div></div>';
    return h;
  }
  function menuHazirlikSaat(tip, id, gun, saat) {
    var ad = tip === 'sube' ? (sube(id) || {}).ad : (ogretmen(id) || {}).ad;
    return mBaslik('Dağıtım öncesi düzenleme', esc(ad + ' · ' + saatMetni(gun, saat, 1))) +
      mOge('Ders kilitle…', 'hazirlik-kilit-ac', tip + '|' + id + '|' + gun + '|' + saat, { ikon: '🔒' }) +
      mOge(kapaliListesi(tip, id).indexOf(gun + '-' + saat) >= 0 ? 'Saati aç' : 'Saati kapat', 'program-saat-toggle', tip + '|' + id + '|' + gun + '|' + saat, { ikon: '◫' });
  }
  /** Kilitli dersler ve yerleştirilmiş dersler kapalı saate dönüştürülmez. */
  function kapatmaHatasi(tip, id, gun, saat) {
    var dersler = dersListesi();
    var on = ProgramAraclari.onYerlesimler(dersler, durum.kilitler);
    var r = durum.sonuc;
    if (r) on = on.concat(r.yerlesim || []);
    for (var i = 0; i < on.length; i++) {
      var y = on[i], d = (r && r.dersler && r.dersler[y.dersId]) || dersBul(y.dersId);
      if (!d || y.gun !== gun || (saat != null && !(y.saat <= saat && saat < y.saat + y.uzunluk))) continue;
      if (tip === 'sube' ? d.subeId === id : (d.ogretmenler || [d.ogretmenId]).indexOf(id) >= 0) {
        return 'Önce ' + d.ders + ' dersinin yerleşim kilidini kaldırın veya mevcut dağıtımı düzenleyin.';
      }
    }
    return null;
  }
  function programKapatAc(tip, id, gun, saat) {
    if (tip !== 'sube' && tip !== 'ogretmen') return;
    var H = +durum.okul.gunlukSaat, D = +durum.okul.gunSayisi;
    if (gun < 0 || gun >= D || (saat != null && (saat < 0 || saat >= H))) return;
    var L = kapaliListesi(tip, id), kapat = saat != null ? L.indexOf(gun + '-' + saat) < 0 : gunDurumu(L, gun, H) !== 'kapali';
    if (kapat) { var hata = kapatmaHatasi(tip, id, gun, saat); if (hata) { bildir(hata, 'hata'); return; } }
    if (saat != null) {
      var slot = gun + '-' + saat, ix = L.indexOf(slot);
      if (kapat && ix < 0) L.push(slot);
      else if (!kapat && ix >= 0) L.splice(ix, 1);
    } else gunAcKapa(L, gun, H);
    degisti(true); ui.modal = null; ciz();
    bildir(M.GUNLER[gun] + (saat != null ? ' ' + (saat + 1) + '. ders saati' : ' günü') + (kapat ? ' kapatıldı.' : ' açıldı.'));
  }
  /** Seçilen boş saate ders kilitleme penceresi */
  function saatKilitModal() {
    var m = ui.modal, r = durum.sonuc, H = +durum.okul.gunlukSaat;
    var saatler = M.saatEtiketleri(durum.okul, H);
    var adaylar = Object.keys(r.dersler).filter(function (id) { var d = r.dersler[id]; return m.tip2 === 'sube' ? d.subeId === m.id : d.ogretmenId === m.id; });
    var baslik = (m.tip2 === 'sube' ? (sube(m.id) || {}).ad : (ogretmen(m.id) || {}).ad) + ' · ' + M.GUNLER[m.gun] + ' ' + (m.saat + 1) + '. ders (' + saatler[m.saat] + ')';
    var h = '<div class="modal-arka" data-a="modal-kapat"><div class="modal" data-durdur="1"><h3>Bu saate ders kilitle</h3><p class="ince">' + esc(baslik) + ' — dersin bir bloğunu seçin; buraya taşınır ve kilitlenir. Uygun olmayanların nedeni üzerine gelince görünür.</p><div class="secenek-listesi">';
    var var_ = false;
    adaylar.forEach(function (id) {
      var d = r.dersler[id], o = ogretmen(d.ogretmenId);
      var bloklar = [];
      r.yerlesim.forEach(function (y, i) { if (y.dersId === id) bloklar.push({ k: 'yer:' + i, y: y, hata: yerHatasi(id, y.uzunluk, m.gun, m.saat, [i]), etiket: M.GUNLER[y.gun].slice(0, 3) + ' ' + (y.saat + 1) + (y.uzunluk > 1 ? '–' + (y.saat + y.uzunluk) : '') + '. ders' + (y.kilitli ? ' 🔒' : '') }); });
      r.yerlesmeyen.forEach(function (y, i) { if (y.dersId === id && y.uzunluk) bloklar.push({ k: 'bek:' + i, y: y, hata: yerHatasi(id, y.uzunluk, m.gun, m.saat, []), etiket: 'yerleşmemiş' }); });
      if (!bloklar.length) return;
      var_ = true;
      h += '<div class="secenek" style="--h:' + M.renk(d.ders) + '"><div class="sec-bas"><i class="grup-nokta"></i><b>' + esc(m.tip2 === 'sube' ? d.ders : (sube(d.subeId) || {}).ad + ' · ' + d.ders) + '</b><span class="ince">' + esc(o ? o.ad : '') + '</span></div><div class="satir">' +
        bloklar.map(function (b) {
          return '<button class="btn kucuk' + (b.hata ? ' pasif-btn' : '') + '" data-a="saat-kilit-sec" data-v="' + esc(id + '|' + b.k) + '"' + (b.hata ? ' title="' + esc(b.hata) + '"' : ' title="Buraya taşı ve kilitle"') + '>' + b.y.uzunluk + ' saat · ' + esc(b.etiket) + '</button>';
        }).join('') + '</div></div>';
    });
    if (!var_) h += '<p class="ince">Bu ' + (m.tip2 === 'sube' ? 'şubenin' : 'öğretmenin') + ' dersi yok.</p>';
    return h + '</div><div class="satir sag"><button class="btn" data-a="modal-kapat">Kapat</button></div></div></div>';
  }
  function ozelSecmeliModal() {
    var t = tur(), gruplar = secmeliGruplari();
    if (gruplar.indexOf('Okula özel') < 0) gruplar.push('Okula özel');
    var duzeyler = t.siniflar.filter(function (s, si) { return t.secmeliSaat[si] > 0; });
    var aktif = ui.secmeliSinif, hedef = durum.subeler.filter(function (x) { return x.sinif === aktif; });
    var kalanlar = hedef.map(function (sb) { return (t.secmeliSaat[t.siniflar.indexOf(aktif)] || 0) - secmeliToplam(M.subeSecmelileri(durum, sb)); });
    return '<div class="modal-arka" data-a="modal-kapat"><div class="modal dd6-custom-modal" data-durdur="1" role="dialog" aria-modal="true" aria-label="Yeni seçmeli ders"><div class="dd6-modal-header"><span class="dd6-step">+</span><div><h3>Yeni seçmeli ders oluştur</h3><p>Okulun kendi dersini havuza ekleyip dilediğin sınıflarda kullanılabilir hâle getir.</p></div></div>' +
      '<div class="dd6-modal-fields"><label class="dd6-field-wide">Ders adı<input type="text" id="ms-ad" placeholder="Örn. Robotik Kodlama" maxlength="120" autocomplete="off"></label>' +
      '<label>Grup<select id="ms-grup">' + gruplar.map(function (g) { return '<option' + (g === 'Okula özel' ? ' selected' : '') + '>' + esc(g) + '</option>'; }).join('') + '</select></label>' +
      '<label>Haftalık ders saati<select id="ms-saat">' + [1,2,3,4,5,6].map(function (n) { return '<option' + (n === 2 ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select></label>' +
      '<fieldset class="dd6-field-wide dd6-level-field"><legend>Bu ders hangi sınıfların havuzunda bulunsun?</legend><div>' + duzeyler.map(function (s) { return '<label class="dd6-level-check"><input type="checkbox" class="ms-sinif" value="' + esc(s) + '"' + (s === aktif ? ' checked' : '') + '><span>' + esc(sinifEtiketi(s)) + '</span></label>'; }).join('') + '</div></fieldset>' +
      '<fieldset class="dd6-field-wide dd6-level-field dd7-modal-targets"><legend>Kaydet ve ata: hangi şubelere gönderilsin?</legend><div>' + hedef.map(function (sb) { var kalan = (t.secmeliSaat[t.siniflar.indexOf(aktif)] || 0) - secmeliToplam(M.subeSecmelileri(durum,sb)); return '<label class="dd6-level-check"><input type="checkbox" class="ms-hedef-sube" value="' + esc(sb.id) + '"' + (kalan > 0 ? ' checked' : '') + '><span>' + esc(sb.ad) + ' <small>' + kalan + ' sa boş</small></span></label>'; }).join('') + '</div></fieldset></div>' +
      '<div class="dd6-modal-info"><b>Atama seçenekleri</b><p>“Havuza kaydet” dersi oluşturur, şubeleri değiştirmez. “Kaydet ve şubelere ata” işaretlediğiniz şubelere, yeterli boş seçmeli saat varsa uygular.</p><small>' + hedef.length + ' şube · Kalan seçmeli saat: ' + (kalanlar.length ? kalanlar.join(' / ') : 'şube yok') + '</small></div>' +
      '<div class="dd6-modal-actions dd6-modal-actions-wide"><button class="btn" data-a="modal-kapat">Vazgeç</button><button class="btn" data-a="ozel-secmeli-kaydet" data-v="havuz">Yalnız havuza kaydet</button><button class="btn ana" data-a="ozel-secmeli-kaydet" data-v="ata">' + ikon('artı') + ' Kaydet ve şubelere ata</button></div></div></div>';
  }

  // ---------- Sağ tık menüsü ----------
  function menuAc(x, y, html) {
    var m = $('#sag-menu');
    if (!m) { m = document.createElement('div'); m.id = 'sag-menu'; m.className = 'sag-menu'; m.setAttribute('role', 'menu'); document.body.appendChild(m); }
    m.innerHTML = html; m.style.display = 'block'; m.style.left = '0px'; m.style.top = '0px';
    var w = m.offsetWidth, h = m.offsetHeight;
    m.style.left = Math.max(8, Math.min(x, window.innerWidth - w - 8)) + 'px';
    m.style.top = Math.max(8, Math.min(y, window.innerHeight - h - 8)) + 'px';
    var ilk = m.querySelector('button[data-a]'); if (ilk) ilk.focus({ preventScroll: true });
    ui.menuAcilis = { t: Date.now(), y: window.scrollY };
  }
  /** Sayfa gerçekten kaydırılınca menüyü kapat (menünün kendi listesi kayınca ya da açılıştaki kaydırmada değil) */
  function menuKaydirma(e) {
    var m = $('#sag-menu');
    if (!m || m.style.display === 'none') return;
    if (e && e.target && e.target.nodeType === 1 && e.target.closest && e.target.closest('#sag-menu')) return;
    var a = ui.menuAcilis || { t: 0, y: window.scrollY };
    if (Date.now() - a.t < 300 || Math.abs(window.scrollY - a.y) < 40) return;
    menuKapat();
  }
  function menuKapat() { var m = $('#sag-menu'); if (m && m.style.display !== 'none') { m.style.display = 'none'; m.innerHTML = ''; } }
  function mOge(etiket, a, v, o) {
    o = o || {};
    if (o.pasif) return '<div class="mo pasif" role="menuitem" aria-disabled="true"><i>' + (o.ikon || '') + '</i><span>' + etiket + '<small>' + esc(o.pasif) + '</small></span></div>';
    return '<button class="mo' + (o.tehlike ? ' tehlike' : '') + '" role="menuitem" data-a="' + a + '" data-v="' + esc(v) + '"' + (o.title ? ' title="' + esc(o.title) + '"' : '') + '><i>' + (o.ikon || '') + '</i><span>' + etiket + (o.alt ? '<small>' + o.alt + '</small>' : '') + '</span>' + (o.sag ? '<em>' + o.sag + '</em>' : '') + '</button>';
  }
  function mBaslik(b, alt) { return '<div class="mb"><b>' + b + '</b>' + (alt ? '<span>' + alt + '</span>' : '') + '</div>'; }
  var mAyrac = '<div class="ma"></div>';
  function saatMetni(gun, saat, uz) { return M.GUNLER[gun] + ' ' + (saat + 1) + (uz > 1 ? '–' + (saat + uz) : '') + '. ders'; }
  function dersBul(dersId) { return dersListesi().filter(function (x) { return x.id === dersId; })[0] || null; }
  function blokBul(dersId, gun, saat) {
    var r = durum.sonuc; if (!r) return -1;
    for (var i = 0; i < r.yerlesim.length; i++) { var y = r.yerlesim[i]; if (y.dersId === dersId && y.gun === gun && saat >= y.saat && saat < y.saat + y.uzunluk) return i; }
    return -1;
  }
  /** Öğretmen değiştirme / atama sayfası maddeleri */
  function menuOgretmenOgeleri(d) {
    if (!d || d.ders === 'Seçmeli Ders') return '';
    var o = ogretmen(d.ogretmenId);
    var h = mOge(o ? 'Öğretmeni değiştir…' : 'Öğretmen ata…', 'ogr-degistir-ac', d.id, { ikon: '👤', alt: o ? 'şu an: ' + esc(o.ad) : 'bu derse öğretmen atanmamış' });
    if (o) {
      h += mOge('Öğretmen atama sayfasına git', 'ogr-git', o.id, { ikon: '↗', alt: esc(o.ad) + ' profili' });
      h += mOge('Atamayı kaldır', 'menu-atama-kaldir', d.id, { ikon: '✕', tehlike: true });
    }
    h += mOge('Şubenin ders ve öğretmen listesi', 'menu-sube-atama', d.subeId, { ikon: '☰', alt: esc((sube(d.subeId) || {}).ad) + ' — atama sayfası' });
    return h;
  }
  /** Programdaki dolu hücre (şube / öğretmen programı, çarşaf) */
  function menuDers(dersId, gun, saat, kaynak) {
    var r = durum.sonuc, i = blokBul(dersId, gun, saat), y = i >= 0 ? r.yerlesim[i] : null;
    var d = dersBul(dersId) || (r && r.dersler[dersId] ? Object.assign({ id: dersId }, r.dersler[dersId]) : null);
    if (!d) return null;
    var sb = sube(d.subeId), o = ogretmen(d.ogretmenId);
    var h = mBaslik(esc((sb || {}).ad + ' · ' + d.ders), esc((o ? o.ad : 'öğretmen yok') + (y ? ' · ' + saatMetni(y.gun, y.saat, y.uzunluk) : '')));
    if (y) {
      var kilitli = (durum.kilitler[dersId] || []).some(function (k) { return k.gun === y.gun && k.saat === y.saat; });
      h += mOge(kilitli ? 'Kilidi kaldır' : 'Bu saate kilitle', 'menu-kilit-tog', dersId + '|' + y.gun + '|' + y.saat + '|' + y.uzunluk, { ikon: kilitli ? '🔓' : '🔒', alt: kilitli ? 'yeniden dağıtımda yeri değişebilir' : 'yeniden dağıtımda burada kalır' });
      h += mOge('Taşı / yer değiştir…', 'menu-tasi-sec', dersId + '|' + y.gun + '|' + y.saat, { ikon: '✥', alt: 'seçer; sonra hedef saate tıklayın' });
      h += mOge('Programdan çıkar', 'menu-cikar', dersId + '|' + y.gun + '|' + y.saat, { ikon: '⤓', tehlike: true });
      h += mAyrac;
      if (kaynak === 'sube' || kaynak === 'carsaf') {
        var adaylar = [];
        r.yerlesim.forEach(function (b, j) {
          if (j === i || b.uzunluk !== y.uzunluk || b.dersId === dersId || (r.dersler[b.dersId] || {}).subeId !== d.subeId) return;
          adaylar.push({ j: j, b: b, hata: takasHatasi(j, i) });
        });
        if (adaylar.length) {
          adaylar.sort(function (a, b) { return (!!a.hata - !!b.hata) || (r.dersler[a.b.dersId].ders || '').localeCompare(r.dersler[b.b.dersId].ders || '', 'tr'); });
          var uygunSay = adaylar.filter(function (x) { return !x.hata; }).length;
          h += '<div class="m-alt-baslik">Bu saate başka ders kilitle <span>' + uygunSay + ' uygun</span></div><div class="m-kaydir kisa">' + adaylar.map(function (x) {
            var xd = r.dersler[x.b.dersId] || {}, xo = ogretmen(xd.ogretmenId);
            return mOge(esc(xd.ders) + ' <b>' + x.b.uzunluk + ' sa</b>', 'menu-takas-kilit', x.j + '|' + i, x.hata ? { pasif: x.hata, ikon: '·' } : { ikon: '🔒', alt: esc((xo ? xo.ad + ' · ' : '') + 'şu an ' + saatMetni(x.b.gun, x.b.saat, x.b.uzunluk) + ' · ' + d.ders + ' oraya geçer') });
          }).join('') + '</div>' + mAyrac;
        }
      }
    }
    h += menuOgretmenOgeleri(d);
    if (r && (kaynak !== 'sube' || (kaynak !== 'ogretmen' && o))) h += mAyrac;
    if (r && kaynak !== 'sube') h += mOge('Şube programını aç', 'menu-program', 'sube|' + d.subeId, { ikon: '▦', alt: esc((sb || {}).ad) });
    if (r && kaynak !== 'ogretmen' && o) h += mOge('Öğretmen programını aç', 'menu-program', 'ogretmen|' + o.id, { ikon: '▦', alt: esc(o.ad) });
    return h;
  }
  /** Programdaki boş saat: o şubenin / öğretmenin derslerinden biri seçilip buraya kilitlenir */
  function menuBosSaat(tip, id, gun, saat) {
    var r = durum.sonuc; if (!r) return null;
    var ad = tip === 'sube' ? (sube(id) || {}).ad : (ogretmen(id) || {}).ad;
    var h = mBaslik('Bu saate ders kilitle', esc(ad + ' · ' + saatMetni(gun, saat, 1))) + '<div class="m-kaydir">';
    var adet = 0;
    Object.keys(r.dersler).filter(function (did) { var d = r.dersler[did]; return tip === 'sube' ? d.subeId === id : d.ogretmenId === id; })
      .sort(function (a, b) { return r.dersler[a].ders.localeCompare(r.dersler[b].ders, 'tr'); })
      .forEach(function (did) {
        var d = r.dersler[did], ad2 = tip === 'sube' ? d.ders : (sube(d.subeId) || {}).ad + ' · ' + d.ders;
        r.yerlesim.forEach(function (y, i) {
          if (y.dersId !== did) return;
          adet++;
          var hata = yerHatasi(did, y.uzunluk, gun, saat, [i]);
          if (hata) {
            // Şubenin o saatteki dersiyle yer değiştirerek yerleştirilebilir mi?
            var j = subeBlogu(d.subeId, gun, saat, y.uzunluk);
            if (j >= 0 && !takasHatasi(i, j)) {
              var bd = r.dersler[r.yerlesim[j].dersId] || {};
              h += mOge(esc(ad2) + ' <b>' + y.uzunluk + ' sa</b>', 'menu-takas-kilit', i + '|' + j, { ikon: '⇄', alt: 'yer değiştirerek: ' + esc((sube(d.subeId) || {}).ad + ' ' + bd.ders) + ' → ' + saatMetni(y.gun, y.saat, y.uzunluk) });
              return;
            }
          }
          h += mOge(esc(ad2) + ' <b>' + y.uzunluk + ' sa</b>', 'menu-saat-kilit', did + '|yer:' + i + '|' + gun + '|' + saat, hata ? { pasif: hata, ikon: '·' } : { ikon: '🔒', alt: 'şu an ' + saatMetni(y.gun, y.saat, y.uzunluk) + (y.kilitli ? ' (kilitli)' : ''), title: 'Buraya taşı ve kilitle' });
        });
        r.yerlesmeyen.forEach(function (y, i) {
          if (y.dersId !== did || !y.uzunluk) return;
          adet++;
          var hata = yerHatasi(did, y.uzunluk, gun, saat, []);
          h += mOge(esc(ad2) + ' <b>' + y.uzunluk + ' sa</b>', 'menu-saat-kilit', did + '|bek:' + i + '|' + gun + '|' + saat, hata ? { pasif: hata, ikon: '·' } : { ikon: '🔒', alt: 'yerleşmemiş blok' });
        });
      });
    if (!adet) h += '<div class="mo pasif"><i></i><span>Bu ' + (tip === 'sube' ? 'şubenin' : 'öğretmenin') + ' programda dersi yok</span></div>';
    return h + '</div>';
  }
  /** Kısıtlar → kilit ızgarası (dağıtımdan önce de çalışır) */
  function kilitDene(dersId, gun, saat, uz) {
    var hata = kilitEkle(dersId, gun, saat, uz);
    if (!hata) kilitSil(dersId, gun, saat);
    return hata;
  }
  function menuKilitIzgara(td, tip, id) {
    var p = td.getAttribute('data-v').split('|'), gun = +p[0], saat = +p[1], H = +durum.okul.gunlukSaat;
    var ad = tip === 'sube' ? (sube(id) || {}).ad : (ogretmen(id) || {}).ad, K = kilitler();
    var h = mBaslik('Bu saate ders kilitle', esc(ad + ' · ' + saatMetni(gun, saat, 1)));
    var yv = td.getAttribute('data-y');
    if (yv) {
      var py = yv.split('|'), yu = +py.pop(), ys = +py.pop(), yg = +py.pop(), yid = py.join('|'), yd = dersBul(yid);
      var hy = kilitDene(yid, yg, ys, yu);
      h += mOge('Programdaki yerleşimi kilitle', 'menu-kilit-ekle', yid + '|' + yg + '|' + ys + '|' + yu, hy ? { pasif: hy, ikon: '·' } : { ikon: '🔒', alt: esc((yd ? yd.ders : '') + ' · ' + saatMetni(yg, ys, yu)) }) + mAyrac;
    }
    h += '<div class="m-kaydir">';
    var benim = dersListesi().filter(function (d) { return tip === 'ogretmen' ? d.ogretmenId === id : d.subeId === id; })
      .sort(function (a, b) { return a.ders.localeCompare(b.ders, 'tr'); });
    var adet = 0;
    benim.forEach(function (d) {
      var kl = (K[d.id] || []).reduce(function (a, k) { return a + k.uzunluk; }, 0), kalan = d.saat - kl;
      if (kalan <= 0) return;
      adet++;
      var ad2 = tip === 'ogretmen' ? (sube(d.subeId) || {}).ad + ' · ' + d.ders : d.ders;
      var o = ogretmen(d.ogretmenId);
      var uzunluklar = [1, 2, 3, 4].filter(function (n) { return n <= kalan && saat + n <= H; });
      var secenek = uzunluklar.map(function (n) { return { n: n, hata: kilitDene(d.id, gun, saat, n) }; });
      var uygun = secenek.filter(function (x) { return !x.hata; });
      if (!uygun.length) { h += mOge(esc(ad2), '', '', { pasif: (secenek[0] && secenek[0].hata) || 'Gün sonuna sığmıyor.', ikon: '·' }); return; }
      h += '<div class="mo cok" role="menuitem"><i>🔒</i><span>' + esc(ad2) + '<small>' + (tip === 'sube' ? esc(o ? o.ad : 'öğretmen yok') + ' · ' : '') + 'kilitlenmemiş ' + kalan + ' saat</small></span><em class="m-cipler">' +
        secenek.map(function (x) { return x.hata ? '<span class="m-cip pasif" title="' + esc(x.hata) + '">' + x.n + ' sa</span>' : '<button class="m-cip" data-a="menu-kilit-ekle" data-v="' + esc(d.id + '|' + gun + '|' + saat + '|' + x.n) + '" title="' + x.n + ' saatlik blok olarak kilitle">' + x.n + ' sa</button>'; }).join('') + '</em></div>';
    });
    if (!adet) h += '<div class="mo pasif"><i></i><span>Kilitlenecek ders kalmadı<small>tüm dersler kilitli ya da ders yok</small></span></div>';
    return h + '</div>';
  }
  function menuKilitli(v) {
    var p = v.split('|'), saat = +p.pop(), gun = +p.pop(), did = p.join('|'), d = dersBul(did);
    if (!d) return null;
    var k = (durum.kilitler[did] || []).filter(function (x) { return x.gun === gun && x.saat === saat; })[0] || { uzunluk: 1 };
    var o = ogretmen(d.ogretmenId);
    return mBaslik('🔒 ' + esc((sube(d.subeId) || {}).ad + ' · ' + d.ders), esc((o ? o.ad : 'öğretmen yok') + ' · ' + saatMetni(gun, saat, k.uzunluk))) +
      mOge('Kilidi kaldır', 'kilit-kaldir', v, { ikon: '🔓' }) + mAyrac + menuOgretmenOgeleri(d);
  }
  /** Dört program şablonunun boş / dolu hücresinde aynı kapsamlı menü. */
  function dd5HucreMenu(td) {
    var raw = td.getAttribute('data-dd5-slot'); if (!raw) return null;
    var a = raw.split('|'), saat = +a.pop(), gun = +a.pop(), tip = a.shift(), id = a.join('|');
    var did = td.getAttribute('data-ders'), v = td.getAttribute('data-v') || '';
    if (!did && (td.getAttribute('data-a') === 'hucre-tik' || td.getAttribute('data-a') === 'hazirlik-kilit-kaldir')) {
      var parts = v.split('|'); parts.pop(); parts.pop(); parts.pop(); did = parts.join('|');
    }
    var html = '';
    if (did) {
      var d = dersBul(did), r = durum.sonuc;
      var blok = r ? blokBul(did, gun, saat) : -1;
      if (r && blok >= 0) html = menuDers(did, gun, saat, tip);
      else {
        var k = (durum.kilitler[did] || []).find(function (x) { return x.gun === gun && x.saat <= saat && saat < x.saat + x.uzunluk; });
        html = k ? menuKilitli(did + '|' + k.gun + '|' + k.saat) : mBaslik(esc((sube(d.subeId) || {}).ad + ' · ' + d.ders), esc(saatMetni(gun, saat, 1)));
        if (d && !k) html += menuOgretmenOgeleri(d);
      }
      if (d) {
        html += mAyrac + mOge('Blok düzenini değiştir…', 'dd5-blok-ac', did, { ikon: '▦', alt: '1+1 / 2+2 gibi ders kalıbını ayarla' });
        html += mOge('Haftalık ders listesinden kaldır…', 'dd5-ders-kaldir', did, { ikon: '✕', tehlike: true, alt: 'Haftalık ders yükünden kaldır; MEB dersi geri alınabilir' });
      }
    } else {
      var kap = kapaliListesi(tip, id).indexOf(gun + '-' + saat) >= 0;
      html = durum.sonuc && !kap ? menuBosSaat(tip, id, gun, saat) : menuHazirlikSaat(tip, id, gun, saat);
      if (durum.sonuc && kap) html = mBaslik('Kapalı ders saati', esc(saatMetni(gun, saat, 1)));
      if (html.indexOf('data-a="program-saat-toggle"') < 0)
        html += mAyrac + mOge(kap ? 'Saati aç' : 'Saati kapat', 'program-saat-toggle', raw, { ikon: kap ? '✓' : '×' });
      html += mOge('Derse öğretmen ata / değiştir…', 'dd5-ogretmen-sec-ac', raw, { ikon: '👤', alt: 'Dersi ve öğretmeni mevcut listelerden seçin' });
    }
    if (did) {
      var kapali = kapaliListesi(tip, id).indexOf(gun + '-' + saat) >= 0;
      var hata = kapali ? null : kapatmaHatasi(tip, id, gun, saat);
      html += mOge(kapali ? 'Saati aç' : 'Saati kapat', 'program-saat-toggle', raw, { ikon: '◫', pasif: hata || null });
    }
    html += mOge('Günü / saatleri düzenle…', 'program-kisit-ac', tip + '|' + id, { ikon: '▤', alt: 'Haftalık uygunluk çizelgesi' });
    return html;
  }
  /** Boş çizelge hücresinden ders seçerek öğretmen atama penceresini aç. */
  function dd5OgretmenSecModal() {
    var m = ui.modal, v = m.slot.split('|'), saat = +v.pop(), gun = +v.pop(), tip = v.shift(), id = v.join('|');
    var ad = tip === 'sube' ? (sube(id) || {}).ad : (ogretmen(id) || {}).ad;
    var tum = dersListesi().filter(function (d) {
      return d.ders !== 'Seçmeli Ders' && (tip === 'sube' ? d.subeId === id : (!d.ogretmenId || d.ogretmenId === id));
    });
    var h = '<div class="modal-arka" data-a="modal-kapat"><div class="modal dd5-ogretmen-sec-modal" data-durdur="1"><h3>Derse öğretmen ata / değiştir</h3>' +
      '<p class="ince">' + esc(ad + ' · ' + saatMetni(gun, saat, 1)) + ' · Ders seçin; ardından öğretmen listesinden atama yapın. Bu işlem dersi otomatik olarak seçilen saate kilitlemez.</p>' +
      '<input type="search" class="dd5-modal-arama" data-a="dd5-ogretmen-ara" placeholder="Ders veya şube ara…" aria-label="Ders ara">' +
      '<div class="dd5-ogretmen-ders-listesi">';
    tum.sort(function (a, b) { return (sube(a.subeId) || {}).ad.localeCompare((sube(b.subeId) || {}).ad,'tr') || a.ders.localeCompare(b.ders,'tr'); }).forEach(function (d) {
      var ogr = ogretmen(d.ogretmenId);
      h += '<button class="dd5-ogretmen-ders" data-a="dd5-ogretmen-ders" data-v="' + esc(d.id) + '" data-ara="' + esc(((sube(d.subeId) || {}).ad + ' ' + d.ders + ' ' + (ogr ? ogr.ad : '')).toLocaleLowerCase('tr-TR')) + '">' +
        '<span><b>' + esc((sube(d.subeId) || {}).ad + ' · ' + d.ders) + '</b><small>' + (ogr ? esc(ogr.ad) : 'Henüz öğretmen atanmadı') + '</small></span><span>Seç →</span></button>';
    });
    if (!tum.length) h += '<p class="ince">Bu görünümle ilişkili ders bulunamadı. Önce Ders havuzları veya Öğretmen atama ekranında ders tanımlayın.</p>';
    return h + '</div><div class="satir sag"><button class="btn" data-a="modal-kapat">Kapat</button><button class="btn" data-a="dd5-atama-git">Tüm öğretmen atamaları</button></div></div></div>';
  }
  function dd5BlokModal() {
    var d = dersBul(ui.modal.dersId); if (!d) { ui.modal = null; return ''; }
    var D = +durum.okul.gunSayisi;
    var oneriler = ux3BlokOnerileri(d.saat, D);
    var elle = durum.yerlesimler[d.id] || '';
    var etkin = d.yerlesimMetni || (oneriler[0] || '—');
    var taslak = ui.modal.taslak !== undefined ? ui.modal.taslak : (elle || oneriler[0] || '');
    var hedef = (sube(d.subeId) || {}).ad || '';
    return '<div class="modal-arka" data-a="modal-kapat"><div class="modal dd6-block-modal" role="dialog" aria-modal="true" data-durdur="1"><div class="dd6-modal-top"><div><h3>Blok düzenini oluştur</h3><p><b>' + esc(hedef + ' · ' + d.ders) + '</b> · Haftalık ' + d.saat + ' saat</p></div><span class="dd6-type '+(d.grup==='Seçmeli'?'elective':'compulsory')+'">'+(d.grup==='Seçmeli'?'Seçmeli':'Zorunlu')+'</span></div>' +
      '<div class="dd6-current"><small>Şu anki düzen</small><b>'+esc(etkin)+'</b></div>'+
      '<h4>Hazır blok seçenekleri</h4>' +
      '<div class="dd6-preset-list">'+(oneriler.length?oneriler.map(function(p,ix){return '<button type="button" class="dd6-preset'+(taslak===p?' active':'')+'" data-a="dd6-preset" data-v="'+esc(p)+'"><b>'+esc(p)+'</b><small>'+(ix===0?'Önerilen':'Alternatif')+'</small></button>';}).join(''):'<p class="dd6-warning">Bu hafta ve en fazla 2 saatlik blok sınırıyla geçerli kalıp yok. Ders saati veya çalışma günü sınırını gözden geçirin.</p>')+'</div>'+
      '<label class="dd6-custom-label" for="dd6-custom-block">Kendin düzenle <small>Örn. 2+1+1</small></label>'+
      '<input id="dd6-custom-block" type="text" inputmode="numeric" autocomplete="off" placeholder="2+2+1" value="'+esc(taslak)+'" aria-describedby="dd6-block-help">' +
      '<p id="dd6-block-help" class="ince">Blokların toplamı '+d.saat+' saat olmalı; her blok 1 veya 2 saat olmalı ve her blok ayrı bir güne yerleşmeli.</p>'+
      '<div class="dd6-modal-footer"><button class="btn" data-a="modal-kapat">Vazgeç</button><button class="btn" data-a="dd6-oto-kaydet">Otomatiğe dön</button><button class="btn ana" data-a="dd5-blok-kaydet">Bloku kaydet</button></div></div></div>';
  }
  function dd5DersiKaldir(did) {
    var d = dersBul(did); if (!d) { bildir('Ders bulunamadı.', 'hata'); return; }
    var sb = sube(d.subeId); if (!sb) return;
    var sec = d.grup === 'Seçmeli';
    var ek = (durum.ekDersler || []).find(function (x) { return x.sinif === sb.sinif && x.ad === d.ders && (!x.subeId || x.subeId === sb.id); });
    if (ek && !ek.subeId) { ui.dd5Havuz = 'zorunlu'; ui.adim = 'zorunlu'; ciz(); bildir('Bu ek ders bütün sınıf düzeyinde ortak. Ayrı şubeden kaldırmak için ders havuzunda düzenleyin.', 'hata'); return; }
    onayla('Ders şubeden kaldırılsın mı?', sb.ad + ' · ' + d.ders + ' haftalık ders yükünden çıkarılır. Programdaki yerleşimler güncelliğini yitirir. Kayıtlı dağıtımlar silinmez.', 'Dersi kaldır', function () {
      if (sec) {
        var l = secmeliListesi('sube', sb.id), i = l.findIndex(function (x) { return x.ad === d.ders; });
        if (i >= 0) l.splice(i, 1);
      } else if (ek) durum.ekDersler = durum.ekDersler.filter(function (x) { return x.id !== ek.id; });
      else durum.saatDegisiklik[sb.id + '|' + d.ders] = 0;
      delete durum.atamalar[d.id];
      kilitleriTemizle(); degisti(true); ciz(); bildir(d.ders + ' ' + sb.ad + ' şubesinden kaldırıldı.');
    });
  }
  // UX V3 Aşama 6 — dört çizelgede tek, erişilebilir hücre işlem çekmecesi.
  // Mevcut dd5HucreMenu aynı kaynak olarak kullanılır: sağ ve sol tık farklı işlem üretmez.
  function dd6PanelKapat() {
    var panel = document.getElementById('dd6-quickpanel');
    if (panel) panel.remove();
    document.querySelectorAll('#icerik td.dd6-selected').forEach(function (cell) { cell.classList.remove('dd6-selected'); });
  }
  function dd6PanelAc(td) {
    if (!td || !td.getAttribute('data-dd5-slot')) return false;
    var did = td.getAttribute('data-ders') || '';
    // Sosyal kulüp görevleri normal ders havuzunda yer almaz; ders/öğretmen
    // düzenleme menüsünü bunlar için açmak yanıltıcı ve güvensiz olur.
    if (did.indexOf('kulup:') === 0 || td.classList.contains('kulup-hucre')) {
      var kHtml = mBaslik('Sosyal kulüp saati', 'Kulüp yerleşimleri ayrı kulüp yönetiminde düzenlenir.') +
        mOge('Sosyal kulüpler menüsünü aç', 'adim', 'kulupler', { ikon: '▦' });
      // Diğer hücrelerle aynı çekmecede, yalnız güvenli kulüp işlemlerini göster.
      var html = kHtml;
    } else var html = dd5HucreMenu(td);
    if (!html) return false;
    dd6PanelKapat();
    var p = td.getAttribute('data-dd5-slot').split('|');
    var saat = +p.pop(), gun = +p.pop(), tip = p.shift(), id = p.join('|');
    var ad = tip === 'sube' ? (sube(id) || {}).ad : (ogretmen(id) || {}).ad;
    var panel = document.createElement('aside');
    panel.id = 'dd6-quickpanel';
    panel.className = 'dd6-quickpanel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'Çizelge hücresi düzenleme işlemleri');
    panel.innerHTML = '<div class="dd6-panel-head"><div><small>HÜCRE İŞLEMLERİ</small><b>' + esc(ad || 'Program') + '</b><span>' + esc(saatMetni(gun,saat,1)) + '</span></div>' +
      '<button type="button" class="dd6-panel-close" data-a="dd6-close" aria-label="İşlem panelini kapat">×</button></div>' +
      '<div class="dd6-panel-help">Ders, öğretmen, kilit ve açık/kapalı saat işlemlerini buradan yönetin. Uygun olmayan seçenekler gerekçesiyle pasif görünür.</div>' +
      '<div class="dd6-panel-actions" role="menu" aria-label="Bu hücre için işlemler">' + html + '</div>' +
      '<div class="dd6-panel-foot">Sağ tık, sol tık veya klavyede Enter ile açılır. Kapatmak için Esc.</div>';
    document.body.appendChild(panel);
    td.classList.add('dd6-selected');
    var close = panel.querySelector('.dd6-panel-close');
    if (close) close.focus({preventScroll: true});
    return true;
  }
  function sagTik(e) {
    var dd5Hucre = e.target.closest('#icerik td[data-dd5-slot]');
    if (dd5Hucre && !e.target.closest('input,select,textarea')) {
      if (dd6PanelAc(dd5Hucre)) { e.preventDefault(); menuKapat(); return; }
    }
    var hedef = e.target.closest('#icerik td[data-a], #icerik [data-ders]');
    if (!hedef || e.target.closest('input, select, textarea')) { menuKapat(); return; }
    var a = hedef.getAttribute('data-a'), v = hedef.getAttribute('data-v') || '', tablo = hedef.closest('table');
    var tip = tablo && tablo.getAttribute('data-tip'), id = tablo && tablo.getAttribute('data-id'), html = null, p;
    if (a === 'hucre-tik') { p = v.split('|'); p.pop(); var s0 = +p.pop(), g0 = +p.pop(); html = menuDers(p.join('|'), g0, s0, tip); }
    else if (a === 'bos-tik') { p = v.split('|'); var s1 = +p.pop(), g1 = +p.pop(); var btip = p.shift(), bid = p.join('|'); html = durum.sonuc ? menuBosSaat(btip, bid, g1, s1) : menuHazirlikSaat(btip, bid, g1, s1); }
    else if (a === 'hazirlik-kilit-kaldir') { p = v.split('|'); p.pop(); var ks0 = +p.pop(), kg0 = +p.pop(); html = menuKilitli(p.join('|') + '|' + kg0 + '|' + ks0); }
    else if (a === 'kilit-hucre') html = menuKilitIzgara(hedef, tip, id);
    else if (a === 'kilit-kaldir') html = menuKilitli(v);
    else if (hedef.getAttribute('data-ders')) {
      var did = hedef.getAttribute('data-ders'), gs = hedef.getAttribute('data-gs');
      if (gs) { var q = gs.split('|'); html = menuDers(did, +q[0], +q[1], 'carsaf'); }
      else { var d = dersBul(did); if (d) { var o = ogretmen(d.ogretmenId); html = mBaslik(esc((sube(d.subeId) || {}).ad + ' · ' + d.ders), esc((o ? o.ad : 'öğretmen yok') + ' · ' + d.saat + ' saat')) + menuOgretmenOgeleri(d); } }
    }
    if (!html) return;
    e.preventDefault();
    menuAc(e.clientX, e.clientY, html);
  }

  // ---------- Öğretmen değiştirme ----------
  /** Öğretmen değişirse programdaki bloklarda oluşacak sorunlar (program yoksa null) */
  function programCakisma(dersId, ogrId) {
    var r = durum.sonuc;
    if (!r || !r.dersler[dersId]) return null;
    var eski = r.dersler[dersId].ogretmenId, l = [];
    r.dersler[dersId].ogretmenId = ogrId;
    try {
      r.yerlesim.forEach(function (y, i) {
        if (y.dersId !== dersId) return;
        var hata = yerDogrula(dersId, y.uzunluk, y.gun, y.saat, [i]);
        if (hata) l.push(saatMetni(y.gun, y.saat, y.uzunluk) + ': ' + hata);
      });
    } finally { r.dersler[dersId].ogretmenId = eski; }
    return l;
  }
  function ogrDegistirModal() {
    var m = ui.modal, d = dersBul(m.dersId);
    if (!d) { ui.modal = null; return ''; }
    var dersler = dersListesi(), yuk = ogretmenYukleri(dersler), mevcut = d.ogretmenId, hepsi = !!ui.ogrDegHepsi;
    var sira = { brans: 0, ek: 1, disi: 2 };
    var adaylar = durum.ogretmenler.map(function (o) { return { o: o, u: bransUyumu(o, d.ders), c: programCakisma(d.id, o.id) }; })
      .filter(function (x) { return hepsi || x.u !== 'disi' || x.o.id === mevcut; })
      .sort(function (a, b) {
        return (b.o.id === mevcut) - (a.o.id === mevcut) || sira[a.u] - sira[b.u] || ((a.c || []).length - (b.c || []).length) || (yuk[a.o.id] || 0) - (yuk[b.o.id] || 0) || a.o.ad.localeCompare(b.o.ad, 'tr');
      });
    var o0 = ogretmen(mevcut);
    var h = '<div class="modal-arka" data-a="modal-kapat"><div class="modal ogr-degistir" data-durdur="1"><h3>' + (o0 ? 'Öğretmeni değiştir' : 'Öğretmen ata') + '</h3>' +
      '<p class="ince"><b>' + esc((sube(d.subeId) || {}).ad + ' · ' + d.ders) + '</b> — haftada ' + d.saat + ' saat · şu an: ' + (o0 ? esc(o0.ad) : 'atanmamış') + '</p>' +
      '<div class="satir"><input type="search" placeholder="Öğretmen ara…" data-a="ogr-deg-ara" value="' + esc(ui.ogrDegAra || '') + '" style="flex:1">' +
      '<label class="satir-alan"><input type="checkbox" data-a="ogr-deg-hepsi"' + (hepsi ? ' checked' : '') + '> Branş dışındakileri de göster</label></div>' +
      (durum.sonuc ? '<p class="ince" style="margin:8px 0 0">“Programda uygun” olan öğretmene geçerseniz program yerinde güncellenir; çakışma varsa atama yapılır ve yeniden dağıtım gerekir.</p>' : '') +
      '<div class="ogr-deg-liste">';
    if (!adaylar.length) h += '<p class="ince">Bu derse branşı uygun öğretmen yok. “Branş dışındakileri de göster”i işaretleyin.</p>';
    adaylar.forEach(function (x) {
      var o = x.o, y = yuk[o.id] || 0, mx = o.maxSaat || 30, sonra = y + (o.id === mevcut ? 0 : d.saat), su = o.id === mevcut;
      var durumHtml = x.c === null ? '' : (x.c.length ? '<span class="etiket kirmizi" title="' + esc(x.c.join('\n')) + '">' + x.c.length + ' blok çakışıyor</span>' : '<span class="etiket yesil">programda uygun</span>');
      h += '<div class="ogr-deg-satir' + (su ? ' mevcut' : '') + '" data-ara="' + esc((o.ad + ' ' + o.brans).toLocaleLowerCase('tr')) + '">' + avatar(o) +
        '<div class="ods-ad"><b>' + esc(o.ad) + '</b><small>' + esc(o.brans) + ' ' + uyumEtiketi(x.u) + '</small></div>' +
        '<div class="ods-yuk"><div class="ilerleme ince-cubuk' + (sonra > mx ? ' eksik' : '') + '"><i style="width:' + Math.min(100, Math.round(sonra / mx * 100)) + '%"></i></div><small class="' + (sonra > mx ? 'asim-yazi' : '') + '">' + y + (su ? '' : ' → ' + sonra) + ' / ' + mx + ' saat</small></div>' +
        '<div class="ods-durum">' + durumHtml + '</div>' +
        (su ? '<span class="etiket">mevcut</span>' : '<button class="btn kucuk ana" data-a="ogr-degistir" data-v="' + esc(d.id + '|' + o.id) + '">Ata</button>') + '</div>';
    });
    var ortak = ortakOgretmenler(d.id);
    h += '</div><div class="ortak-bolum"><b>Ortak öğretmenler</b> <span class="ince">(aynı saatte derse birlikte girer; hepsinin uygunluğu denetlenir — K01)</span><div class="satir">' +
      ortak.map(function (id) { return '<span class="cip">' + esc(ogretmen(id).ad) + ' <button class="cip-sil" data-a="ortak-sil" data-v="' + esc(d.id + '|' + id) + '">×</button></span>'; }).join('') +
      '<select data-a="ortak-ekle" data-v="' + esc(d.id) + '"><option value="">+ Ortak öğretmen ekle…</option>' + durum.ogretmenler.filter(function (o) { return o.id !== mevcut && ortak.indexOf(o.id) < 0; }).sort(function (a, b) { return a.ad.localeCompare(b.ad, 'tr'); }).map(function (o) { return '<option value="' + o.id + '">' + esc(o.ad) + '</option>'; }).join('') + '</select></div>';
    h += '</div><div class="satir">' + (o0 ? '<button class="btn tehlike" data-a="menu-atama-kaldir" data-v="' + esc(d.id) + '">Atamayı kaldır</button>' : '') +
      '<button class="btn" data-a="menu-sube-atama" data-v="' + d.subeId + '">Şubenin atama listesine git</button><span class="bosluk"></span><button class="btn" data-a="modal-kapat">Kapat</button></div></div></div>';
    return h;
  }
  function ogretmenDegistir(dersId, ogrId) {
    var d = dersBul(dersId), o = ogretmen(ogrId), r = durum.sonuc;
    if (!d || !o) return;
    var cak = programCakisma(dersId, ogrId);
    var kapaliKilit = (durum.kilitler[dersId] || []).some(function (k) { for (var i = 0; i < k.uzunluk; i++) if ((o.kapali || []).indexOf(k.gun + '-' + (k.saat + i)) >= 0) return true; return false; });
    var ek = kapaliKilit ? ' Not: bu dersin bir kilidi ' + o.ad + ' için kapalı saate denk geliyor; kilidi gözden geçirin.' : '';
    var bitir = function (yerinde) {
      durum.atamalar[dersId] = ogrId;
      if (yerinde) { r.dersler[dersId].ogretmenId = ogrId; istatistikYenile(); degisti(); }
      else degisti(true);
      ui.modal = null; ciz();
      bildir(d.ders + ' (' + (sube(d.subeId) || {}).ad + ') → ' + o.ad + (yerinde ? '. Program yerinde güncellendi.' : (r ? '. Program güncel değil; yeniden dağıtın.' : '.')) + ek, kapaliKilit ? 'hata' : '');
    };
    if (cak === null) bitir(false);
    else if (!cak.length) bitir(true);
    else onayla(o.ad + ' programda çakışıyor', cak.slice(0, 3).join(' · ') + (cak.length > 3 ? ' …' : '') + ' — Atama yapılırsa mevcut program güncelliğini yitirir ve yeniden dağıtım gerekir.', 'Yine de ata', function () { bitir(false); });
  }
  /** a bloğunu b bloğunun yerine koyma (yer değiştirme) denetimi; hata ya da null */
  function takasHatasi(i, j) {
    var r = durum.sonuc, a = r.yerlesim[i], b = r.yerlesim[j];
    if (!a || !b) return 'Blok bulunamadı.';
    if (a.uzunluk !== b.uzunluk) return 'Farklı uzunlukta bloklar yer değiştiremez.';
    if (a.dersId === b.dersId) return 'Aynı dersin blokları.';
    if ((durum.kilitler[b.dersId] || []).some(function (k) { return k.gun === b.gun && k.saat === b.saat; })) return (r.dersler[b.dersId] || {}).ders + ' bu saate kilitli; önce kilidini kaldırın.';
    return yerHatasi(a.dersId, a.uzunluk, b.gun, b.saat, [i, j]) || yerHatasi(b.dersId, b.uzunluk, a.gun, a.saat, [i, j]);
  }
  /** i bloğunu j bloğunun yerine taşır ve orada kilitler; j bloğu i'nin eski yerine geçer */
  function takasKilitle(i, j) {
    var hata = takasHatasi(i, j);
    if (hata) return hata;
    var r = durum.sonuc, a = r.yerlesim[i], b = r.yerlesim[j], ag = a.gun, as = a.saat;
    kilitTasi(a.dersId, ag, as, b.gun, b.saat, a.uzunluk, true);
    kilitTasi(b.dersId, b.gun, b.saat, ag, as, b.uzunluk, false);
    a.gun = b.gun; a.saat = b.saat; b.gun = ag; b.saat = as;
    istatistikYenile();
    return null;
  }
  /** Şubede (gun, saat) ile başlayan, verilen uzunluktaki blok */
  function subeBlogu(subeId, gun, saat, uz) {
    var r = durum.sonuc;
    for (var j = 0; j < r.yerlesim.length; j++) { var y = r.yerlesim[j]; if (y.gun === gun && y.saat === saat && y.uzunluk === uz && (r.dersler[y.dersId] || {}).subeId === subeId) return j; }
    return -1;
  }
  function blokCikarOnayla(dersId, gun, saat) {
    var ic = yerlesimIndeksi(dersId, gun, saat);
    if (ic < 0) return;
    var dc = durum.sonuc.dersler[dersId] || {};
    onayla('Ders programdan çıkarılsın mı?', (sube(dc.subeId) || {}).ad + ' · ' + dc.ders + ' bloğu programdan alınıp “yerleşemeyen dersler” listesine konur; oradan istediğiniz saate yeniden yerleştirebilirsiniz.', 'Çıkar', function () {
      programdanCikar(ic); ui.secBlok = null; degisti(); ciz();
    });
  }
  function saateKilitle(dersId, hedef, gun, saat) {
    var hi = +hedef.split(':')[1];
    var sonuc = hedef.indexOf('bek:') === 0 ? bekleyeniYerlestir(hi, gun, saat, true) : blokTasi(hi, gun, saat, true);
    if (typeof sonuc === 'string') { bildir(sonuc, 'hata'); return false; }
    ui.modal = null; ui.secBlok = null; degisti(); ciz();
    bildir((durum.sonuc.dersler[dersId] || {}).ders + ' ' + M.GUNLER[gun] + ' ' + (saat + 1) + '. derse kilitlendi 🔒');
    return true;
  }

  // ---------- Merkezi dağıtım kuralları (CP-SAT ve hızlı motor ortak) ----------
  var KURAL_VARSAYILAN = {
    gunlukAyniDersMax: 2, ucluTekrarYasak: true, blokFarkliGun: true, dilAyriGun: true, binaGecisDk: 0,
    esnetIzin: { gunlukMax: false, blokYapisi: false, ayniGunBlok: false },
    tercihler: { subeBosluk: 'yuksek', maxBosluk: 'yuksek', gunSiniri: 'yuksek', ogretmenBosluk: 'orta', zorDers: 'orta', tercihGun: 'orta',
      binaDegisim: 'orta', azGun: 'dusuk', ogretmenDenge: 'dusuk', sinifDenge: 'dusuk', ilkSon: 'dusuk', nobet: 'dusuk', onceki: 'dusuk',
      saatTercihi: 'orta', zumre: 'yuksek' },
    subeMaxBosluk: 0, zorDersGunluk: 4, nobetMaxGunluk: 0, dersAgirlikProfili: false, zumreBranslar: []
  };
  var KURAL_LISTESI = [
    ['K01', 'Öğretmen çakışması', 'Bir öğretmen aynı saatte tek görevde; ortak öğretmenli derslerde bütün öğretmenler denetlenir.', 'her'],
    ['K02', 'Sınıf çakışması', 'Şubeye aynı anda tek ders; paralel (alt grup) seçmeliler birlikte yerleşir.', 'her'],
    ['K03', 'Haftalık ders saatleri', 'Her ders tam haftalık saati kadar yerleşir; eksik ya da fazla kabul edilmez.', 'her'],
    ['K04', 'Günlük ders sınırı', 'Aynı dersten bir şubeye günde en fazla N saat (varsayılan 2).', 'gunlukAyniDersMax'],
    ['K05', 'Üçlü tekrar yasağı', 'Aynı ders kesintisiz 3 saat okutulmaz.', 'ucluTekrarYasak'],
    ['K06', 'Blok dersler', '1→1, 2→2, 3→2+1, 4→2+2, 5→2+2+1, 6→2+2+2; bloklar ardışık, ayrı bloklar farklı günlerde.', 'her'],
    ['K07', 'Aynı gün tekrar', 'Aynı ders bir gün içinde ayrılmış iki blokta bulunmaz.', 'blokFarkliGun'],
    ['K08', 'İngilizce ve Yabancı Dil', 'Ayrı tanımlı İngilizce ve Yabancı Dil aynı şubede aynı güne konmaz (ders kimliğiyle denetlenir).', 'dilAyriGun'],
    ['K09', 'Öğretmen kapalı saatleri', 'Kapalı gün/saatlere ders konmaz (tercih edilen günler ayrı tutulur).', 'her'],
    ['K10', 'Öğretmen sınırları', 'Günlük en fazla ders, haftalık yük ve kesin gün sınırı.', 'her'],
    ['K11', 'Sınıf kapasitesi', 'Şubenin kapalı saatleri ve günlük ders sayısı aşılmaz.', 'her'],
    ['K12', 'Derslik çakışması', 'Bir derslik aynı anda tek şubede; laboratuvar/spor salonu/atölye gerektiren dersler uygun dersliğe.', 'her'],
    ['K13', 'Bina geçişi', 'Farklı binalar arası art arda derste geçiş süresi teneffüse sığmalı.', 'binaGecisDk'],
    ['K14', 'Kilitli dersler', 'Kilitli dersin öğretmeni, şubesi, günü ve saati korunur; çelişen kilitler çözümden önce raporlanır.', 'her'],
    ['K15', 'Sosyal kulüpler', 'Kulüp saatinde öğretmen, şube ve mekân çakışması denetlenir.', 'her'],
    ['K16', 'Etiket kuralları', 'Etiketli dersler için günlük süre ve ardışıklık sınırları.', 'her']
  ];
  var TERCIH_LISTESI = [
    ['subeBosluk', 'Şube programında boş saat olmasın'], ['maxBosluk', 'İzin verilen en fazla boşluk aşılmasın (öğretmen / şube)'],
    ['gunSiniri', 'Öğretmenin “haftada en fazla gün” isteği'], ['ogretmenBosluk', 'Öğretmenlerin gün içi boş saatleri az olsun'],
    ['zorDers', 'Zorlayıcı (“zor” etiketli) dersler aynı güne yığılmasın'], ['tercihGun', 'Öğretmenin tercih ettiği günler'],
    ['binaDegisim', 'Gereksiz bina değişimi olmasın'], ['azGun', 'Öğretmen haftayı daha az günde tamamlasın'],
    ['ogretmenDenge', 'Öğretmenin günlük yükü dengeli olsun'], ['sinifDenge', 'Şubenin günlük ders yükü dengeli olsun'],
    ['ilkSon', 'Öğretmenin ilk / son ders tercihleri'], ['nobet', 'Nöbet gününde öğretmenin dersi olsun ve yığılmasın'],
    ['onceki', 'Önceki kayıtlı dağıtım mümkün olduğunca korunsun'],
    ['saatTercihi', 'Ağır dersler sabah ilk saatlere, uygulamalı dersler öğleden sonraya'],
    ['zumre', 'Seçili branşlarda zümre ortak boş saati bırakılsın']
  ];
  var ONCELIK_AD = { yuksek: 'Yüksek', orta: 'Orta', dusuk: 'Düşük', kapali: 'Kapalı' };
  var DERSLIK_TURLERI = [['normal', 'Normal sınıf'], ['laboratuvar', 'Laboratuvar'], ['spor', 'Spor salonu'], ['bilisim', 'Bilişim sınıfı'], ['atolye', 'Atölye'], ['muzik', 'Müzik sınıfı'], ['gorsel', 'Görsel sanatlar atölyesi'], ['kutuphane', 'Kütüphane'], ['konferans', 'Konferans salonu']];
  var ZOR_DERSLER = /^(Matematik|Fen Bilimleri|Fizik|Kimya|Biyoloji|Türk Dili ve Edebiyatı|Türkçe|Geometri)/;
  function kurallar() {
    var k = durum.kurallar = durum.kurallar || {};
    Object.keys(KURAL_VARSAYILAN).forEach(function (a) { if (k[a] == null) k[a] = JSON.parse(JSON.stringify(KURAL_VARSAYILAN[a])); });
    ['esnetIzin', 'tercihler'].forEach(function (a) { Object.keys(KURAL_VARSAYILAN[a]).forEach(function (b) { if (k[a][b] == null) k[a][b] = KURAL_VARSAYILAN[a][b]; }); });
    return k;
  }
  /** Ders adına göre ayarlar (derslik türü, etiketler, dil, bölünebilirlik) — bütün şubelerde geçerli */
  function dersAyari(ad) { durum.dersAyar = durum.dersAyar || {}; return durum.dersAyar[ad] || {}; }
  function otoDil(ad) {
    if (/^İngilizce/.test(ad)) return 'ingilizce';
    if (/Yabancı Dil/.test(ad)) return 'yabanci';
    return null;
  }
  function dersDili(d) {
    var a = dersAyari(d.ders);
    if (Object.prototype.hasOwnProperty.call(a, 'dil')) return a.dil || null;
    return otoDil(d.temelDers || d.ders);
  }
  function dersEtiketleri(d) {
    var a = dersAyari(d.ders);
    if (Array.isArray(a.etiketler)) return a.etiketler;
    return ZOR_DERSLER.test(d.ders) ? ['zor'] : [];
  }
  function dersBolunebilir(d) {
    var a = dersAyari(d.ders);
    if (a.bolunebilir != null) return !!a.bolunebilir;
    return d.grup === 'Seçmeli' && d.saat === 2;
  }
  function ortakOgretmenler(dersId) { durum.ortakOgretmen = durum.ortakOgretmen || {}; return (durum.ortakOgretmen[dersId] || []).filter(function (id) { return ogretmen(id); }); }
  function dersOgretmenleri(d) {
    var l = d.ogretmenId ? [d.ogretmenId] : [];
    ortakOgretmenler(d.id).forEach(function (x) { if (l.indexOf(x) < 0) l.push(x); });
    return l;
  }
  function nobetGunleri() {
    var dn = (durum.nobet.donemler || [])[0], out = {};
    if (dn) dn = { atama: Object.keys(dn.atama || {}).reduce(function (a, id) { if (nobetTutar(ogretmen(id))) a[id] = dn.atama[id]; return a; }, {}) };
    if (dn) Object.keys(dn.atama || {}).forEach(function (id) { if (dn.atama[id] != null) out[id] = dn.atama[id]; });
    return out;
  }
  /** Motor girdisi (sürüm 2): CP-SAT (Python) ve hızlı motor aynı veriyi kullanır */
  function motorGirdisi(ekMod) {
    var dersler = dersListesi(), k = kurallar(), nobet = nobetGunleri();
    var minDeg = ekMod === 'minimum_degisiklik';
    var oncekiKoru = durum.sonuc && durum.sonuc.yerlesim && durum.sonuc.yerlesim.length && (minDeg || (!durum.sonuc.eski && k.tercihler.onceki !== 'kapali'));
    var zumreGruplari = (k.zumreBranslar || []).map(function (b) {
      var og = durum.ogretmenler.filter(function (o) { return o.brans === b; }).map(function (o) { return o.id; });
      return { ad: b + ' Zümresi', ogretmenler: og, saat: 1, kesin: false };
    }).filter(function (z) { return z.ogretmenler.length >= 2; });
    return {
      surum: 2, gunSayisi: +durum.okul.gunSayisi, gunlukSaat: +durum.okul.gunlukSaat, blok: durum.ayarlar.blok,
      denemeSayisi: +durum.ayarlar.deneme || 10, tohum: Math.floor(Math.random() * 1e9),
      zaman: { teneffusDk: +durum.okul.teneffus || 10, dersDk: +durum.okul.dersSure || 40, ogleSonra: +durum.okul.ogleSonrasi || 0, ogleDk: +durum.okul.ogleSure || 0 },
      kurallar: JSON.parse(JSON.stringify(k)),
      subeler: durum.subeler.map(function (s) { return { id: s.id, ad: s.ad, kapali: durum.subeKapali[s.id] || [], derslikId: s.derslikId || null }; }),
      ogretmenler: durum.ogretmenler.map(function (o) {
        return { id: o.id, ad: o.ad, kapali: o.kapali || [], maxGunluk: o.maxGunluk || null, maxGun: o.maxGun || null, maxGunKesin: !!o.maxGunKesin,
          maxHaftalik: o.maxSaat || null, maxBosluk: o.maxBosluk != null && o.maxBosluk !== '' ? +o.maxBosluk : null, tercihGunler: o.tercihGunler || [],
          ilkSaatIstemez: !!o.ilkSaatIstemez, sonSaatIstemez: !!o.sonSaatIstemez, nobetGunu: nobet[o.id] != null ? nobet[o.id] : null, etiketler: o.etiketler || [] };
      }),
      binalar: (durum.binalar || []).map(function (b) { return { id: b.id, ad: b.ad }; }),
      binaGecis: (durum.binaGecis || []).filter(function (x) { return x.a && x.b && x.a !== x.b; }),
      derslikler: (durum.derslikler || []).map(function (r) { return { id: r.id, ad: r.ad, binaId: r.binaId || null, tur: r.tur || 'normal' }; }),
      dersler: dersler.map(function (d) {
        var a = dersAyari(d.ders);
        return { id: d.id, ad: d.ders, subeId: d.subeId, ogretmenId: d.ogretmenId, ogretmenler: dersOgretmenleri(d), saat: d.saat,
          yerlesimSecenekleri: d.yerlesimSecenekleri, kilitli: durum.kilitler[d.id] || [], dil: dersDili(d), etiketler: dersEtiketleri(d),
          bolunebilir: dersBolunebilir(d), derslikTuru: a.derslikTuru && a.derslikTuru !== 'normal' ? a.derslikTuru : null,
          grup: (durum.paralelGrup || {})[d.id] || null };
      }),
      kulupler: (durum.kulupler || []).filter(function (x) { return x.subeIds && x.subeIds.length; }).map(function (x) {
        return { id: x.id, ad: x.ad, ogretmenler: x.ogretmenId ? [x.ogretmenId] : [], subeIds: x.subeIds, saat: +x.saat || 1,
          sabit: x.sabit && x.sabit.gun != null && x.sabit.gun !== '' ? { gun: +x.sabit.gun, saat: +x.sabit.saat } : null, derslikId: x.derslikId || null };
      }),
      etiketKurallari: (durum.etiketKurallari || []).filter(function (e) { return e.ad; }),
      zumreGruplari: zumreGruplari,
      onceki: oncekiKoru ? durum.sonuc.yerlesim.map(function (y) { return { dersId: y.dersId, gun: y.gun, saat: y.saat, uzunluk: y.uzunluk }; }) : [],
      cozucu: { sureSn: +durum.ayarlar.cpsatSure || 60, isci: +durum.ayarlar.isci || 0, mod: minDeg ? 'minimum_degisiklik' : '' }
    };
  }
  /** Hızlı motor için korumacı destek kontrolü; otomatik geçiş buna bağlıdır. */
  function hizliMotorEksikleri(g) { return window.DersMotorSecim.hizliEksikleri(g); }
  function slotAyir(x) { var p = String(x).split('-'); return [+p[0], +p[1]]; }

  /** Bağımsız kural denetimi (CP-SAT doğrulayıcısının tarayıcı karşılığı). r: sonuç. */
  function kuralDenetle(r) {
    var g = motorGirdisi(), k = g.kurallar, D = g.gunSayisi, H = g.gunlukSaat, ihl = [];
    if (!r) return ihl;
    var ders = {}, sube0 = {}, ogr0 = {}, oda0 = {};
    g.dersler.forEach(function (d) { ders[d.id] = d; });
    g.subeler.forEach(function (s) { sube0[s.id] = s; });
    g.ogretmenler.forEach(function (o) { ogr0[o.id] = o; });
    g.derslikler.forEach(function (o) { oda0[o.id] = o; });
    var L = +k.gunlukAyniDersMax || 2;
    var cpAsama = (r.cozucu || {}).asama || '';
    var izinEsnet = cpAsama === 'İzinli sınır esnetme' ? (k.esnetIzin || {}) : {};
    var alternatif = cpAsama === 'Alternatif blok' || cpAsama === 'Tercih esnetme' || cpAsama === 'İzinli sınır esnetme';
    var dolu = {}, gunSaat = {}, gunBlok = {}, kapsam = {}, sadi = function (id) { return (sube0[id] || {}).ad || id; };
    function kullan(an, ad, kural) {
      if (dolu[an] && dolu[an] !== ad) {
        var p = an.split('|');
        ihl.push({ kural: kural, mesaj: M.GUNLER[+p[2]] + ' ' + (+p[3] + 1) + '. ders: “' + dolu[an] + '” ve “' + ad + '” aynı ' + (kural === 'K01' ? 'öğretmende' : kural === 'K02' ? 'şubede' : 'derslikte') + '.' });
      }
      dolu[an] = ad;
    }
    var grupGoruldu = {};
    r.yerlesim.forEach(function (y) {
      var d = ders[y.dersId];
      if (!d) return;
      var ad = sadi(d.subeId) + ' · ' + d.ad;
      var grupAn = d.grup ? d.subeId + '|' + d.grup + '|' + y.gun + '|' + y.saat : null;
      var subeAd = d.grup ? sadi(d.subeId) + ' · grup ' + d.grup : ad;
      gunSaat[d.id + '|' + y.gun] = (gunSaat[d.id + '|' + y.gun] || 0) + y.uzunluk;
      gunBlok[d.id + '|' + y.gun] = (gunBlok[d.id + '|' + y.gun] || 0) + 1;
      for (var i = 0; i < y.uzunluk; i++) {
        var h = y.saat + i, sl = y.gun + '-' + h;
        kapsam[d.id + '|' + y.gun + '|' + h] = 1;
        if (!grupAn || !grupGoruldu[grupAn + i]) kullan('S|' + d.subeId + '|' + y.gun + '|' + h, subeAd, 'K02');
        if (sube0[d.subeId].kapali.indexOf(sl) >= 0) ihl.push({ kural: 'K11', mesaj: ad + ': ' + M.GUNLER[y.gun] + ' ' + (h + 1) + '. ders şubenin kapalı saati.' });
        d.ogretmenler.forEach(function (t) {
          kullan('T|' + t + '|' + y.gun + '|' + h, ad, 'K01');
          if (ogr0[t] && ogr0[t].kapali.indexOf(sl) >= 0) ihl.push({ kural: 'K09', mesaj: ad + ': ' + ogr0[t].ad + ' ' + M.GUNLER[y.gun] + ' ' + (h + 1) + '. derste kapalı.' });
        });
        if (y.derslikId) kullan('R|' + y.derslikId + '|' + y.gun + '|' + h, ad, 'K12');
      }
      if (grupAn) for (var j = 0; j < y.uzunluk; j++) grupGoruldu[grupAn + j] = 1;
      if (d.derslikTuru && !y.derslikId) ihl.push({ kural: 'K12', mesaj: ad + ': zorunlu derslik ataması eksik.' });
      if (y.derslikId && !oda0[y.derslikId]) ihl.push({ kural: 'K12', mesaj: ad + ': tanımsız derslik.' });
      if (y.derslikId && d.derslikTuru && (oda0[y.derslikId] || {}).tur !== d.derslikTuru) ihl.push({ kural: 'K12', mesaj: ad + ': ' + d.derslikTuru + ' dersliği gerekiyor.' });
      var sbOda = sube0[d.subeId] && sube0[d.subeId].derslikId;
      if (!d.derslikTuru && sbOda && y.derslikId !== sbOda && !d.grup) ihl.push({ kural: 'K12', mesaj: ad + ': sabit şube dersliği korunmadı.' });
    });
    (r.kulupYerlesim || []).forEach(function (ky) {
      var kk = g.kulupler.filter(function (x) { return x.id === ky.kulupId; })[0]; if (!kk) return;
      for (var i = 0; i < ky.uzunluk; i++) {
        kk.subeIds.forEach(function (s) { kullan('S|' + s + '|' + ky.gun + '|' + (ky.saat + i), kk.ad + ' kulübü', 'K02'); });
        kk.ogretmenler.forEach(function (t) { kullan('T|' + t + '|' + ky.gun + '|' + (ky.saat + i), kk.ad + ' kulübü', 'K01'); });
        if (ky.derslikId) kullan('R|' + ky.derslikId + '|' + ky.gun + '|' + (ky.saat + i), kk.ad + ' kulübü', 'K12');
      }
    });
    g.kulupler.forEach(function (kk) {
      var y = (r.kulupYerlesim || []).filter(function (a) { return a.kulupId === kk.id; });
      if (y.length !== 1 || (y[0] && +y[0].uzunluk !== +kk.saat)) ihl.push({ kural: 'K15', mesaj: kk.ad + ': kulüp saati eksik veya mükerrer.' });
      if (kk.sabit && (!y[0] || +y[0].gun !== +kk.sabit.gun || +y[0].saat !== +kk.sabit.saat)) ihl.push({ kural: 'K15', mesaj: kk.ad + ': sabit kulüp saati korunmadı.' });
      if (kk.derslikId && y[0] && y[0].derslikId !== kk.derslikId) ihl.push({ kural: 'K15', mesaj: kk.ad + ': kulüp dersliği korunmadı.' });
    });
    // ders bazında kurallar
    var dilGun = {};
    g.dersler.forEach(function (d) {
      var ad = sadi(d.subeId) + ' · ' + d.ad, toplam = 0, sinir = L + (izinEsnet.gunlukMax ? 1 : 0);
      for (var gun = 0; gun < D; gun++) {
        var x = gunSaat[d.id + '|' + gun] || 0; toplam += x;
        if (x > sinir) ihl.push({ kural: 'K04', mesaj: ad + ': ' + M.GUNLER[gun] + ' ' + x + ' saat (en fazla ' + sinir + ').' });
        if ((gunBlok[d.id + '|' + gun] || 0) > 1 && k.blokFarkliGun && !izinEsnet.ayniGunBlok) ihl.push({ kural: 'K07', mesaj: ad + ': ' + M.GUNLER[gun] + ' günü ayrı iki blok.' });
        if (k.ucluTekrarYasak) for (var h = 0; h + 2 < H; h++) if (kapsam[d.id + '|' + gun + '|' + h] && kapsam[d.id + '|' + gun + '|' + (h + 1)] && kapsam[d.id + '|' + gun + '|' + (h + 2)]) ihl.push({ kural: 'K05', mesaj: ad + ': ' + M.GUNLER[gun] + ' ' + (h + 1) + '.–' + (h + 3) + '. derslerde kesintisiz 3 saat.' });
        if (x && d.dil && k.dilAyriGun) { var an = d.subeId + '|' + gun; (dilGun[an] = dilGun[an] || {})[d.dil] = 1; }
      }
      var n = +d.saat, birincil = [], kaliplar = [];
      if (Array.isArray(d.yerlesimSecenekleri)) kaliplar = d.yerlesimSecenekleri.filter(function (a) { return Array.isArray(a) && a.reduce(function (x, z) { return x + (+z || 0); }, 0) === n && a.every(function (x) { return +x > 0; }); });
      if (!kaliplar.length) {
        if (g.blok === 'tekli') birincil = Array(n).fill(1);
        else { for (var bi = 0; bi < Math.floor(n / 2); bi++) birincil.push(2); if (n % 2) birincil.push(1); }
        kaliplar = [birincil];
      }
      if (d.bolunebilir && n === 2 && !kaliplar.some(function (a) { return a.join(',') === '1,1'; })) kaliplar.push([1, 1]);
      var izinli = alternatif ? kaliplar.slice() : kaliplar.slice(0, 1);
      if (izinEsnet.blokYapisi) izinli = izinli.concat([Array(Math.floor(n / 2)).fill(2).concat(n % 2 ? [1] : []), Array(n).fill(1)]);
      if (k.ucluTekrarYasak) izinli = izinli.filter(function (a) { return a.every(function (u) { return +u <= 2; }); });
      var kullanilan = r.yerlesim.filter(function (y) { return y.dersId === d.id; }).map(function (y) { return +y.uzunluk; }).sort(function (a, b) { return b - a; }).join(',');
      if (!izinli.some(function (a) { return a.slice().sort(function (x, y) { return y - x; }).join(',') === kullanilan; })) ihl.push({ kural: 'K06', mesaj: ad + ': blok yapısı izin verilen kalıplarla uyuşmuyor.' });
      var yerlesmeyen = (r.yerlesmeyen || []).filter(function (y) { return y.dersId === d.id; }).reduce(function (a, y) { return a + y.uzunluk; }, 0);
      if (toplam !== d.saat) ihl.push({ kural: 'K03', mesaj: ad + ': ' + d.saat + ' saat olmalı, ' + toplam + ' saat yerleşti' + (yerlesmeyen ? ' (' + yerlesmeyen + ' saat yerleşmedi)' : '') + '.' });
      (d.kilitli || []).forEach(function (kl) {
        for (var i = 0; i < (+kl.uzunluk || 1); i++) if (!kapsam[d.id + '|' + kl.gun + '|' + (+kl.saat + i)]) ihl.push({ kural: 'K14', mesaj: ad + ': ' + M.GUNLER[kl.gun] + ' ' + (+kl.saat + i + 1) + '. ders kilidi korunmadı.' });
      });
    });
    Object.keys(dilGun).forEach(function (an) { if (Object.keys(dilGun[an]).length > 1) { var p = an.split('|'); ihl.push({ kural: 'K08', mesaj: sadi(p[0]) + ': ' + M.GUNLER[+p[1]] + ' İngilizce ve Yabancı Dil aynı gün.' }); } });
    // K10 günlük sınır ve kesin gün sınırı
    var og = {}, ogGun = {};
    Object.keys(dolu).forEach(function (an) { var p = an.split('|'); if (p[0] !== 'T') return; og[p[1] + '|' + p[2]] = (og[p[1] + '|' + p[2]] || 0) + 1; (ogGun[p[1]] = ogGun[p[1]] || {})[p[2]] = 1; });
    Object.keys(og).forEach(function (an) { var p = an.split('|'), o = ogr0[p[0]]; if (o && o.maxGunluk && og[an] > o.maxGunluk) ihl.push({ kural: 'K10', mesaj: o.ad + ': ' + M.GUNLER[+p[1]] + ' ' + og[an] + ' saat (en fazla ' + o.maxGunluk + ').' }); });
    Object.keys(ogGun).forEach(function (t) { var o = ogr0[t], n = Object.keys(ogGun[t]).length; if (o && o.maxGun && o.maxGunKesin && n > o.maxGun) ihl.push({ kural: 'K10', mesaj: o.ad + ': ' + n + ' gün (kesin sınır ' + o.maxGun + ').' }); });
    g.ogretmenler.forEach(function (o) {
      var toplam = Object.keys(og).filter(function (a) { return a.indexOf(o.id + '|') === 0; }).reduce(function (x, a) { return x + og[a]; }, 0);
      if (o.maxHaftalik && toplam > +o.maxHaftalik) ihl.push({ kural: 'K10', mesaj: o.ad + ': haftalık üst sınır aşıldı.' });
    });
    // K13 bina geçişi
    if (g.binalar.length > 1) {
      var gecis = {}, yasakGun = {};
      g.binalar.forEach(function (a) { g.binalar.forEach(function (b) { if (a.id !== b.id && +k.binaGecisDk) gecis[a.id + '|' + b.id] = +k.binaGecisDk; }); });
      g.binaGecis.forEach(function (x) {
        gecis[x.a + '|' + x.b] = gecis[x.b + '|' + x.a] = +x.dk || 0;
        yasakGun[x.a + '|' + x.b] = yasakGun[x.b + '|' + x.a] = !!x.ayniGunYasak;
      });
      var ob = {}, obGruplu = {};
      r.yerlesim.forEach(function (y) {
        var d = ders[y.dersId]; if (!d) return;
        var oda = y.derslikId || (!d.grup && sube0[d.subeId].derslikId), bina = oda && oda0[oda] && oda0[oda].binaId;
        if (!bina) return;
        d.ogretmenler.forEach(function (t) { for (var i = 0; i < y.uzunluk; i++) ob[t + '|' + y.gun + '|' + (y.saat + i)] = bina; });
      });
      Object.keys(ob).forEach(function (an) {
        var p = an.split('|'), gr = p[0] + '|' + p[1];
        (obGruplu[gr] = obGruplu[gr] || []).push({ h: +p[2], bina: ob[an] });
      });
      Object.keys(obGruplu).forEach(function (key) {
        var a = obGruplu[key].sort(function (x, y) { return x.h - y.h; });
        var pp = key.split('|'), gorulen = {};
        a.forEach(function (x) { gorulen[x.bina] = 1; });
        for (var i = 1; i < a.length; i++) {
          var p = a[i - 1], q = a[i]; if (p.bina === q.bina) continue;
          var dk = 0;
          for (var h = p.h; h < q.h; h++) dk += (+g.zaman.ogleSonra && h + 1 === +g.zaman.ogleSonra) ? +g.zaman.ogleDk : +g.zaman.teneffusDk;
          dk += Math.max(0, q.h - p.h - 1) * (+g.zaman.dersDk || 40);
          if (yasakGun[p.bina + '|' + q.bina] || (gecis[p.bina + '|' + q.bina] || 0) > dk)
            ihl.push({ kural: 'K13', mesaj: (ogr0[pp[0]] || {}).ad + ': ' + M.GUNLER[+pp[1]] + ' ' + (p.h + 1) + '.→' + (q.h + 1) + '. ders bina geçişi uygun değil.' });
        }
        Object.keys(gorulen).forEach(function (a) { Object.keys(gorulen).forEach(function (b) {
          if (a < b && yasakGun[a + '|' + b]) ihl.push({ kural: 'K13', mesaj: (ogr0[pp[0]] || {}).ad + ': aynı gün geçişi yasak iki bina.' });
        }); });
      });
    }
    // K16 ders etiketleri
    g.etiketKurallari.filter(function (e) { return (e.hedef || 'ders') === 'ders'; }).forEach(function (e) {
      var sg = {}, sk = {};
      r.yerlesim.forEach(function (y) {
        var d = ders[y.dersId]; if (!d || d.etiketler.indexOf(e.ad) < 0) return;
        var an = d.subeId + '|' + y.gun;
        sg[an] = (sg[an] || 0) + y.uzunluk;
        for (var i = 0; i < y.uzunluk; i++) (sk[an] = sk[an] || {})[y.saat + i] = d.id;
      });
      Object.keys(sg).forEach(function (an) {
        var p = an.split('|');
        if (e.maxGunluk && sg[an] > +e.maxGunluk) ihl.push({ kural: 'K16', mesaj: sadi(p[0]) + ': ' + M.GUNLER[+p[1]] + ' “' + e.ad + '” etiketli ' + sg[an] + ' saat (en fazla ' + e.maxGunluk + ').' });
        if (e.ardisikYasak) Object.keys(sk[an]).forEach(function (h) { var n = sk[an][+h + 1]; if (n && n !== sk[an][h]) ihl.push({ kural: 'K16', mesaj: sadi(p[0]) + ': ' + M.GUNLER[+p[1]] + ' “' + e.ad + '” etiketli iki ders art arda.' }); });
      });
    });
    var gor = {};
    return ihl.filter(function (x) { if (gor[x.mesaj]) return false; gor[x.mesaj] = 1; return true; });
  }

  /** Dağıtım kalite analizi (yumuşak kuralların gerçekleşen değerleri) */
  function kaliteAnalizi(r) {
    var g = motorGirdisi(), D = g.gunSayisi, H = g.gunlukSaat, ders = {}, kalite = { ogretmen: [], sube: [] };
    g.dersler.forEach(function (d) { ders[d.id] = d; });
    var ogrSaat = {}, subeSaat = {}, zor = {};
    r.yerlesim.forEach(function (y) {
      var d = ders[y.dersId]; if (!d) return;
      for (var i = 0; i < y.uzunluk; i++) {
        (subeSaat[d.subeId] = subeSaat[d.subeId] || {})[y.gun + '-' + (y.saat + i)] = 1;
        d.ogretmenler.forEach(function (t) { (ogrSaat[t] = ogrSaat[t] || {})[y.gun + '-' + (y.saat + i)] = 1; });
      }
      if (d.etiketler.indexOf('zor') >= 0) zor[d.subeId + '|' + y.gun] = (zor[d.subeId + '|' + y.gun] || 0) + y.uzunluk;
    });
    g.ogretmenler.forEach(function (o) {
      var s = ogrSaat[o.id]; if (!s) return;
      var bos = 0, gun = 0, tepe = 0, gunluk = [], ilkSon = 0, tercihDisi = 0;
      for (var d = 0; d < D; d++) {
        var l = []; for (var h = 0; h < H; h++) if (s[d + '-' + h]) l.push(h);
        if (!l.length) continue;
        gun++; tepe = Math.max(tepe, l.length); gunluk.push(l.length);
        bos += l[l.length - 1] - l[0] + 1 - l.length;
        if ((o.ilkSaatIstemez && l[0] === 0) || (o.sonSaatIstemez && l[l.length - 1] === H - 1)) ilkSon++;
        if (o.tercihGunler.length && o.tercihGunler.indexOf(d) < 0) tercihDisi++;
      }
      kalite.ogretmen.push({ id: o.id, ad: o.ad, bosluk: bos, gun: gun, maxGun: o.maxGun, tepe: tepe, ilkSon: ilkSon, tercihDisi: tercihDisi,
        nobetUyum: o.nobetGunu == null ? null : !!gunluk.length && Object.keys(s).some(function (x) { return +x.split('-')[0] === o.nobetGunu; }) });
    });
    g.subeler.forEach(function (sb) {
      var s = subeSaat[sb.id] || {}, bos = 0, yuk = [], zorMax = 0;
      for (var d = 0; d < D; d++) {
        var son = -1, n = 0;
        for (var h = 0; h < H; h++) if (s[d + '-' + h]) { son = h; n++; }
        for (h = 0; h <= son; h++) if (!s[d + '-' + h] && sb.kapali.indexOf(d + '-' + h) < 0) bos++;
        yuk.push(n);
        zorMax = Math.max(zorMax, zor[sb.id + '|' + d] || 0);
      }
      kalite.sube.push({ id: sb.id, ad: sb.ad, bosluk: bos, enAz: Math.min.apply(null, yuk), enCok: Math.max.apply(null, yuk), zorMax: zorMax });
    });
    var o = kalite.ogretmen, s = kalite.sube, zs = +g.kurallar.zorDersGunluk || 4;
    kalite.ozet = {
      ogretmenBosluk: o.reduce(function (a, x) { return a + x.bosluk; }, 0), subeBosluk: s.reduce(function (a, x) { return a + x.bosluk; }, 0),
      gunAsimi: o.filter(function (x) { return x.maxGun && x.gun > x.maxGun; }).length,
      ortGun: o.length ? (o.reduce(function (a, x) { return a + x.gun; }, 0) / o.length).toFixed(1) : 0,
      zorYigilma: s.filter(function (x) { return x.zorMax > zs; }).length,
      dengesizSube: s.filter(function (x) { return x.enCok - x.enAz > 2; }).length,
      ilkSon: o.reduce(function (a, x) { return a + x.ilkSon; }, 0), tercihDisi: o.reduce(function (a, x) { return a + x.tercihDisi; }, 0),
      nobetUyumsuz: o.filter(function (x) { return x.nobetUyum === false; }).length
    };
    var puan = 100 - Math.min(40, kalite.ozet.subeBosluk * 4) - Math.min(25, kalite.ozet.ogretmenBosluk * 0.5) - Math.min(15, kalite.ozet.gunAsimi * 3) -
      Math.min(10, kalite.ozet.zorYigilma * 2) - Math.min(10, kalite.ozet.dengesizSube);
    kalite.puan = Math.max(0, Math.round(puan));
    return kalite;
  }

  // ---------- Dağıtımı çalıştır (CP-SAT arka plan işi ya da hızlı motor) ----------
  function cpsatDurumuGetir() {
    if (CFG.mod !== 'sunucu' || ui.cpsat) return;
    ui.cpsat = { hazir: false, sorgu: true };
    api('motorlar').then(function (j) { ui.cpsat = j.cpsat || { hazir: false }; if (ui.adim === 'dagitim' || ui.adim === 'kurallar') ciz(); })
      .catch(function () { ui.cpsat = { hazir: false, neden: 'Sunucuya ulaşılamadı' }; });
  }
  function secilenMotor() { return (durum.ayarlar.motor || 'otomatik'); }
  function dagitimiCalistir(motorZorla, ekMod) {
    var girdi = motorGirdisi(ekMod), dersler = dersListesi(), veriSurumu = ui.veriSurum || 0;
    var harita = {};
    dersler.forEach(function (d) {
      harita[d.id] = { subeId: d.subeId, ders: d.ders, grup: d.grup, ogretmenId: d.ogretmenId, ogretmenler: dersOgretmenleri(d), saat: d.saat,
        yerlesimMetni: d.yerlesimMetni, paralel: (durum.paralelGrup || {})[d.id] || null };
    });
    var kulupler = {};
    girdi.kulupler.forEach(function (k) { kulupler[k.id] = { ad: k.ad, subeIds: k.subeIds, ogretmenler: k.ogretmenler }; });
    var secim = motorZorla || secilenMotor();
    var otomatik = secim === 'otomatik';
    var hazir = CFG.mod === 'sunucu' && ui.cpsat && ui.cpsat.hazir;
    var eksikler = hizliMotorEksikleri(girdi); // Genetik ve Hızlı aynı güvenli çözümleyiciyi kullanır.
    var sira = window.DersMotorSecim.motorSirasi(secim, hazir);
    var gecmis = [], bulunanlar = [], ilkCpsat = null;
    var gorev = { motor: sira[0], oran: 0, mesaj: 'Başlatılıyor', bas: Date.now(), basMotor: Date.now(), worker: null };
    ui.calisiyor = true; ui.is = gorev; ciz();
    function aktif() { return ui.is === gorev && ui.calisiyor; }
    function kayitEkle(motorAdi, durumAdi, aciklama, ms) {
      gecmis.push({ motor: motorAdi, durum: durumAdi || 'UNKNOWN', aciklama: aciklama || '', sureMs: ms || 0 });
    }
    function adi(m) { return m === 'cpsat' ? 'CP-SAT' : m === 'genetik' ? 'Genetik' : 'Hızlı'; }
    function temizleWorker() { if (gorev.worker) { gorev.worker.terminate(); gorev.worker = null; } }
    function kulupHazirla() {
      // Her iki tarayıcı motoru için kilitli kulüp saatleri eşdeğer biçimde kapatılır.
      var hg = JSON.parse(JSON.stringify(girdi)), sk = {}, ok = {}, kulupYer = [];
      hg.subeler.forEach(function (s) { sk[s.id] = s; }); hg.ogretmenler.forEach(function (o) { ok[o.id] = o; });
      hg.kulupler.forEach(function (k) {
        if (!k.sabit) return;
        for (var i = 0; i < k.saat; i++) {
          var sl = k.sabit.gun + '-' + (k.sabit.saat + i);
          k.subeIds.forEach(function (s) { if (sk[s] && sk[s].kapali.indexOf(sl) < 0) sk[s].kapali.push(sl); });
          k.ogretmenler.forEach(function (t) { if (ok[t] && ok[t].kapali.indexOf(sl) < 0) ok[t].kapali.push(sl); });
        }
        kulupYer.push({ kulupId: k.id, gun: k.sabit.gun, saat: k.sabit.saat, uzunluk: k.saat, derslikId: k.derslikId });
      });
      return { girdi: hg, kulupYerlesim: kulupYer };
    }
    function duzenle(r, m) {
      r.dersler = harita; r.kulupBilgi = kulupler; r.tarih = new Date().toISOString();
      if ((ui.veriSurum || 0) !== veriSurumu) r.eski = true;
      r.cozucu = r.cozucu || {};
      r.cozucu.motor = adi(m);
      r.cozucu.kuralIhlalleri = kuralDenetle(r);
      if (m !== 'cpsat') {
        r.cozucu.desteklenmeyen = eksikler;
        r.cozucu.durum = eksikler.length ? 'DESTEKLENMIYOR' : r.cozucu.kuralIhlalleri.length && !r.istatistik.eksikSaat ? 'DOGRULAMA_HATASI' : r.istatistik.eksikSaat ? 'UNKNOWN' : 'FEASIBLE';
        r.cozucu.basarili = !r.istatistik.eksikSaat && !r.cozucu.kuralIhlalleri.length && !eksikler.length;
      } else if (r.cozucu.basarili && r.cozucu.kuralIhlalleri.length) {
        r.cozucu.basarili = false; r.cozucu.durum = 'DOGRULAMA_HATASI';
      }
      if (r.eski) r.cozucu.basarili = false;
      return r;
    }
    function sonlandir(r, mesaj) {
      if (!aktif()) return;
      temizleWorker();
      if (!r) {
        var y = girdi.dersler.map(function (d) { return { dersId: d.id, uzunluk: d.saat, neden: mesaj || 'Hiçbir motor çözüm üretemedi.' }; });
        r = { yerlesim: [], kulupYerlesim: [], yerlesmeyen: y, dersler: harita, kulupBilgi: kulupler,
          istatistik: { eksikSaat: y.reduce(function (t, d) { return t + (+d.uzunluk || 0); }, 0), sureMs: Date.now() - gorev.bas },
          cozucu: { basarili: false, motor: 'Çoklu motor', durum: 'UNKNOWN', kanit: mesaj || 'Bütün motorlar sonuçsuz kaldı.', kuralIhlalleri: [] } };
      }
      if (ilkCpsat && r !== ilkCpsat && !r.cozucu.basarili) {
        r.cozucu.oncekiCpsat = { durum: ilkCpsat.cozucu.durum, kanit: ilkCpsat.cozucu.kanit || '',
          cekirdek: ilkCpsat.cozucu.cekirdek || [], onDenetim: ilkCpsat.cozucu.onDenetim || {} };
      }
      r.cozucu.motorGecmisi = gecmis.slice();
      if (mesaj && !r.cozucu.basarili) r.cozucu.gecisNotu = mesaj;
      durum.sonuc = r; ui.calisiyor = false; ui.is = null; ui.secBlok = null; ui.raporAcik = !r.cozucu.basarili;
      degisti(false); ciz();
      bildir(r.cozucu.basarili ? 'Dağıtım tamamlandı: zorunlu kurallar sağlandı (' + r.cozucu.motor + ').'
        : (r.cozucu.taslak || r.yerlesim.length ? 'Dağıtım tamamlanamadı — taslak gösteriliyor; nedenler raporda.' : 'Dağıtım yapılamadı; nedenler raporda.'), r.cozucu.basarili ? '' : 'hata');
    }
    function enIyiTaslak() {
      if (!bulunanlar.length) return null;
      return bulunanlar.slice().sort(function (a, b) {
        return (+a.istatistik.eksikSaat || 0) - (+b.istatistik.eksikSaat || 0) ||
          (a.cozucu.kuralIhlalleri || []).length - (b.cozucu.kuralIhlalleri || []).length;
      })[0];
    }
    function siradaki(onceki) {
      if (!aktif()) return;
      var sonraki = sira.shift();
      if (!sonraki) return sonlandir(enIyiTaslak(), onceki || 'Tüm motorlar denendi.');
      gorev.motor = sonraki; gorev.basMotor = Date.now(); gorev.oran = 0.03;
      gorev.mesaj = adi(sonraki) + ' motoru başlatılıyor'; isIlerlemeGuncelle();
      if (sonraki !== 'cpsat' && eksikler.length) {
        kayitEkle(adi(sonraki), 'DESTEKLENMIYOR', 'Bu motorun desteklemediği zorunlu kurallar: ' + eksikler.join(', '), 0);
        return siradaki('Tarayıcı motorları bu okulun zorunlu kurallarını güvenle karşılayamıyor.');
      }
      if (sonraki === 'cpsat') return cpsatCalistir();
      if (sonraki === 'genetik') return genetikCalistir();
      return hizliCalistir();
    }
    function sonucAl(r, m, not) {
      if (!aktif()) return;
      if (!r || !r.yerlesim || !r.istatistik) return basarisiz(m, 'Motor geçerli sonuç döndürmedi.');
      if (m === 'genetik') temizleWorker();
      r = duzenle(r, m);
      kayitEkle(adi(m), r.cozucu.durum, not || '', Date.now() - gorev.basMotor);
      bulunanlar.push(r);
      if (m === 'cpsat') ilkCpsat = r;
      if (r.cozucu.basarili || r.eski || (m === 'cpsat' && r.cozucu.durum === 'INFEASIBLE')) {
        return sonlandir(r, r.cozucu.durum === 'INFEASIBLE' ? 'CP-SAT bütün izinli aşamalarda çözümsüzlüğü kanıtladı; diğer motorlara geçilmedi.' : '');
      }
      if (!otomatik) return sonlandir(r);
      return siradaki(adi(m) + ' geçerli çözüm bulamadı.');
    }
    function basarisiz(m, hataMetni) {
      if (!aktif()) return;
      if (m === 'genetik') temizleWorker();
      kayitEkle(adi(m), 'HATA', hataMetni, Date.now() - gorev.basMotor);
      if (otomatik) return siradaki(adi(m) + ' hata verdi: ' + hataMetni);
      return sonlandir(enIyiTaslak(), adi(m) + ' hata verdi: ' + hataMetni);
    }
    function hizliCalistir() {
      gorev.mesaj = 'Hızlı motor yerleşim arıyor'; isIlerlemeGuncelle();
      var hazirVeri = kulupHazirla();
      setTimeout(function () {
        if (!aktif()) return;
        try {
          var r = window.DersDagitim.dagit(hazirVeri.girdi); r.kulupYerlesim = hazirVeri.kulupYerlesim;
          sonucAl(r, 'hizli');
        } catch (e) { basarisiz('hizli', e.message); }
      }, 30);
    }
    function genetikCalistir() {
      var hazirVeri = kulupHazirla();
      try {
        if (typeof Worker !== 'function') throw new Error('Bu tarayıcı Web Worker desteklemiyor.');
        var worker = new Worker('assets/genetik-worker.js');
        gorev.worker = worker;
        worker.onmessage = function (ev) {
          if (!aktif() || gorev.worker !== worker) return;
          var m = ev.data || {};
          if (m.tip === 'ilerleme') {
            var p = m.ilerleme;
            gorev.oran = .05 + .88 * p.nesil / p.toplamNesil;
            gorev.mesaj = 'Genetik: ' + p.nesil + '/' + p.toplamNesil + ' kuşak · ' + p.degerlendirme + ' aday · en az ' + p.enIyiEksik + ' eksik saat';
            isIlerlemeGuncelle();
          } else if (m.tip === 'sonuc') {
            var r = m.sonuc;
            r.kulupYerlesim = hazirVeri.kulupYerlesim;
            sonucAl(r, 'genetik', (r.istatistik.gaDegerlendirme || 0) + ' aday, ' + (r.istatistik.gaNesil || 0) + ' kuşak');
          } else if (m.tip === 'hata') basarisiz('genetik', m.mesaj);
        };
        worker.onerror = function (ev) { if (aktif() && gorev.worker === worker) basarisiz('genetik', ev.message || 'Genetik iş parçacığı çalışmadı.'); };
        worker.postMessage({ girdi: hazirVeri.girdi, ayarlar: { sureMs: Math.min(60000, Math.max(8000, (+durum.ayarlar.cpsatSure || 60) * 350)) } });
      } catch (e) { basarisiz('genetik', e.message); }
    }
    function cpsatCalistir() {
      api('dagit-baslat', { girdi: girdi }).then(function (j) {
        if (!aktif()) { api('dagit-iptal', { is: j.is }).catch(function () {}); return; }
        gorev.id = j.is;
        var sorgula = function () {
          if (!aktif() || gorev.id !== j.is) return;
          api('dagit-durum&is=' + encodeURIComponent(j.is)).then(function (d) {
            if (!aktif() || gorev.id !== j.is) return;
            if (d.durum === 'bitti') return sonucAl(d.sonuc, 'cpsat');
            if (d.durum === 'hata') return basarisiz('cpsat', d.mesaj || 'çözücü hatası');
            gorev.oran = d.oran || 0; gorev.mesaj = d.mesaj || 'Çalışıyor'; isIlerlemeGuncelle();
            gorev.zaman = setTimeout(sorgula, 1000);
          }).catch(function (e) { basarisiz('cpsat', 'Durum alınamadı: ' + e.message); });
        };
        gorev.zaman = setTimeout(sorgula, 700);
      }).catch(function (e) { basarisiz('cpsat', 'Başlatılamadı: ' + e.message); });
    }
    if (otomatik && !hazir) kayitEkle('CP-SAT', 'KULLANILAMADI', (ui.cpsat && ui.cpsat.neden) || 'Sunucuda OR-Tools hazır değil.', 0);
    siradaki();
  }
  function isIlerlemeGuncelle() {
    var el = $('#is-ilerleme'); if (!el || !ui.is) return;
    var sn = Math.round((Date.now() - ui.is.bas) / 1000);
    el.innerHTML = isIlerlemeIc();
    void sn;
  }
  function isIlerlemeIc() {
    var i = ui.is, sn = Math.round((Date.now() - i.bas) / 1000);
    return '<div class="is-ust"><b>' + (i.motor === 'cpsat' ? 'CP-SAT' : i.motor === 'genetik' ? 'Genetik Algoritma' : 'Hızlı') + ' motoru çalışıyor' + '</b><span class="ince">' + sn + ' sn' + (i.motor === 'cpsat' ? ' / en fazla ' + (+durum.ayarlar.cpsatSure || 60) + ' sn' : '') + '</span></div>' +
      '<div class="ilerleme"><i style="width:' + Math.round((i.oran || 0.03) * 100) + '%"></i></div><p class="ince">' + esc(i.mesaj || '') + '</p>' +
      '<button class="btn kucuk" data-a="is-iptal">Durdur</button>';
  }

  // ---------- Excel (SpreadsheetML) dışa aktarma ----------
  function excelAktar() {
    var r = durum.sonuc; if (!r) return;
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, harita = hucreHaritasi();
    var x = function (v) { return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); };
    var hucre = function (v, st) { return '<Cell' + (st ? ' ss:StyleID="' + st + '"' : '') + '><Data ss:Type="' + (typeof v === 'number' ? 'Number' : 'String') + '">' + x(v) + '</Data></Cell>'; };
    var satir = function (l, st) { return '<Row>' + l.map(function (v) { return hucre(v, st); }).join('') + '</Row>'; };
    var bas = ['']; for (var d = 0; d < D; d++) for (var h = 0; h < H; h++) bas.push(M.GUNLER[d].slice(0, 3) + ' ' + (h + 1));
    function carsaf(tip, liste) {
      var out = satir([tip === 's' ? 'Şube' : 'Öğretmen'].concat(bas.slice(1)), 'b');
      liste.forEach(function (e) {
        var l = [e.ad];
        for (var d = 0; d < D; d++) for (var h = 0; h < H; h++) {
          var c = harita[tip + ':' + e.id + ':' + d + '-' + h];
          l.push(c ? (tip === 's' ? M.kisaltma(c.ders) + ' ' + (ogretmen(c.ogretmenId) ? basHarf(ogretmen(c.ogretmenId).ad) : '') : ((sube(c.subeId) || {}).ad || c.ders) + ' ' + M.kisaltma(c.ders)) : '');
        }
        out += satir(l);
      });
      return out;
    }
    function programlar(tip, liste) {
      var out = '';
      liste.forEach(function (e) {
        out += satir([e.ad], 'b') + satir(['Gün'].concat(Array.from({ length: H }, function (_, i) { return (i + 1) + '. ders'; })), 'b');
        for (var d = 0; d < D; d++) {
          var l = [M.GUNLER[d]];
          for (var h = 0; h < H; h++) {
            var c = harita[tip + ':' + e.id + ':' + d + '-' + h];
            l.push(c ? (tip === 's' ? c.ders + (ogretmen(c.ogretmenId) ? ' (' + ogretmen(c.ogretmenId).ad + ')' : '') : ((sube(c.subeId) || {}).ad || '') + ' ' + c.ders) : '');
          }
          out += satir(l);
        }
        out += '<Row/>';
      });
      return out;
    }
    var ihl = (r.cozucu && r.cozucu.kuralIhlalleri) || kuralDenetle(r), kal = kaliteAnalizi(r);
    var ogrs = durum.ogretmenler.slice().sort(function (a, b) { return a.ad.localeCompare(b.ad, 'tr'); });
    var sayfa = function (ad, ic) { return '<Worksheet ss:Name="' + x(ad) + '"><Table>' + ic + '</Table></Worksheet>'; };
    var xml = '<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' +
      '<Styles><Style ss:ID="b"><Font ss:Bold="1"/><Interior ss:Color="#E6EDF7" ss:Pattern="Solid"/></Style></Styles>' +
      sayfa('Şube çarşafı', carsaf('s', durum.subeler)) + sayfa('Öğretmen çarşafı', carsaf('o', ogrs)) +
      sayfa('Şube programları', programlar('s', durum.subeler)) + sayfa('Öğretmen programları', programlar('o', ogrs)) +
      sayfa('Kural ihlalleri', satir(['Kural', 'Açıklama'], 'b') + (ihl.length ? ihl.map(function (v) { return satir([v.kural, v.mesaj]); }).join('') : satir(['—', 'Zorunlu kural ihlali yok']))) +
      sayfa('Kalite', satir(['Öğretmen', 'Boş saat', 'Gün', 'En yoğun gün', 'İlk/son ihlali'], 'b') + kal.ogretmen.map(function (o) { return satir([o.ad, o.bosluk, o.gun, o.tepe, o.ilkSon]); }).join('') +
        '<Row/>' + satir(['Şube', 'Boş saat', 'En az günlük', 'En çok günlük', 'Günlük en çok zor ders'], 'b') + kal.sube.map(function (s) { return satir([s.ad, s.bosluk, s.enAz, s.enCok, s.zorMax]); }).join('')) +
      '</Workbook>';
    var ad = (durum.okul.ad || 'program').replace(/[^\wçğıöşüÇĞİÖŞÜ -]/g, '') + ' - ders dağıtımı.xls';
    dosyaIndir(ad, xml, 'application/vnd.ms-excel');
  }
  function dosyaIndir(ad, icerik, tur) {
    if (ui.indirme) {
      ui.indirme.save({ filename: ad, data: icerik }).then(function () { bildir('“' + ad + '” indirildi.'); }, function (err) {
        bildir(err && err.code === 'declined' ? 'İndirme iptal edildi.' : 'İndirme yapılamadı.', 'hata');
      });
      return;
    }
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + icerik], { type: tur + ';charset=utf-8' }));
    a.download = ad; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    bildir('“' + ad + '” indirildi.');
  }

  // ---------- Sayfa: Dağıtım kuralları (tek merkez) ----------
  function oncelikSecimi(an, deger) {
    return '<select data-a="tercih-oncelik" data-v="' + an + '" class="oncelik-' + deger + '">' + ['yuksek', 'orta', 'dusuk', 'kapali'].map(function (p) { return '<option value="' + p + '"' + (p === deger ? ' selected' : '') + '>' + ONCELIK_AD[p] + '</option>'; }).join('') + '</select>';
  }
  function motorKarti() {
    var c = ui.cpsat, sunucu = CFG.mod === 'sunucu';
    var durumMetni = !sunucu ? '<span class="etiket">Önizleme: Genetik ve Hızlı motor</span> <span class="ince">CP-SAT, PHP sürümünde Python + OR-Tools ile sunucuda çalışır (pip install ortools).</span>'
      : (!c || c.sorgu ? '<span class="ince">Denetleniyor…</span>' : (c.hazir ? '<span class="etiket yesil">CP-SAT hazır · OR-Tools ' + esc((c.surum || '').split(' ')[0]) + '</span>' : '<span class="etiket kirmizi">CP-SAT kullanılamıyor</span> <span class="ince">' + esc(c.neden || '') + '</span>'));
    return '<div class="kart"><div class="kart-ust"><h3>Dağıtım motoru</h3>' + durumMetni + '</div><div class="form">' +
      '<label class="alan">Motor<select data-a="motor-sec"><option value="otomatik"' + (secilenMotor() === 'otomatik' ? ' selected' : '') + '>Otomatik (CP-SAT → Genetik → Hızlı)</option><option value="cpsat"' + (secilenMotor() === 'cpsat' ? ' selected' : '') + (sunucu && c && c.hazir ? '' : ' disabled') + '>CP-SAT (OR-Tools) — kanıtlı, önerilen</option><option value="genetik"' + (secilenMotor() === 'genetik' ? ' selected' : '') + '>Genetik (tarayıcı) — evrimsel arama</option><option value="hizli"' + (secilenMotor() === 'hizli' ? ' selected' : '') + '>Hızlı (tarayıcı) — sezgisel</option></select></label>' +
      '<label class="alan">Süre sınırı (sn)<input type="number" min="5" max="900" data-a="cpsat-sure" value="' + (+durum.ayarlar.cpsatSure || 60) + '"></label>' +
      '<label class="alan">İşlemci (0 = sunucu ayarı)<input type="number" min="0" max="64" data-a="cpsat-isci" value="' + (+durum.ayarlar.isci || 0) + '"></label></div>' +
      '<p class="ince" style="margin:10px 0 0"><b>Otomatik:</b> CP-SAT ile başlar; sonuç bulunamazsa Genetik, ardından Hızlı motor denenir. CP-SAT kesin çözümsüzlük kanıtlarsa diğerlerine geçilmez. Tarayıcı motorlarının desteklemediği kurallar varsa güvenli geçiş engellenir. Her motorun sonucu ayrı denetlenir; izin verilmemiş kural gevşetilmez.</p></div>';
  }
  function kurallarCiz() {
    var k = kurallar(), dersler = dersListesi();
    var baslik = sayfaBasi('Dağıtım kuralları', 'Günlük kullanım için temel ayarlar; ayrıntılar ayrı sekmede.', '<button class="btn" data-a="kural-varsayilan">Varsayılanlara dön</button>');
    var motor = motorKarti();
    var h = '';
    // Zorunlu kurallar
    h += '<div class="kart"><div class="kart-ust"><h3>Zorunlu kurallar</h3><span class="ince">Bu kuralları çiğneyen program “başarılı” sayılmaz</span></div><div class="kaydirma"><table class="tablo kural-tablo"><tr><th>Kod</th><th>Kural</th><th>Açıklama</th><th>Ayar</th></tr>' +
      KURAL_LISTESI.map(function (x) {
        var ayar = '<span class="etiket">Her zaman</span>';
        if (x[3] === 'gunlukAyniDersMax') ayar = '<label class="satir-alan"><input type="number" min="1" max="6" data-a="kural-sayi" data-v="gunlukAyniDersMax" value="' + k.gunlukAyniDersMax + '" style="width:58px"> saat / gün</label>';
        else if (x[3] === 'binaGecisDk') ayar = '<label class="satir-alan"><input type="number" min="0" max="120" data-a="kural-sayi" data-v="binaGecisDk" value="' + (+k.binaGecisDk || 0) + '" style="width:58px"> dk</label>';
        else if (x[3] !== 'her') ayar = '<label class="anahtar"><input type="checkbox" data-a="kural-ac" data-v="' + x[3] + '"' + (k[x[3]] ? ' checked' : '') + '><span></span>' + (k[x[3]] ? 'Açık' : 'Kapalı') + '</label>';
        return '<tr><td><b>' + x[0] + '</b></td><td>' + esc(x[1]) + '</td><td class="ince">' + esc(x[2]) + '</td><td class="nowrap">' + ayar + '</td></tr>';
      }).join('') + '</table></div><p class="ince" style="margin:10px 0 0">Haftalık saati “gün × günlük sınır”dan fazla olan dersler (ör. hazırlık sınıfında 20 saat İngilizce) için günlük sınır otomatik ⌈saat ÷ gün⌉ alınır; bu derslerde aynı gün iki blok olabilir ama kesintisiz 3 saat olmaz.</p></div>';
    var temel = h; h = '';
    // Esnetme izinleri
    var izin = [['gunlukMax', 'K04 günlük üst sınır', 'Çözüm bulunamazsa günlük sınır 1 saat artırılabilir.'], ['blokYapisi', 'K06 blok yapısı', 'Bloklar 1 ve 2 saatlik parçalara serbestçe bölünebilir.'], ['ayniGunBlok', 'K07 aynı gün ayrı blok', 'Aynı ders bir günde ayrı iki blokta olabilir (K05 korunur).']];
    h += '<div class="izgara2"><div class="kart"><h3>Esnetme izinleri <span class="ek">4. aşama</span></h3><p class="ince">Dağıtım sırasıyla dener: 1) tam kurallar, 2) izin verilen alternatif bloklar (VEYA), 3) tercihleri esnetme, 4) yalnız burada izin verdiğiniz sınırlar. Öğretmen/şube/derslik çakışması, haftalık saat, kapalı saatler ve kilitler <b>asla</b> esnetilmez.</p>' +
      izin.map(function (x) { return '<label class="izin-satir"><input type="checkbox" data-a="esnet-izin" data-v="' + x[0] + '"' + (k.esnetIzin[x[0]] ? ' checked' : '') + '><span><b>' + x[1] + '</b><small>' + x[2] + '</small></span></label>'; }).join('') + '</div>';
    // Tercihler
    h += '<div class="kart"><h3>Tercihler <span class="ek">yumuşak kurallar · sıralı optimizasyon</span></h3><p class="ince">Önce “Yüksek” öncelikliler en iyi hâle getirilir, sonra o değer korunarak “Orta”, en son “Düşük”.</p><table class="tablo sik">' +
      TERCIH_LISTESI.map(function (x) { return '<tr><td>' + esc(x[1]) + '</td><td class="s">' + oncelikSecimi(x[0], k.tercihler[x[0]]) + '</td></tr>'; }).join('') +
      '<tr><td>Şube başına izin verilen haftalık boş saat</td><td class="s"><input type="number" min="0" max="20" data-a="kural-sayi" data-v="subeMaxBosluk" value="' + (+k.subeMaxBosluk || 0) + '" style="width:62px"></td></tr>' +
      '<tr><td>Bir günde en fazla “zor” etiketli ders saati</td><td class="s"><input type="number" min="1" max="12" data-a="kural-sayi" data-v="zorDersGunluk" value="' + (+k.zorDersGunluk || 4) + '" style="width:62px"></td></tr>' +
      '<tr><td>Nöbet gününde öğretmene en fazla ders saati <small class="ince">(0 = sınır yok)</small></td><td class="s"><input type="number" min="0" max="12" data-a="kural-sayi" data-v="nobetMaxGunluk" value="' + (+k.nobetMaxGunluk || 0) + '" style="width:62px"></td></tr>' +
      '<tr><td>Ders ağırlık profili <small class="ince">(Mat/Fen/Türkçe sabah, Beden/Görsel/Müzik öğleden sonra)</small></td><td class="s"><label class="anahtar"><input type="checkbox" data-a="kural-ac" data-v="dersAgirlikProfili"' + (k.dersAgirlikProfili ? ' checked' : '') + '><span></span>' + (k.dersAgirlikProfili ? 'Açık' : 'Kapalı') + '</label></td></tr></table></div></div>';
    // Zümre ortak boş saati
    var bransSay = {};
    durum.ogretmenler.forEach(function (o) { if (o.brans) bransSay[o.brans] = (bransSay[o.brans] || 0) + 1; });
    var zumreAday = Object.keys(bransSay).filter(function (b) { return bransSay[b] >= 2; }).sort(function (a, b) { return a.localeCompare(b, 'tr'); });
    var secZumre = k.zumreBranslar || [];
    h += '<div class="kart"><div class="kart-ust"><h3>Zümre ortak boş saati <span class="ek">CP-SAT</span></h3><span class="ince">Seçili branşlardaki tüm öğretmenler için haftada en az 1 ortak boş ders saati bırakılır</span></div>' +
      (zumreAday.length ? '<div class="satir" style="flex-wrap:wrap;gap:6px">' + zumreAday.map(function (b) {
        var acik = secZumre.indexOf(b) >= 0;
        return '<button type="button" class="btn kucuk' + (acik ? ' ana' : '') + '" data-a="zumre-brans" data-v="' + esc(b) + '">' + (acik ? '✓ ' : '+ ') + esc(b) + ' (' + bransSay[b] + ')</button>';
      }).join('') + '</div>' : '<p class="ince">En az 2 öğretmeni olan bir branş eklendiğinde burada zümre seçimi yapabilirsiniz.</p>') + '</div>';
    var gelismis = h; h = '';
    // Ders ayarları
    var adlar = {};
    dersler.forEach(function (d) { if (d.ders !== 'Seçmeli Ders') { var a = adlar[d.ders] = adlar[d.ders] || { n: 0, ornek: d }; a.n++; } });
    var turler = DERSLIK_TURLERI.filter(function (t) { return t[0] === 'normal' || (durum.derslikler || []).some(function (r) { return r.tur === t[0]; }); });
    h += '<details class="kart katlanir"' + (ui.dersAyarAcik ? ' open' : '') + '><summary data-a="ders-ayar-ac"><b>Ders ayarları</b> <span class="ince">derslik türü, dil (K08), etiketler (K16), 1+1 bölünebilirlik — ' + Object.keys(adlar).length + ' ders</span></summary>' +
      '<input type="search" placeholder="Ders ara…" data-a="ders-ayar-ara" value="' + esc(ui.dersAyarAra || '') + '" style="max-width:320px;margin-bottom:10px">' +
      '<div class="kaydirma"><table class="tablo sik"><tr><th>Ders</th><th class="s">Şube</th><th>Derslik türü</th><th>Dil (K08)</th><th>Etiketler</th><th class="s">1+1</th></tr>' +
      Object.keys(adlar).sort(function (a, b) { return a.localeCompare(b, 'tr'); }).map(function (ad) {
        var a = dersAyari(ad), d = adlar[ad].ornek, dil = !Object.prototype.hasOwnProperty.call(a, 'dil') ? 'oto' : (a.dil || 'yok');
        return '<tr class="ders-ayar-satir" data-ara="' + esc(ad.toLocaleLowerCase('tr')) + '"><td>' + esc(ad) + '</td><td class="s">' + adlar[ad].n + '</td>' +
          '<td><select data-a="ders-ayar" data-k="derslikTuru" data-v="' + esc(ad) + '">' + turler.map(function (t) { return '<option value="' + t[0] + '"' + ((a.derslikTuru || 'normal') === t[0] ? ' selected' : '') + '>' + t[1] + '</option>'; }).join('') + '</select></td>' +
          '<td><select data-a="ders-ayar" data-k="dil" data-v="' + esc(ad) + '"><option value="oto"' + (dil === 'oto' ? ' selected' : '') + '>Otomatik (' + ({ ingilizce: 'İngilizce', yabanci: 'Yabancı Dil' }[otoDil(d.temelDers || d.ders)] || 'yok') + ')</option><option value="yok"' + (dil === 'yok' ? ' selected' : '') + '>Dil dersi değil</option><option value="ingilizce"' + (dil === 'ingilizce' ? ' selected' : '') + '>İngilizce</option><option value="yabanci"' + (dil === 'yabanci' ? ' selected' : '') + '>Yabancı Dil</option></select></td>' +
          '<td><input type="text" data-a="ders-ayar" data-k="etiketler" data-v="' + esc(ad) + '" value="' + esc(dersEtiketleri(d).join(', ')) + '" placeholder="ör. zor, laboratuvar" style="min-width:160px"></td>' +
          '<td class="s"><input type="checkbox" data-a="ders-ayar" data-k="bolunebilir" data-v="' + esc(ad) + '"' + (dersBolunebilir(d) ? ' checked' : '') + (d.saat === 2 ? '' : ' disabled title="Yalnız 2 saatlik derslerde"') + '></td></tr>';
      }).join('') + '</table></div><p class="ince">“zor” etiketi zorlayıcı dersleri belirtir (Matematik, Fen, Fizik, Kimya, Biyoloji, Türkçe/TDE varsayılan). Etiket kurallarını aşağıda tanımlayın.</p></details>';
    // Etiket kuralları
    var ek = durum.etiketKurallari || [];
    h += '<div class="kart"><div class="kart-ust"><h3>Etiket kuralları <span class="ek">K16</span></h3><button class="btn kucuk" data-a="etiket-ekle">' + ikon('artı') + 'Kural ekle</button></div>' +
      (ek.length ? '<table class="tablo sik"><tr><th>Etiket</th><th>Uygulandığı</th><th class="s">Günde en fazla (saat)</th><th class="s">Art arda yasak</th><th></th></tr>' + ek.map(function (e, i) {
        return '<tr><td><input type="text" data-a="etiket-alan" data-k="ad" data-v="' + i + '" value="' + esc(e.ad || '') + '" placeholder="ör. laboratuvar"></td>' +
          '<td><select data-a="etiket-alan" data-k="hedef" data-v="' + i + '"><option value="ders"' + (e.hedef !== 'ogretmen' ? ' selected' : '') + '>Dersler (şube bazında)</option><option value="ogretmen"' + (e.hedef === 'ogretmen' ? ' selected' : '') + '>Öğretmenler</option></select></td>' +
          '<td class="s"><input type="number" min="1" max="12" data-a="etiket-alan" data-k="maxGunluk" data-v="' + i + '" value="' + (e.maxGunluk || '') + '" style="width:62px"></td>' +
          '<td class="s"><input type="checkbox" data-a="etiket-alan" data-k="ardisikYasak" data-v="' + i + '"' + (e.ardisikYasak ? ' checked' : '') + (e.hedef === 'ogretmen' ? ' disabled' : '') + '></td>' +
          '<td class="s"><button class="btn ikon-btn tehlike" data-a="etiket-sil" data-v="' + i + '">' + ikon('cop') + '</button></td></tr>';
      }).join('') + '</table>' : '<p class="ince">Örnek: “laboratuvar” etiketli derslerden bir şubeye günde en fazla 2 saat; “zor” etiketli dersler art arda gelmesin. Öğretmen etiketi (ör. “yarı zamanlı”) öğretmenin günlük sınırını belirler; öğretmene etiketi Kısıtlar → Tercihler’den verin.</p>') + '</div>';
    gelismis += h;
    var aktif = ui.ux5KuralSekme || 'temel';
    var sekmeler = [['temel','Temel kurallar'],['gelismis','Gelişmiş kurallar'],['motor','Dağıtım motoru']];
    var tablar = '<div class="ux5-tabs" role="tablist" aria-label="Dağıtım kuralları">'+sekmeler.map(function(x){return '<button role="tab" type="button" data-a="ux5-kural-sekme" data-v="'+x[0]+'" class="'+(aktif===x[0]?'aktif':'')+'" aria-selected="'+(aktif===x[0]?'true':'false')+'">'+x[1]+'</button>'}).join('')+'</div>';
    return baslik+'<section class="ux5-page ux5-rules">'+tablar+'<div class="ux5-panel">'+(aktif==='temel'?temel:aktif==='motor'?motor:gelismis)+'</div></section>';
  }

  // ---------- Sayfa: Derslikler ve binalar ----------
  function yeniKimlik(on) { return on + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36); }
  function dersliklerCiz() {
    var B = durum.binalar = durum.binalar || [], R = durum.derslikler = durum.derslikler || [], G = durum.binaGecis = durum.binaGecis || [];
    var h = sayfaBasi('Derslikler ve binalar', '');
    h += '<div class="izgara2"><div class="kart"><div class="kart-ust"><h3>Binalar <span class="ek">' + B.length + '</span></h3><button class="btn kucuk" data-a="bina-ekle">' + ikon('artı') + 'Bina ekle</button></div>' +
      (B.length ? B.map(function (b, i) { return '<div class="satir dd3-bina-satir" style="margin-bottom:6px">' + ikon('okul') + '<input type="text" data-a="bina-ad" data-v="' + i + '" value="' + esc(b.ad) + '" style="flex:1"><span class="ince">' + R.filter(function (r) { return r.binaId === b.id; }).length + ' derslik</span><button class="btn ikon-btn tehlike" data-a="bina-sil" data-v="' + i + '">' + ikon('cop') + '</button></div>'; }).join('') : '<p class="ince">Tek binalı okullarda bina eklemeniz gerekmez.</p>') + '</div>';
    h += '<div class="kart"><h3>Bina geçişi <span class="ek">K13</span></h3>' +
      '<label class="satir-alan">Binalar arası varsayılan geçiş süresi<input type="number" min="0" max="120" data-a="kural-sayi" data-v="binaGecisDk" value="' + (+kurallar().binaGecisDk || 0) + '" style="width:64px"> dk</label>' +
      '<p class="ince">Teneffüs ' + (+durum.okul.teneffus || 10) + ' dk. Geçiş süresi teneffüsten uzunsa öğretmen farklı binalarda art arda derse giremez.</p>' +
      (B.length > 1 ? '<table class="tablo sik"><tr><th>Bina</th><th>Bina</th><th class="s">Süre (dk)</th><th class="s">Aynı gün olmaz</th><th></th></tr>' + G.map(function (x, i) {
        var sec = function (k) { return '<select data-a="gecis-alan" data-k="' + k + '" data-v="' + i + '">' + B.map(function (b) { return '<option value="' + b.id + '"' + (x[k] === b.id ? ' selected' : '') + '>' + esc(b.ad) + '</option>'; }).join('') + '</select>'; };
        return '<tr><td>' + sec('a') + '</td><td>' + sec('b') + '</td><td class="s"><input type="number" min="0" max="240" data-a="gecis-alan" data-k="dk" data-v="' + i + '" value="' + (+x.dk || 0) + '" style="width:62px"></td><td class="s"><input type="checkbox" data-a="gecis-alan" data-k="ayniGunYasak" data-v="' + i + '"' + (x.ayniGunYasak ? ' checked' : '') + '></td><td><button class="btn ikon-btn tehlike" data-a="gecis-sil" data-v="' + i + '">' + ikon('cop') + '</button></td></tr>';
      }).join('') + '</table><button class="btn kucuk" data-a="gecis-ekle">' + ikon('artı') + 'Bina çifti için özel süre</button>' : '') + '</div></div>';
    // Derslikler
    var turAd = {}; DERSLIK_TURLERI.forEach(function (t) { turAd[t[0]] = t[1]; });
    h += '<div class="kart"><div class="kart-ust"><h3>Derslikler <span class="ek">' + R.length + '</span></h3><div class="satir">' +
      '<button class="btn kucuk" data-a="derslik-ekle">' + ikon('artı') + 'Derslik ekle</button><button class="btn kucuk" data-a="derslik-sube-olustur">Her şubeye sınıf dersliği oluştur</button></div></div>';
    if (R.length) {
      h += '<div class="kaydirma"><table class="tablo sik"><tr><th>Derslik</th><th>Bina</th><th>Tür</th><th>Kullanan</th><th></th></tr>' + R.map(function (r, i) {
        var kullanan = durum.subeler.filter(function (s) { return s.derslikId === r.id; }).map(function (s) { return s.ad; });
        return '<tr class="dd3-derslik-satir" data-dd3-ara="' + esc(r.ad + ' ' + ((B.filter(function (b) { return b.id === r.binaId; })[0] || {}).ad || '') + ' ' + (turAd[r.tur] || '')) + '" data-dd3-tur="' + esc(r.tur || 'normal') + '"><td><input type="text" data-a="derslik-alan" data-k="ad" data-v="' + i + '" value="' + esc(r.ad) + '"></td>' +
          '<td><select data-a="derslik-alan" data-k="binaId" data-v="' + i + '"><option value="">—</option>' + B.map(function (b) { return '<option value="' + b.id + '"' + (r.binaId === b.id ? ' selected' : '') + '>' + esc(b.ad) + '</option>'; }).join('') + '</select></td>' +
          '<td><select data-a="derslik-alan" data-k="tur" data-v="' + i + '">' + DERSLIK_TURLERI.map(function (t) { return '<option value="' + t[0] + '"' + ((r.tur || 'normal') === t[0] ? ' selected' : '') + '>' + t[1] + '</option>'; }).join('') + '</select></td>' +
          '<td class="ince">' + (kullanan.length ? esc(kullanan.join(', ')) + ' (sınıf dersliği)' : (r.tur !== 'normal' ? esc(dersListesi().filter(function (d) { return dersAyari(d.ders).derslikTuru === r.tur; }).map(function (d) { return d.ders; }).filter(function (v, j, a) { return a.indexOf(v) === j; }).join(', ') || '—') : '—')) + '</td>' +
          '<td class="s"><button class="btn ikon-btn tehlike" data-a="derslik-sil" data-v="' + i + '">' + ikon('cop') + '</button></td></tr>';
      }).join('') + '</table></div>';
    } else h += '<p class="ince">Derslik tanımlamazsanız derslik ve bina kuralları uygulanmaz. Laboratuvar, spor salonu, atölye gibi özel derslikleri ekleyip derslerle eşleştirin.</p>';
    h += '</div>';
    if (R.length) {
      var normal = R.filter(function (r) { return (r.tur || 'normal') === 'normal'; });
      h += '<div class="izgara2"><div class="kart"><h3>Şube derslikleri</h3><p class="ince">Şubenin normal dersleri bu derslikte yapılır (bina kuralları için gerekir).</p><table class="tablo sik">' + durum.subeler.map(function (s) {
        return '<tr><td><b>' + esc(s.ad) + '</b></td><td><select data-a="sube-derslik" data-v="' + s.id + '"><option value="">—</option>' + normal.map(function (r) { return '<option value="' + r.id + '"' + (s.derslikId === r.id ? ' selected' : '') + '>' + esc(r.ad) + (r.binaId ? ' · ' + esc((B.filter(function (b) { return b.id === r.binaId; })[0] || {}).ad || '') : '') + '</option>'; }).join('') + '</select></td></tr>';
      }).join('') + '</table></div>';
      h += '<div class="kart"><h3>Özel derslik gerektiren dersler</h3><p class="ince">Dersin derslik türünü “Dağıtım kuralları → Ders ayarları”ndan da değiştirebilirsiniz.</p>' +
        '<button class="btn" data-a="derslik-oneri">Önerilen eşleşmeleri uygula</button><p class="ince" style="margin-top:8px">Fen/Fizik/Kimya/Biyoloji → laboratuvar · Beden Eğitimi → spor salonu · Bilişim → bilişim sınıfı · Görsel Sanatlar → atölye · Müzik → müzik sınıfı (o türden derslik varsa).</p>' +
        '<ul class="duz-liste">' + DERSLIK_TURLERI.filter(function (t) { return t[0] !== 'normal' && R.some(function (r) { return r.tur === t[0]; }); }).map(function (t) {
          var l = Object.keys(durum.dersAyar || {}).filter(function (ad) { return durum.dersAyar[ad].derslikTuru === t[0]; });
          return '<li><b>' + t[1] + '</b> (' + R.filter(function (r) { return r.tur === t[0]; }).length + '): ' + (l.length ? esc(l.join(', ')) : '<span class="ince">ders yok</span>') + '</li>';
        }).join('') + '</ul></div></div>';
    }
    return h;
  }

  // ---------- Sayfa: Sosyal kulüpler (K15) ----------
  var ORNEK_KULUPLER = ['Afet Hazırlık Kulübü', 'Bilim, Fen ve Teknoloji Kulübü', 'Bilinçli Tüketici Kulübü', 'Bilişim ve İnternet Kulübü', 'Çevre Koruma Kulübü',
    'Çocuk Hakları Kulübü', 'Değerler Eğitimi Kulübü', 'Demokrasi, İnsan Hakları ve Yurttaşlık Kulübü', 'Engellilerle Dayanışma Kulübü', 'Enerji Verimliliği Kulübü',
    'Fotoğrafçılık Kulübü', 'Geleneksel Sanatlar Kulübü', 'Gezi, Tanıtma ve Turizm Kulübü', 'Girişimcilik Kulübü', 'Görsel Sanatlar Kulübü', 'Halk Oyunları Kulübü',
    'Havacılık Kulübü', 'Hayvanları Sevme ve Koruma Kulübü', 'İzcilik Kulübü', 'Kızılay ve Kan Bağışı Kulübü', 'Kooperatifçilik Kulübü', 'Kültür ve Edebiyat Kulübü',
    'Kütüphanecilik Kulübü', 'Medya Okuryazarlığı Kulübü', 'Meslek Tanıtma Kulübü', 'Münazara Kulübü', 'Müzik Kulübü', 'Satranç Kulübü', 'Sağlık, Temizlik ve Beslenme Kulübü',
    'Şiir ve Tefekkür Kulübü', 'Sivil Savunma Kulübü', 'Sosyal Yardımlaşma ve Dayanışma Kulübü', 'Spor Kulübü', 'Tiyatro Kulübü', 'Trafik Güvenliği ve İlkyardım Kulübü',
    'Yabancı Diller Kulübü', 'Yayın ve İletişim Kulübü', 'Yeşilay Kulübü', 'Yeşili Koruma Kulübü', 'Zekâ Oyunları Kulübü'];
  function kuluplerCiz() {
    var K = durum.kulupler = durum.kulupler || [], D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, t = tur();
    var h = sayfaBasi('Sosyal kulüpler', '', '<button class="btn ana" data-a="kulup-ekle">' + ikon('artı') + 'Kulüp ekle</button>');
    h += '<datalist id="kulup-adlari">' + ORNEK_KULUPLER.concat(durum.ozelKulupAdlari || []).map(function (x) { return '<option value="' + esc(x) + '">'; }).join('') + '</datalist>';
    if (!K.length) h += '<div class="kart bos-durum genis"><h3>Henüz kulüp yok</h3><p>“Kulüp ekle” ile başlayın; ad kutusunda ' + ORNEK_KULUPLER.length + ' örnek kulüp listelenir, kendi kulübünüzü de yazabilirsiniz. Kulübün öğretmeni, katılan şubeler ve haftalık saati dağıtımda çakışmasız yerleşir.</p></div>';
    K.forEach(function (k, i) {
      var subeSec = k.subeIds || [];
      h += '<div class="kart kulup-karti"><div class="kart-ust"><input type="text" list="kulup-adlari" class="kulup-ad" data-a="kulup-alan" data-k="ad" data-v="' + i + '" value="' + esc(k.ad || '') + '" placeholder="Kulüp adı">' +
        '<button class="btn ikon-btn tehlike" data-a="kulup-sil" data-v="' + i + '" title="Kulübü sil">' + ikon('cop') + '</button></div><div class="form">' +
        '<label class="alan">Danışman öğretmen<select data-a="kulup-alan" data-k="ogretmenId" data-v="' + i + '"><option value="">—</option>' + durum.ogretmenler.slice().sort(function (a, b) { return a.ad.localeCompare(b.ad, 'tr'); }).map(function (o) { return '<option value="' + o.id + '"' + (k.ogretmenId === o.id ? ' selected' : '') + '>' + esc(o.ad) + '</option>'; }).join('') + '</select></label>' +
        '<label class="alan">Haftalık saat<input type="number" min="1" max="4" data-a="kulup-alan" data-k="saat" data-v="' + i + '" value="' + (+k.saat || 1) + '"></label>' +
        '<label class="alan">Zaman<select data-a="kulup-zaman" data-v="' + i + '"><option value="oto"' + (!k.sabit ? ' selected' : '') + '>Otomatik (CP-SAT bulur)</option>' +
        Array.from({ length: D }, function (_, d) { return Array.from({ length: H }, function (_, s) { var on = k.sabit && +k.sabit.gun === d && +k.sabit.saat === s; return '<option value="' + d + '-' + s + '"' + (on ? ' selected' : '') + '>' + M.GUNLER[d] + ' ' + (s + 1) + '. ders</option>'; }).join(''); }).join('') + '</select></label>' +
        '<label class="alan">Mekân<select data-a="kulup-alan" data-k="derslikId" data-v="' + i + '"><option value="">— (şube dersliği)</option>' + (durum.derslikler || []).map(function (r) { return '<option value="' + r.id + '"' + (k.derslikId === r.id ? ' selected' : '') + '>' + esc(r.ad) + '</option>'; }).join('') + '</select></label></div>' +
        '<div class="kulup-subeler"><span class="ince">Katılan şubeler (' + subeSec.length + '):</span>' + t.siniflar.map(function (s) {
          var l = durum.subeler.filter(function (x) { return x.sinif === s; });
          if (!l.length) return '';
          var hepsi = l.every(function (x) { return subeSec.indexOf(x.id) >= 0; });
          return '<span class="kulup-duzey"><button class="fcip' + (hepsi ? ' aktif' : '') + '" data-a="kulup-duzey" data-v="' + i + '" data-k="' + esc(s) + '">' + esc(sinifEtiketi(s)) + '</button>' +
            l.map(function (x) { return '<button class="fcip kucuk-cip' + (subeSec.indexOf(x.id) >= 0 ? ' aktif' : '') + '" data-a="kulup-sube" data-v="' + i + '" data-k="' + x.id + '">' + esc(x.ad) + '</button>'; }).join('') + '</span>';
        }).join('') + '</div></div>';
    });
    return h;
  }

  // ---------- Dağıtım raporu (durum, aşamalar, ön denetim, ihlaller, kalite) ----------
  var DURUM_ACIKLAMA = {
    OPTIMAL: ['yesil', 'En iyi (OPTIMAL)', 'Bütün zorunlu kurallar sağlandı; tercihler açısından en iyi olduğu kanıtlandı.'],
    FEASIBLE: ['yesil', 'Geçerli (FEASIBLE)', 'Bütün zorunlu kurallar sağlandı; en iyi olduğu kanıtlanmadı (süre arttırılırsa iyileşebilir).'],
    INFEASIBLE: ['kirmizi', 'Çözüm yok (INFEASIBLE)', 'Bu kurallarla çözüm olmadığı kanıtlandı. Çelişen kurallar aşağıda.'],
    UNKNOWN: ['sari', 'Belirsiz (UNKNOWN)', 'Süre içinde sonuç kesinleşmedi; süreyi artırın ya da kısıtları gözden geçirin.'],
    DOGRULAMA_HATASI: ['kirmizi', 'Doğrulanamadı', 'Program bağımsız denetimde kural ihlali içeriyor; başarılı sayılmaz.'],
    DESTEKLENMIYOR: ['sari', 'Kurallar uygulanamadı', 'Hızlı motor bu okulda kullanılan bazı kuralları uygulayamaz.']
  };
  /** Aşama 4: dağıtım sonuçlarını ayrı merkezde göster; yeni sonuç oluşturma. */
  function dd4RaporlarCiz() {
    var r = durum.sonuc, h = '<div class="dd4-page dd4-rapor-page">' +
      sayfaBasi('Rapor merkezi', 'Motor performansı, yerleştirme, kural ihlalleri ve dağıtım kalitesini buradan inceleyin.',
      '<button class="btn" data-a="adim" data-v="dagitim">' + ikon('dagitim') + 'Dağıtım</button>' +
      (r ? '<button class="btn" data-a="excel">' + ikon('indir') + 'Excel / CSV</button><button class="btn ana" data-a="dd4-rapor-yazdir">' + ikon('yazdir') + 'Raporu yazdır</button>' : ''));
    if (!r || !r.istatistik) return h + '<section class="dd4-yuzey dd4-empty"><div class="dd4-empty-simge">' + ikon('dagitim') + '</div><h3>Henüz dağıtım sonucu bulunmuyor</h3>' +
      '<p>Önce dağıtım yapın. Ön kilit ve kapalı günlerinizi oluşturmak için boş çizelgeleri kullanabilirsiniz.</p>' +
      '<button class="btn ana" data-a="adim" data-v="dagitim">Dağıtım ekranını aç</button></section></div>';
    var c = sonucDurumu(r), ihl = c.kuralIhlalleri || [], k = kaliteAnalizi(r);
    h += '<div class="dd4-metrikler dd4-rapor-metrikler">' +
      dd4Metrik('dagitim','Çözücü', (DURUM_ACIKLAMA[c.durum] || [0, c.durum || '—'])[1], c.motor || 'Motor') +
      dd4Metrik('tamam','Yerleşen ders', ((+r.istatistik.toplamSaat || 0) - (+r.istatistik.eksikSaat || 0)), 'Yerleşen saat', 'yesil') +
      dd4Metrik('uyari','Eksik saat', +r.istatistik.eksikSaat || 0, 'Yerleştirilemeyen', (+r.istatistik.eksikSaat || 0) ? 'sari' : 'yesil') +
      dd4Metrik('kisitlar','Kural ihlali', ihl.length, 'Bağımsız denetim', ihl.length ? 'sari' : 'yesil') +
      dd4Metrik('bloklar','Kalite puanı', k.puan + '/100', 'Tercih hedefleri') +
      dd4Metrik('kaydet','Süre', ((r.istatistik.sureMs || 0)/1000).toFixed(1) + ' sn', 'Dağıtım süresi') + '</div>';
    if (r.eski) h += '<div class="dd4-rapor-uyari">' + ikon('uyari') + '<span>Ders veya kural verileri değişmiş. Bu rapor eski dağıtıma aittir.</span><button class="btn kucuk" data-a="adim" data-v="dagitim">Dağıtıma dön</button></div>';
    h += '<div class="dd4-yuzey dd4-grafik-kart"><div class="dd4-bolum-ust"><div><span class="dd4-kicker">GÖRSEL ANALİZ</span><h3>Öğretmen boşlukları</h3></div><span class="ince">İlk 8 öğretmen · en yüksek boşluk</span></div>';
    var max = Math.max(1,...k.ogretmen.map(function (x) { return x.bosluk || 0; }));
    h += '<div class="dd4-cubuklar">' + k.ogretmen.slice().sort(function (a,b) { return b.bosluk-a.bosluk; }).slice(0,8).map(function (x) {
      return '<div class="dd4-cubuk-satir"><span title="' + esc(x.ad) + '">' + esc(x.ad) + '</span><div class="dd4-cubuk-iz"><i style="width:' + Math.round((x.bosluk || 0)/max*100) + '%"></i></div><b>' + (+x.bosluk || 0) + '</b></div>';
    }).join('') + '</div><small class="dd4-grafik-alt">Bu grafik kalite ölçümüdür; kural ihlali tespiti için aşağıdaki denetim raporunu kullanın.</small></div>';
    ui.raporAcik = true;
    h += '<div class="dd4-detay" id="dd4-detay">' + raporKarti(r) + '</div></div>';
    return h;
  }

  /** Aşama 4: ayarları tek merkezde birleştir, kural alanlarını mevcut olaylarla yönet. */
  function dd4GorunumUygula() {
    var g = ui.dd4Gorunum || { yogun: false, kontrast: false };
    document.body.classList.toggle('dd4-yogun', !!g.yogun);
    document.body.classList.toggle('dd4-kontrast', !!g.kontrast);
  }
  function dd4GorunumYukle() {
    try { ui.dd4Gorunum = JSON.parse(localStorage.getItem(YEREL_ANAHTAR + '-gorunum') || '{}') || {}; }
    catch(e) { ui.dd4Gorunum = {}; }
    dd4GorunumUygula();
  }
  function dd4AyarlarCiz() {
    var g = ui.dd4Gorunum || {}, h = '<div class="dd4-page dd4-ayar-page">' + sayfaBasi('Ayarlar merkezi','Uygulama görünümünü ve motor seçeneklerini buradan yönetin.');
    h += '<section class="dd4-yuzey"><div class="dd4-bolum-ust"><div><span class="dd4-kicker">GÖRÜNÜM TERCİHLERİ</span><h3>Çalışma alanını özelleştir</h3></div><span class="ince">Bu cihazda geçerlidir</span></div>' +
      '<div class="dd4-ayar-satir"><div><b>Yoğun görünüm</b><small>Tablo, kart ve alanların yüksekliğini azaltır.</small></div><label class="dd4-switch"><input type="checkbox" data-a="dd4-gorunum" data-v="yogun"' + (g.yogun ? ' checked' : '') + '><span></span><em>' + (g.yogun ? 'Açık' : 'Kapalı') + '</em></label></div>' +
      '<div class="dd4-ayar-satir"><div><b>Yüksek kontrast</b><small>Başlıkları, hücre kenarlıklarını ve yazıları belirginleştirir.</small></div><label class="dd4-switch"><input type="checkbox" data-a="dd4-gorunum" data-v="kontrast"' + (g.kontrast ? ' checked' : '') + '><span></span><em>' + (g.kontrast ? 'Açık' : 'Kapalı') + '</em></label></div></section>';
    h += '<div class="dd4-ayar-grid"><div class="dd4-yuzey"><div class="dd4-bolum-ust"><div><span class="dd4-kicker">DAĞITIM</span><h3>Motor seçenekleri</h3></div></div><div class="dd4-motor-inline">' + motorKarti() + '</div></div>' +
      '<section class="dd4-yuzey"><div class="dd4-bolum-ust"><div><span class="dd4-kicker">YÖNETİM</span><h3>Diğer ayarlar</h3></div></div><div class="dd4-ayarlari-listesi">' +
      [['okul','Okul ve saatler','Ders başlangıcı, süreler, çalışma günleri','okul'],['kurallar','Dağıtım kuralları','Bloklar, zorunlu sınırlar, tercih puanları','kisitlar'],['kisitlar','Gün / saat kısıtları','Öğretmen ve şube uygunluğu, ön kilit','kilit'],['ciktilar','Belge ayarları','Öğretim yılı, imza bilgileri, A4 önizleme','yazdir'],['veri','Veri ve yedek','JSON içe/dışa aktarımı, kayıtlı projeler','indir']].map(function (a) { return '<button class="dd4-ayar-link" data-a="adim" data-v="' + a[0] + '">' + ikon(a[3]) + '<span><b>' + a[1] + '</b><small>' + a[2] + '</small></span><strong>›</strong></button>'; }).join('') + '</div></section></div></div>';
    return h;
  }

  function sonucDurumu(r) {
    var c = r.cozucu || {};
    if (!c.durum) { c.durum = r.istatistik.eksikSaat ? 'UNKNOWN' : 'FEASIBLE'; }
    return c;
  }
  function raporBandi(r) {
    var c = sonucDurumu(r), a = DURUM_ACIKLAMA[c.durum] || ['', c.durum, ''], ihl = c.kuralIhlalleri || [];
    var basarili = c.basarili != null ? c.basarili : (!r.istatistik.eksikSaat && !ihl.length);
    var metin = basarili ? a[2] : (c.durum === 'FEASIBLE' || c.durum === 'OPTIMAL' ? 'Program bütün kuralları sağlamıyor.' : a[2]);
    if (!basarili && (c.desteklenmeyen || []).length) metin += ' Hızlı motor şu kuralları uygulayamaz: ' + c.desteklenmeyen.join(', ') + ' — CP-SAT motorunu kullanın.';
    if (c.taslak) metin += ' Ekrandaki program bir taslaktır (yerleşebilen dersler).';
    if (r.eski) { basarili = false; metin = 'Bu program yapıldıktan sonra veriler ya da kurallar değişti; kural denetimi için yeniden dağıtın ya da “Dağıtımı kontrol et”e basın.'; }
    return '<div class="sonuc-bandi ' + (r.eski ? 'eski' : (basarili ? 'iyi' : 'kotu')) + ' yazdirma-gizle"><div class="sb-sol"><span class="etiket ' + a[0] + '">' + esc(a[1]) + '</span>' +
      '<b>' + (r.eski ? 'Program güncel değil' : (basarili ? 'Dağıtım başarılı' : 'Dağıtım tamamlanamadı')) + '</b><span class="ince">' + esc(c.motor || '') + (c.asama ? ' · ' + esc(c.asama) + ' aşaması' : '') + ' · ' + ((r.istatistik.sureMs || 0) / 1000).toFixed(1) + ' sn</span></div>' +
      '<p>' + esc(metin) + (ihl.length ? ' <b>' + ihl.length + ' kural ihlali.</b>' : '') + '</p>' +
      '<div class="satir"><button class="btn kucuk" data-a="rapor-ac">' + (ui.raporAcik ? 'Raporu gizle' : 'Dağıtım raporu') + '</button><button class="btn kucuk" data-a="dagitim-kontrol">' + ikon('tamam') + 'Dağıtımı kontrol et</button><button class="btn kucuk" data-a="excel">' + ikon('indir') + 'Excel</button></div></div>';
  }
  function raporKarti(r) {
    if (!ui.raporAcik) return '';
    var c = sonucDurumu(r), sekme = ui.raporSekme || 'ozet';
    var ihl = c.kuralIhlalleri || [], on = c.onDenetim || {};
    var h = '<div class="kart rapor-karti yazdirma-gizle"><div class="satir" style="margin-bottom:12px">' + sekmeler('rapor-sekme', sekme, [['ozet', 'Özet'], ['asamalar', 'Aşamalar'], ['denetim', 'Ön denetim' + ((on.hatalar || []).length ? ' (' + on.hatalar.length + ')' : '')], ['ihlal', 'Kural ihlalleri' + (ihl.length ? ' (' + ihl.length + ')' : '')], ['kalite', 'Kalite analizi']]) + '</div>';
    if (sekme === 'ozet') {
      var mb = c.modelBoyutu;
      h += '<table class="tablo sik"><tr><td>Çözücü durumu</td><td><b>' + esc((DURUM_ACIKLAMA[c.durum] || [0, c.durum])[1]) + '</b> — ' + esc((DURUM_ACIKLAMA[c.durum] || [0, 0, ''])[2]) + '</td></tr>' +
        '<tr><td>Motor / aşama</td><td>' + esc(c.motor || '—') + (c.asama ? ' · ' + esc(c.asama) : '') + '</td></tr>' +
        (c.motor === 'Genetik' ? '<tr><td>Genetik arama</td><td>' + (+c.nesil || 0) + ' kuşak · ' + (+c.degerlendirme || 0) + ' aday</td></tr>' : '') +
        (mb ? '<tr><td>Model boyutu</td><td>' + mb.degisken + ' değişken · ' + mb.kisit + ' kısıt · ' + mb.oturum + ' ders oturumu · ' + mb.baslangic + ' geçerli başlangıç</td></tr>' : '') +
        '<tr><td>Süre</td><td>' + ((r.istatistik.sureMs || 0) / 1000).toFixed(1) + ' sn' + (c.isci ? ' · ' + c.isci + ' işlemci' : '') + '</td></tr>' +
        (c.kanit ? '<tr><td>Kanıt</td><td>' + esc(c.kanit) + '</td></tr>' : '') +
        (c.gecisNotu ? '<tr><td>Motor değişimi</td><td>' + esc(c.gecisNotu) + '</td></tr>' : '') + '</table>';
      if ((c.motorGecmisi || []).length) h += '<h4>Motor denemeleri</h4><table class="tablo sik"><tr><th>Motor</th><th>Durum</th><th>Süre</th><th>Açıklama</th></tr>' + c.motorGecmisi.map(function (x) { return '<tr><td>' + esc(x.motor) + '</td><td>' + esc(x.durum) + '</td><td>' + ((x.sureMs || 0) / 1000).toFixed(1) + ' sn</td><td>' + esc(x.aciklama || '—') + '</td></tr>'; }).join('') + '</table>';
      if (c.oncekiCpsat) h += '<p class="ince">Önceki CP-SAT durumu: ' + esc(c.oncekiCpsat.durum) + (c.oncekiCpsat.kanit ? ' · ' + esc(c.oncekiCpsat.kanit) : '') + '</p>';
      if ((c.cekirdekOneriler || []).length) {
        h += '<div class="uyari hata">' + ikon('uyari') + '<div><b>Akıllı Çakışma Teşhisi — Birlikte sağlanamayan kurallar (çözücü kanıtladı):</b><ul>' +
          c.cekirdekOneriler.map(function (x) {
            return '<li><b>' + esc(x.mesaj) + '</b><br><span class="ince">→ Öneri: ' + esc(x.oneri) + '</span></li>';
          }).join('') + '</ul></div></div>';
      } else if ((c.cekirdek || []).length) {
        h += '<div class="uyari hata">' + ikon('uyari') + '<div><b>Birlikte sağlanamayan kurallar (çözücü kanıtladı):</b><ul>' + c.cekirdek.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>Bu kurallardan en az birini gevşetin (kapalı saat, kilit, günlük sınır…) ya da Esnetme izinlerini açın.</div></div>';
      }
      if (r.yerlesmeyen.length) h += '<div class="uyari dikkat">' + ikon('uyari') + '<div><b>Yerleşmeyen dersler (' + r.istatistik.eksikSaat + ' saat):</b><ul>' + r.yerlesmeyen.slice(0, 30).map(function (y) {
        var d = r.dersler[y.dersId] || {}; return '<li>' + esc((sube(d.subeId) || {}).ad) + ' · ' + esc(d.ders) + ' (' + y.uzunluk + ' saat)' + (y.neden ? ' — ' + esc(y.neden) : '') + '</li>';
      }).join('') + '</ul>Bunlar olası nedenlerdir; kesin çelişki yalnız yukarıda “kanıtladı” diye belirtilenlerdir.</div></div>';
    } else if (sekme === 'asamalar') {
      var as = c.asamalar || [];
      h += as.length ? '<table class="tablo sik"><tr><th>Aşama</th><th>Durum</th><th class="s">Süre</th><th>Korunan kurallar</th><th>Esnetilen</th></tr>' + as.map(function (x) {
        return '<tr><td><b>' + esc(x.ad) + '</b>' + (x.amac && Object.keys(x.amac).length ? '<br><small class="ince">' + Object.keys(x.amac).map(function (p) { return ONCELIK_AD[p] + ': ' + (x.amac[p].deger == null ? '—' : x.amac[p].deger) + ' (' + x.amac[p].durum + ')'; }).join(' · ') + '</small>' : '') + '</td><td><span class="etiket ' + ((DURUM_ACIKLAMA[x.durum] || [''])[0]) + '">' + esc(x.durum) + '</span></td><td class="s">' + ((x.sureMs || 0) / 1000).toFixed(1) + ' sn</td>' +
          '<td class="ince">' + esc((x.korunan || []).join(', ')) + '</td><td class="ince">' + esc((x.esnetilen || []).join('; ') || '—') + '</td></tr>';
      }).join('') + '</table>' : '<p class="ince">' + (c.motor === 'Hızlı' || c.motor === 'Genetik' ? 'Tarayıcı motorları CP-SAT aşama raporu oluşturmaz; Genetik motorun kuşak ve aday sayıları özet ve motor geçmişinde gösterilir.' : 'Aşama bilgisi yok.') + '</p>';
    } else if (sekme === 'denetim') {
      h += (on.hatalar || []).length ? '<div class="uyari hata">' + ikon('uyari') + '<div><b>Dağıtımı engelleyen veri sorunları:</b><ul>' + on.hatalar.map(function (x) { return '<li><b>' + esc(x.kural) + '</b> ' + esc(x.mesaj) + '</li>'; }).join('') + '</ul></div></div>' : '<div class="uyari basari">' + ikon('tamam') + '<div>Ön denetimde engelleyici sorun yok.</div></div>';
      if ((on.uyarilar || []).length) h += '<div class="uyari dikkat">' + ikon('uyari') + '<div><ul>' + on.uyarilar.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div></div>';
      if ((on.bilgiler || []).length) h += '<div class="uyari bilgi">' + ikon('bloklar') + '<div><ul>' + on.bilgiler.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div></div>';
    } else if (sekme === 'ihlal') {
      h += ihl.length ? '<table class="tablo sik"><tr><th>Kural</th><th>Açıklama</th></tr>' + ihl.map(function (x) { return '<tr><td><b>' + esc(x.kural) + '</b></td><td>' + esc(x.mesaj) + '</td></tr>'; }).join('') + '</table>'
        : '<div class="uyari basari">' + ikon('tamam') + '<div>Zorunlu kural ihlali yok (K01–K16 bağımsız denetimden geçti).</div></div>';
    } else {
      var k = kaliteAnalizi(r), o = k.ozet;
      h += '<div class="ozet"><div class="k ' + (k.puan >= 80 ? 'iyi' : k.puan < 60 ? 'kotu' : '') + '"><span>Kalite puanı</span><b>' + k.puan + '/100</b></div>' +
        '<div class="k"><span>Öğretmen boş saati</span><b>' + o.ogretmenBosluk + '</b></div><div class="k"><span>Şube boş saati</span><b>' + o.subeBosluk + '</b></div>' +
        '<div class="k"><span>Ort. gün / öğretmen</span><b>' + o.ortGun + '</b><small>' + o.gunAsimi + ' öğretmende gün isteği aşıldı</small></div>' +
        '<div class="k"><span>Zor ders yığılması</span><b>' + o.zorYigilma + '</b><small>şube-gün · ' + o.dengesizSube + ' dengesiz şube</small></div></div>' +
        '<div class="izgara2"><div><h4>En çok boşluğu olan öğretmenler</h4><table class="tablo sik"><tr><th>Öğretmen</th><th class="s">Boş</th><th class="s">Gün</th><th class="s">En yoğun gün</th></tr>' +
        k.ogretmen.slice().sort(function (a, b) { return b.bosluk - a.bosluk || b.gun - a.gun; }).slice(0, 10).map(function (x) { return '<tr><td>' + esc(x.ad) + '</td><td class="s">' + x.bosluk + '</td><td class="s">' + x.gun + (x.maxGun && x.gun > x.maxGun ? ' <span class="etiket sari">istek ' + x.maxGun + '</span>' : '') + '</td><td class="s">' + x.tepe + '</td></tr>'; }).join('') + '</table></div>' +
        '<div><h4>Şubeler</h4><table class="tablo sik"><tr><th>Şube</th><th class="s">Boş</th><th class="s">Günlük</th><th class="s">Zor (en çok/gün)</th></tr>' +
        k.sube.slice().sort(function (a, b) { return b.bosluk - a.bosluk || (b.enCok - b.enAz) - (a.enCok - a.enAz); }).slice(0, 10).map(function (x) { return '<tr><td>' + esc(x.ad) + '</td><td class="s">' + x.bosluk + '</td><td class="s">' + x.enAz + '–' + x.enCok + '</td><td class="s">' + x.zorMax + '</td></tr>'; }).join('') + '</table></div></div>' +
        '<p class="ince">İlk/son ders tercihine uymayan gün: ' + o.ilkSon + ' · tercih dışı günde ders: ' + o.tercihDisi + ' · nöbet gününde dersi olmayan öğretmen: ' + o.nobetUyumsuz + '</p>';
    }
    return h + '</div>';
  }
  /** Öğretmen çarşafı (öğretmenler satırda, gün/saat sütunda) */
  function ogretmenCarsafTablosu() {
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, harita = hucreHaritasi(), yuk = ogretmenYukleri(dersListesi());
    var h = '<table class="carsaf"><tr><th rowspan="2">Öğretmen</th>';
    for (var d = 0; d < D; d++) h += '<th colspan="' + H + '" class="gunbas">' + M.GUNLER[d] + '</th>';
    h += '</tr><tr>';
    for (d = 0; d < D; d++) for (var s = 0; s < H; s++) h += '<th' + (s === 0 ? ' class="gunbas"' : '') + '>' + (s + 1) + '</th>';
    h += '</tr>';
    durum.ogretmenler.slice().sort(function (a, b) { return a.ad.localeCompare(b.ad, 'tr'); }).forEach(function (o) {
      h += '<tr data-dd2-ara="' + esc(o.ad + ' ' + o.brans) + '"><td class="sube"><button class="carsaf-kisit-dugme" data-a="program-kisit-ac" data-v="ogretmen|' + esc(o.id) + '" title="Gün ve saat kapat/aç">' + esc(o.ad) + ' ⚙</button><small class="ince">' + (yuk[o.id] || 0) + ' sa</small></td>';
      for (var d = 0; d < D; d++) for (var s = 0; s < H; s++) {
        var x = harita['o:' + o.id + ':' + d + '-' + s], kap = (o.kapali || []).indexOf(d + '-' + s) >= 0;
        h += x ? '<td class="d' + (s === 0 ? ' gunbas' : '') + '" data-dd5-slot="' + esc('ogretmen|' + o.id + '|' + d + '|' + s) + '" style="--h:' + M.renk(x.ders) + '"' + (x.kulup ? '' : ' data-ders="' + esc(x.dersId) + '" data-gs="' + d + '|' + s + '"') + carsafOnKilit(x.dersId, d, s) + ' title="' + esc(x.ders + ' — ' + ((sube(x.subeId) || {}).ad || x.subeAd || '')) + '">' + esc((sube(x.subeId) || {}).ad || 'Kulüp') + '<small>' + esc(M.kisaltma(x.ders)) + '</small></td>'
          : '<td class="' + (s === 0 ? 'gunbas ' : '') + (kap ? 'kapali-hucre' : '') + '" data-dd5-slot="' + esc('ogretmen|' + o.id + '|' + d + '|' + s) + '"' + (!durum.sonuc ? ' data-a="carsaf-bos-tik" data-v="' + esc('ogretmen|' + o.id + '|' + d + '|' + s) + '" title="Dersi kilitle veya saati kapat"' : '') + '>' + (kap ? '×' : '') + '</td>';
      }
      h += '</tr>';
    });
    return h + '</table>';
  }
  /** Öğretmen tercihleri penceresi */
  function ogrTercihModal() {
    var o = ogretmen(ui.modal.id), D = +durum.okul.gunSayisi;
    if (!o) { ui.modal = null; return ''; }
    var tg = o.tercihGunler || [];
    return '<div class="modal-arka" data-a="modal-kapat"><div class="modal kucuk-modal" data-durdur="1"><h3>' + esc(o.ad) + ' · tercihler</h3><p class="ince">Tercihler yumuşak kurallardır (Dağıtım kuralları → Tercihler önceliğiyle). Kapalı saatler ise kesindir.</p><div class="form tek">' +
      '<div class="alan">Tercih ettiği günler<div class="satir">' + M.GUNLER.slice(0, D).map(function (g, i) { return '<button class="fcip' + (tg.indexOf(i) >= 0 ? ' aktif' : '') + '" data-a="ogr-tercih-gun" data-v="' + i + '">' + g + '</button>'; }).join('') + '</div><small class="ince">Seçilmezse bütün açık günler eşit.</small></div>' +
      '<label class="izin-satir"><input type="checkbox" data-a="ogr-tercih" data-k="ilkSaatIstemez"' + (o.ilkSaatIstemez ? ' checked' : '') + '><span><b>İlk derse girmesin</b></span></label>' +
      '<label class="izin-satir"><input type="checkbox" data-a="ogr-tercih" data-k="sonSaatIstemez"' + (o.sonSaatIstemez ? ' checked' : '') + '><span><b>Son derse girmesin</b></span></label>' +
      '<label class="izin-satir"><input type="checkbox" data-a="ogr-tercih" data-k="maxGunKesin"' + (o.maxGunKesin ? ' checked' : '') + '><span><b>“Haftada en fazla gün” kesin olsun</b><small>İşaretlenmezse istek olarak uygulanır (3. aşamada esnetilebilir).</small></span></label>' +
      '<label class="alan">Haftalık en fazla boş saat<input type="number" min="0" max="30" data-a="ogr-tercih" data-k="maxBosluk" value="' + (o.maxBosluk != null ? o.maxBosluk : '') + '" placeholder="sınırsız"></label>' +
      '<label class="alan">Etiketler<input type="text" data-a="ogr-tercih" data-k="etiketler" value="' + esc((o.etiketler || []).join(', ')) + '" placeholder="ör. yarı zamanlı"></label></div>' +
      '<div class="satir sag" style="margin-top:14px"><button class="btn ana" data-a="modal-kapat">Tamam</button></div></div></div>';
  }

  /** Bir dersin gerçekleşen blok düzeni ("2+1") */
  function gercekYerlesim(dersId) {
    var r = durum.sonuc;
    if (!r) return '';
    var l = r.yerlesim.filter(function (y) { return y.dersId === dersId; }).map(function (y) { return y.uzunluk; }).sort(function (a, b) { return b - a; });
    return l.join('+');
  }

  // ---------- Resmî çıktılar ----------
  function gorevliAd(g) { var o = durum.ogretmenler.filter(function (x) { return x.gorev === g; })[0]; return o ? o.ad : ''; }
  function belgeAyar() {
    var b = durum.belge;
    var yil = new Date().getFullYear(), ay = new Date().getMonth();
    var ogretimYili = ay >= 6 ? yil + '-' + (yil + 1) : (yil - 1) + '-' + yil;
    return {
      mudurluk: b.mudurluk || (durum.okul.ad || '').toLocaleUpperCase('tr') + ' MÜDÜRLÜĞÜ',
      mudur: b.mudur || gorevliAd('mudur'), mudurYrd: b.mudurYrd || gorevliAd('basyrd') || gorevliAd('yrd'),
      ogretimYili: b.ogretimYili || ogretimYili,
      tarih: b.tarih || new Date().toLocaleDateString('tr-TR'),
      sayi: b.sayi || '',
      nobetDonem: b.nobetDonem != null ? +b.nobetDonem : 0
    };
  }
  function belgeAyarFormu(B, ekAlanlar) {
    var eksik = [['mudur', 'müdür'], ['ogretimYili', 'öğretim yılı'], ['tarih', 'tarih']].filter(function (x) { return !String(B[x[0]] || '').trim(); }).map(function (x) { return x[1]; });
    var acik = ui.belgeAcik != null ? ui.belgeAcik : eksik.length > 0;
    return '<details class="kart katlanir yazdirma-gizle"' + (acik ? ' open' : '') + '><summary data-a="belge-ac"><b>Belge bilgileri</b> <span class="ince">tüm çıktılarda ortak</span>' +
      (eksik.length ? '<span class="etiket sari">Eksik: ' + esc(eksik.join(', ')) + '</span>' : '<span class="etiket yesil">' + esc((B.mudur || '') + ' · ' + (B.ogretimYili || '')) + '</span>') + '</summary><div class="form">' +
      [['mudurluk', 'Başlık (müdürlük)', B.mudurluk], ['mudur', 'Okul müdürü', B.mudur], ['mudurYrd', 'Müdür yardımcısı', B.mudurYrd],
        ['ogretimYili', 'Öğretim yılı', B.ogretimYili], ['tarih', 'Uygulama / tebliğ tarihi', B.tarih], ['sayi', 'Sayı', B.sayi]].map(function (a) {
        return '<label class="alan">' + a[1] + '<input type="text" data-a="belge" data-v="' + a[0] + '" value="' + esc(a[2]) + '"></label>';
      }).join('') + (ekAlanlar || '') + '</div>' +
      (CFG.mod !== 'sunucu' ? '<p class="ince" style="margin:10px 0 0">Önizleme penceresinde yazdırma engelli olabilir; indirdiğiniz HTML dosyasında ya da PHP sürümünde “Yazdır / PDF” ile A4 çıktı alınır.</p>' : '') + '</details>';
  }
  function ciktilarCiz() {
    var B = belgeAyar(), sekme = ui.belgeSekme === 'sube' ? 'sube' : 'ogretmen';
    var h = sayfaBasi('Resmî çıktılar', 'Müdür onaylı A4 öğretmen ders programı (tebliğ) ve şube ders programları. Nöbet çizelgesi “Nöbet programı” sayfasındadır.',
      (durum.sonuc ? '<button class="btn" data-a="excel-indir">' + ikon('indir') + 'Excel İndir (.xls)</button>' : '') +
      '<button class="btn ana" data-a="yazdir">' + ikon('yazdir') + 'Yazdır / PDF</button>');
    h += belgeAyarFormu(B, '<label class="alan">Tebliğde nöbet dönemi<select data-a="belge" data-v="nobetDonem">' + durum.nobet.donemler.map(function (d, i) { return '<option value="' + i + '"' + (i === B.nobetDonem ? ' selected' : '') + '>' + esc(d.aralik) + '</option>'; }).join('') + '</select></label>');
    h += '<div class="satir yazdirma-gizle" style="margin-bottom:12px">' + sekmeler('belge-sekme', sekme, [['ogretmen', 'Öğretmen programları'], ['sube', 'Şube programları']]);
    var liste = sekme === 'ogretmen' ? durum.ogretmenler.slice().sort(function (a, b) { return a.ad.localeCompare(b.ad, 'tr'); }) : durum.subeler;
    h += '<select data-a="belge-sec"><option value="">Tümü (' + liste.length + ' sayfa)</option>' + liste.map(function (x) { return '<option value="' + x.id + '"' + (ui.belgeSecim === x.id ? ' selected' : '') + '>' + esc(x.ad) + '</option>'; }).join('') + '</select></div>';
    if (!durum.sonuc) return '<div class="dd4-page dd4-cikti-page">' + h + '<div class="dd4-empty dd4-yuzey"><div class="dd4-empty-simge">' + ikon('ciktilar') + '</div><h3>Henüz yazdırılacak dağıtım bulunmuyor</h3><p>Şube ve öğretmen programlarını yerleştirdikten sonra A4 çıktı önizlemesi burada görünür.</p><button class="btn ana" data-a="adim" data-v="dagitim">Dağıtım merkezine git</button></div></div>';
    var sayfaSayisi = ui.belgeSecim ? 1 : liste.length;
    var uyar = !sonucGuvenliMi(durum.sonuc) ? '<span class="dd4-cikti-uyari" role="alert">TASLAK — ders programı tüm zorunlu kurallar açısından doğrulanmadı. Resmî kullanım öncesi Dağıtımı Kontrol Et işlemini çalıştırın.</span>' : '';
    var arac = '<div class="dd4-cikti-arac yazdirma-gizle"><div><span class="dd4-kicker">BASKI ÖNİZLEMESİ</span><b>A4 dikey · ' + sayfaSayisi + ' sayfa</b>' + uyar + '</div><div class="dd4-cikti-islemler"><span>Tarayıcıdaki Yazdır / PDF ekranında “PDF olarak kaydet” seçilebilir.</span><button class="btn ana" data-a="yazdir">' + ikon('yazdir') + 'Yazdır / PDF</button></div></div>';
    return '<div class="dd4-page dd4-cikti-page">' + h + arac + '<div class="dd4-kagit-cerceve"><div id="belgeler">' + belgeSayfalari(B, sekme) + '</div></div></div>';
  }
  function belgeSayfalari(B, sekme) {
    if (sekme === 'nobet') return durum.ogretmenler.length ? nobetBelgesi(B) : '';
    if (!durum.sonuc) return '';
    var secili = ui.belgeSecim, h = '';
    if (sekme === 'ogretmen') {
      durum.ogretmenler.slice().sort(function (a, b) { return a.ad.localeCompare(b.ad, 'tr'); })
        .filter(function (o) { return !secili || o.id === secili; }).forEach(function (o) { h += ogretmenBelgesi(o, B); });
    } else {
      durum.subeler.filter(function (sb) { return !secili || sb.id === secili; }).forEach(function (sb) { h += subeBelgesi(sb, B); });
    }
    return h;
  }

  // ---------- Nöbet programı ----------
  function nobetHazirla() { return durum.nobet; }
  /** Öğretmen başına günlük ders saati sayıları (dağıtım sonucundan) */
  function dersGunSayilari() {
    var D = +durum.okul.gunSayisi, out = {}, r = durum.sonuc;
    durum.ogretmenler.forEach(function (o) { out[o.id] = new Array(D).fill(0); });
    if (r) r.yerlesim.forEach(function (y) { var d = r.dersler[y.dersId]; if (d && d.ogretmenId && out[d.ogretmenId] && y.gun < D) out[d.ogretmenId][y.gun] += y.uzunluk; });
    return out;
  }
  function dersGunleri() {
    var s = dersGunSayilari(), out = {};
    Object.keys(s).forEach(function (id) { out[id] = {}; s[id].forEach(function (n, g) { if (n) out[id][g] = true; }); });
    return out;
  }
  /**
   * Nöbet dağıtımı. Strateji:
   *  - 'enAz'   : öğretmen, dersinin en az olduğu (ama dersi olan) güne
   *  - 'enCok'  : dersinin en çok olduğu güne
   *  - 'dengeli': günlere eşit sayıda
   * Her gün her nöbet alanının ihtiyaç duyduğu öğretmen sayısı gözetilir; dönemler arasında gün ve alan döner.
   */
  function nobetOtomatik() {
    var N = durum.nobet, D = +durum.okul.gunSayisi, dgs = dersGunSayilari(), varSonuc = !!durum.sonuc;
    var alanlar = N.alanlar.filter(function (a) { return a.ad; });
    var gunIhtiyac = alanlar.reduce(function (a, x) { return a + Math.max(1, +x.kisi || 1); }, 0) || 1;
    var onceki = {};
    N.donemler.forEach(function (dn, di) {
      dn.atama = {}; dn.alan = {};
      var gunSayac = new Array(D).fill(0);
      var alanDolu = []; for (var g0 = 0; g0 < D; g0++) alanDolu.push(alanlar.map(function () { return 0; }));
      var sira = durum.ogretmenler.filter(nobetTutar).sort(function (a, b) {
        var ca = dgs[a.id].filter(Boolean).length, cb = dgs[b.id].filter(Boolean).length;
        return (ca || 9) - (cb || 9) || (a.ad < b.ad ? -1 : 1);
      });
      sira.forEach(function (o, i) {
        var adaylar = [];
        for (var g = 0; g < D; g++) if (!N.bosGunVerme || !varSonuc || dgs[o.id][g] > 0) adaylar.push(g);
        if (!adaylar.length) for (g = 0; g < D; g++) adaylar.push(g);
        var puan = function (g) {
          var p = 0, ders = dgs[o.id][g];
          if (N.strateji === 'enAz') p += ders * 3;
          else if (N.strateji === 'enCok') p -= ders * 3;
          p += gunSayac[g] >= gunIhtiyac ? 40 + gunSayac[g] * 5 : gunSayac[g] * 1.5;   // gün dolduysa ağır ceza
          if (onceki[o.id] && onceki[o.id].g === g) p += 4;                             // dönemler arası döndürme
          return p + ((g + di + i) % D) * 0.01;
        };
        adaylar.sort(function (a, b) { return puan(a) - puan(b); });
        var gun = adaylar[0];
        dn.atama[o.id] = gun; gunSayac[gun]++;
        if (alanlar.length) {
          var ai = alanlar.map(function (a, k) { return k; }).sort(function (a, b) {
            var ba = alanDolu[gun][a] / Math.max(1, +alanlar[a].kisi || 1), bb = alanDolu[gun][b] / Math.max(1, +alanlar[b].kisi || 1);
            var oa = onceki[o.id] && onceki[o.id].a === alanlar[a].ad ? 0.5 : 0, ob = onceki[o.id] && onceki[o.id].a === alanlar[b].ad ? 0.5 : 0;
            return (ba + oa) - (bb + ob);
          })[0];
          alanDolu[gun][ai]++;
          dn.alan[o.id] = alanlar[ai].ad;
        }
      });
      Object.keys(dn.atama).forEach(function (id) { onceki[id] = { g: dn.atama[id], a: dn.alan[id] }; });
    });
    idariNobetOtomatik();
  }
  /**
   * İdari nöbet: her gün "günlük kişi" kadar müdür yardımcısı nöbetçi olur. Günler yardımcılar arasında eşit bölünür;
   * dönemden döneme günler döner (aynı kişi hep aynı güne düşmez).
   */
  function idariNobetOtomatik() {
    var N = durum.nobet, D = +durum.okul.gunSayisi, kisiler = idariNobetciler(), n = kisiler.length, oncekiGun = {};
    var kisi = Math.max(1, Math.min(n || 1, +N.idari.gunlukKisi || 1));
    N.donemler.forEach(function (dn, di) {
      dn.idari = {};
      if (!n) return;
      var say = {};
      kisiler.forEach(function (o) { say[o.id] = 0; dn.idari[o.id] = []; });
      for (var g = 0; g < D; g++) {
        var sec = kisiler.map(function (o, i) { return { o: o, p: say[o.id] * 10 + ((oncekiGun[o.id] || []).indexOf(g) >= 0 ? 3 : 0) + ((i - g - di) % n + n) % n * 0.01 }; })
          .sort(function (a, b) { return a.p - b.p; }).slice(0, kisi);
        sec.forEach(function (x) { say[x.o.id]++; dn.idari[x.o.id].push(g); });
      }
      kisiler.forEach(function (o) { oncekiGun[o.id] = dn.idari[o.id].slice(); });
    });
  }
  function idariGunler(dn, id) { return (dn && dn.idari && dn.idari[id]) || []; }
  function idariNobetMetni(dn, id) {
    var g = idariGunler(dn, id).slice().sort();
    return g.length ? g.map(function (x) { return M.GUNLER[x].toLocaleUpperCase('tr'); }).join(', ') : '—';
  }
  function nobetMetni(dn, ogrId) {
    if (!dn || dn.atama[ogrId] == null) return '—';
    return M.GUNLER[dn.atama[ogrId]].toLocaleUpperCase('tr') + (dn.alan[ogrId] ? ' (' + dn.alan[ogrId] + ')' : '');
  }
  function nobetCiz() {
    var N = durum.nobet, B = belgeAyar(), D = +durum.okul.gunSayisi;
    var nobetVar = N.donemler.some(function (dn) { return Object.keys(dn.atama || {}).length; });
    var h = sayfaBasi('Nöbet programı', 'Nöbet yerlerini ve dönemleri tanımlayın; nöbetleri öğretmenin dersinin en az ya da en çok olduğu güne, veya günlere dengeli dağıtın.',
      '<button class="btn' + (nobetVar ? '' : ' ana') + '" data-a="nobet-oto">' + ikon('nobet') + 'Nöbetleri otomatik dağıt</button><button class="btn' + (nobetVar ? ' ana' : '') + '" data-a="yazdir">' + ikon('yazdir') + 'Yazdır / PDF</button>');
    if (!nobetVar) h += '<div class="uyari bilgi yazdirma-gizle">' + ikon('nobet') + '<div><b>Nöbetler henüz dağıtılmadı.</b> Nöbet yerlerini ve dönemleri kontrol edip “Nöbetleri otomatik dağıt”a basın' + (durum.sonuc ? '' : ' (önce ders programını oluşturmanız önerilir; nöbet günü derslere göre seçilir)') + '.</div></div>';
    h += '<div class="izgara2 yazdirma-gizle">';
    h += '<div class="kart"><h3>Dağıtım kuralı</h3><div class="form tek">' +
      '<label class="alan">Nöbet günü seçimi<select data-a="nobet-strateji">' + [['dengeli', 'Dengeli — günlere eşit sayıda'], ['enAz', 'Dersinin en az olduğu gün'], ['enCok', 'Dersinin en çok olduğu gün']].map(function (x) { return '<option value="' + x[0] + '"' + (N.strateji === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></label>' +
      '<label class="satir-alan"><input type="checkbox" data-a="nobet-bosgun"' + (N.bosGunVerme ? ' checked' : '') + '> Dersi olmayan güne nöbet verme</label>' +
      '<label class="satir-alan"><input type="checkbox" data-a="nobet-yonetici"' + (N.yoneticiHaric ? ' checked' : '') + '> Okul müdürü ve müdür yardımcıları öğretmen nöbeti tutmaz</label></div>' +
      (durum.sonuc ? '' : '<p class="ince">Dağıtım yapılmadığı için öğretmenlerin ders günleri bilinmiyor; nöbetler günlere dengeli dağıtılır.</p>') + '</div>';
    h += '<div class="kart"><h3>Nöbet yerleri <span class="ek">günlük öğretmen sayısı</span></h3>' + N.alanlar.map(function (a, i) {
      return '<div class="satir" style="margin-bottom:6px"><input type="text" data-a="nobet-alan-ad" data-v="' + i + '" value="' + esc(a.ad) + '" placeholder="Nöbet yeri" style="flex:1">' +
        '<input type="number" min="1" max="10" data-a="nobet-alan-kisi" data-v="' + i + '" value="' + (a.kisi || 1) + '" style="width:70px" title="Günde kaç öğretmen">' +
        '<button class="btn ikon-btn tehlike" data-a="nobet-alan-sil" data-v="' + i + '" title="Sil">' + ikon('cop') + '</button></div>';
    }).join('') + '<button class="btn kucuk" data-a="nobet-alan-ekle">' + ikon('artı') + 'Nöbet yeri ekle</button>' +
      '<p class="ince">Günlük ihtiyaç: ' + N.alanlar.reduce(function (a, x) { return a + (+x.kisi || 1); }, 0) + ' öğretmen × ' + D + ' gün = ' + N.alanlar.reduce(function (a, x) { return a + (+x.kisi || 1); }, 0) * D + ' · Nöbet tutan öğretmen: ' + durum.ogretmenler.filter(nobetTutar).length + '</p></div>';
    h += '<div class="kart"><h3>Dönemler <span class="ek">tarih aralıkları</span></h3>' + N.donemler.map(function (d, i) {
      return '<div class="satir" style="margin-bottom:6px"><input type="text" data-a="nobet-aralik" data-v="' + i + '" value="' + esc(d.aralik) + '" style="flex:1">' +
        '<button class="btn ikon-btn tehlike" data-a="nobet-donem-sil" data-v="' + i + '" title="Dönemi sil">' + ikon('cop') + '</button></div>';
    }).join('') + '<button class="btn kucuk" data-a="nobet-donem-ekle">' + ikon('artı') + 'Dönem ekle</button></div>';
    h += idariAyarKarti();
    h += '</div>';
    if (!durum.ogretmenler.length) return h + '<div class="kart bos-durum">Önce öğretmenleri oluşturun.</div>';
    // Gün × alan doluluk özeti (ilk dönem)
    h += '<div class="kart yazdirma-gizle"><h3>Günlük doluluk <span class="ek">her dönem için nöbetçi sayısı / ihtiyaç</span></h3><div class="kaydirma"><table class="tablo"><tr><th>Dönem</th>' + M.GUNLER.slice(0, D).map(function (g) { return '<th class="s">' + g.slice(0, 3) + '</th>'; }).join('') + '</tr>' +
      N.donemler.map(function (dn) {
        var ihtiyac = N.alanlar.reduce(function (a, x) { return a + (+x.kisi || 1); }, 0);
        return '<tr><td>' + esc(dn.aralik) + '</td>' + M.GUNLER.slice(0, D).map(function (_, g) {
          var n = Object.keys(dn.atama).filter(function (id) { return dn.atama[id] === g && nobetTutar(ogretmen(id)); }).length;
          return '<td class="s"><span class="etiket ' + (!Object.keys(dn.atama || {}).length ? '' : (n < ihtiyac ? 'kirmizi' : 'yesil')) + '">' + n + '/' + ihtiyac + '</span></td>';
        }).join('') + '</tr>';
      }).join('') + '</table></div></div>';
    h += belgeAyarFormu(B);
    return h + '<div id="belgeler">' + nobetBelgesi(B) + '</div>';
  }
  function nobetBelgesi(B) {
    var N = durum.nobet, D = +durum.okul.gunSayisi, dg = dersGunleri(), varSonuc = !!durum.sonuc;
    var ogrs = durum.ogretmenler.filter(nobetTutar).sort(function (a, b) { return a.ad.localeCompare(b.ad, 'tr'); });
    var idariVar = idariNobetciler().length > 0 && N.idari.cikti !== 'yok';
    var h = '<section class="kagit serbest"><div class="b-baslik">' + esc(B.mudurluk) + '</div><div class="b-baslik2">' + esc(B.ogretimYili) + ' EĞİTİM ÖĞRETİM YILI ÖĞRETMEN NÖBET PROGRAMI</div>';
    N.donemler.forEach(function (dn, di) {
      h += '<div class="b-nobet"><div class="b-donem"><span>' + esc(dn.aralik) + '</span></div><table class="b-liste"><tr><th class="sol">Öğretmen</th>' +
        M.GUNLER.slice(0, D).map(function (g) { return '<th>' + g.toLocaleUpperCase('tr') + '</th>'; }).join('') + '</tr>' +
        ogrs.map(function (o) {
          return '<tr><td class="sol">' + esc(o.ad) + '</td>' + M.GUNLER.slice(0, D).map(function (_, g) {
            var nob = dn.atama[o.id] === g, bos = varSonuc && !dg[o.id][g];
            return '<td class="' + (nob ? 'nobet' : '') + (bos ? ' bosgun' : '') + '" data-a="nobet-hucre" data-v="' + di + '|' + o.id + '|' + g + '">' + (nob ? esc(dn.alan[o.id] || 'NÖBET') : '') + '</td>';
          }).join('') + '</tr>';
        }).join('') + '</table></div>';
    });
    h += '<p class="b-not yazdirma-gizle">Taralı hücreler öğretmenin dersi olmayan günleridir. Hücreye tıklamak o güne nöbet verir; aynı hücreye tekrar tıklamak nöbet yerini değiştirir, son yerden sonra nöbeti kaldırır.</p>';
    if (idariVar && N.idari.cikti === 'alt') h += '<div class="b-alt-baslik">İDARİ NÖBET (MÜDÜR YARDIMCILARI)</div>' + idariNobetTablolari(B);
    h += imzaBlogu(B) + '</section>';
    if (idariVar && N.idari.cikti === 'ayri') h += idariNobetBelgesi(B);
    return h;
  }
  function imzaBlogu(B) {
    return '<div class="b-imza"><div>……………………………<br>……………………………<br>ASLINI TESLİM ALDIM<br><br>HAZIRLAYAN<br><br>' + esc(B.mudurYrd || '……………………') + '<br>Müdür Yardımcısı</div><div class="sag"><br><br><br><br>ONAY<br><br>' + esc(B.mudur || '……………………') + '<br>Okul Müdürü</div></div>';
  }
  /** İdari nöbet tabloları: satırlar müdür yardımcıları, sütunlar günler; hücreye tıklamak o günü verir/kaldırır */
  function idariNobetTablolari(B) {
    var N = durum.nobet, D = +durum.okul.gunSayisi, kisiler = idariNobetciler(), h = '';
    N.donemler.forEach(function (dn, di) {
      h += '<div class="b-nobet"><div class="b-donem"><span>' + esc(dn.aralik) + '</span></div><table class="b-liste"><tr><th class="sol">Müdür Yardımcısı</th>' +
        M.GUNLER.slice(0, D).map(function (g) { return '<th>' + g.toLocaleUpperCase('tr') + '</th>'; }).join('') + '</tr>' +
        kisiler.map(function (o) {
          var gun = idariGunler(dn, o.id);
          return '<tr><td class="sol">' + esc(o.ad) + (o.gorev === 'basyrd' ? ' <small>(Başyrd.)</small>' : '') + '</td>' + M.GUNLER.slice(0, D).map(function (_, g) {
            var var_ = gun.indexOf(g) >= 0;
            return '<td class="' + (var_ ? 'nobet' : '') + '" data-a="idari-hucre" data-v="' + di + '|' + o.id + '|' + g + '">' + (var_ ? 'İDARİ NÖBET' : '') + '</td>';
          }).join('') + '</tr>';
        }).join('') +
        '<tr class="b-ozet"><td class="sol">Günün nöbetçisi</td>' + M.GUNLER.slice(0, D).map(function (_, g) {
          var l = kisiler.filter(function (o) { return idariGunler(dn, o.id).indexOf(g) >= 0; });
          return '<td class="' + (l.length ? '' : 'idari-bos') + '">' + (l.length ? l.map(function (o) { return esc(o.ad); }).join('<br>') : '—') + '</td>';
        }).join('') + '</tr></table></div>';
    });
    return h + '<p class="b-not yazdirma-gizle">Hücreye tıklamak o güne idari nöbet verir ya da kaldırır.</p>';
  }
  function idariNobetBelgesi(B) {
    return '<section class="kagit serbest"><div class="b-baslik">' + esc(B.mudurluk) + '</div><div class="b-baslik2">' + esc(B.ogretimYili) + ' EĞİTİM ÖĞRETİM YILI İDARİ NÖBET ÇİZELGESİ</div>' +
      idariNobetTablolari(B) +
      '<div class="b-imza"><div></div><div class="sag"><br><br>ONAY<br><br>' + esc(B.mudur || '……………………') + '<br>Okul Müdürü</div></div></section>';
  }
  function idariAyarKarti() {
    var N = durum.nobet, kisiler = idariNobetciler(), yon = durum.ogretmenler.filter(yoneticiMi);
    var h = '<div class="kart"><h3>İdari nöbet <span class="ek">müdür yardımcıları</span></h3>';
    if (!yon.length) {
      return h + '<p class="ince">Okul müdürü ve müdür yardımcılarını <a href="#" data-a="adim" data-v="ogretmenler">Öğretmen listesi</a>nde <b>Görev</b> sütunundan seçin. ' +
        'Müdür ve yardımcıları öğretmen nöbetine girmez; müdür yardımcıları için ayrı idari nöbet çizelgesi hazırlanır.</p></div>';
    }
    h += '<p class="ince" style="margin-top:0">' + yon.map(function (o) { return '<b>' + esc(o.ad) + '</b> (' + esc(GOREV_AD[o.gorev]) + ')'; }).join(', ') + '</p>';
    h += '<div class="form tek">' +
      '<label class="alan">Her gün kaç müdür yardımcısı nöbetçi<input type="number" min="1" max="5" data-a="idari-kisi" value="' + (N.idari.gunlukKisi || 1) + '" style="width:80px"></label>' +
      '<label class="satir-alan"><input type="checkbox" data-a="idari-basyrd"' + (N.idari.basyrd ? ' checked' : '') + '> Müdür başyardımcısı da idari nöbet tutar</label>' +
      '<label class="alan">İdari nöbet çıktısı<select data-a="idari-cikti">' + [['ayri', 'Ayrı sayfa (İdari Nöbet Çizelgesi)'], ['alt', 'Öğretmen nöbet çizelgesiyle aynı sayfada'], ['yok', 'Nöbet çıktısında gösterme']].map(function (x) { return '<option value="' + x[0] + '"' + (N.idari.cikti === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></label></div>' +
      '<p class="ince">' + (kisiler.length ? kisiler.length + ' kişi idari nöbet tutar. İdari nöbet günleri ayrıca müdür yardımcısının ders programı (tebliğ) çıktısında “İdari Nöbet Günü” olarak yazar.' : 'İdari nöbet tutacak müdür yardımcısı yok.') + '</p>' +
      (kisiler.length ? '<button class="btn kucuk" data-a="idari-oto">' + ikon('nobet') + 'Yalnız idari nöbeti dağıt</button>' : '');
    return h + '</div>';
  }

  // ---------- Kaynaklar ----------
  function kaynaklarCiz() {
    var sekme = ui.kaynakSekme || 'turler';
    var h = sayfaBasi('Kaynaklar', 'MEB Talim ve Terbiye Kurulu Başkanlığı haftalık ders çizelgeleri, okul türlerine göre ayrım ve programın kullandığı veriler.',
      sekmeler('kaynak-sekme', sekme, [['turler', 'Okul türlerine göre ayrım'], ['cizelge', 'Seçili türün çizelgesi'], ['meb', 'MEB TTKB çizelge listesi'], ['havuz', 'Seçmeli havuzları'], ['kaynakca', 'Kaynakça']]));
    if (sekme === 'cizelge') return h + cizelgeCiz();
    if (sekme === 'meb') return h + mebListesiCiz();
    if (sekme === 'havuz') return h + havuzlarCiz();
    if (sekme === 'kaynakca') return h + kaynakcaCiz();
    // Okul türleri
    var kademeler = {};
    VERI.okulTurleri.forEach(function (x) { (kademeler[x.kademe] = kademeler[x.kademe] || []).push(x); });
    Object.keys(kademeler).forEach(function (k) {
      h += '<div class="kart"><h3>' + esc(k) + ' <span class="ek">' + kademeler[k].length + ' okul türü</span></h3><div class="kaydirma"><table class="tablo"><tr><th>Okul türü</th><th>Sınıflar</th><th class="s">Haftalık</th><th class="s">Zorunlu ders</th><th>Seçmeli saati</th><th>Ders grupları</th><th>Çizelge</th><th></th></tr>' +
        kademeler[k].map(function (x) {
          var gruplar = {};
          x.dersler.forEach(function (r) { gruplar[r[1]] = (gruplar[r[1]] || 0) + 1; });
          return '<tr' + (x.id === durum.okul.turId ? ' class="secili-satir"' : '') + '><td><b>' + esc(x.ad) + '</b></td><td>' + x.siniflar.map(function (s) { return s === 'Hz' ? 'Hazırlık' : s; }).join(', ') + '</td>' +
            '<td class="s">' + Array.from(new Set(x.toplam)).join('/') + '</td><td class="s">' + x.dersler.length + '</td><td>' + x.secmeliSaat.join(' · ') + '</td>' +
            '<td>' + Object.keys(gruplar).map(function (g) { return '<span class="etiket ' + esc(g) + '">' + esc(g) + ' ' + gruplar[g] + '</span>'; }).join(' ') + '</td>' +
            '<td class="nowrap"><a href="' + esc(x.kaynakUrl) + '" target="_blank" rel="noopener">PDF</a> · ' + esc(x.kararTarihi) + '</td>' +
            '<td>' + (x.id === durum.okul.turId ? '<span class="etiket yesil">seçili</span>' : '') + '</td></tr>';
        }).join('') + '</table></div></div>';
    });
    return h;
  }
  function havuzlarCiz() {
    return Object.keys(VERI.havuzlar).map(function (k) {
      var hv = VERI.havuzlar[k];
      var kullanan = VERI.okulTurleri.filter(function (t) { return t.havuz === k; }).map(function (t) { return t.ad; });
      return '<div class="kart"><h3>' + (k === 'lise' ? 'Ortaöğretim' : 'Ortaokul') + ' seçmeli havuzu <span class="ek">' + hv.dersler.length + ' ders · ' + esc(kullanan.join(', ')) + '</span></h3><div class="izgara2">' +
        hv.gruplar.map(function (g) {
          var l = hv.dersler.filter(function (d) { return d[1] === g; });
          return '<div class="sinif-blok"><h4>' + esc(g) + ' <span class="etiket">' + l.length + '</span></h4><table class="tablo">' +
            l.map(function (d) { return '<tr><td>' + esc(d[0]) + '</td><td class="ince">' + d[2].join(', ') + '</td><td class="ince">' + esc(d[4]) + '</td></tr>'; }).join('') + '</table></div>';
        }).join('') + '</div></div>';
    }).join('');
  }
  function kaynakcaCiz() {
    var h = '<div class="kart"><h3>Veri kaynağı</h3><ul class="kaynak-liste">' +
      '<li><b>MEB Talim ve Terbiye Kurulu Başkanlığı — Haftalık Ders Çizelgeleri</b><br><a href="' + esc(VERI.kaynak) + '" target="_blank" rel="noopener">' + esc(VERI.kaynak) + '</a></li>' +
      '<li><b>Liste servisi</b> (PHP sürümünün güncel listeyi çektiği adres): <code>' + esc(VERI.mebListesi ? VERI.mebListesi.adres : '') + '</code>, kategori ' + esc(VERI.mebListesi ? VERI.mebListesi.kategori : 7) + '</li>' +
      '<li><b>Veri sürümü:</b> ' + esc(VERI.surum) + (VERI.mebListesi ? ' · liste çekilme tarihi ' + esc(VERI.mebListesi.cekilme) : '') + '</li>' +
      '<li><b>Yöntem:</b> ' + esc(VERI.aciklama) + '</li></ul></div>';
    h += '<div class="kart"><h3>Okul türü çizelgeleri</h3><table class="tablo"><tr><th>Okul türü</th><th>Kaynak belge</th><th>Karar / yayın</th></tr>' +
      VERI.okulTurleri.map(function (t) { return '<tr><td><b>' + esc(t.ad) + '</b></td><td><a href="' + esc(t.kaynakUrl) + '" target="_blank" rel="noopener">' + esc(t.kaynakBaslik) + '</a></td><td class="nowrap">' + esc(t.kararTarihi) + '</td></tr>'; }).join('') + '</table></div>';
    h += '<div class="kart"><h3>Branş eşlemesi <span class="ek">otomatik öğretmen atamasında kullanılır</span></h3><table class="tablo">' +
      Object.keys(VERI.branslar).map(function (b) { return '<tr><td class="nowrap"><b>' + esc(b) + '</b></td><td class="ince">' + esc(VERI.branslar[b].join(', ')) + '</td></tr>'; }).join('') + '</table></div>';
    return h;
  }

  // ---------- Veri ve yedek ----------
  function disaAktarMetni() {
    return JSON.stringify({ uygulama: 'ders-dagitim', surum: DURUM_SURUMU, veriSurumu: VERI.surum, tarih: new Date().toISOString(), durum: durum }, null, 1);
  }
  function jsonIndir() {
    var metin = disaAktarMetni();
    var ad = (durum.okul.ad || 'ders-programi').replace(/[^\wçğıöşüÇĞİÖŞÜ -]/g, '').trim() + ' - ' + new Date().toISOString().slice(0, 10) + '.json';
    // claude.ai yayınında indirme, sayfanın 'downloads' yeteneğiyle (izleyici onayıyla) yapılır
    if (ui.indirme) {
      ui.indirme.save({ filename: ad, data: metin }).then(function () { bildir('“' + ad + '” indirildi.'); }, function (err) {
        if (err && err.code === 'declined') bildir('İndirme iptal edildi.');
        else bildir('İndirme yapılamadı; “Panoya kopyala”yı kullanın.', 'hata');
      });
      return;
    }
    if (window.AndroidKopru && window.AndroidKopru.dosyaIndir) {
      window.AndroidKopru.dosyaIndir(ad, 'application/json', metin);
      return;
    }
    try {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([metin], { type: 'application/json' }));
      a.download = ad;
      document.body.appendChild(a); a.click(); a.remove();
      bildir('“' + ad + '” indirildi.');
    } catch (e) { bildir('İndirme bu pencerede engelli; “Panoya kopyala”yı kullanın.', 'hata'); }
  }
  function jsonUygula(metin) {
    var j;
    try { j = JSON.parse(metin); } catch (e) { bildir('Dosya geçerli bir JSON değil.', 'hata'); return; }
    var d = j && j.durum ? j.durum : j;
    if (!d || !d.okul || !M.turBul(VERI, d.okul.turId)) { bildir('Bu dosya ders dağıtım verisi değil ya da okul türü tanınmıyor.', 'hata'); return; }
    onayla('Veriler yüklensin mi?', '<b>' + esc(d.okul.ad) + '</b> (' + esc(M.turBul(VERI, d.okul.turId).ad) + ', ' + (d.subeler || []).length + ' şube, ' + (d.ogretmenler || []).length + ' öğretmen) yüklenecek. Şu anki verilerin yerini alır.', 'Yükle', function () {
      var projeId = durum.projeId, projeRev = durum.projeRev;
      durum = gocEt(d);
      delete durum.projeId; delete durum.projeRev;
      if (CFG.mod === 'sunucu' && projeId) { durum.projeId = projeId; durum.projeRev = projeRev; }
      degisti(); ui.adim = 'okul'; ciz(); bildir('Veriler yüklendi.');
    }, true);
  }
  function veriCiz() {
    var h = sayfaBasi('Veri ve yedek', '');
    var boyut = Math.round(disaAktarMetni().length / 1024);
    h += '<div class="izgara2">';
    h += '<div class="kart"><h3>' + ikon('kaydet') + ' Otomatik kayıt</h3>' +
      '<p class="ince">Proje boyutu: ' + boyut + ' KB · ' + durum.subeler.length + ' şube · ' + durum.ogretmenler.length + ' öğretmen · ' + durum.dagitimKayitlari.length + ' kayıtlı dağıtım</p></div>';
    h += '<div class="kart"><h3>' + ikon('indir') + ' JSON indir</h3>' +
      '<div class="satir"><button class="btn ana" data-a="json-indir">' + ikon('indir') + 'JSON indir</button><button class="btn" data-a="json-kopyala">Panoya kopyala</button></div></div>';
    h += '<div class="kart"><h3>' + ikon('yukle') + ' JSON yükle</h3>' +
      '<div class="satir"><label class="btn dosya-sec">' + ikon('yukle') + 'Dosya seç (.json)<input type="file" class="gizli-girdi" accept=".json,application/json" data-a="json-dosya"></label></div>' +
      '<details style="margin-top:8px"><summary>Metinden yükle</summary><textarea id="json-metin" rows="5" style="width:100%;margin-top:8px" placeholder="{ &quot;uygulama&quot;: &quot;ders-dagitim&quot;, ... }"></textarea><button class="btn" data-a="json-metinden">Yükle</button></details></div>';
    h += '<div class="kart tehlike-kart"><h3>' + ikon('cop') + ' Sıfırla</h3><button class="btn tehlike" data-a="sifirla">Tüm verileri sıfırla</button></div>';
    if (CFG.mod === 'sunucu') {
      h += '<div class="kart" style="grid-column:1/-1;min-width:0"><h3>' + ikon('veri') + ' Hesabınızdaki projeler</h3>' + (ui.projeler.length ? '<div class="kaydirma"><table class="tablo"><tr><th>Ad</th><th>Tür</th><th>Güncelleme</th><th class="s">İşlem</th></tr>' + ui.projeler.map(function (p) {
        var t = M.turBul(VERI, p.okul_turu);
        return '<tr' + (durum.projeId == p.id ? ' class="secili-satir"' : '') + '><td><b>' + esc(p.ad) + '</b> <span class="ince">#' + esc(p.id) + '</span></td><td>' + esc(t ? t.ad : p.okul_turu) + '</td><td class="ince nowrap">' + esc(p.guncelleme) + '</td>' +
          '<td class="s nowrap"><button class="btn kucuk" data-a="proje-ac" data-v="' + esc(p.id) + '">Aç</button> <button class="btn ikon-btn tehlike" data-a="proje-sil" data-v="' + esc(p.id) + '" title="Projeyi sil">' + ikon('cop') + '</button></td></tr>';
      }).join('') + '</table></div>' : '<p class="ince">Kayıtlı proje yok.</p>') + '<div class="satir" style="margin-top:10px"><button class="btn" data-a="yeni">' + ikon('artı') + 'Yeni proje</button></div></div>';
    }
    return h + '</div>';
  }

  // ---------- Dağıtımı çalıştır ----------
  // ---------- 2. Çizelge ----------
  function cizelgeCiz() {
    var t = tur();
    var h = '<div class="uyari bilgi">' + ikon('kaynaklar') + '<div><b>' + esc(t.ad) + '</b> — kaynak: <a href="' + esc(t.kaynakUrl) + '" target="_blank" rel="noopener">' + esc(t.kaynakBaslik) + '</a> (' + esc(t.kararTarihi) + ')</div></div>';
    h += '<div class="kart kaydirma"><table class="tablo"><tr><th>Ders</th><th>Grup</th><th>Branş</th>' + t.siniflar.map(function (s) { return '<th class="s">' + esc(s) + '</th>'; }).join('') + '</tr>';
    var gruplar = [];
    t.dersler.forEach(function (r) { if (gruplar.indexOf(r[1]) < 0) gruplar.push(r[1]); });
    gruplar.forEach(function (g) {
      t.dersler.filter(function (r) { return r[1] === g; }).forEach(function (r) {
        h += '<tr><td>' + esc(r[0]) + '</td><td><span class="etiket ' + esc(r[1]) + '">' + esc(r[1]) + '</span></td><td class="ince">' + esc(M.bransBul(r[0], VERI.branslar)) + '</td>' +
          r[2].map(function (v) { return '<td class="s' + (v ? '' : ' sifir') + '">' + (v || '–') + '</td>'; }).join('') + '</tr>';
      });
      if (g !== 'Rehberlik') {
        h += '<tr class="ara"><td colspan="3">' + esc(g) + ' ders saati toplamı</td>' + t.siniflar.map(function (s, i) {
          return '<td class="s">' + t.dersler.filter(function (r) { return r[1] === g; }).reduce(function (a, r) { return a + r[2][i]; }, 0) + '</td>';
        }).join('') + '</tr>';
      }
    });
    h += '<tr><td>Seçmeli dersler</td><td><span class="etiket Seçmeli">Seçmeli</span></td><td class="ince">havuzdan</td>' + t.secmeliSaat.map(function (v) { return '<td class="s">' + (v || '–') + '</td>'; }).join('') + '</tr>';
    h += '<tr class="toplam"><td colspan="3">Toplam haftalık ders saati</td>' + t.toplam.map(function (v) { return '<td class="s">' + v + '</td>'; }).join('') + '</tr></table></div>';

    var havuz = VERI.havuzlar[t.havuz];
    h += '<div class="kart"><h3>Seçmeli ders havuzu <span class="ek">' + havuz.dersler.length + ' ders · parantezli değerler çizelgedeki saat seçenekleridir</span></h3><div class="izgara2">';
    havuz.gruplar.forEach(function (g) {
      var l = havuz.dersler.filter(function (d) { return d[1] === g; });
      h += '<div class="sinif-blok"><h4>' + esc(g) + ' <span class="etiket">' + l.length + '</span></h4><table class="tablo">' +
        l.map(function (d) { return '<tr><td>' + esc(d[0]) + '</td><td class="ince">' + d[2].join(', ') + '</td><td class="ince">' + esc(d[4]) + '</td></tr>'; }).join('') + '</table></div>';
    });
    h += '</div></div>';
    return h;
  }

  function mebListesiCiz() {
    var L = ui.mebListesi || VERI.mebListesi;
    if (!L) return '';
    var kullanilan = {};
    VERI.okulTurleri.forEach(function (x) { kullanilan[decodeURIComponent(x.kaynakUrl)] = x.ad; });
    var h = '<div class="kart"><div class="satir" style="margin-bottom:10px"><h3 style="margin:0">MEB TTKB çizelge listesi <span class="ek">' +
      (ui.mebListesi ? 'şimdi sunucudan çekildi' : 'son çekilme: ' + esc(L.cekilme)) + ' · ' + L.kayitlar.length + ' kayıt</span></h3><span class="bosluk" style="flex:1"></span>' +
      (CFG.mod === 'sunucu' ? '<button class="btn" data-a="meb-cek">TTKB’den güncel listeyi çek</button>' : '<span class="ince">Güncel listeyi çekme PHP sürümünde çalışır.</span>') + '</div>';
    h += '<div class="kaydirma"><table class="tablo"><tr><th>Tarih</th><th>Başlık</th><th>Programda</th></tr>' + L.kayitlar.map(function (k) {
      var ad = kullanilan[decodeURIComponent(k.link)];
      return '<tr><td style="white-space:nowrap">' + esc(k.tarih) + '</td><td><a href="' + esc(k.link) + '" target="_blank" rel="noopener">' + esc(k.baslik) + '</a></td><td>' +
        (ad ? '<span class="etiket Rehberlik">' + esc(ad) + '</span>' : '<span class="ince">—</span>') + '</td></tr>';
    }).join('') + '</table></div></div>';
    return h;
  }

  function hucreHaritasi() {
    var r = durum.sonuc, harita = {};
    if (!r) {
      var liste = dersListesi(), sozluk = {};
      liste.forEach(function (d) { sozluk[d.id] = d; });
      r = { dersler: sozluk, yerlesim: ProgramAraclari.onYerlesimler(liste, durum.kilitler), kulupYerlesim: [] };
    }
    r.yerlesim.forEach(function (y) {
      var d = r.dersler[y.dersId]; if (!d) return;
      var blok = y.dersId + '@' + y.gun + '-' + y.saat;
      for (var k = 0; k < y.uzunluk; k++) {
        var anahtar = y.gun + '-' + (y.saat + k);
        var kayit = Object.assign({ dersId: y.dersId, blok: blok, derslikId: y.derslikId }, d);
        var sa = 's:' + d.subeId + ':' + anahtar;
        if (harita[sa] && d.paralel) {
          // paralel (alt grup) dersler aynı hücrede birlikte gösterilir
          var on = harita[sa];
          kayit = Object.assign({}, on, { paralelAdlar: (on.paralelAdlar || [on.ders]).concat(d.ders), blok: on.blok });
        }
        harita[sa] = kayit;
        (d.ogretmenler || (d.ogretmenId ? [d.ogretmenId] : [])).forEach(function (t) { harita['o:' + t + ':' + anahtar] = Object.assign({}, kayit, { paralelAdlar: null, ders: d.ders, dersId: y.dersId, ogretmenId: t, blok: blok }); });
      }
    });
    (r.kulupYerlesim || []).forEach(function (ky) {
      var kb = (r.kulupBilgi || {})[ky.kulupId] || (durum.kulupler || []).filter(function (x) { return x.id === ky.kulupId; })[0];
      if (!kb) return;
      var kogr = kb.ogretmenler || (kb.ogretmenId ? [kb.ogretmenId] : []);
      for (var k = 0; k < ky.uzunluk; k++) {
        var an = ky.gun + '-' + (ky.saat + k);
        var kayit = { dersId: 'kulup:' + ky.kulupId, blok: 'kulup:' + ky.kulupId + '@' + ky.gun, ders: kb.ad, grup: 'Kulüp', kulup: true, ogretmenId: kogr[0] || null, subeAd: 'Kulüp' };
        (kb.subeIds || []).forEach(function (sid) { harita['s:' + sid + ':' + an] = Object.assign({ subeId: sid }, kayit); });
        kogr.forEach(function (t) { harita['o:' + t + ':' + an] = Object.assign({ subeId: (kb.subeIds || [])[0] }, kayit); });
      }
    });
    return harita;
  }
  /** Bir günün hücrelerini birleşik bloklara çevirir: [{x, bas, uzunluk}] */
  function gunHucreleri(harita, onek, id, gun, H) {
    var out = [];
    for (var s = 0; s < H; s++) {
      var x = harita[onek + id + ':' + gun + '-' + s];
      var n = 1;
      while (x && s + n < H) {
        var y = harita[onek + id + ':' + gun + '-' + (s + n)];
        if (!y || y.blok !== x.blok) break;
        n++;
      }
      out.push({ x: x || null, bas: s, uzunluk: n });
      s += n - 1;
    }
    return out;
  }
  function programTablosu(tip, id) {
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat;
    var saatler = M.saatEtiketleri(durum.okul, H), harita = hucreHaritasi();
    var kapali = kapaliListesi(tip, id) || [];
    var onek = tip === 'sube' ? 's:' : 'o:';
    var r = durum.sonuc, mod = r ? (ui.duzenMod || 'tasi') : (ui.duzenMod === 'bak' ? 'bak' : 'kilit'), sec = r ? ui.secBlok : null;
    var secY = null, secIdx = -1;
    if (mod === 'tasi' && sec && r) {
      if (sec.tip === 'bekleyen') secY = r.yerlesmeyen[sec.i];
      else { secIdx = yerlesimIndeksi(sec.dersId, sec.gun, sec.saat); secY = r.yerlesim[secIdx]; }
    }
    var h = '<div class="kaydirma"><table class="program duzenlenebilir mod-' + mod + '" data-tip="' + tip + '" data-id="' + esc(id) + '"><colgroup><col class="gun-sutun">' + new Array(H + 1).join('<col>') + '</colgroup><tr><th></th>';
    for (var s = 0; s < H; s++) h += '<th class="saat-bas"><b>' + (s + 1) + '</b><span>' + saatler[s].replace('–', '<br>') + '</span></th>';
    h += '</tr>';
    for (var d = 0; d < D; d++) {
      var gunSinifi = gunDurumu(kapali, d, H);
      h += '<tr><th class="gun"><button class="program-gun-dugme ' + gunSinifi + '" data-a="program-gun-toggle" data-v="' + esc(tip + '|' + id + '|' + d) + '" title="' + esc(M.GUNLER[d] + ' gününü kapat/aç') + '">' + M.GUNLER[d] + '<small>' + (gunSinifi === 'kapali' ? 'Kapalı' : gunSinifi === 'kismi' ? 'Kısmi' : 'Açık') + '</small></button></th>';
      gunHucreleri(harita, onek, id, d, H).forEach(function (c) {
        var x = c.x;
        if (x && x.kulup) {
          h += '<td class="dolu kulup-hucre" colspan="' + c.uzunluk + '" style="--h:' + M.renk(x.ders) + '" title="' + esc(x.ders + ' (sosyal kulüp)') + '"><div class="k1">KULÜP</div><div class="k2">' + esc(x.ders) + '</div></td>';
          return;
        }
        if (x) {
          var ogr = ogretmen(x.ogretmenId), sb = sube(x.subeId);
          var kilitli = ((durum.kilitler || {})[x.dersId] || []).some(function (k) { return k.gun === d && k.saat === c.bas; });
          var secili = sec && sec.tip !== 'bekleyen' && sec.dersId === x.dersId && sec.gun === d && sec.saat === c.bas;
          var takas = '';
          if (secY && secIdx >= 0 && !secili) {
            var j = yerlesimIndeksi(x.dersId, d, c.bas), sy = r.yerlesim[j];
            var tHata = !sy ? 'yok' : sy.uzunluk !== secY.uzunluk ? 'Farklı uzunlukta blok' : sy.dersId === secY.dersId ? 'Aynı ders'
              : (yerHatasi(secY.dersId, secY.uzunluk, sy.gun, sy.saat, [secIdx, j]) || yerHatasi(sy.dersId, sy.uzunluk, secY.gun, secY.saat, [secIdx, j]));
            takas = tHata ? ' takas-yok' : ' takas-uygun';
          }
          var ipucu = !r ? ' — tıklayınca ön kilit kaldırılır' : mod === 'kilit' ? (kilitli ? ' — tıklayınca kilit kalkar' : ' — tıklayınca bu yere kilitlenir')
            : mod === 'tasi' ? (secili ? ' — seçili; boş bir saate ya da aynı uzunlukta başka bir derse tıklayın' : (secY ? (takas === ' takas-uygun' ? ' — tıklayınca seçili dersle yer değiştirir' : ' — seçili dersle yer değiştiremez') : ' — taşımak için seçin')) : '';
          // colspan gerçek ders sayısını kapsar. Çoklu bloklarda ders başlığı
          // bütün sütunlara ortalanır, alt şerit her ders saatini ayrı gösterir.
          var birlesik = c.uzunluk > 1;
          var saatEtiketleri = birlesik ? ProgramAraclari.blokSaatEtiketleri(c.bas, c.uzunluk) : [];
          h += '<td class="dolu tiklanir' + (birlesik ? ' blok-birlesik' : '') + (kilitli ? ' kilitli' : '') + (secili ? ' secili-blok' : '') + takas + '" colspan="' + c.uzunluk + '" style="--h:' + M.renk(x.ders) + '" data-dd5-slot="' + esc(tip + '|' + id + '|' + d + '|' + c.bas) + '" data-a="' + (r ? 'hucre-tik' : 'hazirlik-kilit-kaldir') + '" data-v="' + esc(x.dersId + '|' + d + '|' + c.bas + '|' + c.uzunluk) + '" aria-label="' + esc(x.ders + (birlesik ? ', ' + saatEtiketleri.map(function (t) { return t + '. saat'; }).join(' ve ') : ', ' + (c.bas + 1) + '. saat')) + '" title="' + esc(x.ders + (ogr ? ' — ' + ogr.ad : '') + (birlesik ? ' — ' + c.uzunluk + ' ders saati' : '') + (kilitli ? ' (kilitli)' : '') + ipucu) + '">' +
            (birlesik ? '<div class="blok-kart"><div class="blok-bilgi"><span class="blok-rozet">' + c.uzunluk + ' saat blok</span>' : '') +
            (tip === 'sube'
              ? (x.paralelAdlar ? '<div class="k1">' + (kilitli ? '🔒 ' : '') + '∥ GRUP</div><div class="k2">' + esc(x.paralelAdlar.join(' / ')) + '</div>'
                : '<div class="k1">' + (kilitli ? '🔒 ' : '') + esc(M.kisaltma(x.ders)) + '</div><div class="k2">' + esc(x.ders) + '</div><div class="k3">' + esc(ogr ? ogr.ad : (x.ders === 'Seçmeli Ders' ? '' : 'öğretmen yok')) + ((x.ogretmenler || []).length > 1 ? ' +' + (x.ogretmenler.length - 1) : '') + '</div>')
              : '<div class="k1">' + (kilitli ? '🔒 ' : '') + esc(sb ? sb.ad : '') + '</div><div class="k2">' + esc(M.kisaltma(x.ders)) + ' · ' + esc(x.ders) + '</div>') +
            (birlesik ? '</div><div class="blok-saat-seridi" style="--blok-sutun:' + c.uzunluk + '" aria-hidden="true">' +
              saatEtiketleri.map(function (saat) { return '<span>' + saat + '. saat</span>'; }).join('') + '</div></div>' : '') + '</td>';
        } else if (kapali.indexOf(d + '-' + c.bas) >= 0) {
          h += '<td class="kapali" data-dd5-slot="' + esc(tip + '|' + id + '|' + d + '|' + c.bas) + '" data-a="program-saat-toggle" data-v="' + esc(tip + '|' + id + '|' + d + '|' + c.bas) + '" title="' + (tip === 'sube' ? 'Şubenin kapalı saati' : 'Öğretmenin kapalı saati') + ' — açmak için tıklayın"><span class="kapali-yazi">Kapalı</span></td>';
        } else {
          var cls = 'bos-hucre', baslik = mod === 'bak' ? '' : 'Bu saate ders kilitle';
          if (secY) {
            var hata = yerHatasi(secY.dersId, secY.uzunluk, d, c.bas, secIdx >= 0 ? [secIdx] : []);
            cls += hata ? ' hedef-yok' : ' hedef-uygun'; baslik = hata || 'Seçili dersi buraya taşı';
          }
          h += '<td class="' + cls + '" data-dd5-slot="' + esc(tip + '|' + id + '|' + d + '|' + c.bas) + '"' + (mod === 'bak' ? '' : ' data-a="bos-tik" data-v="' + esc(tip + '|' + id + '|' + d + '|' + c.bas) + '"') + (baslik ? ' title="' + esc(baslik) + '"' : '') + '>' + (mod !== 'bak' ? '<span class="bos-arti">' + (secY ? '' : '+') + '</span>' : '') + '</td>';
        }
      });
      h += '</tr>';
    }
    return h + '</table></div>';
  }
  /** Çarşaf üzerinde kilitli bloğun her iki saatinden de ön kilit kaldırılabilir. */
  function carsafOnKilit(dersId, gun, saat) {
    if (durum.sonuc) return '';
    var k = ((durum.kilitler || {})[dersId] || []).filter(function (x) {
      return x.gun === gun && x.saat <= saat && saat < x.saat + x.uzunluk;
    })[0];
    return k ? ' data-a="hazirlik-kilit-kaldir" data-v="' + esc(dersId + '|' + gun + '|' + k.saat + '|' + k.uzunluk) + '"' : '';
  }
  function carsafTablosu() {
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, harita = hucreHaritasi();
    var h = '<table class="carsaf"><tr><th rowspan="2">Şube</th>';
    for (var d = 0; d < D; d++) h += '<th colspan="' + H + '" class="gunbas">' + M.GUNLER[d] + '</th>';
    h += '</tr><tr>';
    for (d = 0; d < D; d++) for (var s = 0; s < H; s++) h += '<th' + (s === 0 ? ' class="gunbas"' : '') + '>' + (s + 1) + '</th>';
    h += '</tr>';
    durum.subeler.forEach(function (sb) {
      h += '<tr data-dd2-ara="' + esc(sb.ad) + '"><td class="sube"><button class="carsaf-kisit-dugme" data-a="program-kisit-ac" data-v="sube|' + esc(sb.id) + '" title="Gün ve saat kapat/aç">' + esc(sb.ad) + ' ⚙</button></td>';
      for (var d = 0; d < D; d++) for (var s = 0; s < H; s++) {
        var x = harita['s:' + sb.id + ':' + d + '-' + s];
        var ogr = x && ogretmen(x.ogretmenId);
        var kapSube = kapaliListesi('sube', sb.id).indexOf(d + '-' + s) >= 0;
        h += x ? '<td class="d' + (s === 0 ? ' gunbas' : '') + '" data-dd5-slot="' + esc('sube|' + sb.id + '|' + d + '|' + s) + '" data-ders="' + esc(x.dersId) + '" data-gs="' + d + '|' + s + '"' + carsafOnKilit(x.dersId, d, s) + ' style="--h:' + M.renk(x.ders) + '" title="' + esc(x.ders + (ogr ? ' — ' + ogr.ad : '')) + '">' + esc(M.kisaltma(x.ders)) + (ogr ? '<small>' + esc(basHarf(ogr.ad)) + '</small>' : '') + '</td>'
          : '<td class="' + (s === 0 ? 'gunbas ' : '') + (kapSube ? 'kapali-hucre' : '') + '" data-dd5-slot="' + esc('sube|' + sb.id + '|' + d + '|' + s) + '"' + (!durum.sonuc ? ' data-a="carsaf-bos-tik" data-v="' + esc('sube|' + sb.id + '|' + d + '|' + s) + '" title="Dersi kilitle veya saati kapat"' : '') + '>' + (kapSube ? '×' : '') + '</td>';
      }
      h += '</tr>';
    });
    return h + '</table>';
  }
  function basHarf(ad) {
    var m = /^(.*\S)\s+(\d+)$/.exec(ad);
    if (m && VERI.branslar[m[1]]) return M.kisaltma(m[1]) + m[2];
    return ad.split(/\s+/).filter(function (k) { return ['ve', 'ile'].indexOf(k) < 0; }).map(function (k) { return k[0]; }).join('').toLocaleUpperCase('tr').slice(0, 4);
  }
  function yukTablosu() {
    var r = durum.sonuc, D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat;
    var gun = {};
    durum.ogretmenler.forEach(function (o) { gun[o.id] = new Array(D).fill(0); });
    r.yerlesim.forEach(function (y) { var d = r.dersler[y.dersId]; if (d && d.ogretmenId && gun[d.ogretmenId]) gun[d.ogretmenId][y.gun] += y.uzunluk; });
    var harita = hucreHaritasi();
    return '<table class="tablo"><tr><th>Öğretmen</th><th>Branş</th>' + M.GUNLER.slice(0, D).map(function (g) { return '<th class="s">' + g.slice(0, 3) + '</th>'; }).join('') + '<th class="s">Toplam</th><th class="s">Boş saat</th></tr>' +
      durum.ogretmenler.slice().sort(function (a, b) { return a.brans.localeCompare(b.brans, 'tr'); }).map(function (o) {
        var bos = 0;
        for (var d = 0; d < D; d++) {
          var ilk = -1, son = -1, dolu = 0;
          for (var s = 0; s < H; s++) if (harita['o:' + o.id + ':' + d + '-' + s]) { if (ilk < 0) ilk = s; son = s; dolu++; }
          if (son >= 0) bos += son - ilk + 1 - dolu;
        }
        var t = gun[o.id].reduce(function (a, b) { return a + b; }, 0);
        return '<tr><td>' + esc(o.ad) + '</td><td class="ince">' + esc(o.brans) + '</td>' + gun[o.id].map(function (v) { return '<td class="s' + (v ? '' : ' sifir') + '">' + (v || '–') + '</td>'; }).join('') + '<td class="s"><b>' + t + '</b></td><td class="s">' + bos + '</td></tr>';
      }).join('') + '</table>';
  }

  function rehberlikSubeleri(ogrId) {
    var r = durum.sonuc, out = [];
    var kaynak = r ? Object.keys(r.dersler).map(function (k) { return r.dersler[k]; }) : dersListesi();
    kaynak.forEach(function (d) { if (d.grup === 'Rehberlik' && d.ogretmenId === ogrId) { var sb = sube(d.subeId); if (sb) out.push(sb.ad.replace('-', '/')); } });
    return out;
  }

  /** Resmî belge ızgarası (satır gün, sütun ders saati, birleşik bloklar) */
  function belgeIzgara(tip, id) {
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, harita = hucreHaritasi();
    var saatler = M.saatEtiketleri(durum.okul, H), onek = tip === 'sube' ? 's:' : 'o:';
    var h = '<table class="b-izgara"><tr><th class="b-gun"></th>';
    for (var s = 0; s < H; s++) { var p = saatler[s].split('–'); h += '<th><b>' + (s + 1) + '</b><br>' + p[0] + '<br>' + p[1] + '</th>'; }
    h += '</tr>';
    for (var d = 0; d < D; d++) {
      h += '<tr><th class="b-gun">' + M.GUNLER[d] + '</th>';
      gunHucreleri(harita, onek, id, d, H).forEach(function (c) {
        var x = c.x;
        if (!x) { h += '<td></td>'; return; }
        var ogr = ogretmen(x.ogretmenId), sb = sube(x.subeId);
        h += '<td colspan="' + c.uzunluk + '">' + (tip === 'sube'
          ? '<b>' + esc(M.kisaltma(x.ders)) + '</b><br><span>' + esc(ogr ? basHarf(ogr.ad) : '') + '</span>'
          : '<b>' + esc(sb ? sb.ad.replace('-', '') : '') + '</b><br><span>' + esc(M.kisaltma(x.ders)) + '</span>') + '</td>';
      });
      h += '</tr>';
    }
    return h + '</table>';
  }
  function dersOzetleri(filtre) {
    var r = durum.sonuc, l = [];
    Object.keys(r.dersler).forEach(function (k) { var d = r.dersler[k]; if (filtre(d)) l.push(Object.assign({ dersId: k }, d)); });
    return l;
  }
  function ogretmenBelgesi(o, B) {
    var dersler = dersOzetleri(function (d) { return d.ogretmenId === o.id; });
    dersler.sort(function (a, b) { return durum.subeler.indexOf(sube(a.subeId)) - durum.subeler.indexOf(sube(b.subeId)) || a.ders.localeCompare(b.ders, 'tr'); });
    var toplam = dersler.reduce(function (a, d) { return a + (d.saat || 0); }, 0);
    var dn = durum.nobet && durum.nobet.donemler && durum.nobet.donemler[B.nobetDonem];
    var nobet = nobetTutar(o) ? nobetMetni(dn, o.id) : '—', nobetEtiket = 'Nöbet Günü';
    if (!nobetTutar(o) && idariNobetci(o)) { nobet = idariNobetMetni(dn, o.id); nobetEtiket = 'İdari Nöbet Günü'; }
    var rehber = rehberlikSubeleri(o.id);
    return '<section class="kagit">' +
      '<div class="b-baslik">' + esc(B.mudurluk) + '</div>' +
      '<table class="b-bilgi"><tr><td>Sayı</td><td>: ' + esc(B.sayi) + '</td></tr><tr><td>Öğretmen</td><td>: <b>' + esc(o.ad) + '</b></td></tr>' +
      '<tr><td>Branş</td><td>: ' + esc(o.brans) + '</td></tr>' + (yoneticiMi(o) ? '<tr><td>Görevi</td><td>: ' + esc(GOREV_AD[o.gorev]) + '</td></tr>' : '') + '<tr><td>Toplam Saat</td><td>: ' + toplam + '</td></tr></table>' +
      '<p class="b-ek">' + nobetEtiket + ': <b>' + esc(nobet) + '</b> &nbsp;&nbsp; Sınıf Rehberliği: <b>' + esc(rehber.join(', ') || '—') + '</b> &nbsp;&nbsp; Sosyal Kulüp: <b>' + esc(o.kulup || '—') + '</b></p>' +
      belgeIzgara('ogretmen', o.id) +
      '<p class="b-alt-baslik">Ders Listesi:</p><table class="b-liste"><tr><th>S</th><th>Ders</th><th>Ders Adı</th><th>Sınıflar</th><th>Yerleşim</th><th>Saat</th></tr>' +
      dersler.map(function (d, i) { var sb = sube(d.subeId); return '<tr><td>' + (i + 1) + '</td><td>' + esc(M.kisaltma(d.ders)) + '</td><td class="sol">' + esc(d.ders) + '</td><td>' + esc(sb ? sb.ad.replace('-', '') : '') + '</td><td>' + esc(gercekYerlesim(d.dersId) || d.yerlesimMetni || '') + '</td><td>' + d.saat + '</td></tr>'; }).join('') +
      '</table>' +
      '<p class="b-metin">Yukarıdaki dersler ' + esc(B.tarih) + ' tarihinden itibaren uygulanacaktır. Bilgilerinizi rica ederim.</p>' +
      '<div class="b-imza"><div>' + esc(B.tarih) + '<br>Aslını Aldım<br><br>' + esc(o.ad) + '</div><div class="sag"><br><br><br>' + esc(B.mudur || '……………………') + '<br>Okul Müdürü</div></div>' +
      '</section>';
  }
  function subeBelgesi(sb, B) {
    var dersler = dersOzetleri(function (d) { return d.subeId === sb.id; });
    var toplam = dersler.reduce(function (a, d) { return a + (d.saat || 0); }, 0);
    var reh = dersler.filter(function (d) { return d.grup === 'Rehberlik'; })[0];
    var rehO = reh && ogretmen(reh.ogretmenId);
    return '<section class="kagit">' +
      '<div class="b-baslik">' + esc(B.mudurluk) + '</div>' +
      '<div class="b-baslik2">' + esc(B.ogretimYili) + ' EĞİTİM ÖĞRETİM YILI ' + esc(sb.ad.replace('-', '/')) + ' SINIFI HAFTALIK DERS PROGRAMI</div>' +
      '<p class="b-ek">Sınıf Rehber Öğretmeni: <b>' + esc(rehO ? rehO.ad : '—') + '</b> &nbsp;&nbsp; Haftalık Ders Saati: <b>' + toplam + '</b></p>' +
      belgeIzgara('sube', sb.id) +
      '<p class="b-alt-baslik">Ders Listesi:</p><table class="b-liste"><tr><th>S</th><th>Ders</th><th>Ders Adı</th><th>Öğretmen</th><th>Yerleşim</th><th>Saat</th></tr>' +
      dersler.map(function (d, i) { var o = ogretmen(d.ogretmenId); return '<tr><td>' + (i + 1) + '</td><td>' + esc(M.kisaltma(d.ders)) + '</td><td class="sol">' + esc(d.ders) + '</td><td class="sol">' + esc(o ? o.ad : '') + '</td><td>' + esc(gercekYerlesim(d.dersId) || d.yerlesimMetni || '') + '</td><td>' + d.saat + '</td></tr>'; }).join('') +
      '</table>' +
      '<div class="b-imza"><div></div><div class="sag">' + esc(B.tarih) + '<br>ONAY<br><br>' + esc(B.mudur || '……………………') + '<br>Okul Müdürü</div></div>' +
      '</section>';
  }
  // ---------- Modal: öğretmen / şube uygunluk ----------
  function excelOgrModal() {
    var branslar = Object.keys(VERI.branslar);
    return '<div class="perde" data-a="modal-kapat"><div class="modal" role="dialog" aria-modal="true" style="max-width:600px" onclick="event.stopPropagation()">' +
      '<div class="modal-ust"><h3>Excel / CSV’den Öğretmen İçe Aktar</h3><button class="btn ikon-btn" data-a="modal-kapat" aria-label="Kapat">×</button></div>' +
      '<div class="modal-govde">' +
      '<p class="ince" style="margin-top:0">Excel’den doğrudan kopyalayıp aşağıya yapıştırın veya sütunları <b>Sekme (Tab)</b>, <b>Noktalı Virgül (;)</b> ya da <b>Virgül (,)</b> ile ayırın.<br>' +
      'Biçim: <code>Ad Soyad ; Branş ; Üst Sınır</code> (Üst sınır boşsa varsayılan ' + (durum.ayarlar.maxSaat || 30) + ' alınır).</p>' +
      '<textarea id="excel-ogr-metin" rows="8" style="width:100%;font-family:monospace;font-size:12.5px" placeholder="Ayşe YILMAZ\tMatematik\t28&#10;Mehmet KAYA\tTürkçe\t30&#10;Zeynep DEMİR\tFen Bilimleri\t26"></textarea>' +
      '<div class="satir" style="margin-top:10px"><label class="satir-alan">Branşı boş satırlar için varsayılan:<select id="excel-ogr-vars-brans">' +
      branslar.map(function (b) { return '<option>' + esc(b) + '</option>'; }).join('') + '</select></label></div>' +
      '</div><div class="modal-alt"><button class="btn" data-a="modal-kapat">İptal</button><button class="btn ana" data-a="ogr-excel-uygula">' + ikon('artı') + 'Öğretmenleri İçe Aktar</button></div></div></div>';
  }
  function excelSubeModal() {
    return '<div class="perde" data-a="modal-kapat"><div class="modal" role="dialog" aria-modal="true" style="max-width:520px" onclick="event.stopPropagation()">' +
      '<div class="modal-ust"><h3>Excel / Listeden Şube Ekle</h3><button class="btn ikon-btn" data-a="modal-kapat" aria-label="Kapat">×</button></div>' +
      '<div class="modal-govde">' +
      '<p class="ince" style="margin-top:0">Şube adlarını her satıra bir tane ya da virgülle ayırarak yapıştırın (ör. <code>5-A, 5-B, 6-A, 7-A</code>). Sınıf düzeyi şube adının başındaki sayıdan otomatik algılanır.</p>' +
      '<textarea id="excel-sube-metin" rows="6" style="width:100%;font-family:monospace;font-size:13px" placeholder="5-A&#10;5-B&#10;6-A&#10;6-B"></textarea>' +
      '</div><div class="modal-alt"><button class="btn" data-a="modal-kapat">İptal</button><button class="btn ana" data-a="sube-excel-uygula">' + ikon('artı') + 'Şubeleri Ekle</button></div></div></div>';
  }
  function excelIndir() {
    if (!durum.sonuc) { bildir('Önce dağıtım yapmalısınız.', 'hata'); return; }
    var ad = (durum.okul.ad || 'ders-programi').replace(/[^\wçğıöşüÇĞİÖŞÜ-]+/g, '_');
    var html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">' +
      '<head><meta charset="utf-8"><style>table{border-collapse:collapse;font-family:Calibri,Arial,sans-serif;font-size:11pt;margin-bottom:24px}th,td{border:1px solid #94a3b8;padding:4px 6px;text-align:center}th{background:#1e3a5f;color:#fff;font-weight:700}td.sube{text-align:left;font-weight:700;background:#f1f5f9}h2{font-family:Calibri,Arial,sans-serif;color:#1e3a5f}</style></head><body>' +
      '<h2>' + esc(durum.okul.ad || 'Okul') + ' — Şubeler Çarşaf Listesi</h2>' + carsafTablosu() +
      '<h2>' + esc(durum.okul.ad || 'Okul') + ' — Öğretmenler Çarşaf Listesi</h2>' + ogretmenCarsafTablosu() +
      '</body></html>';
    if (window.AndroidKopru && window.AndroidKopru.dosyaIndir) {
      window.AndroidKopru.dosyaIndir(ad + '_carsaf_program.xls', 'application/vnd.ms-excel', '\uFEFF' + html);
      return;
    }
    var blob = new Blob(['\uFEFF' + html], { type: 'application/vnd.ms-excel;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = ad + '_carsaf_program.xls';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    bildir('Excel çarşaf dosyası indirildi (.xls).');
  }
  function modalCiz() {
    gecmisPlanla();
    var kap = $('#modal-kok');
    if (!ui.modal) { kap.innerHTML = ''; return; }
    if (ui.modal.tip === 'excelOgr') { kap.innerHTML = excelOgrModal(); var eo = $('#excel-ogr-metin'); if (eo) eo.focus(); return; }
    if (ui.modal.tip === 'excelSube') { kap.innerHTML = excelSubeModal(); var es = $('#excel-sube-metin'); if (es) es.focus(); return; }
    if (ui.modal.tip === 'saatKilit') { if (!durum.sonuc) { ui.modal = null; kap.innerHTML = ''; return; } kap.innerHTML = saatKilitModal(); return; }
    if (ui.modal.tip === 'hazirlikKilit') { kap.innerHTML = hazirlikKilitModal(); return; }
    if (ui.modal.tip === 'ux3Pool') { kap.innerHTML = ux3PoolModal(); var ar = $('#ux3-pool-search'); if (ar) ar.focus(); return; }
    if (ui.modal.tip === 'ux3Hours') { kap.innerHTML = ux3HoursModal(); var hs = $('#ux3-new-hours'); if (hs) hs.focus(); return; }
    if (ui.modal.tip === 'dd5OgrSec') { kap.innerHTML = dd5OgretmenSecModal(); return; }
    if (ui.modal.tip === 'dd5Blok') { kap.innerHTML = dd5BlokModal(); return; }
    if (ui.modal.tip === 'ux3Atama') { kap.innerHTML = ux3AtamaModal(); var arA = $('#ux3a-aday-ara'); if (arA) arA.focus(); return; }
    if (ui.modal.tip === 'ogrDegistir') { kap.innerHTML = ogrDegistirModal(); aramaUygula(); return; }
    if (ui.modal.tip === 'ogrTercih') { kap.innerHTML = ogrTercihModal(); return; }
    if (ui.modal.tip === 'ozelSecmeli') { kap.innerHTML = ozelSecmeliModal(); var g0 = $('#ms-ad'); if (g0) g0.focus(); return; }
    if (ui.modal.tip === 'dd6ZorEkle') { kap.innerHTML = dd6ZorEkleModal(); var g6 = $('#ek-ad-' + ui.dd6Sinif); if (g6) g6.focus(); return; }
    var tip = ui.modal.tip || 'ogretmen', varlik = tip === 'sube' ? sube(ui.modal.id) : ogretmen(ui.modal.id);
    if (!varlik) { ui.modal = null; kap.innerHTML = ''; return; }
    var liste = kapaliListesi(tip, ui.modal.id);
    var D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, saatler = M.saatEtiketleri(durum.okul, H);
    var h = '<div class="modal-arka" data-a="modal-kapat"><div class="modal" data-durdur="1"><h3>' + esc(varlik.ad) + ' — ' + (tip === 'sube' ? 'sınıfın açık/kapalı saatleri' : 'öğretmenin açık/kapalı saatleri') + '</h3>' +
      '<p class="ince">Kırmızı saatlere ders konmaz. Gün başlığı bütün günü, saat başlığı o saati bütün günlerde açar/kapatır.</p><table class="uygunluk"><tr><th></th>';
    for (var d = 0; d < D; d++) h += '<th><button class="btn kucuk" data-a="uyg-gun" data-v="' + d + '">' + M.GUNLER[d] + '</button></th>';
    h += '</tr>';
    for (var s = 0; s < H; s++) {
      h += '<tr><th><button class="btn kucuk" data-a="uyg-saat" data-v="' + s + '" title="' + saatler[s] + '">' + (s + 1) + '. ders</button></th>';
      for (d = 0; d < D; d++) {
        var k = d + '-' + s, kapali = liste.indexOf(k) >= 0;
        h += '<td><button class="' + (kapali ? 'kapali' : '') + '" data-a="uyg-hucre" data-v="' + k + '">' + (kapali ? 'Kapalı' : 'Açık') + '</button></td>';
      }
      h += '</tr>';
    }
    h += '</table><div class="satir"><button class="btn ana" data-a="modal-kapat">Tamam</button><button class="btn" data-a="uyg-temizle">Hepsini aç</button></div></div></div>';
    kap.innerHTML = h;
  }

  function csvIndir() {
    var r = durum.sonuc, D = +durum.okul.gunSayisi, H = +durum.okul.gunlukSaat, harita = hucreHaritasi();
    var satir = [['Şube', 'Gün', 'Ders saati', 'Saat aralığı', 'Ders', 'Öğretmen']];
    var saatler = M.saatEtiketleri(durum.okul, H);
    durum.subeler.forEach(function (sb) {
      for (var d = 0; d < D; d++) for (var s = 0; s < H; s++) {
        var x = harita['s:' + sb.id + ':' + d + '-' + s];
        if (x) { var o = ogretmen(x.ogretmenId); satir.push([sb.ad, M.GUNLER[d], s + 1, saatler[s], x.ders, o ? o.ad : '']); }
      }
    });
    var metin = '﻿' + satir.map(function (l) { return l.map(function (c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(';'); }).join('\r\n');
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([metin], { type: 'text/csv;charset=utf-8' }));
    a.download = (durum.okul.ad || 'program').replace(/[^\wçğıöşüÇĞİÖŞÜ -]/g, '') + ' - ders programi.csv';
    document.body.appendChild(a); a.click(); a.remove();
    void r;
  }

  // ---------- Olaylar: tıklama ----------
  function tikla(e) {
    // Çizelge hücrelerinde tıklama, ileri taşıma hedefi seçili değilse her zaman işlem panelini açar.
    var dd6Cell = e.target.closest && e.target.closest('#icerik td[data-dd5-slot]');
    if (dd6Cell && !e.target.closest('button,input,select,textarea,a') && !(ui.secBlok && (ui.duzenMod || 'tasi') === 'tasi')) {
      if (dd6PanelAc(dd6Cell)) { e.preventDefault(); menuKapat(); return; }
    }
    var el = e.target.closest('[data-a]');
    if (e.target.closest('#sag-menu') && !el) return;   // pasif menü maddesi
    menuKapat();
    if (!el) return;
    if (el.tagName === 'SELECT' || el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return;
    var a = el.getAttribute('data-a'), v = el.getAttribute('data-v'), k = el.getAttribute('data-k');
    if (el.tagName === 'A') e.preventDefault();
    if (ui.mobilMenu && a !== 'mobil-menu' && el.closest('#mobil-kok')) { ui.mobilMenu = false; mobilMenuCiz(); }
    if ((a === 'modal-kapat' || a === 'onay-hayir') && el.classList.contains('modal-arka') && e.target !== el) return;
    var t = tur();
    switch (a) {
      case 'dd6-close': dd6PanelKapat(); break;
      case 'adim': {
        ui.adim = v === 'secmeli' ? 'zorunlu' : v;
        if (v === 'secmeli') ui.dd5Havuz = 'secmeli';
        MENU.forEach(function (g, gi) { if (g.adimlar.some(function (x) { return x.id === v; })) ui.tasarimGruplar[gi] = true; });
        yanKapat(); ciz(); window.scrollTo(0, 0); break;
      }
      case 'dd3-yerel-sekme': {
        if (ui.adim === 'bloklar' && ['zorunlu', 'secmeli', 'atama'].indexOf(v) >= 0) ui.blokYerelSekme = v;
        else if (ui.adim === 'atama' && ['zorunlu', 'secmeli', 'bloklar'].indexOf(v) >= 0) {
          ui.atamaYerelSekme = v;
          if (v !== 'bloklar') { ui.atamaSekme = v; ui.atamaGorunum = 'sinif'; }
        }
        else break;
        ciz();
        break;
      }
      case 'dd5-havuz-sek': ui.dd5Havuz = v; ui.dd8Ara = ''; ui.dd8HavuzAc = false; ui.adim = 'zorunlu'; ciz(); break;
      case 'dd6-sinif': ui.dd8Sube = null; ui.dd8Ara = ''; ui.dd8HavuzAc = false; ui.dd6Sinif = ui.dd5ZorSinif = ui.secmeliSinif = v; ui.dd5ZorDers = ''; ui.secDers = {}; ui.secSube = {}; ui.dd7ZorSec = {}; ui.dd7ZorSubeler = null; ui.secSadeceSecili = false; ciz(); break;

      case 'ux3-pool-open': ui.modal = {tip:'ux3Pool'}; ciz(); break;
      case 'ux3-hours-open': ui.modal = {tip:'ux3Hours',dersId:v}; ciz(); break;
      case 'ux3-hours-save': {
        if (!ui.modal || ui.modal.tip !== 'ux3Hours') break;
        var xd = dersListesi().find(function (d) {return d.id===ui.modal.dersId;});
        var z = $('#ux3-new-hours'), newHours = z ? Number(z.value) : NaN;
        if (!xd || !Number.isInteger(newHours) || newHours < 1 || newHours > 20) { bildir('Ders saati 1–20 arasında tam sayı olmalı.','hata'); break; }
        var sel= sube(xd.subeId), cap = subeSaatleri(xd.subeId);
        if (cap.toplam-xd.saat+newHours>cap.sinir) { bildir('Haftalık saat sınırı aşılır. Önce başka bir dersin saatini azalt.','hata'); break; }
        if (xd.grup==='Seçmeli') {
          var err = dd5SecmeliDegistir(xd.subeId,xd.ders,newHours,false);
          if (err) { bildir(err,'hata'); break; }
        } else {
          var tr=tur(), trrow=tr.dersler.find(function(r){return r[0]===xd.ders;});
          var extra=(durum.ekDersler||[]).find(function(r){return r.ad===xd.ders && (r.subeId===xd.subeId || (!r.subeId && r.sinif===sel.sinif));});
          var base=trrow ? +trrow[2][tr.siniflar.indexOf(sel.sinif)] : (extra ? +extra.saat : 0);
          if (newHours===base) delete durum.saatDegisiklik[xd.id]; else durum.saatDegisiklik[xd.id]=newHours;
          kilitleriTemizle(); degisti(true);
        }
        ui.modal=null; ciz(); bildir('Ders saati '+newHours+' olarak kaydedildi.'); break;
      }
      case 'dd8-havuz': ui.dd8HavuzAc = !ui.dd8HavuzAc; ui.dd8Ara = ''; ciz(); break;
      case 'dd8-gelismis': ui.dd8Gelismis = !ui.dd8Gelismis; ciz(); break;
      case 'dd8-zor-ekle': {
        var ss8 = sube(ui.dd8Sube), idx8 = ss8 ? t.siniflar.indexOf(ss8.sinif) : -1;
        var r8 = t.dersler.find(function (r) { return r[0] === v; });
        var custom8 = (durum.ekDersler || []).find(function (e) { return e.ad === v && ss8 && (e.subeId ? e.subeId === ss8.id : e.sinif === ss8.sinif); });
        var saat8z = r8 && idx8 >= 0 ? (+r8[2][idx8] || 0) : (custom8 ? (+custom8.saat || 0) : 0);
        if (!ss8 || !(saat8z > 0)) { bildir('Ders şube için uygun değil.', 'hata'); break; }
        var k8 = ss8.id + '|' + v, mevcut8 = dersListesi().find(function (d) { return d.id === k8; });
        var fark8 = saat8z - (mevcut8 ? mevcut8.saat : 0), sinir8 = subeSaatleri(ss8.id);
        if (sinir8.toplam + fark8 > sinir8.sinir) { bildir('Şubede yeterli saat yok. Önce mevcut bir dersi azalt veya kaldır.', 'hata'); break; }
        delete durum.saatDegisiklik[k8]; ui.dd8HavuzAc = false; if (ui.modal && ui.modal.tip === 'ux3Pool') ui.modal = null; kilitleriTemizle(); degisti(true); ciz(); bildir(v + ' şubeye eklendi.'); break;
      }
      case 'dd8-zor-kaldir': {
        var sid8 = ui.dd8Sube, sb8 = sube(sid8); if (!sb8) break;
        onayla('Ders şubeden kaldırılsın mı?', esc(sb8.ad) + ' şubesindeki <b>' + esc(v) + '</b> kaldırılır. Okulun ders havuzundan silinmez.', 'Kaldır', function () {
          durum.saatDegisiklik[sid8 + '|' + v] = 0;
          kilitleriTemizle(); degisti(true); ciz(); bildir(v + ' şubeden kaldırıldı.');
        }); break;
      }
      case 'dd8-sec-ekle': {
        var ss8e = sube(ui.dd8Sube), si8 = ss8e ? t.siniflar.indexOf(ss8e.sinif) : -1;
        var ders8 = secmeliHavuzu().find(function (r) { return r[0] === v && si8 >= 0 && r[2].indexOf(ss8e.sinif) >= 0; });
        if (!ders8 || !ss8e) { bildir('Seçmeli ders bu sınıf için uygun değil.', 'hata'); break; }
        var sec8 = M.subeSecmelileri(durum, ss8e);
        if (sec8.some(function (x) { return x.ad === v; })) { bildir('Ders zaten şubede var.'); break; }
        var saat8 = Math.max(1,Math.min(20,+ders8[3] || +t.secmeliVarsayilanSaat || 2));
        var limit8 = t.secmeliSaat[si8] || 0;
        if (secmeliToplam(sec8) + saat8 > limit8) { bildir('Seçmeli ders eklenemedi: ' + (limit8 - secmeliToplam(sec8)) + ' saat boş. Önce mevcut dersin saatini azalt veya kaldır.', 'hata'); break; }
        secmeliListesi('sube',ss8e.id).push({ad:v,grup:ders8[1],saat:saat8});
        ui.dd8HavuzAc = false; if (ui.modal && ui.modal.tip === 'ux3Pool') ui.modal = null; kilitleriTemizle(); degisti(true); ciz(); bildir(v + ' ' + ss8e.ad + ' şubesine eklendi.'); break;
      }
      case 'dd8-sec-kaldir': {
        var sid8s = ui.dd8Sube, sb8s = sube(sid8s); if (!sb8s) break;
        onayla('Seçmeli ders kaldırılsın mı?', esc(sb8s.ad) + ' şubesindeki <b>' + esc(v) + '</b> kaldırılacak; diğer şubeler değişmeyecek.', 'Kaldır', function () {
          var err8 = dd5SecmeliDegistir(sid8s,v,0,true); if (err8) bildir(err8,'hata'); else bildir('Seçmeli ders kaldırıldı.');
        }); break;
      }
      case 'dd6-zor-ders': ui.dd5ZorDers = v; ciz(); break;
      case 'dd7-zor-gorunen': {
        ui.dd7ZorSec = ui.dd7ZorSec || {};
        document.querySelectorAll('.dd7-zor-satir').forEach(function (row) {
          if (!row.hidden) { var ch = row.querySelector('[data-a="dd7-zor-sec"]'); if (ch) ui.dd7ZorSec[ch.value] = true; }
        });
        ciz(); break;
      }
      case 'dd7-zor-temizle': ui.dd7ZorSec = {}; ciz(); break;
      case 'dd7-zor-sube-tum': {
        ui.dd7ZorSubeler = {}; durum.subeler.filter(function (sb) { return sb.sinif === ui.dd6Sinif; }).forEach(function (sb) { ui.dd7ZorSubeler[sb.id] = true; }); ciz(); break;
      }
      case 'dd7-zor-sube-temizle': ui.dd7ZorSubeler = {}; ciz(); break;
      case 'dd7-zor-toplu': {
        var zorSinif = ui.dd6Sinif || t.siniflar[0], zorIndex = t.siniflar.indexOf(zorSinif);
        var secilenZor = t.dersler.filter(function (r) { return !!(ui.dd7ZorSec || {})[r[0]] && (+r[2][zorIndex] || 0) > 0; });
        var hedefZor = durum.subeler.filter(function (sb) { return sb.sinif === zorSinif && !!(ui.dd7ZorSubeler || {})[sb.id]; });
        if (!secilenZor.length || !hedefZor.length) { bildir('Önce dersleri ve hedef şubeleri işaretleyin.', 'hata'); break; }
        var asilDersler = dersListesi(), asim = [];
        hedefZor.forEach(function (sb) {
          var eski = subeSaatleri(sb.id, asilDersler), yeni = eski.toplam;
          secilenZor.forEach(function (r) {
            var d = asilDersler.find(function (x) { return x.subeId === sb.id && x.ders === r[0] && x.grup !== 'Seçmeli'; });
            yeni = yeni - (d ? +d.saat : 0) + (+r[2][zorIndex] || 0);
          });
          if (yeni > eski.sinir) asim.push(sb.ad + ' (' + yeni + '/' + eski.sinir + ' saat)');
        });
        if (asim.length) { bildir('Hiçbir değişiklik yapılmadı. Önce saat sınırını düzeltin: ' + asim.join(', '), 'hata'); break; }
        onayla('Toplu zorunlu ders ataması', secilenZor.length + ' ders, ' + hedefZor.length + ' şubede MEB saatlerine uygulanacak. İşlem yalnız seçili şubeleri etkiler. Devam edilsin mi?', 'Uygula', function () {
          hedefZor.forEach(function (sb) { secilenZor.forEach(function (r) { delete durum.saatDegisiklik[sb.id + '|' + r[0]]; }); });
          ui.dd7ZorSec = {}; kilitleriTemizle(); degisti(true); ciz();
          bildir(secilenZor.length + ' zorunlu ders, ' + hedefZor.length + ' şubede MEB saatlerine göre güncellendi.');
        }, true); break;
      }
      case 'dd6-zor-ozel-ac': ui.modal = {tip:'dd6ZorEkle'}; ciz(); break;
      case 'dd5-zor-ata': {
        var dd5Sinif = ui.dd5ZorSinif || t.siniflar[0], dd5Ad = ui.dd5ZorDers || '';
        var dd5Hedef = ($('#dd5-zor-hedef') || {}).value || '';
        var dd5Saat = Math.max(1, Math.min(20, parseInt(($('#dd5-zor-saat') || {}).value, 10) || 0));
        var dd5Mev = t.dersler.find(function (x) { return x[0] === dd5Ad && +x[2][t.siniflar.indexOf(dd5Sinif)] > 0; });
        if (!dd5Mev) { bildir('Lütfen havuzdan bir MEB zorunlu dersi seçin.', 'hata'); break; }
        var dd5Subeler = durum.subeler.filter(function (x) { return x.sinif === dd5Sinif && (!dd5Hedef || dd5Hedef === x.id); });
        var dd5Asan = [];
        dd5Subeler.forEach(function (sb) {
          var ss = subeSaatleri(sb.id), d0 = dersListesi().find(function (x) { return x.subeId === sb.id && x.ders === dd5Ad; });
          if (ss.toplam - (d0 ? d0.saat : 0) + dd5Saat > ss.sinir) dd5Asan.push(sb.ad);
        });
        if (dd5Asan.length) { bildir(dd5Asan.join(', ') + ' şubesinde haftalık MEB toplamı aşılır; önce başka dersin saatini düşürün.', 'hata'); break; }
        dd5Subeler.forEach(function (sb) {
          var k = sb.id + '|' + dd5Ad, temel = +dd5Mev[2][t.siniflar.indexOf(dd5Sinif)];
          if (dd5Saat === temel) delete durum.saatDegisiklik[k]; else durum.saatDegisiklik[k] = dd5Saat;
        });
        kilitleriTemizle(); degisti(true); ciz(); bildir(dd5Ad + ' · ' + dd5Subeler.length + ' şubede ' + dd5Saat + ' saat olarak uygulandı.'); break;
      }
      case 'dd5-secmeli-sil': {
        var p = v.split('|'), sid = p.shift(), ad = p.join('|');
        onayla(ad + ' kaldırılacak mı?', (sube(sid) || {}).ad + ' şubesindeki seçmeli ders kaldırılır. Diğer şubelerin seçmelileri korunur.', 'Kaldır', function () { var hata = dd5SecmeliDegistir(sid, ad, 0, true); if (hata) bildir(hata, 'hata'); });
        break;
      }
      case 'dd5-ogretmen-sec-ac': ui.modal = { tip: 'dd5OgrSec', slot: v }; ciz(); break;
      case 'dd5-atama-git': ui.modal = null; ui.adim = 'atama'; ciz(); break;
      case 'dd5-ogretmen-ders': ui.modal = { tip: 'ogrDegistir', dersId: v }; ui.ogrDegAra = ''; ciz(); break;
      case 'dd6-preset': {
        if (!ui.modal || ui.modal.tip !== 'dd5Blok') break;
        ui.modal.taslak = v;
        var inp6 = $('#dd6-custom-block'); if (inp6) inp6.value = v;
        document.querySelectorAll('.dd6-preset').forEach(function(b){b.classList.toggle('active',b.getAttribute('data-v')===v);});
        break;
      }
      case 'dd6-oto-kaydet': {
        if (!ui.modal || ui.modal.tip !== 'dd5Blok') break;
        var autoId = ui.modal.dersId, autoDers = dersBul(autoId);
        if (!autoDers) break;
        var autoSube = sube(autoDers.subeId) || {};
        var duzeyKurali = durum.blokKurallari[String(autoSube.sinif) + '|' + autoDers.ders];
        var alternatifler = M.yerlesimListesiCoz(duzeyKurali, autoDers.saat, +durum.okul.gunSayisi).map(function(p){return p.join('+');});
        if (!alternatifler.length) alternatifler = [M.varsayilanYerlesim(autoDers.saat, +durum.okul.gunSayisi, durum.ayarlar.blok).join('+')];
        var izinliOto = alternatifler.some(function(k) { return !ux3BlokDogrula(k, autoDers.saat, +durum.okul.gunSayisi, durum.kilitler[autoId] || []); });
        if (!izinliOto) { bildir('Otomatik düzene dönüş mevcut kilitlerle veya blok sınırlarıyla uyumsuz. Önce kilitleri ve kuralları gözden geçirin.', 'hata'); break; }
        delete durum.yerlesimler[autoId]; ui.modal = null; degisti(true); ciz(); bildir('Dersin otomatik blok düzeni geri yüklendi.'); break;
      }
      case 'dd5-blok-ac': ui.modal = { tip: 'dd5Blok', dersId: v }; ciz(); break;
      case 'dd5-blok-kaydet': {
        if (!ui.modal || ui.modal.tip !== 'dd5Blok') break;
        var did = ui.modal.dersId, ds = dersBul(did), sec = $('#dd6-custom-block');
        if (!ds || !sec) break;
        var yeniKalip = sec.value.replace(/\s+/g, '');
        var hata = ux3BlokDogrula(yeniKalip, ds.saat, +durum.okul.gunSayisi, durum.kilitler[did] || []);
        if (hata) { bildir(hata, 'hata'); break; }
        durum.yerlesimler[did] = yeniKalip;
        ui.modal = null; degisti(true); ciz(); bildir('Blok düzeni '+yeniKalip+' olarak kaydedildi. Yeniden dağıtımda uygulanır.'); break;
      }
      case 'dd5-ders-kaldir': dd5DersiKaldir(v); break;
      case 'tasarim-grup': ui.tasarimGruplar[+v] = ui.tasarimGruplar[+v] === false; yanCiz(); break;
      case 'tasarim-yan-daralt': {
        if (window.innerWidth <= 860) { document.body.classList.add('yan-acik'); gecmisPlanla(); }
        else { document.body.classList.toggle('yan-dar'); try { localStorage.setItem('dd-tasarim-yan-dar', document.body.classList.contains('yan-dar') ? '1' : '0'); } catch (e) {} }
        var yanDug = $('#tasarim-menu-dug'); if (yanDug) yanDug.setAttribute('aria-pressed', String(document.body.classList.contains('yan-dar')));
        break;
      }
      case 'mobil-menu': ui.mobilMenu = !ui.mobilMenu; mobilMenuCiz(); break;
      case 'mobil-kapat': ui.mobilMenu = false; mobilMenuCiz(); break;
      case 'adimlar-ac': document.body.classList.add('yan-acik'); gecmisPlanla(); var ak = $('#yan .adim.aktif'); if (ak) ak.scrollIntoView({ block: 'center' }); break;
      case 'yan-kapat': yanKapat(); break;
      case 'pwa-yukle': if (window.PWA) window.PWA.yukle(); break;
      // --- Dağıtım kuralları, derslikler, kulüpler, rapor
      case 'kural-varsayilan':
        onayla('Kurallar varsayılana dönsün mü?', 'Zorunlu kural ayarları, esnetme izinleri ve tercih öncelikleri varsayılan değerlere döner. Ders ayarları ve etiket kuralları korunur.', 'Varsayılana dön', function () { durum.kurallar = {}; kurallar(); degisti(true); ciz(); bildir('Kurallar varsayılana döndü.'); }, true);
        break;
      case 'etiket-ekle': durum.etiketKurallari.push({ ad: '', hedef: 'ders', maxGunluk: 2, ardisikYasak: false }); degisti(true); ciz(); break;
      case 'etiket-sil': onayla('Etiket kuralı silinsin mi?', '“' + esc((durum.etiketKurallari[+v] || {}).ad || 'adsız') + '” kuralı kaldırılır.', 'Sil', function () { durum.etiketKurallari.splice(+v, 1); degisti(true); ciz(); }); break;
      case 'ders-ayar-ac': ui.dersAyarAcik = !el.parentNode.open; break;
      case 'bina-ekle': durum.binalar.push({ id: yeniKimlik('b'), ad: String.fromCharCode(65 + durum.binalar.length) + ' Blok' }); degisti(true); ciz(); break;
      case 'bina-sil': {
        var bs = durum.binalar[+v];
        onayla('“' + esc(bs.ad) + '” silinsin mi?', 'Bu binaya bağlı dersliklerin bina bilgisi boşalır.', 'Sil', function () {
          durum.derslikler.forEach(function (r0) { if (r0.binaId === bs.id) r0.binaId = ''; });
          durum.binaGecis = durum.binaGecis.filter(function (x) { return x.a !== bs.id && x.b !== bs.id; });
          durum.binalar.splice(+v, 1); degisti(true); ciz();
        });
        break;
      }
      case 'gecis-ekle': if (durum.binalar.length > 1) { durum.binaGecis.push({ a: durum.binalar[0].id, b: durum.binalar[1].id, dk: 15, ayniGunYasak: false }); degisti(true); ciz(); } break;
      case 'gecis-sil': durum.binaGecis.splice(+v, 1); degisti(true); ciz(); break;
      case 'derslik-ekle': durum.derslikler.push({ id: yeniKimlik('r'), ad: 'Derslik ' + (durum.derslikler.length + 1), binaId: (durum.binalar[0] || {}).id || '', tur: 'normal' }); degisti(true); ciz(); break;
      case 'derslik-sil': {
        var rs = durum.derslikler[+v];
        onayla('“' + esc(rs.ad) + '” silinsin mi?', 'Bu dersliği kullanan şube ve kulüp bağlantıları kaldırılır.', 'Sil', function () {
          durum.subeler.forEach(function (sb0) { if (sb0.derslikId === rs.id) sb0.derslikId = ''; });
          durum.kulupler.forEach(function (k0) { if (k0.derslikId === rs.id) k0.derslikId = ''; });
          durum.derslikler.splice(+v, 1); degisti(true); ciz();
        });
        break;
      }
      case 'derslik-sube-olustur': {
        var bosta = durum.subeler.filter(function (sb0) { return !sb0.derslikId; });
        if (!bosta.length) { bildir('Bütün şubelerin dersliği var.'); break; }
        bosta.forEach(function (sb0) { var r0 = { id: yeniKimlik('r'), ad: sb0.ad + ' sınıfı', binaId: (durum.binalar[0] || {}).id || '', tur: 'normal' }; durum.derslikler.push(r0); sb0.derslikId = r0.id; });
        degisti(true); ciz(); bildir(bosta.length + ' şubeye sınıf dersliği oluşturuldu' + (durum.binalar.length > 1 ? '; binalarını tablodan düzenleyin.' : '.'));
        break;
      }
      case 'derslik-oneri': {
        var esle = [[/^(Fen Bilimleri|Fizik|Kimya|Biyoloji)/, 'laboratuvar'], [/^Beden Eğitimi/, 'spor'], [/^Bilişim/, 'bilisim'], [/^Görsel Sanatlar/, 'gorsel'], [/^Müzik/, 'muzik']];
        var nE = 0;
        dersListesi().forEach(function (d0) {
          esle.forEach(function (e0) {
            if (e0[0].test(d0.ders) && durum.derslikler.some(function (r0) { return r0.tur === e0[1]; }) && dersAyari(d0.ders).derslikTuru !== e0[1]) {
              durum.dersAyar[d0.ders] = Object.assign({}, durum.dersAyar[d0.ders], { derslikTuru: e0[1] }); nE++;
            }
          });
        });
        degisti(true); ciz(); bildir(nE ? nE + ' ders uygun derslik türüne bağlandı.' : 'Eşleşecek ders ya da uygun türde derslik yok (önce laboratuvar, spor salonu vb. ekleyin).', nE ? '' : 'hata');
        break;
      }
      case 'kulup-ekle': durum.kulupler.push({ id: yeniKimlik('k'), ad: '', ogretmenId: '', subeIds: [], saat: 1, sabit: null, derslikId: '' }); degisti(true); ciz(); setTimeout(function () { var x = document.querySelectorAll('.kulup-ad'); if (x.length) x[x.length - 1].focus(); }, 30); break;
      case 'kulup-sil': onayla('Kulüp silinsin mi?', '“' + esc(durum.kulupler[+v].ad || 'adsız') + '” kulübü ve dağıtımdaki saati kaldırılır.', 'Sil', function () { durum.kulupler.splice(+v, 1); degisti(true); ciz(); }); break;
      case 'kulup-sube': case 'kulup-duzey': {
        var kb0 = durum.kulupler[+v], l0 = kb0.subeIds = kb0.subeIds || [];
        if (a === 'kulup-sube') { var ix = l0.indexOf(k); if (ix >= 0) l0.splice(ix, 1); else l0.push(k); }
        else {
          var dz = durum.subeler.filter(function (x) { return x.sinif === k; }).map(function (x) { return x.id; });
          var hepsi0 = dz.every(function (x) { return l0.indexOf(x) >= 0; });
          dz.forEach(function (x) { var i0 = l0.indexOf(x); if (hepsi0 && i0 >= 0) l0.splice(i0, 1); if (!hepsi0 && i0 < 0) l0.push(x); });
        }
        degisti(true); ciz(); break;
      }
      case 'ogr-tercih-ac': ui.modal = { tip: 'ogrTercih', id: v }; ciz(); break;
      case 'ogr-tercih-gun': { var ot = ogretmen(ui.modal.id), tg0 = ot.tercihGunler = ot.tercihGunler || [], gi = tg0.indexOf(+v); if (gi >= 0) tg0.splice(gi, 1); else tg0.push(+v); tg0.sort(); degisti(true); ciz(); break; }
      case 'ortak-sil': { var po = v.split('|'), oid0 = po.pop(), did0 = po.join('|'); durum.ortakOgretmen[did0] = ortakOgretmenler(did0).filter(function (x) { return x !== oid0; }); if (!durum.ortakOgretmen[did0].length) delete durum.ortakOgretmen[did0]; degisti(true); ciz(); bildir('Ortak öğretmen kaldırıldı; yeniden dağıtın.'); break; }
      case 'paralel-ac': {
        if (durum.paralelGrup[v]) delete durum.paralelGrup[v]; else durum.paralelGrup[v] = 'P';
        var sid0 = v.split('|')[0], uye = Object.keys(durum.paralelGrup).filter(function (x) { return x.split('|')[0] === sid0; });
        var saatler0 = dersListesi().filter(function (d0) { return uye.indexOf(d0.id) >= 0; }).map(function (d0) { return d0.saat; });
        degisti(true); ciz();
        if (uye.length === 1) bildir('Paralel grup için aynı şubeden en az iki seçmeli işaretleyin (aynı saatte, öğrenciler bölünerek okutulur).');
        else if (saatler0.some(function (x) { return x !== saatler0[0]; })) bildir('Paralel gruptaki derslerin haftalık saatleri eşit olmalı.', 'hata');
        else if (uye.length > 1) bildir(uye.length + ' seçmeli paralel grup oldu: aynı saatte yerleşecek (CP-SAT).');
        break;
      }
      case 'rapor-ac': ui.raporAcik = !ui.raporAcik; ciz(); break;
      case 'rapor-sekme': ui.raporSekme = v; ui.raporAcik = true; ciz(); break;
      case 'dagitim-kontrol': {
        if (!durum.sonuc) break;
        var ih = kuralDenetle(durum.sonuc);
        durum.sonuc.cozucu = durum.sonuc.cozucu || {};
        durum.sonuc.cozucu.kuralIhlalleri = ih;
        durum.sonuc.cozucu.basarili = !ih.length && !durum.sonuc.istatistik.eksikSaat && !(durum.sonuc.cozucu.desteklenmeyen || []).length;
        ui.raporAcik = true; ui.raporSekme = 'ihlal'; degisti(); ciz();
        bildir(ih.length ? ih.length + ' kural ihlali bulundu; ayrıntılar raporda.' : 'Denetim tamam: zorunlu kural ihlali yok.', ih.length ? 'hata' : '');
        break;
      }
      case 'excel': excelAktar(); break;
      case 'is-iptal':
        if (ui.is) { if (ui.is.worker) ui.is.worker.terminate(); clearTimeout(ui.is.zaman); if (ui.is.id) { var isId = ui.is.id; api('dagit-iptal', { is: isId }).catch(function () {}); } }
        ui.calisiyor = false; ui.is = null; ciz(); bildir('Dağıtım durduruldu.');
        break;

      case 'belge-ac': ui.belgeAcik = !el.parentNode.open; break;
      case 'gelismis-ac': ui.gelismisAcik = !el.parentNode.open; break;
      case 'yardim-ac': ui.yardimAcik = ui.yardimAcik || {}; ui.yardimAcik[ui.adim] = !ui.yardimAcik[ui.adim]; ciz(); break;
      case 'onay-evet': { var o0 = ui.onay; ui.onay = null; onayCiz(); if (o0 && o0.islem) o0.islem(); break; }
      case 'onay-hayir': if (ui.onay && ui.onay.ikinci) break; ui.onay = null; onayCiz(); break;
      case 'onay-ikinci': { var o1 = ui.onay; ui.onay = null; onayCiz(); if (o1 && o1.ikinci) o1.ikinci.islem(); break; }
      case 'demo': {
        var demo = function () {
          durum = varsayilanDurum(durum.okul.turId, durum);
          M.otomatikAta(durum, VERI, { maxSaat: durum.ayarlar.maxSaat });
          ui.adim = 'dagitim'; ui.gorunum = 'sube'; degisti(); ciz(); dagitimiCalistir('hizli');
        };
        if (durum.ogretmenler.length || durum.sonuc) onayla('Örnek veriyle başlansın mı?', 'Şubeler, dersler, öğretmenler ve dağıtım örnek verilerle değiştirilecek. Gerekirse önce JSON yedeği alın.', 'Örnekle başla', demo, true);
        else demo();
        break;
      }
      case 'sifirla':
        onayla('Tüm veriler silinsin mi?', 'Şubeler, dersler, öğretmenler, kısıtlar, kilitler, dağıtımlar ve nöbetler silinir. Bu işlem geri alınamaz.', 'Sıfırla', function () {
          var pid = durum.projeId, prev = durum.projeRev; durum = varsayilanDurum(durum.okul.turId); if (pid) { durum.projeId = pid; durum.projeRev = prev; }
          ui.adim = 'okul'; degisti(); ciz(); bildir('Veriler sıfırlandı.');
        });
        break;
      case 'yeni':
        onayla('Yeni proje açılsın mı?', 'Mevcut proje hesabınızda kayıtlı kalır; yeni ve boş bir proje başlatılır.', 'Yeni proje', function () {
          durum = varsayilanDurum(durum.okul.turId); ui.adim = 'okul'; degisti(); ciz(); bildir('Yeni proje başlatıldı.');
        }, true);
        break;
      case 'kaydet': sunucuKaydet(false); break;

      // Şubeler
      case 'sube-olustur': {
        var istek = {}, silinecek = [];
        document.querySelectorAll('.hizli-sayi').forEach(function (inp) { istek[inp.getAttribute('data-sinif')] = Math.max(0, Math.min(20, parseInt(inp.value, 10) || 0)); });
        t.siniflar.forEach(function (s) {
          var mevcut = durum.subeler.filter(function (x) { return x.sinif === s; });
          if (mevcut.length > istek[s]) silinecek = silinecek.concat(mevcut.slice(istek[s]));
        });
        var uygula = function () {
          silinecek.forEach(function (x) { subeSil(x.id); });
          var eklenen = 0;
          t.siniflar.forEach(function (s) {
            while (durum.subeler.filter(function (x) { return x.sinif === s; }).length < istek[s]) { if (!subeEkle(s)) break; eklenen++; }
          });
          degisti(true); ciz(); bildir(eklenen + ' şube eklendi' + (silinecek.length ? ', ' + silinecek.length + ' şube silindi' : '') + '.');
        };
        if (silinecek.length) onayla('Şubeler silinsin mi?', '<b>' + silinecek.map(function (x) { return esc(x.ad); }).join(', ') + '</b> ve bu şubelere ait ders atamaları, kilitler ve şubeye özel seçmeliler silinecek.', 'Sil ve uygula', uygula);
        else uygula();
        break;
      }
      case 'sube-arti': { var yeni = subeEkle(v); if (!yeni) bildir('Bu düzeyde en fazla ' + M.HARFLER.length + ' şube açılabilir.'); degisti(true); ciz(); break; }
      case 'sube-sil': {
        var sb = sube(v);
        onayla(sb.ad + ' şubesi silinsin mi?', 'Bu şubenin ders atamaları, saat değişiklikleri, kilitleri, kapalı saatleri ve şubeye özel seçmelileri de silinir.', 'Şubeyi sil', function () { subeSil(v); degisti(true); ciz(); bildir(sb.ad + ' silindi.'); });
        break;
      }

      // Seçmeliler
      case 'secmeli-sil': {
        var silS = secmeliListesi(k, v).splice(+el.getAttribute('data-i'), 1)[0];
        kilitleriTemizle(); degisti(true); ciz();
        if (silS) bildir(silS.ad + (k === 'sube' ? ' ' + (sube(v) || {}).ad + ' şubesinden' : '') + ' kaldırıldı.');
        break;
      }
      case 'secmeli-oner': {
        var oneri = M.onerilenSecmeliler(t, VERI, k === 'sube' ? sube(v).sinif : v);
        if (k === 'sube') durum.subeSecmeli[v] = oneri; else durum.secmeliler[v] = oneri;
        degisti(true); ciz(); break;
      }
      case 'secmeli-ozel':
        durum.subeSecmeli[v] = JSON.parse(JSON.stringify(durum.secmeliler[sube(v).sinif] || []));
        degisti(true); ciz(); break;
      case 'secmeli-duzeye':
        delete durum.subeSecmeli[v];
        Object.keys(durum.atamalar).forEach(function (key) { if (key.indexOf(v + '|S:') === 0 && !dersListesi().some(function (d) { return d.id === key; })) delete durum.atamalar[key]; });
        degisti(true); ciz(); break;
      case 'secmeli-oner-tum':
        onayla('Tüm şubelere seçmeli önerilsin mi?', 'Tüm sınıf düzeylerinde seçmeliler, her gruptan en az bir ders olacak şekilde yeniden oluşturulur; şubeye özel listeler düzey listesine döner.', 'Öner', function () {
          t.siniflar.forEach(function (s) { durum.secmeliler[s] = M.onerilenSecmeliler(t, VERI, s); }); durum.subeSecmeli = {}; kilitleriTemizle(); degisti(true); ciz(); bildir('Seçmeliler önerildi.');
        }, true);
        break;

      case 'secmeli-sinif': ui.secmeliSinif = v; ui.secDers = {}; ui.secSube = {}; ciz(); break;
      case 'secmeli-liste-ac': ui.secmeliListeAcik = !el.parentNode.open; break;
      case 'dd7-sec-gorunen': {
        ui.secDers = ui.secDers || {};
        document.querySelectorAll('.havuz-oge').forEach(function (row) {
          if (row.style.display === 'none') return;
          var ch = row.querySelector('[data-a="sec-ders-sec"]');
          if (ch && !ch.disabled) ui.secDers[ch.value] = true;
        }); ciz(); break;
      }
      case 'dd7-sec-temizle': ui.secDers = {}; ui.secSadeceSecili = false; ciz(); break;
      case 'dd7-sec-sadece': ui.secSadeceSecili = !ui.secSadeceSecili; ciz(); break;
      case 'dd7-sec-bos-sube': {
        ui.secSube = {}; durum.subeler.filter(function (sb) { return sb.sinif === ui.secmeliSinif && secmeliToplam(M.subeSecmelileri(durum, sb)) < secmeliGerekli('sube', sb.id); }).forEach(function (sb) { ui.secSube[sb.id] = true; });
        ciz(); break;
      }
      case 'sec-grup': ui.secGrup = v; ciz(); break;
      case 'secim-temizle': ui.secDers = {}; ui.secSube = {}; ciz(); break;
      case 'secmeli-ata': {
        var secDersN = Object.keys(ui.secDers || {}).filter(function(x){return ui.secDers[x];}).length;
        var secSubeN = Object.keys(ui.secSube || {}).filter(function(x){return ui.secSube[x];}).length;
        if (!secDersN || !secSubeN) { bildir('Önce dersleri ve şubeleri seçin.', 'hata'); break; }
        onayla('Seçmeli dersleri şubelere ata', secDersN + ' seçmeli ders, ' + secSubeN + ' şubeye uygulanacak. Haftalık saat sınırı önce kontrol edilir; geçersiz atama yapılmaz.', 'Seçilileri ata', function(){ secmeliTopluUygula(false); }, true);
        break;
      }
      case 'secmeli-kaldir': {
        var nD = Object.keys(ui.secDers).filter(function (x) { return ui.secDers[x]; }).length, nS = Object.keys(ui.secSube).filter(function (x) { return ui.secSube[x]; }).length;
        onayla('Seçilen seçmeliler kaldırılsın mı?', nD + ' ders, seçili ' + nS + ' şubenin seçmeli listesinden çıkarılır. Bu derslere yapılan öğretmen atamaları da düşer.', 'Kaldır', function () { secmeliTopluUygula(true); });
        break;
      }
      case 'ozel-secmeli-ac': ui.modal = { tip: 'ozelSecmeli' }; ciz(); break;
      case 'ozel-secmeli-kaydet': {
        var msAd = ($('#ms-ad').value || '').replace(/\s+/g, ' ').trim();
        var msSinif = Array.prototype.map.call(document.querySelectorAll('.ms-sinif:checked'), function (x) { return x.value; });
        if (!msAd) { bildir('Ders adını yazın.', 'hata'); break; }
        if (!msSinif.length) { bildir('En az bir sınıf düzeyi seçin.', 'hata'); break; }
        var ayni = secmeliHavuzu().some(function (x) { return x[0].toLocaleLowerCase('tr') === msAd.toLocaleLowerCase('tr'); }) ||
          dersListesi().some(function (x) { return x.grup !== 'Seçmeli' && x.ders.toLocaleLowerCase('tr') === msAd.toLocaleLowerCase('tr'); });
        if (ayni) { bildir('“' + msAd + '” adında bir ders zaten var.', 'hata'); break; }
        var msSaat = +$('#ms-saat').value || 2, msGrup = $('#ms-grup').value || 'Okula özel';
        var msHedefId = Array.prototype.map.call(document.querySelectorAll('.ms-hedef-sube:checked'), function (x) { return x.value; });
        var msHedefler = v === 'ata' ? durum.subeler.filter(function (sb) { return sb.sinif === ui.secmeliSinif && msHedefId.indexOf(sb.id) >= 0; }) : [];
        if (v === 'ata') {
          if (msSinif.indexOf(ui.secmeliSinif) < 0) { bildir('Şubelere atamak için geçerli sınıf düzeyini de işaretleyin.', 'hata'); break; }
          if (!msHedefler.length) { bildir('Atama için en az bir şube işaretleyin veya dersi yalnız havuza kaydedin.', 'hata'); break; }
          var msYetersiz = msHedefler.filter(function (sb) { return secmeliToplam(M.subeSecmelileri(durum, sb)) + msSaat > secmeliGerekli('sube', sb.id); });
          if (msYetersiz.length) { bildir(msYetersiz.map(function (sb) { return sb.ad; }).join(', ') + ': seçmeli saat sınırı dolu. Önce mevcut seçmeli saatlerini azaltın veya “Yalnız havuza kaydet” seçeneğini kullanın.', 'hata'); break; }
        }
        durum.ozelSecmeliler.push({ ad: msAd, grup: msGrup, saat: msSaat, siniflar: msSinif });
        msHedefler.forEach(function (sb) { secmeliListesi('sube', sb.id).push({ad:msAd, grup:msGrup, saat:msSaat}); });
        ui.modal = null; ui.secDers = ui.secDers || {};
        if (msSinif.indexOf(ui.secmeliSinif) >= 0 && !msHedefler.length) ui.secDers[msAd] = true;
        if (msHedefler.length) kilitleriTemizle();
        degisti(!!msHedefler.length); ciz(); bildir('“' + msAd + '” havuza eklendi' + (msHedefler.length ? ' ve ' + msHedefler.length + ' şubeye atandı.' : '. Dersleri ve şubeleri seçip atama yapabilirsiniz.'));
        break;
      }
      case 'ozel-secmeli-sil': {
        var osAd = v, osKul = 0;
        Object.keys(durum.secmeliler).forEach(function (x) { osKul += (durum.secmeliler[x] || []).filter(function (y) { return y.ad === osAd; }).length; });
        Object.keys(durum.subeSecmeli).forEach(function (x) { osKul += (durum.subeSecmeli[x] || []).filter(function (y) { return y.ad === osAd; }).length; });
        onayla('“' + osAd + '” silinsin mi?', 'Okula özel ders havuzdan kaldırılır' + (osKul ? ' ve atandığı ' + osKul + ' listeden de çıkarılır' : '') + '.', 'Sil', function () {
          durum.ozelSecmeliler = durum.ozelSecmeliler.filter(function (x) { return x.ad !== osAd; });
          var temizle = function (l) { return (l || []).filter(function (y) { return y.ad !== osAd; }); };
          Object.keys(durum.secmeliler).forEach(function (x) { durum.secmeliler[x] = temizle(durum.secmeliler[x]); });
          Object.keys(durum.subeSecmeli).forEach(function (x) { durum.subeSecmeli[x] = temizle(durum.subeSecmeli[x]); });
          delete ui.secDers[osAd]; kilitleriTemizle(); degisti(true); ciz(); bildir('“' + osAd + '” silindi.');
        });
        break;
      }
      case 'havuz-kapsam': ui.havuzKapsam = v; ciz(); break;
      case 'ek-brans-sil': { var ob2 = ogretmen(v); ob2.ekBranslar.splice(+el.getAttribute('data-i'), 1); degisti(); ciz(); break; }
      case 'ogr-derslerini-kaldir': {
        var ok2 = ogretmen(v);
        onayla(ok2.ad + ' öğretmeninin atamaları kaldırılsın mı?', 'Tüm dersleri atanmamış olarak kalır; öğretmen listeden silinmez.', 'Kaldır', function () {
          Object.keys(durum.atamalar).forEach(function (key) { if (durum.atamalar[key] === v) delete durum.atamalar[key]; });
          degisti(true); ciz();
        });
        break;
      }

      // Zorunlu dersler
      case 'zorunlu-gorunum': ui.zorunluGorunum = v; ciz(); break;
      case 'zorunlu-sifirla':
        onayla('MEB çizelgesine dönülsün mü?', 'Tüm saat değişiklikleri ve okulun eklediği dersler silinir; şubeler MEB çizelgesindeki derslere döner.', 'MEB’e döndür', function () {
          durum.saatDegisiklik = {}; durum.ekDersler = []; degisti(true); ciz(); bildir('Dersler MEB çizelgesine döndürüldü.');
        });
        break;
      case 'ders-kaldir': {
        var p1 = v.split('|'), sinif1 = p1[0], ders1 = p1.slice(1).join('|');
        onayla(ders1 + ' kaldırılsın mı?', 'Ders tüm ' + esc(sinifEtiketi(sinif1)) + ' şubelerinden kaldırılır (saat 0 yapılır). Haftalık ders saati MEB toplamının altına düşerse uyarı gösterilir. “Geri al” ile geri getirebilirsiniz.', 'Kaldır', function () {
          durum.subeler.filter(function (x) { return x.sinif === sinif1; }).forEach(function (x) { durum.saatDegisiklik[x.id + '|' + ders1] = 0; });
          degisti(true); ciz();
        });
        break;
      }
      case 'ders-geri-al': {
        var p3 = v.split('|'), sinif3 = p3[0], ders3 = p3.slice(1).join('|');
        var mebSaat3 = (t.dersler.filter(function (r) { return r[0] === ders3; })[0] || [0, 0, []])[2][t.siniflar.indexOf(sinif3)] || 0;
        var dl3 = dersListesi(), asan3 = durum.subeler.filter(function (x) { return x.sinif === sinif3; }).filter(function (x) { var ss3 = subeSaatleri(x.id, dl3); return ss3.toplam + mebSaat3 > ss3.sinir; });
        if (asan3.length) { bildir('Geri alınamaz: ' + asan3.map(function (x) { return x.ad; }).join(', ') + ' haftalık ders saatini aşar. Önce eklediğiniz dersleri azaltın.', 'hata'); break; }
        durum.subeler.filter(function (x) { return x.sinif === sinif3; }).forEach(function (x) { delete durum.saatDegisiklik[x.id + '|' + ders3]; });
        degisti(true); ciz(); break;
      }
      case 'ek-ders-ekle': {
        var ad = ($('#ek-ad-' + v).value || '').trim(), saat = parseInt($('#ek-saat-' + v).value, 10) || 0, hedef = $('#ek-hedef-' + v).value || null;
        if (!ad) { bildir('Ders adını yazın.', 'hata'); break; }
        if (saat < 1) { bildir('Haftalık saat en az 1 olmalı.', 'hata'); break; }
        var si = t.siniflar.indexOf(v);
        var mebVar = t.dersler.some(function (r) { return r[0] === ad; });
        var dl0 = dersListesi(), asan = [];
        durum.subeler.filter(function (x) { return x.sinif === v && (!hedef || x.id === hedef); }).forEach(function (x) {
          var mevcut = dl0.filter(function (d) { return d.subeId === x.id && d.ders === ad; })[0];
          var ss0 = subeSaatleri(x.id, dl0);
          if (ss0.toplam - (mevcut ? mevcut.saat : 0) + saat > ss0.sinir) asan.push(x.ad + ' (' + ss0.toplam + '/' + ss0.sinir + ')');
        });
        if (asan.length) { bildir('Haftalık ders saati aşılır: ' + asan.join(', ') + '. Önce bir dersin saatini azaltın ya da kaldırın.', 'hata'); break; }
        if (mebVar) {
          // MEB dersi kaldırılmışsa saatini geri ver
          durum.subeler.filter(function (x) { return x.sinif === v && (!hedef || x.id === hedef); }).forEach(function (x) {
            var meb = t.dersler.filter(function (r) { return r[0] === ad; })[0][2][si];
            if (saat === meb) delete durum.saatDegisiklik[x.id + '|' + ad]; else durum.saatDegisiklik[x.id + '|' + ad] = saat;
          });
        } else {
          if (durum.ekDersler.some(function (e2) { return e2.ad === ad && e2.sinif === v && (e2.subeId || null) === hedef; })) { bildir('Bu ders zaten eklenmiş.', 'hata'); break; }
          durum.ekDersler.push({ id: yeniId('e'), ad: ad, saat: saat, sinif: v, subeId: hedef, grup: 'Ek' });
        }
        if (ui.modal && ui.modal.tip === 'dd6ZorEkle') ui.modal = null;
        degisti(true); ciz(); bildir(ad + ' eklendi.'); break;
      }
      case 'ek-ders-sil': {
        var ek = durum.ekDersler.filter(function (x) { return x.id === v; })[0];
        if (!ek) break;
        onayla(ek.ad + ' silinsin mi?', 'Okulun eklediği bu ders ' + (ek.subeId ? esc((sube(ek.subeId) || {}).ad) + ' şubesinden' : 'tüm ' + esc(sinifEtiketi(ek.sinif)) + ' şubelerinden') + ' silinir; öğretmen ataması ve kilitleri de kaldırılır.', 'Sil', function () {
          durum.ekDersler = durum.ekDersler.filter(function (x) { return x.id !== v; });
          kilitleriTemizle(); degisti(true); ciz();
        });
        break;
      }

      // Blok düzeni
      case 'blok-kalip': {
        var kl0 = durum.blokKurallari[v] = durum.blokKurallari[v] || [];
        var j0 = kl0.indexOf(k);
        if (j0 >= 0) kl0.splice(j0, 1); else kl0.push(k);
        if (!kl0.length) delete durum.blokKurallari[v];
        degisti(true); ciz(); break;
      }
      case 'blok-sifirla': delete durum.blokKurallari[v]; degisti(true); ciz(); break;
      case 'blok-ozel-temizle':
        onayla('Şube ayarları temizlensin mi?', 'Tek tek derslere verilmiş blok düzenleri silinir; dersler düzey kuralını kullanır.', 'Temizle', function () { durum.yerlesimler = {}; degisti(true); ciz(); });
        break;

      // Öğretmenler
      case 'oto-ata': {
        onayla('Eksik öğretmenleri otomatik ata',
          'Bu gelişmiş işlem, mevcut öğretmenler yeterli değilse yeni öğretmen kayıtları oluşturabilir. Gerçek okul personeli dışında otomatik isimler oluşabileceği için sonucu mutlaka kontrol edin.',
          'Kontrol ederek otomatik ata', function () {
            var once = durum.ogretmenler.length;
            M.otomatikAta(durum, VERI, { maxSaat: durum.ayarlar.maxSaat });
            degisti(true); ciz();
            bildir((durum.ogretmenler.length - once) + ' yeni öğretmen oluşturuldu; eksik atamalar güncellendi. Öğretmenleri doğrulayın.');
          });
        break;
      }
      case 'atama-temizle':
        onayla('Tüm atamalar temizlensin mi?', 'Bütün derslerin öğretmen ataması kaldırılır; öğretmen listesi silinmez.', 'Temizle', function () { durum.atamalar = {}; degisti(true); ciz(); bildir('Atamalar temizlendi.'); });
        break;
      case 'ogr-ekle': {
        var ad2 = $('#yeni-ogr-ad').value.trim(), br = $('#yeni-ogr-brans').value, mx = parseInt($('#yeni-ogr-max').value, 10) || durum.ayarlar.maxSaat;
        if (!ad2) { bildir('Öğretmen adını yazın.', 'hata'); return; }
        durum.ogretmenler.push({ id: yeniId('o'), ad: ad2, brans: br, maxSaat: mx, kapali: [] });
        degisti(true); ciz(); bildir(ad2 + ' eklendi.'); break;
      }
      case 'ogr-toplu-ekle': {
        var satirlar = ($('#toplu-ogr').value || '').split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean);
        var br2 = $('#yeni-ogr-brans').value, mx2 = parseInt($('#yeni-ogr-max').value, 10) || durum.ayarlar.maxSaat;
        satirlar.forEach(function (ad3) { durum.ogretmenler.push({ id: yeniId('o'), ad: ad3, brans: br2, maxSaat: mx2, kapali: [] }); });
        degisti(true); ciz(); bildir(satirlar.length + ' öğretmen eklendi (' + br2 + ').'); break;
      }
      case 'ogr-sil': {
        var o1 = ogretmen(v);
        var ds = dersListesi().filter(function (d) { return d.ogretmenId === v; }).length;
        onayla(o1.ad + ' silinsin mi?', ds ? 'Bu öğretmenin ' + ds + ' ders ataması kaldırılır; dersler atanmamış olarak kalır.' : 'Öğretmen listeden silinir.', 'Sil', function () { ogretmenSil([v]); degisti(true); ciz(); bildir(o1.ad + ' silindi.'); });
        break;
      }
      case 'ogr-toplu-sil': {
        var sec = seciliOgretmenler();
        onayla(sec.length + ' öğretmen silinsin mi?', '<b>' + sec.map(function (x) { return esc(x.ad); }).join(', ') + '</b> silinecek; ders atamaları kaldırılır.', 'Seçilenleri sil', function () {
          ogretmenSil(sec.map(function (x) { return x.id; })); degisti(true); ciz(); bildir(sec.length + ' öğretmen silindi.');
        });
        break;
      }
      case 'ogr-toplu-uygula': {
        var sec2 = seciliOgretmenler(), tb = $('#toplu-brans').value, tm = parseInt($('#toplu-max').value, 10), tk = $('#toplu-kulup').value.trim();
        if (!tb && !(tm > 0) && !tk) { bildir('Değiştirilecek alanı doldurun.', 'hata'); break; }
        sec2.forEach(function (o) { if (tb) o.brans = tb; if (tm > 0) o.maxSaat = tm; if (tk) o.kulup = tk; });
        degisti(true); ciz(); bildir(sec2.length + ' öğretmen güncellendi.'); break;
      }
      case 'ogr-atamalari-kaldir': {
        var sec3 = seciliOgretmenler(), ids3 = {};
        sec3.forEach(function (o) { ids3[o.id] = true; });
        onayla('Atamalar kaldırılsın mı?', sec3.length + ' öğretmenin tüm ders atamaları kaldırılır.', 'Kaldır', function () {
          Object.keys(durum.atamalar).forEach(function (key) { if (ids3[durum.atamalar[key]]) delete durum.atamalar[key]; });
          degisti(true); ciz();
        });
        break;
      }
      case 'ogr-secim-temizle': ui.secOgr = {}; ciz(); break;
      case 'ogr-git': ui.modal = null; ui.adim = 'atama'; ui.atamaGorunum = 'ogretmen'; ui.atamaOgr = v; ciz(); window.scrollTo(0, 0); break;

      // UX V3 Aşama 4 – aynı menü içinde ders-öğretmen atamaları
      case 'ux3a-gelismis': ui.ux3AtamaGelismis = !ui.ux3AtamaGelismis; ciz(); break;
      case 'ux3a-ac': {if(!dersBul(v))break;ui.ux3AtamaDiger=false;ui.modal={tip:'ux3Atama',dersId:v};modalCiz();break;}
      case 'ux3a-sec': {
        var ders = ui.modal && ui.modal.tip==='ux3Atama' ? dersBul(ui.modal.dersId) : null;
        var ogr = ogretmen(v);if(!ders || !ogr)break;
        var adaylar=ux3AtamaAdaylari(ders),aday=adaylar.find(function(x){return x.o.id===v;});
        if(!aday)break;
        if(aday.asin){bildir(ogr.ad+' için haftalık '+aday.sinir+' saat sınırı aşılır.','hata');break;}
        if(aday.kapali){bildir('Bu öğretmenin kapalı saati ile kilitli ders çakışıyor.','hata');break;}
        if(!aday.uyum){
          onayla('Branş dışı öğretmen ataması',esc(ogr.ad)+' öğretmeninin branşı <b>'+esc(ogr.brans)+'</b>. <b>'+esc(ders.ders)+'</b> için branş dışı atama yapılacak.', 'Branş dışı ata',function(){ogretmenDegistir(ders.id,ogr.id);});
        }else ogretmenDegistir(ders.id,ogr.id);
        break;
      }
      case 'ux3a-kaldir': {
        var d0=dersBul(v);if(!d0)break;
        onayla('Öğretmen ataması kaldırılsın mı?',esc((sube(d0.subeId)||{}).ad+' · '+d0.ders)+' dersinin öğretmeni kaldırılacak. Öğretmen kaydı silinmez; varsa dağıtım sonucu yeniden hesaplanmalıdır.', 'Atamayı kaldır',function(){delete durum.atamalar[v];ui.modal=null;degisti(true);ciz();bildir('Dersin öğretmen ataması kaldırıldı.');});
        break;
      }

      // Atama
      case 'atama-gorunum': ui.atamaGorunum = v; ciz(); break;
      case 'atama-sekme': ui.atamaSekme = v; if (ui.adim === 'atama') ui.atamaYerelSekme = v; ciz(); break;
      case 'atama-ogr': ui.atamaOgr = v; ciz(); break;
      case 'atama-kaldir': delete durum.atamalar[v]; degisti(true); ciz(); break;
      case 'havuzdan-ata': {
        var secilen = Array.prototype.map.call(document.querySelectorAll('.havuz-sec:checked'), function (x) { return x.value; });
        if (!secilen.length) { bildir('Havuzdan en az bir ders seçin.', 'hata'); break; }
        var alinan = secilen.filter(function (id) { return durum.atamalar[id] && durum.atamalar[id] !== v; }).length;
        var dSaat = {}; dersListesi().forEach(function (d) { dSaat[d.id] = d.saat; });
        secilen.forEach(function (id) { durum.atamalar[id] = v; });
        var yeniYuk = ogretmenYukleri(dersListesi())[v], hedefO = ogretmen(v);
        degisti(true); ciz();
        bildir(secilen.length + ' ders ' + hedefO.ad + ' öğretmenine atandı' + (alinan ? ' (' + alinan + ' ders başka öğretmenden alındı)' : '') + (yeniYuk > (hedefO.maxSaat || 30) ? '. Dikkat: ' + yeniYuk + ' saat, üst sınır ' + (hedefO.maxSaat || 30) + '.' : '.'), yeniYuk > (hedefO.maxSaat || 30) ? 'hata' : '');
        break;
      }

      // UX V3 Aşama 5 — menü içi sekmeler / haftalık uygunluk
      case 'ux5-kisit-sekme': ui.ux5KisitSekme=v; ciz(); break;
      case 'ux5-kilit-tip': ui.ux5KilitTip=v; ciz(); break;
      case 'ux5-kural-sekme': ui.ux5KuralSekme=v; ciz(); break;
      case 'ux5-kisit-hucre': {
        var tip5=ui.ux5KisitSekme==='sube'?'sube':'ogretmen';
        var id5=tip5==='sube'?ui.ux5KisitSube:ui.ux5KisitOgretmen;
        if (!id5) break;
        var l5=kapaliListesi(tip5,id5), ix5=l5.indexOf(v);
        if (ix5<0) { var p5=v.split('-'), err5=kapatmaHatasi(tip5,id5,+p5[0],+p5[1]); if (err5) { bildir(err5,'hata'); break; } l5.push(v); }
        else l5.splice(ix5,1);
        degisti(true); ciz(); break;
      }
      case 'ux5-kisit-gun': {
        var t5=ui.ux5KisitSekme==='sube'?'sube':'ogretmen', i5=t5==='sube'?ui.ux5KisitSube:ui.ux5KisitOgretmen;
        if (!i5) break;
        var a5=kapaliListesi(t5,i5), dg5=+v, hs5=+durum.okul.gunlukSaat;
        if (gunDurumu(a5,dg5,hs5)!=='kapali') { var er5=kapatmaHatasi(t5,i5,dg5,null); if (er5){bildir(er5,'hata');break;} }
        gunAcKapa(a5,dg5,hs5); degisti(true); ciz(); break;
      }
      case 'ux5-kisit-ac-hepsi': {
        var tt5=ui.ux5KisitSekme==='sube'?'sube':'ogretmen', idd5=tt5==='sube'?ui.ux5KisitSube:ui.ux5KisitOgretmen;
        if (!idd5) break;
        onayla('Bu '+(tt5==='sube'?'şubenin':'öğretmenin')+' tüm saatleri açılsın mı?', 'Yalnızca seçili kaydın kapalı saatleri kaldırılacaktır. Ders kilitleri değişmez.', 'Tüm saatleri aç', function(){kapaliListesi(tt5,idd5).length=0;degisti(true);ciz();bildir('Seçili kaydın saatleri açıldı.');});
        break;
      }
      // Kısıtlar ve kilitler
      case 'uygunluk': ui.modal = { tip: k || 'ogretmen', id: v }; modalCiz(); break;
      case 'modal-kapat': ui.modal = null; ciz(); break;
      case 'uyg-hucre': {
        var uygTip = ui.modal.tip || 'ogretmen', L = kapaliListesi(uygTip, ui.modal.id), ii = L.indexOf(v);
        if (ii < 0) {
          var uygSlot = v.split('-'), uygHata = kapatmaHatasi(uygTip, ui.modal.id, +uygSlot[0], +uygSlot[1]);
          if (uygHata) { bildir(uygHata, 'hata'); break; }
        }
        if (ii >= 0) L.splice(ii, 1); else L.push(v);
        degisti(true); modalCiz(); break;
      }
      case 'uyg-gun': {
        var uygT = ui.modal.tip || 'ogretmen', uygL = kapaliListesi(uygT, ui.modal.id), uygG = +v;
        if (gunDurumu(uygL, uygG, +durum.okul.gunlukSaat) !== 'kapali') {
          var uygGH = kapatmaHatasi(uygT, ui.modal.id, uygG, null);
          if (uygGH) { bildir(uygGH, 'hata'); break; }
        }
        gunAcKapa(uygL, uygG, +durum.okul.gunlukSaat); degisti(true); modalCiz(); break;
      }
      case 'uyg-saat': {
        var uygTip2 = ui.modal.tip || 'ogretmen', L2 = kapaliListesi(uygTip2, ui.modal.id), Dg = +durum.okul.gunSayisi, hepsi2 = true;
        for (var g2 = 0; g2 < Dg; g2++) if (L2.indexOf(g2 + '-' + v) < 0) hepsi2 = false;
        if (!hepsi2) {
          var saatHata = null;
          for (g2 = 0; g2 < Dg; g2++) if (L2.indexOf(g2 + '-' + v) < 0) {
            saatHata = kapatmaHatasi(uygTip2, ui.modal.id, g2, +v);
            if (saatHata) break;
          }
          if (saatHata) { bildir(saatHata, 'hata'); break; }
        }
        for (g2 = 0; g2 < Dg; g2++) {
          var k2 = g2 + '-' + v, j2 = L2.indexOf(k2);
          if (hepsi2 && j2 >= 0) L2.splice(j2, 1);
          if (!hepsi2 && j2 < 0) L2.push(k2);
        }
        degisti(true); modalCiz(); break;
      }
      case 'uyg-temizle': kapaliListesi(ui.modal.tip || 'ogretmen', ui.modal.id).length = 0; degisti(true); modalCiz(); break;
      case 'kisit-sekme': ui.kisitSekme = v; ciz(); break;
      case 'gun-ackapa': {
        var gunK = +el.getAttribute('data-i'), gunL = kapaliListesi(k, v);
        if (gunDurumu(gunL, gunK, +durum.okul.gunlukSaat) !== 'kapali') {
          var gunHata = kapatmaHatasi(k, v, gunK, null);
          if (gunHata) { bildir(gunHata, 'hata'); break; }
        }
        gunAcKapa(gunL, gunK, +durum.okul.gunlukSaat); degisti(true); ciz(); break;
      }
      case 'bos-gun-ver': {
        var Dn = +durum.okul.gunSayisi, yk = ogretmenYukleri(dersListesi()), n3 = 0, atlanan = 0;
        durum.ogretmenler.forEach(function (o) {
          var eski = o.maxGun; o.maxGun = Dn - 1;
          if ((yk[o.id] || 0) > ogretmenKapasite(o).gunSiniriyla) { o.maxGun = eski; atlanan++; } else n3++;
        });
        degisti(true); ciz(); bildir(n3 + ' öğretmene haftada en fazla ' + (Dn - 1) + ' gün tanımlandı' + (atlanan ? '; ' + atlanan + ' öğretmenin yükü buna uygun değil' : '') + '.'); break;
      }
      case 'kisit-temizle-ogr':
        onayla('Öğretmen kısıtları temizlensin mi?', 'Tüm öğretmenlerin kapalı gün/saatleri, günlük ve haftalık gün sınırları silinir.', 'Temizle', function () {
          durum.ogretmenler.forEach(function (o) { o.kapali = []; delete o.maxGunluk; delete o.maxGun; });
          degisti(true); ciz(); bildir('Öğretmen kısıtları temizlendi.');
        });
        break;
      case 'kilit-hepsini-sil':
        onayla('Tüm kilitler kaldırılsın mı?', kilitSayisi() + ' kilitli blok serbest bırakılır; yeniden dağıtımda yerleri değişebilir.', 'Kilitleri kaldır', function () { durum.kilitler = {}; degisti(); ciz(); bildir('Tüm kilitler kaldırıldı.'); });
        break;
      case 'kilit-ders': ui.kilitDers = ui.kilitDers === v ? null : v; ciz(); break;
      case 'kilit-kaldir': {
        var pk = v.split('|'), ks = +pk.pop(), kg = +pk.pop();
        kilitSil(pk.join('|'), kg, ks); degisti(); ciz(); break;
      }
      case 'kilit-hucre': {
        var ph = v.split('|'), hg = +ph[0], hs = +ph[1], hata;
        if (ui.kilitDers) {
          var dd = dersListesi().filter(function (x) { return x.id === ui.kilitDers; })[0];
          var kl = (kilitler()[ui.kilitDers] || []).reduce(function (a2, x) { return a2 + x.uzunluk; }, 0);
          var uz = Math.min(ui.kilitUzunluk || 2, dd ? dd.saat - kl : 1);
          hata = kilitEkle(ui.kilitDers, hg, hs, Math.max(1, uz));
        } else if (el.getAttribute('data-y')) {
          var py = el.getAttribute('data-y').split('|'), yu = +py.pop(), ys = +py.pop(), yg = +py.pop();
          hata = kilitEkle(py.join('|'), yg, ys, yu);
        } else { bildir('Önce soldaki listeden kilitlenecek dersi seçin.'); break; }
        if (hata) bildir(hata, 'hata'); else { degisti(); ciz(); }
        break;
      }
      case 'hucre-tik': {
        var pc = v.split('|'), cu = +pc.pop(), cs = +pc.pop(), cg = +pc.pop(), cid = pc.join('|');
        var mod = ui.duzenMod || 'tasi';
        if (mod === 'bak') break;
        if (mod === 'kilit') {
          if (!kilitSil(cid, cg, cs)) { var hc = kilitEkle(cid, cg, cs, cu); if (hc) { bildir(hc, 'hata'); break; } bildir('Kilitlendi: yeniden dağıtımda bu ders burada kalır.'); }
          else bildir('Kilit kaldırıldı.');
          if (durum.sonuc) istatistikYenile(true);
          degisti(); ciz(); break;
        }
        var sb0 = ui.secBlok, ix = yerlesimIndeksi(cid, cg, cs);
        if (!sb0) { ui.secBlok = { tip: 'yer', dersId: cid, gun: cg, saat: cs }; ciz(); break; }
        if (sb0.tip !== 'bekleyen' && sb0.dersId === cid && sb0.gun === cg && sb0.saat === cs) { ui.secBlok = null; ciz(); break; }
        if (sb0.tip === 'bekleyen') { bildir('Yerleşmemiş dersi boş (yeşil) bir saate yerleştirin.', 'hata'); break; }
        var i1 = yerlesimIndeksi(sb0.dersId, sb0.gun, sb0.saat);
        var hd = blokDegistir(i1, ix);
        if (hd) { bildir(hd, 'hata'); break; }
        ui.secBlok = null; degisti(); ciz(); bildir('Dersler yer değiştirdi' + (ui.tasiKilitle !== false ? ' ve yerlerine kilitlendi' : '') + '.');
        break;
      }
      case 'bos-tik': {
        var pb = v.split('|'), bs = +pb.pop(), bg = +pb.pop(), btip = pb.shift(), bid = pb.join('|');
        var sb1 = ui.secBlok;
        if ((ui.duzenMod || 'tasi') === 'tasi' && sb1) {
          var sonucB = sb1.tip === 'bekleyen' ? bekleyeniYerlestir(sb1.i, bg, bs, ui.tasiKilitle !== false) : blokTasi(yerlesimIndeksi(sb1.dersId, sb1.gun, sb1.saat), bg, bs, ui.tasiKilitle !== false);
          if (typeof sonucB === 'string') { bildir(sonucB, 'hata'); break; }
          ui.secBlok = null; degisti(); ciz(); bildir((sb1.tip === 'bekleyen' ? 'Ders yerleştirildi' : 'Ders taşındı') + (ui.tasiKilitle !== false ? ' ve kilitlendi' : '') + ' — ' + M.GUNLER[bg] + ' ' + (bs + 1) + '. ders.');
          break;
        }
        ui.modal = { tip: durum.sonuc ? 'saatKilit' : 'hazirlikKilit', tip2: btip, id: bid, gun: bg, saat: bs }; ciz(); break;
      }
      case 'saat-kilit-sec': { var pk = v.split('|'), hedef = pk.pop(); saateKilitle(pk.join('|'), hedef, ui.modal.gun, ui.modal.saat); break; }
      case 'duzen-mod': ui.duzenMod = v; ui.secBlok = null; ciz(); break;
      case 'secim-iptal': ui.secBlok = null; ciz(); break;
      case 'bekleyen-sec': ui.duzenMod = 'tasi'; ui.secBlok = { tip: 'bekleyen', i: +v }; ciz(); bildir('Şimdi programda yeşil görünen boş bir saate tıklayın.'); break;
      case 'blok-cikar': { var sb2 = ui.secBlok; if (sb2 && sb2.tip !== 'bekleyen') blokCikarOnayla(sb2.dersId, sb2.gun, sb2.saat); break; }
      // Sağ tık menüsü
      case 'menu-kilit-tog': {
        var mt = v.split('|'), mu = +mt.pop(), ms = +mt.pop(), mg = +mt.pop(), mid = mt.join('|');
        if (!kilitSil(mid, mg, ms)) { var mh = kilitEkle(mid, mg, ms, mu); if (mh) { bildir(mh, 'hata'); break; } bildir('Kilitlendi 🔒 — yeniden dağıtımda bu ders burada kalır.'); }
        else bildir('Kilit kaldırıldı.');
        if (durum.sonuc) istatistikYenile(true);
        degisti(); ciz(); break;
      }
      case 'menu-tasi-sec': { var mts = v.split('|'), tsa = +mts.pop(), tg = +mts.pop(); ui.duzenMod = 'tasi'; ui.secBlok = { tip: 'yer', dersId: mts.join('|'), gun: tg, saat: tsa }; ciz(); bildir('Seçildi: yeşil boş saate tıklayarak taşıyın ya da yeşil çerçeveli derse tıklayarak yer değiştirin.'); break; }
      case 'menu-cikar': { var mc = v.split('|'), cs2 = +mc.pop(), cg2 = +mc.pop(); blokCikarOnayla(mc.join('|'), cg2, cs2); break; }
      case 'menu-saat-kilit': { var msk = v.split('|'), kS = +msk.pop(), kG = +msk.pop(), kH = msk.pop(); saateKilitle(msk.join('|'), kH, kG, kS); break; }
      case 'menu-takas-kilit': {
        var tk = v.split('|'), ti = +tk[0], tj = +tk[1], r6 = durum.sonuc;
        var ta = r6.yerlesim[ti], tb = r6.yerlesim[tj];
        var tad = (r6.dersler[ta.dersId] || {}).ders, tbd = (r6.dersler[tb.dersId] || {}).ders, hedefMetin = saatMetni(tb.gun, tb.saat, tb.uzunluk), eskiMetin = saatMetni(ta.gun, ta.saat, ta.uzunluk);
        var th = takasKilitle(ti, tj);
        if (th) { bildir(th, 'hata'); break; }
        ui.secBlok = null; degisti(); ciz();
        bildir(tad + ' ' + hedefMetin + ' kilitlendi 🔒; ' + tbd + ' ' + eskiMetin + ' saatine geçti.');
        break;
      }
      case 'menu-kilit-ekle': {
        var mk = v.split('|'), kuz = +mk.pop(), kss = +mk.pop(), kgg = +mk.pop(), kid2 = mk.join('|');
        var mkh = kilitEkle(kid2, kgg, kss, kuz);
        if (mkh) { bildir(mkh, 'hata'); break; }
        var mkd = dersBul(kid2);
        if (durum.sonuc) istatistikYenile(true);
        degisti(); ciz(); bildir((mkd ? mkd.ders : 'Ders') + ' ' + saatMetni(kgg, kss, kuz) + ' kilitlendi 🔒'); break;
      }
      case 'ogr-degistir-ac': ui.modal = { tip: 'ogrDegistir', dersId: v }; ui.ogrDegAra = ''; ciz(); break;
      case 'ogr-degistir': { var od = v.split('|'), oid = od.pop(); ogretmenDegistir(od.join('|'), oid); break; }
      case 'menu-atama-kaldir': {
        var ak = dersBul(v), ako = ak && ogretmen(ak.ogretmenId);
        if (!ak || !ako) break;
        onayla('Atama kaldırılsın mı?', (sube(ak.subeId) || {}).ad + ' · ' + ak.ders + ' dersinden ' + ako.ad + ' alınır; ders atanmamış kalır.', 'Kaldır', function () {
          delete durum.atamalar[v];
          var r5 = durum.sonuc;
          if (r5 && r5.dersler[v]) { r5.dersler[v].ogretmenId = null; istatistikYenile(); degisti(); } else degisti(true);
          ui.modal = null; ciz(); bildir('Atama kaldırıldı.');
        });
        break;
      }
      case 'menu-sube-atama':
        ui.modal = null; ui.adim = 'atama'; ui.atamaGorunum = 'siniflar'; ciz();
        setTimeout(function () { var k5 = $('#sdl-' + v); if (k5) { k5.scrollIntoView({ block: 'center' }); k5.classList.add('vurgu'); setTimeout(function () { k5.classList.remove('vurgu'); }, 1800); } }, 30);
        break;
      case 'menu-program': { var mp = v.split('|'), mpt = mp.shift(); ui.adim = 'dagitim'; ui.gorunum = mpt; if (mpt === 'sube') ui.seciliSube = mp.join('|'); else ui.seciliOgr = mp.join('|'); ciz(); break; }
      case 'kayitlar-goster': ui.kayitlarAcik = true; ciz(); setTimeout(function () { var x = $('#kayit-ad'); if (x) { x.scrollIntoView({ block: 'center' }); x.focus(); } }, 30); break;
      case 'tumunu-kilitle': {
        var kilitle = function () {
          var r3 = durum.sonuc, n4 = 0;
          durum.kilitler = {};
          if (r3) r3.yerlesim.forEach(function (y) { if (!kilitEkle(y.dersId, y.gun, y.saat, y.uzunluk)) n4++; });
          degisti(); ciz(); bildir(n4 + ' blok kilitlendi.');
        };
        if (kilitSayisi()) onayla('Tüm program kilitlensin mi?', 'Mevcut ' + kilitSayisi() + ' kilit silinip programdaki bütün dersler bulundukları yere kilitlenecek.', 'Kilitle', kilitle, true);
        else kilitle();
        break;
      }

      // Dağıtım
      case 'dagit': dagitimiCalistir(); break;
      case 'dagit-min-deg': dagitimiCalistir('cpsat', 'minimum_degisiklik'); break;
      case 'excel-indir': excelIndir(); break;
      case 'zumre-brans': {
        var kz = kurallar();
        kz.zumreBranslar = kz.zumreBranslar || [];
        var zi = kz.zumreBranslar.indexOf(v);
        if (zi >= 0) kz.zumreBranslar.splice(zi, 1);
        else kz.zumreBranslar.push(v);
        degisti(true); ciz(); break;
      }
      case 'ogr-excel-ac': ui.modal = { tip: 'excelOgr' }; modalCiz(); break;
      case 'ogr-excel-uygula': {
        var ham = ($('#excel-ogr-metin') && $('#excel-ogr-metin').value) || '';
        var varsBrans = ($('#excel-ogr-vars-brans') && $('#excel-ogr-vars-brans').value) || Object.keys(VERI.branslar)[0] || 'Genel';
        var bransList = Object.keys(VERI.branslar);
        var eklenen = 0;
        ham.split(/\r?\n/).forEach(function (satir) {
          var t0 = satir.trim();
          if (!t0) return;
          var parca = t0.split(/[\t;,]+/).map(function (x) { return x.trim(); });
          var ad = parca[0];
          if (!ad || /^ad\s*soyad$/i.test(ad)) return;
          var hamBrans = parca[1] || '';
          var eslesenBrans = bransList.filter(function (b) { return b.toLocaleLowerCase('tr') === hamBrans.toLocaleLowerCase('tr'); })[0] || hamBrans || varsBrans;
          var maxS = parseInt(parca[2], 10);
          if (!(maxS > 0 && maxS <= 45)) maxS = +durum.ayarlar.maxSaat || 30;
          durum.ogretmenler.push({ id: yeniKimlik('o'), ad: ad, brans: eslesenBrans, maxSaat: maxS, kapali: [], maxGun: null, maxGunluk: null, kulup: '' });
          eklenen++;
        });
        ui.modal = null;
        if (eklenen) { degisti(true); ciz(); bildir(eklenen + ' öğretmen Excel/CSV’den eklendi.'); }
        else { modalCiz(); bildir('Eklenecek geçerli satır bulunamadı.', 'hata'); }
        break;
      }
      case 'sube-excel-ac': ui.modal = { tip: 'excelSube' }; modalCiz(); break;
      case 'sube-excel-uygula': {
        var hamS = ($('#excel-sube-metin') && $('#excel-sube-metin').value) || '';
        var tS = tur(), ekS = 0;
        hamS.split(/[\r\n,;]+/).forEach(function (parca) {
          var adS = parca.trim();
          if (!adS) return;
          var m = adS.match(/^(Hz|\d+)/i);
          var sinif = m ? (m[1].toLowerCase() === 'hz' ? 'Hz' : m[1]) : tS.siniflar[0];
          if (tS.siniflar.indexOf(sinif) < 0) {
            if (tS.siniflar.indexOf(+sinif) >= 0) sinif = +sinif;
            else return;
          }
          if (durum.subeler.some(function (x) { return x.ad.toLocaleLowerCase('tr') === adS.toLocaleLowerCase('tr'); })) return;
          durum.subeler.push({ id: yeniKimlik('s'), sinif: sinif, ad: adS });
          ekS++;
        });
        ui.modal = null;
        if (ekS) { degisti(true); ciz(); bildir(ekS + ' şube eklendi.'); }
        else { modalCiz(); bildir('Eklenecek yeni/geçerli şube bulunamadı.', 'hata'); }
        break;
      }
      case 'dagitim-sifirla': {
        // Tüm proje sıfırlaması değildir: sadece etkin dağıtım ve konum kilitleri kaldırılır.
        // Arşivdeki kayıtlar, öğretmenler, ders yükleri ve kısıtlar aynen korunur.
        if (ui.calisiyor || !durum.sonuc) break;
        var yerlesenSaat = (durum.sonuc.yerlesim || []).reduce(function (toplam, y) { return toplam + (+y.uzunluk || 0); }, 0);
        var arsivSayisi = (durum.dagitimKayitlari || []).length;
        onayla('Dağıtılan ders programı sıfırlansın mı?',
          '<b>' + yerlesenSaat + ' ders saati</b> ekrandaki çizelgeden kaldırılacak ve yerleşim kilitleri temizlenecek.' +
          '<br><br><b>Korunacak:</b> Şubeler, öğretmenler, dersler, atamalar, günlük/haftalık kısıtlar, kurallar, motor seçimi, nöbetler ve ' +
          arsivSayisi + ' kayıtlı dağıtım.' +
          '<br><span class="ince">Kaydedilmemiş manuel düzenlemeler geri getirilemez. Arşivdeki dağıtımları “Kayıtlı dağıtımlar” bölümünden tekrar açabilirsiniz.</span>',
          'Programı sıfırla', function () {
            ProgramAraclari.sifirlaEtkinDagitim(durum);
            ui.secBlok = null;
            ui.duzenMod = 'tasi';
            ui.raporAcik = false;
            ui.kayitlarAcik = arsivSayisi > 0;
            // 'false': öğretmen/ders verileri değişmedi, sadece sonuç temizlendi.
            degisti(false); ciz(); bildir('Dağıtılmış program temizlendi. Öğretmenler, dersler ve kayıtlı dağıtımlar korundu.');
          });
        break;
      }
      case 'program-kisit-ac': {
        var pka = v.split('|'), pkTip = pka.shift(), pkId = pka.join('|');
        ui.modal = { tip: pkTip, id: pkId }; ciz(); break;
      }
      case 'program-gun-toggle': {
        var pgg = v.split('|'), pgGun = +pgg.pop(), pgTip = pgg.shift();
        programKapatAc(pgTip, pgg.join('|'), pgGun, null); break;
      }
      case 'program-saat-toggle': {
        var pst = v.split('|'), psSaat = +pst.pop(), psGun = +pst.pop(), psTip = pst.shift();
        programKapatAc(psTip, pst.join('|'), psGun, psSaat); break;
      }
      case 'carsaf-bos-tik': {
        if (durum.sonuc) break;
        var cb = v.split('|'), cbSaat = +cb.pop(), cbGun = +cb.pop(), cbTip = cb.shift(), cbId = cb.join('|');
        ui.modal = kapaliListesi(cbTip, cbId).indexOf(cbGun + '-' + cbSaat) >= 0
          ? { tip: cbTip, id: cbId }
          : { tip: 'hazirlikKilit', tip2: cbTip, id: cbId, gun: cbGun, saat: cbSaat };
        ciz(); break;
      }
      case 'hazirlik-kilit-ac': {
        var hka = v.split('|'), hkSaat = +hka.pop(), hkGun = +hka.pop(), hkTip = hka.shift();
        ui.modal = { tip: 'hazirlikKilit', tip2: hkTip, id: hka.join('|'), gun: hkGun, saat: hkSaat }; ciz(); break;
      }
      case 'hazirlik-kilit-ekle': {
        if (durum.sonuc) break;
        var hke = v.split('|'), heUz = +hke.pop(), heSaat = +hke.pop(), heGun = +hke.pop();
        var heId = hke.join('|'), heHata = kilitEkle(heId, heGun, heSaat, heUz);
        if (heHata) { bildir(heHata, 'hata'); break; }
        ui.modal = null; degisti(true); ciz();
        bildir((dersBul(heId) || {}).ders + ' ' + saatMetni(heGun, heSaat, heUz) + ' önceden kilitlendi.'); break;
      }
      case 'hazirlik-kilit-kaldir': {
        if (durum.sonuc) break;
        var hkk = v.split('|'); hkk.pop(); var huSaat = +hkk.pop(), huGun = +hkk.pop();
        if (kilitSil(hkk.join('|'), huGun, huSaat)) { degisti(true); ciz(); bildir('Ders kilidi kaldırıldı.'); }
        break;
      }
      case 'dd2-odak': ui.dagitimOdak = !ui.dagitimOdak; ciz(); if ($('.dd2-calisma-alani')) $('.dd2-calisma-alani').scrollIntoView({ block: 'start' }); break;
      case 'dd2-yazdir': window.print(); break;
      case 'gorunum': ui.gorunum = v; ui.dd2CarsafAra = ''; ciz(); if ($('.dd2-calisma-alani')) $('.dd2-calisma-alani').scrollIntoView({ block: 'start' }); break;
      case 'kayitlar-ac': ui.kayitlarAcik = !el.parentNode.open; break;
      case 'dagitim-kaydet': {
        if (!durum.sonuc) break;
        var kad = ($('#kayit-ad').value || '').trim() || ('Dağıtım ' + (durum.dagitimKayitlari.length + 1));
        var kid0 = 'k' + Date.now().toString(36);
        durum.sonuc.kayitId = kid0; durum.sonuc.kayitDegisti = false;
        durum.dagitimKayitlari.unshift({ id: kid0, ad: kad, tarih: new Date().toISOString(), sonuc: JSON.parse(JSON.stringify(durum.sonuc)), kilitler: JSON.parse(JSON.stringify(durum.kilitler)) });
        if (durum.dagitimKayitlari.length > 20) durum.dagitimKayitlari.length = 20;
        ui.kayitlarAcik = true; degisti(); ciz(); bildir('“' + kad + '” kaydedildi. Programı düzenledikten sonra “Üzerine kaydet” ile güncelleyebilirsiniz.'); break;
      }
      case 'dagitim-guncelle': {
        var kg = durum.dagitimKayitlari.filter(function (x) { return x.id === v; })[0];
        if (!kg || !durum.sonuc) break;
        onayla('“' + kg.ad + '” güncellensin mi?', 'Kayıt, ekrandaki program ve kilitlerle değiştirilir. Önceki hâli geri gelmez; ayrı tutmak isterseniz “Yeni kayıt olarak kaydet”i kullanın.', 'Üzerine kaydet', function () {
          durum.sonuc.kayitDegisti = false;
          kg.sonuc = JSON.parse(JSON.stringify(durum.sonuc)); kg.kilitler = JSON.parse(JSON.stringify(durum.kilitler)); kg.tarih = new Date().toISOString();
          degisti(); ciz(); bildir('“' + kg.ad + '” güncellendi.');
        }, true);
        break;
      }
      case 'dagitim-geri': {
        var kay = durum.dagitimKayitlari[+v];
        var acKayit = function () {
          durum.sonuc = JSON.parse(JSON.stringify(kay.sonuc));
          durum.sonuc.kayitId = kay.id; durum.sonuc.kayitDegisti = false;
          var gecerli = {};
          dersListesi().forEach(function (d) { gecerli[d.id] = d; });
          var uyumsuz = Object.keys(durum.sonuc.dersler).some(function (id) { var d = gecerli[id]; return !d || d.ogretmenId !== durum.sonuc.dersler[id].ogretmenId || d.saat !== durum.sonuc.dersler[id].saat; });
          durum.sonuc.eski = uyumsuz;
          if (kay.kilitler) durum.kilitler = JSON.parse(JSON.stringify(kay.kilitler));
          kilitleriTemizle();
          ui.secBlok = null; ui.duzenMod = 'tasi';
          degisti(); ciz(); bildir('“' + kay.ad + '” açıldı; programda dersleri taşıyıp “Üzerine kaydet” ile güncelleyebilirsiniz' + (uyumsuz ? ' (o tarihten sonra ders/atama değişmiş; yeniden dağıtmanız önerilir)' : '') + '.');
        };
        if (durum.sonuc && durum.sonuc.kayitDegisti) onayla('“' + kay.ad + '” açılsın mı?', 'Ekrandaki programda kaydedilmemiş değişiklikler var; açarsanız bu değişiklikler kaybolur.', 'Aç', acKayit);
        else if (durum.sonuc && !durum.sonuc.kayitId) onayla('“' + kay.ad + '” açılsın mı?', 'Ekrandaki dağıtım (kaydedilmemiş) bu kayıtla değiştirilir.', 'Aç', acKayit, true);
        else acKayit();
        break;
      }
      case 'dagitim-kayit-sil': {
        var kay2 = durum.dagitimKayitlari[+v];
        onayla('“' + kay2.ad + '” silinsin mi?', 'Kayıtlı dağıtım silinir; ekrandaki program etkilenmez.', 'Sil', function () { durum.dagitimKayitlari.splice(+v, 1); degisti(); ciz(); });
        break;
      }
      case 'dd4-rapor-yazdir':
        document.body.classList.add('dd4-rapor-yazdir');
        try { window.print(); } catch(err) { bildir('Yazdırma bu pencerede kullanılamıyor.', 'hata'); }
        break;
      case 'yazdir':
        if (!durum.sonuc) { bildir('Yazdırmak için dağıtılmış bir program gerekli.', 'hata'); break; }
        document.body.classList.add('belge-yazdir');
        setTimeout(function () {
          try { window.print(); } catch (err) { bildir('Bu pencerede yazdırma kapalı; dosyayı tarayıcıda açıp Ctrl+P ile yazdırın.', 'hata'); }
          // Baskı penceresi kapandığında afterprint dinleyicisi temizler.
          setTimeout(function () { document.body.classList.remove('belge-yazdir'); }, 12000);
        }, 30);
        break;
      case 'belge-sekme': ui.belgeSekme = v; ui.belgeSecim = ''; ciz(); break;
      case 'csv': csvIndir(); break;

      // Nöbet
      case 'nobet-oto': {
        var var0 = durum.nobet.donemler.some(function (dn) { return Object.keys(dn.atama).length; });
        var dagitN = function () { nobetOtomatik(); degisti(); ciz(); bildir('Nöbetler dağıtıldı (' + { dengeli: 'dengeli', enAz: 'dersin en az olduğu gün', enCok: 'dersin en çok olduğu gün' }[durum.nobet.strateji] + ').'); };
        if (var0) onayla('Nöbetler yeniden dağıtılsın mı?', 'Elle yapılan nöbet değişiklikleri dahil tüm dönemlerin nöbetleri yeniden oluşturulur.', 'Yeniden dağıt', dagitN, true);
        else dagitN();
        break;
      }
      case 'nobet-donem-ekle': durum.nobet.donemler.push({ aralik: (durum.nobet.donemler.length + 1) + '. dönem', atama: {}, alan: {}, idari: {} }); degisti(); ciz(); break;
      case 'idari-oto': idariNobetOtomatik(); degisti(); ciz(); bildir('İdari nöbetler müdür yardımcıları arasında dağıtıldı.'); break;
      case 'idari-hucre': {
        var ip = v.split('|'), idn = durum.nobet.donemler[+ip[0]], iid = ip[1], ig = +ip[2];
        if (!idn) break;
        var il = idn.idari[iid] = idn.idari[iid] || [], ix = il.indexOf(ig);
        if (ix >= 0) il.splice(ix, 1); else il.push(ig);
        degisti(); ciz(); break;
      }
      case 'nobet-donem-sil': {
        var dn0 = durum.nobet.donemler[+v];
        onayla('“' + dn0.aralik + '” silinsin mi?', 'Bu dönemin nöbet atamaları da silinir.', 'Sil', function () { durum.nobet.donemler.splice(+v, 1); if (!durum.nobet.donemler.length) gocEt(durum); degisti(); ciz(); });
        break;
      }
      case 'nobet-alan-ekle': durum.nobet.alanlar.push({ ad: 'Yeni nöbet yeri', kisi: 1 }); degisti(); ciz(); break;
      case 'nobet-alan-sil': {
        var al = durum.nobet.alanlar[+v];
        onayla('“' + al.ad + '” silinsin mi?', 'Bu nöbet yerine atanmış öğretmenlerin nöbet yeri boşalır.', 'Sil', function () {
          durum.nobet.alanlar.splice(+v, 1);
          durum.nobet.donemler.forEach(function (dn) { Object.keys(dn.alan).forEach(function (id) { if (dn.alan[id] === al.ad) delete dn.alan[id]; }); });
          degisti(); ciz();
        });
        break;
      }
      case 'nobet-hucre': {
        var p = v.split('|'), dn = durum.nobet.donemler[+p[0]], oid = p[1], gun = +p[2];
        if (!dn) break;
        var alanAdlari = durum.nobet.alanlar.map(function (x) { return x.ad; });
        if (dn.atama[oid] !== gun) {
          dn.atama[oid] = gun;
          var dolu = {};
          Object.keys(dn.atama).forEach(function (id) { if (id !== oid && dn.atama[id] === gun && dn.alan[id]) dolu[dn.alan[id]] = (dolu[dn.alan[id]] || 0) + 1; });
          var bos = durum.nobet.alanlar.filter(function (x) { return (dolu[x.ad] || 0) < (+x.kisi || 1); })[0];
          if (alanAdlari.length) dn.alan[oid] = (bos || durum.nobet.alanlar[0]).ad; else delete dn.alan[oid];
        } else {
          var j = alanAdlari.indexOf(dn.alan[oid]);
          if (alanAdlari.length && j < alanAdlari.length - 1) dn.alan[oid] = alanAdlari[j + 1];
          else { delete dn.atama[oid]; delete dn.alan[oid]; }
        }
        degisti(); ciz(); break;
      }

      // Kaynaklar
      case 'kaynak-sekme': ui.kaynakSekme = v; ciz(); break;
      case 'meb-cek':
        api('meb-liste').then(function (j) { ui.mebListesi = j; ciz(); bildir(j.kayitlar.length + ' çizelge kaydı TTKB’den alındı.'); })
          .catch(function (err) { bildir('TTKB listesi alınamadı: ' + err.message, 'hata'); });
        break;

      // Veri
      case 'json-indir': jsonIndir(); break;
      case 'json-kopyala': {
        var metin = disaAktarMetni();
        try {
          navigator.clipboard.writeText(metin).then(function () { bildir('JSON panoya kopyalandı (' + Math.round(metin.length / 1024) + ' KB).'); }, function () { bildir('Panoya kopyalanamadı.', 'hata'); });
        } catch (e2) { bildir('Panoya kopyalanamadı.', 'hata'); }
        break;
      }
      case 'json-metinden': jsonUygula($('#json-metin').value || ''); break;
      case 'proje-ac': projeAc(v); break;
      case 'proje-sil': {
        var pr = ui.projeler.filter(function (x) { return String(x.id) === String(v); })[0];
        onayla('“' + (pr ? pr.ad : v) + '” silinsin mi?', 'Proje evrakplus.com hesabınızdan kalıcı olarak silinir. Bu işlem geri alınamaz.', 'Projeyi sil', function () {
          api('sil', { id: +v }).then(function () { if (String(durum.projeId) === String(v)) { delete durum.projeId; delete durum.projeRev; yerelKaydet(); } bildir('Proje silindi.'); projeleriGetir(); })
            .catch(function (err) { bildir('Silinemedi: ' + err.message, 'hata'); });
        });
        break;
      }
    }
  }

  // ---------- Olaylar: değişiklik ----------
  function degisim(e) {
    var el = e.target;
    var alan = el.getAttribute('data-okul');
    if (alan) {
      var deger = el.type === 'number' ? (+el.value || 0) : el.value;
      if (alan === 'gunSayisi') deger = Math.max(5, Math.min(6, deger));
      if (alan === 'gunlukSaat') deger = Math.max(4, Math.min(12, deger));
      durum.okul[alan] = deger;
      degisti(alan === 'gunSayisi' || alan === 'gunlukSaat');
      ustCiz();
      if (e.type === 'change') {
        var kap = $('#kapasite'); if (kap) kap.innerHTML = kapasiteHtml();
        var se = $('#saat-etiketleri'); if (se) se.innerHTML = saatEtiketHtml();
        if (alan === 'gunSayisi' || alan === 'gunlukSaat') yanCiz();
      }
      return;
    }
    var a = el.getAttribute('data-a'), v = el.getAttribute('data-v'), k = el.getAttribute('data-k');
    if (!a) {
      if (el.id === 'proje-sec' && el.value) projeAc(el.value);
      if (el.classList.contains('havuz-sec')) havuzOzeti();
      return;
    }
    var yaziAlani = el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && (el.type === 'text' || el.type === 'number' || el.type === 'search'));
    if (e.type === 'input' && !yaziAlani) return;
    switch (a) {
      case 'ux3a-sube': ui.ux3AtamaSube = el.value; ciz(); break;
      case 'ux3a-tur': ui.ux3AtamaTur = el.value; ciz(); break;
      case 'ux3a-durum': ui.ux3AtamaDurum = el.value; ciz(); break;
      case 'ux3a-diger': ui.ux3AtamaDiger = el.checked; modalCiz(); break;
      case 'dd4-gorunum': {
        ui.dd4Gorunum = ui.dd4Gorunum || {}; ui.dd4Gorunum[v] = !!el.checked;
        dd4GorunumUygula();
        try { localStorage.setItem(YEREL_ANAHTAR + '-gorunum', JSON.stringify(ui.dd4Gorunum)); } catch (e) {}
        var label = el.closest('label'); var em = label && label.querySelector('em'); if (em) em.textContent = el.checked ? 'Açık' : 'Kapalı';
        break;
      }
      case 'dd3-durum': case 'dd3-tur': ui.dd3Filtreler = ui.dd3Filtreler || {}; ui.dd3Filtreler[ui.adim] = el.value; dd3FiltreUygula(); break;
      case 'motor-sec': durum.ayarlar.motor = el.value; degisti(); ciz(); break;
      case 'cpsat-sure': durum.ayarlar.cpsatSure = Math.max(5, Math.min(900, +el.value || 60)); degisti(); break;
      case 'cpsat-isci': durum.ayarlar.isci = Math.max(0, Math.min(64, +el.value || 0)); degisti(); break;
      case 'kural-sayi': { if (e.type !== 'change') return; var kr = kurallar(); kr[v] = Math.max(0, +el.value || 0); if (v === 'gunlukAyniDersMax') kr[v] = Math.max(1, Math.min(6, kr[v])); degisti(true); ciz(); break; }
      case 'kural-ac': kurallar()[v] = el.checked; degisti(true); ciz(); break;
      case 'esnet-izin': kurallar().esnetIzin[v] = el.checked; degisti(); break;
      case 'tercih-oncelik': kurallar().tercihler[v] = el.value; el.className = 'oncelik-' + el.value; degisti(); break;
      case 'ders-ayar': {
        if (e.type !== 'change') return;
        var da = durum.dersAyar[v] = Object.assign({}, durum.dersAyar[v]);
        if (k === 'derslikTuru') { if (el.value === 'normal') delete da.derslikTuru; else da.derslikTuru = el.value; }
        else if (k === 'dil') { if (el.value === 'oto') delete da.dil; else da.dil = el.value === 'yok' ? null : el.value; }
        else if (k === 'etiketler') da.etiketler = el.value.split(',').map(function (x) { return x.trim().toLocaleLowerCase('tr'); }).filter(Boolean);
        else if (k === 'bolunebilir') da.bolunebilir = el.checked;
        degisti(true); break;
      }
      case 'ders-ayar-ara': { ui.dersAyarAra = el.value; var qd = el.value.toLocaleLowerCase('tr').trim(); document.querySelectorAll('.ders-ayar-satir').forEach(function (x) { x.style.display = !qd || x.getAttribute('data-ara').indexOf(qd) >= 0 ? '' : 'none'; }); break; }
      case 'etiket-alan': {
        if (e.type !== 'change') return;
        var et = durum.etiketKurallari[+v]; if (!et) break;
        if (k === 'ardisikYasak') et[k] = el.checked; else if (k === 'maxGunluk') et[k] = +el.value || null; else if (k === 'ad') et[k] = el.value.trim().toLocaleLowerCase('tr'); else et[k] = el.value;
        degisti(true); if (k === 'hedef') ciz(); break;
      }
      case 'bina-ad': if (e.type === 'change') { durum.binalar[+v].ad = el.value.trim() || durum.binalar[+v].ad; degisti(); } break;
      case 'gecis-alan': { var gc = durum.binaGecis[+v]; if (k === 'ayniGunYasak') gc[k] = el.checked; else if (k === 'dk') gc[k] = +el.value || 0; else gc[k] = el.value; degisti(true); break; }
      case 'derslik-alan': { if (e.type !== 'change') return; var rr = durum.derslikler[+v]; rr[k] = k === 'ad' ? (el.value.trim() || rr.ad) : el.value; degisti(true); if (k !== 'ad') ciz(); break; }
      case 'sube-derslik': { var sbd = sube(v); if (sbd) { sbd.derslikId = el.value; degisti(true); ciz(); } break; }
      case 'kulup-alan': {
        if (e.type !== 'change') return;
        var ka = durum.kulupler[+v]; if (!ka) break;
        ka[k] = k === 'saat' ? Math.max(1, Math.min(4, +el.value || 1)) : (k === 'ad' ? el.value.trim() : el.value);
        if (k === 'ogretmenId' && ka.ogretmenId) { var ko = ogretmen(ka.ogretmenId); if (ko && !ko.kulup && ka.ad) ko.kulup = ka.ad; }
        if (k === 'ad' && ka.ogretmenId) { var ko2 = ogretmen(ka.ogretmenId); if (ko2 && !ko2.kulup) ko2.kulup = ka.ad; }
        degisti(true); if (k !== 'ad') ciz(); break;
      }
      case 'kulup-zaman': { var kz = durum.kulupler[+v]; if (el.value === 'oto') kz.sabit = null; else { var pz = el.value.split('-'); kz.sabit = { gun: +pz[0], saat: +pz[1] }; } degisti(true); break; }
      case 'ogr-tercih': {
        if (e.type !== 'change' && el.type !== 'checkbox') return;
        var ot2 = ogretmen(ui.modal && ui.modal.id); if (!ot2) break;
        if (el.type === 'checkbox') ot2[k] = el.checked;
        else if (k === 'maxBosluk') ot2[k] = el.value === '' ? null : Math.max(0, +el.value);
        else if (k === 'etiketler') ot2[k] = el.value.split(',').map(function (x) { return x.trim().toLocaleLowerCase('tr'); }).filter(Boolean);
        degisti(true); break;
      }
      case 'ortak-ekle': {
        if (!el.value) break;
        var oo0 = ortakOgretmenler(v); oo0.push(el.value); durum.ortakOgretmen[v] = oo0;
        degisti(true); ciz(); bildir(ogretmen(el.value).ad + ' ortak öğretmen olarak eklendi (aynı saatte derse girer).');
        break;
      }
      case 'tur-sec': {
        var yeniTur = el.value;
        var uygula = function () { durum = varsayilanDurum(yeniTur, durum); degisti(); ciz(); bildir(tur().ad + ' çizelgesi yüklendi; şubeler ve seçmeliler yeniden oluşturuldu.'); };
        if (durum.ogretmenler.length || durum.sonuc || durum.ekDersler.length) {
          onayla('Okul türü değiştirilsin mi?', 'Okul türü değişince şubeler, dersler, öğretmenler, kısıtlar ve dağıtım sıfırlanır. Gerekirse önce JSON yedeği alın.', 'Türü değiştir', uygula);
          el.value = durum.okul.turId;
        } else uygula();
        break;
      }
      case 'sube-ad': { var sb = sube(v); if (sb) { sb.ad = el.value; degisti(); if (e.type === 'change') yanCiz(); } break; }
      case 'sube-adlandirma': case 'sube-ayrac': {
        if (a === 'sube-adlandirma') durum.subeAyar.adlandirma = el.value; else durum.subeAyar.ayrac = el.value;
        tur().siniflar.forEach(function (s) { durum.subeler.filter(function (x) { return x.sinif === s; }).forEach(function (x, i) { x.ad = subeAdi(s, i); }); });
        degisti(); ciz(); bildir('Şube adları yeniden yazıldı.'); break;
      }
      case 'secmeli-ekle': {
        if (!el.value) return;
        var t = tur(), d = VERI.havuzlar[t.havuz].dersler.find(function (x) { return x[0] === el.value; });
        var liste = secmeliListesi(k, v);
        var sinif = k === 'sube' ? sube(v).sinif : v;
        var gerekli = t.secmeliSaat[t.siniflar.indexOf(sinif)];
        var kullanilan = secmeliToplam(liste);
        if (kullanilan >= gerekli) { bildir('Seçmeli saati dolu (' + kullanilan + '/' + gerekli + '). Önce bir seçmeliyi kaldırın ya da saatini azaltın.', 'hata'); el.value = ''; break; }
        var saat = Math.max(1, Math.min(t.secmeliVarsayilanSaat || d[3], gerekli - kullanilan));
        liste.push({ ad: d[0], grup: d[1], saat: saat });
        degisti(true); ciz(); break;
      }
      case 'dd5-ogretmen-ara': {
        var q = String(el.value || '').trim().toLocaleLowerCase('tr-TR');
        document.querySelectorAll('.dd5-ogretmen-ders').forEach(function (node) {
          node.hidden = !!q && (node.getAttribute('data-ara') || '').indexOf(q) < 0;
        });
        break;
      }
      case 'dd5-zor-sinif': ui.dd5ZorSinif = el.value; ui.dd5ZorDers = ''; ciz(); break;
      case 'dd5-zor-ders': {
        ui.dd5ZorDers = el.value;
        var dr = t.dersler.find(function (x) { return x[0] === ui.dd5ZorDers; });
        var saatEl = $('#dd5-zor-saat');
        if (dr && saatEl) saatEl.value = dr[2][t.siniflar.indexOf(ui.dd5ZorSinif || t.siniflar[0])] || 1;
        break;
      }
      case 'dd5-secmeli-saat': {
        if (e.type !== 'change') return;
        var p = v.split('|'), sid = p.shift(), ad = p.join('|');
        var hata = dd5SecmeliDegistir(sid, ad, +el.value, false);
        if (hata) { bildir(hata, 'hata'); ciz(); }
        break;
      }
      case 'secmeli-saat':
        if (e.type !== 'change') return;
        var ls = secmeliListesi(k, v), ix = +el.getAttribute('data-i'), ger = secmeliGerekli(k, v);
        var istenen = Math.max(1, +el.value || 1), izin2 = ger - secmeliToplam(ls, ix);
        if (istenen > izin2) { bildir('Seçmeli toplamı ' + ger + ' saati aşamaz; bu derse en fazla ' + Math.max(1, izin2) + ' saat verilebilir.', 'hata'); istenen = Math.max(1, izin2); }
        ls[ix].saat = istenen; degisti(true); ciz(); break;
      case 'zorunlu-saat': {
        if (e.type !== 'change') return;
        var meb = +el.getAttribute('data-meb'), yeni = Math.max(0, Math.min(20, parseInt(el.value, 10) || 0));
        var subeId0 = v.split('|')[0], mevcutDers = dersListesi().filter(function (d) { return d.id === v; })[0];
        var eskiSaat = mevcutDers ? mevcutDers.saat : 0, ss = subeSaatleri(subeId0);
        if (ss.toplam - eskiSaat + yeni > ss.sinir) {
          var izin = Math.max(0, ss.sinir - (ss.toplam - eskiSaat));
          bildir((sube(subeId0) || {}).ad + ' haftalık ' + ss.sinir + ' saati aşamaz; bu derse en fazla ' + izin + ' saat verilebilir. Önce başka bir dersin saatini azaltın.', 'hata');
          yeni = Math.min(yeni, izin);
        }
        if (yeni === meb) delete durum.saatDegisiklik[v]; else durum.saatDegisiklik[v] = yeni;
        degisti(true);
        el.value = yeni; el.classList.toggle('degisik', yeni !== meb);
        // Doldurma uyarısını ve toplamları yerinde güncelle (odak kaybolmasın)
        var dl = dersListesi(), dol = $('#doldurma');
        if (dol) dol.innerHTML = doldurmaUyarisi(dl);
        subeDoluluk(dl).forEach(function (x) { var c = $('#top-' + x.sube.id); if (c) { c.textContent = x.saat; c.style.color = x.saat !== x.meb ? 'var(--err)' : ''; } });
        yanCiz();
        clearTimeout(ui.zorunluZaman); ui.zorunluZaman = setTimeout(function () { if (!document.activeElement || !document.activeElement.matches('[data-a="zorunlu-saat"]')) ciz(); }, 700);
        break;
      }
      case 'toplu-ata': {
        if (!el.value) return;
        var p2 = v.split('|'), sinif2 = p2[0], ders2 = p2.slice(1).join('|'), n2 = 0;
        dersListesi().forEach(function (dd) { if (dd.ders === ders2 && sube(dd.subeId).sinif === sinif2) { durum.atamalar[dd.id] = el.value; n2++; } });
        degisti(true); ciz(); bildir(n2 + ' şubeye atandı.'); break;
      }
      case 'atama':
        if (el.value) durum.atamalar[v] = el.value; else delete durum.atamalar[v];
        degisti(true); ciz(); break;
      case 'ogr-aktar': {
        if (!el.value) return;
        var hedef = ogretmen(el.value), kaynak = ogretmen(v);
        el.value = '';
        onayla('Dersler aktarılsın mı?', '<b>' + esc(kaynak.ad) + '</b> öğretmeninin tüm dersleri <b>' + esc(hedef.ad) + '</b> öğretmenine verilecek.', 'Aktar', function () {
          var n5 = 0;
          Object.keys(durum.atamalar).forEach(function (key) { if (durum.atamalar[key] === kaynak.id) { durum.atamalar[key] = hedef.id; n5++; } });
          degisti(true); ciz(); bildir(n5 + ' ders aktarıldı.');
        }, true);
        break;
      }
      case 'havuz-hepsi':
        document.querySelectorAll('.havuz-satir').forEach(function (tr) { if (tr.style.display !== 'none') tr.querySelector('.havuz-sec').checked = el.checked; });
        havuzOzeti(); break;
      case 'ek-brans-ekle': {
        if (!el.value) return;
        var oe = ogretmen(v); oe.ekBranslar = oe.ekBranslar || [];
        if (oe.ekBranslar.indexOf(el.value) < 0) oe.ekBranslar.push(el.value);
        degisti(); ciz(); bildir(el.value + ' ek branş olarak eklendi; bu branşın dersleri artık uygun dersler arasında.'); break;
      }
      case 'ogr-brans-filtre': ui.ogrBransFiltre = el.value; ciz(); break;
      case 'ogr-ara': ui.ogrAra = el.value; aramaUygula(); break;
      case 'havuz-ara': ui.havuzAra = el.value; aramaUygula(); break;
      case 'secmeli-ara': ui.secmeliAra = el.value; aramaUygula(); break;
      case 'ogr-deg-ara': ui.ogrDegAra = el.value; aramaUygula(); break;
      case 'ogr-deg-hepsi': ui.ogrDegHepsi = el.checked; modalCiz(); break;
      case 'dd7-zor-sec': ui.dd7ZorSec = ui.dd7ZorSec || {}; if (el.checked) ui.dd7ZorSec[el.value] = true; else delete ui.dd7ZorSec[el.value]; ciz(); break;
      case 'dd7-zor-sube': ui.dd7ZorSubeler = ui.dd7ZorSubeler || {}; if (el.checked) ui.dd7ZorSubeler[el.value] = true; else delete ui.dd7ZorSubeler[el.value]; ciz(); break;
      case 'sec-ders-sec': if (el.checked) ui.secDers[el.value] = true; else delete ui.secDers[el.value]; ciz(); break;
      case 'sec-ders-saat': ui.secDersSaat[v] = +el.value; break;
      case 'sec-sube-sec': if (el.checked) ui.secSube[el.value] = true; else delete ui.secSube[el.value]; ciz(); break;
      case 'sec-sube-hepsi': ui.secSube = {}; if (el.checked) durum.subeler.forEach(function (x) { if (x.sinif === ui.secmeliSinif) ui.secSube[x.id] = true; }); ciz(); break;
      case 'tasi-kilitle': ui.tasiKilitle = el.checked; break;
      case 'kayit-ad-degis': { if (e.type !== 'change') return; var kr = durum.dagitimKayitlari[+v]; var yad = (el.value || '').trim(); if (kr && yad) { kr.ad = yad; degisti(); bildir('Kayıt adı “' + yad + '” oldu.'); } else if (kr) el.value = kr.ad; break; }
      case 'max-saat': if (e.type === 'change') { durum.ayarlar.maxSaat = Math.max(1, +el.value || 30); degisti(); } break;
      case 'ogr-ad': { var o = ogretmen(v); if (o) { o.ad = el.value; degisti(); } break; }
      case 'ogr-kulup': { var ok = ogretmen(v); if (ok) { ok.kulup = el.value; degisti(); } break; }
      case 'ogr-brans': { var ob = ogretmen(v); if (ob) { ob.brans = el.value; degisti(); ciz(); } break; }
      case 'ogr-gorev': {
        var og = ogretmen(v); if (!og) break;
        og.gorev = GOREV_AD[el.value] ? el.value : '';
        // yöneticiyse öğretmen nöbetinden çıkar
        if (durum.nobet.yoneticiHaric && yoneticiMi(og)) durum.nobet.donemler.forEach(function (dn) { delete dn.atama[og.id]; delete dn.alan[og.id]; });
        if (!idariNobetci(og)) durum.nobet.donemler.forEach(function (dn) { delete dn.idari[og.id]; });
        degisti(); ciz();
        bildir(yoneticiMi(og) ? og.ad + ': ' + GOREV_AD[og.gorev] + ' — öğretmen nöbetine girmez' + (idariNobetci(og) ? ', idari nöbet tutar.' : '.') : og.ad + ': öğretmen.');
        break;
      }
      case 'ogr-sec': if (el.checked) ui.secOgr[v] = true; else delete ui.secOgr[v]; ciz(); break;
      case 'ogr-hepsini-sec': ui.secOgr = {}; if (el.checked) durum.ogretmenler.forEach(function (x) { ui.secOgr[x.id] = true; }); ciz(); break;
      case 'ux5-kisit-kisi': { var pk5=ui.ux5KisitSekme==='sube'?'ux5KisitSube':'ux5KisitOgretmen'; ui[pk5]=el.value; ciz(); break; }
      case 'ogr-gunluk': case 'ogr-gun': {
        if (e.type !== 'change') return;
        var og = ogretmen(v); if (!og) return;
        var alanAd = a === 'ogr-gunluk' ? 'maxGunluk' : 'maxGun', deg = parseInt(el.value, 10);
        if (deg > 0) og[alanAd] = deg; else delete og[alanAd];
        degisti(true); ciz(); break;
      }
      case 'ogr-max': if (e.type === 'change') { var o3 = ogretmen(v); if (o3) { o3.maxSaat = +el.value || 30; degisti(); ciz(); } } break;
      case 'kilit-sec': ui[k === 'ogretmen' ? 'kilitOgr' : 'kilitSube'] = el.value; ui.kilitDers = null; ciz(); break;
      case 'kilit-uzunluk': ui.kilitUzunluk = +el.value; break;
      case 'yerlesim':
        if (el.value) durum.yerlesimler[v] = el.value; else delete durum.yerlesimler[v];
        degisti(true); break;
      case 'belge': {
        durum.belge[v] = el.value; degisti();
        var bl = $('#belgeler');
        if (bl) bl.innerHTML = belgeSayfalari(belgeAyar(), ui.adim === 'nobet' ? 'nobet' : (ui.belgeSekme === 'sube' ? 'sube' : 'ogretmen'));
        break;
      }
      case 'belge-sec': ui.belgeSecim = el.value; ciz(); break;
      case 'nobet-aralik': durum.nobet.donemler[+v].aralik = el.value; degisti(); if (e.type === 'change') ciz(); break;
      case 'nobet-strateji': durum.nobet.strateji = el.value; degisti(); bildir('Kural değişti; uygulamak için “Nöbetleri otomatik dağıt”a basın.'); break;
      case 'nobet-bosgun': durum.nobet.bosGunVerme = el.checked; degisti(); break;
      case 'nobet-yonetici':
        durum.nobet.yoneticiHaric = el.checked;
        if (el.checked) durum.nobet.donemler.forEach(function (dn) { durum.ogretmenler.filter(yoneticiMi).forEach(function (o) { delete dn.atama[o.id]; delete dn.alan[o.id]; }); });
        degisti(); ciz(); bildir(el.checked ? 'Müdür ve yardımcıları öğretmen nöbetinden çıkarıldı.' : 'Müdür ve yardımcıları öğretmen nöbetine katılır; “Nöbetleri otomatik dağıt” ile uygulayın.'); break;
      case 'idari-kisi': if (e.type === 'change') { durum.nobet.idari.gunlukKisi = Math.max(1, Math.min(5, parseInt(el.value, 10) || 1)); idariNobetOtomatik(); degisti(); ciz(); } break;
      case 'idari-basyrd': durum.nobet.idari.basyrd = el.checked; idariNobetOtomatik(); degisti(); ciz(); break;
      case 'idari-cikti': durum.nobet.idari.cikti = el.value; degisti(); ciz(); break;
      case 'nobet-alan-ad': {
        var eskiAd = durum.nobet.alanlar[+v].ad;
        durum.nobet.alanlar[+v].ad = el.value;
        durum.nobet.donemler.forEach(function (dn) { Object.keys(dn.alan).forEach(function (id) { if (dn.alan[id] === eskiAd) dn.alan[id] = el.value; }); });
        degisti(); if (e.type === 'change') ciz(); break;
      }
      case 'nobet-alan-kisi': if (e.type === 'change') { durum.nobet.alanlar[+v].kisi = Math.max(1, parseInt(el.value, 10) || 1); degisti(); ciz(); } break;
      case 'blok': durum.ayarlar.blok = el.value; degisti(true); ciz(); break;
      case 'deneme': if (e.type === 'change') { durum.ayarlar.deneme = Math.max(1, Math.min(20, +el.value || 10)); degisti(); } break;

      case 'dd8-sube': ui.dd8Sube = el.value; var bs= sube(ui.dd8Sube); if(bs) ui.dd6Sinif = ui.dd5ZorSinif = ui.secmeliSinif = bs.sinif; ui.dd8Ara = ''; ui.dd8HavuzAc = false; ciz(); break;
      case 'dd8-zor-saat': {
        if (e.type !== 'change') return;
        var key8=String(v), sid8=key8.split('|')[0], ss8=sube(sid8);
        if (!ss8) { ciz(); break; }
        var r8=dersListesi().find(function (d) { return d.id===key8; });
        if (!r8) { ciz(); break; }
        var value8=parseInt(el.value,10);
        if (!(value8 >= 1 && value8 <= 20)) { bildir('Ders saati 1–20 arasında olmalı. Kaldırmak için çöp düğmesini kullan.', 'hata'); ciz(); break; }
        var capacity8=subeSaatleri(sid8);
        if (capacity8.toplam-r8.saat+value8>capacity8.sinir) { bildir('Şubenin haftalık saat sınırı aşılır. Diğer bir dersin saatini azalt.', 'hata'); ciz(); break; }
        var t8=tur(), row8=t8.dersler.find(function(r){return r[0]===r8.ders;});
        var ex8=(durum.ekDersler||[]).find(function(r){return r.ad===r8.ders && (r.subeId===sid8 || (!r.subeId && r.sinif===ss8.sinif));});
        var base8=row8 ? +row8[2][t8.siniflar.indexOf(ss8.sinif)] : (ex8 ? +ex8.saat : 0);
        if(value8===base8) delete durum.saatDegisiklik[key8]; else durum.saatDegisiklik[key8]=value8;
        kilitleriTemizle(); degisti(true); ciz(); bildir('Ders saati güncellendi.'); break;
      }
      case 'dd8-sec-saat': {
        if (e.type !== 'change') return;
        var val8=parseInt(el.value,10);
        if (!(val8 >= 1 && val8 <= 20)) { bildir('Geçerli bir saat yaz; kaldırma için çöp düğmesini kullan.', 'hata'); ciz(); break; }
        var parts8=String(v).split('|'), id8=parts8.shift(), name8=parts8.join('|');
        var err8=dd5SecmeliDegistir(id8,name8,val8,false);
        if (err8) { bildir(err8,'hata'); ciz(); }
        else bildir('Seçmeli ders saati güncellendi.');
        break;
      }
      case 'sec-sube': ui.seciliSube = el.value; ciz(); break;
      case 'sec-ogr': ui.seciliOgr = el.value; ciz(); break;
      case 'json-dosya': {
        var f = el.files && el.files[0];
        if (!f) return;
        var okuyucu = new FileReader();
        okuyucu.onload = function () { jsonUygula(String(okuyucu.result || '')); el.value = ''; };
        okuyucu.readAsText(f, 'utf-8');
        break;
      }
    }
  }

  // ---------- Başlat ----------
  function baslat() {
    dd4GorunumYukle();
    window.addEventListener('afterprint', function () { document.body.classList.remove('belge-yazdir', 'dd4-rapor-yazdir'); });
    try { if (localStorage.getItem('dd-tasarim-yan-dar') === '1') document.body.classList.add('yan-dar'); } catch (e) {}
    document.addEventListener('click', tikla);
    document.addEventListener('change', degisim);
    document.addEventListener('contextmenu', sagTik);
    window.addEventListener('resize', menuKapat);
    window.addEventListener('scroll', menuKaydirma, true);
    document.addEventListener('input', function (e) {
      if (e.target.id === 'menu-ara') { ui.menuArama = e.target.value; menuAraUygula(); return; }
      if (e.target.id === 'dd2-carsaf-ara') { ui.dd2CarsafAra = e.target.value; dd2CarsafFiltrele(ui.dd2CarsafAra); return; }
      if (e.target.id === 'dd6-blok-ara') { var a6=String(e.target.value||'').toLocaleLowerCase('tr-TR').trim(); document.querySelectorAll('.dd6-block-row').forEach(function(row){ row.hidden = !!a6 && (row.getAttribute('data-dd6-search')||'').indexOf(a6)<0; }); return; }
      if (e.target.id === 'ux3a-ders-ara') { ux3AtamaSatirAra(); return; }
      if (e.target.id === 'ux3a-aday-ara') { ux3AtamaFiltrele(); return; }
      if (e.target.getAttribute('data-a') === 'ux3-pool-search') {
        var query=String(e.target.value||'').toLocaleLowerCase('tr-TR').trim();
        document.querySelectorAll('.ux3-pool-item[data-search]').forEach(function(node){node.hidden=!!query && (node.getAttribute('data-search')||'').indexOf(query)<0;});
        return;
      }
      if (e.target.getAttribute('data-a') === 'dd8-ara') { ui.dd8Ara = e.target.value; dd8Filtrele(); return; }
      if (e.target.getAttribute('data-a') === 'dd6-zor-ara') {
        ui.dd6ZorAra = e.target.value;
        var q6 = ui.dd6ZorAra.toLocaleLowerCase('tr-TR').trim();
        document.querySelectorAll('.dd6-zor-oge').forEach(function (btn) { btn.hidden = (btn.getAttribute('data-dd6-search') || '').indexOf(q6) < 0; });
        return;
      }
      if (e.target.getAttribute('data-a') === 'dd3-ara') { ui.dd3Aramalar = ui.dd3Aramalar || {}; ui.dd3Aramalar[ui.adim] = e.target.value; dd3FiltreUygula(); return; }
      var a0 = e.target.getAttribute('data-a');
      if (e.target.getAttribute('data-okul') === 'ad' || ['ogr-ad', 'ogr-kulup', 'belge', 'nobet-aralik', 'sube-ad', 'nobet-alan-ad', 'ogr-ara', 'havuz-ara', 'secmeli-ara', 'ogr-deg-ara', 'ders-ayar-ara', 'dd5-ogretmen-ara'].indexOf(a0) >= 0) degisim(e);
    });
    document.addEventListener('keydown', function (e) {
      if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.matches && e.target.matches('#icerik td[data-dd5-slot]')) {
        e.preventDefault(); e.target.click(); return;
      }
      if (e.key !== 'Escape') return;
      if (document.getElementById('dd6-quickpanel')) { dd6PanelKapat(); return; }
      if ($('#sag-menu') && $('#sag-menu').style.display === 'block') { menuKapat(); return; }
      if (ui.onay) { if (!ui.onay.ikinci) { ui.onay = null; onayCiz(); } } else if (ui.modal) { ui.modal = null; ciz(); }
      else if (ui.mobilMenu) { ui.mobilMenu = false; mobilMenuCiz(); } else if (document.body.classList.contains('yan-acik')) yanKapat();
    });
    window.addEventListener('beforeunload', function () { yerelKaydet(); });
    // Yayınlanmış sayfada (claude.ai) dosya indirme yeteneği
    try {
      if (window.claude && typeof window.claude.use === 'function') {
        window.claude.use('downloads').then(function (ns) { ui.indirme = ns || null; }, function () { ui.indirme = null; });
      }
    } catch (e) { ui.indirme = null; }

    var yerel = yerelYukle(), B = CFG.baslangicDurumu, yereliGonder = false;
    if (CFG.mod === 'sunucu' && B) {
      // Bu cihazda, hesaptaki aynı sürümün üzerine yapılmış ama gönderilememiş değişiklik varsa onu kullan
      if (yerel && bekleyenVar() && String(yerel.projeId) === String(B.id) && yerel.projeRev === B.rev) { durum = yerel; yereliGonder = true; }
      else { durum = gocEt(B.durum); durum.projeId = B.id; durum.projeRev = B.rev; sonGonderilen = durumMetni(); bekleyenIsaretle(false); yerelKaydet(); }
    } else if (CFG.mod === 'sunucu') {
      // Hesapta proje yok: bu cihazda gönderilmemiş yeni bir proje varsa onu gönder
      durum = (yerel && !yerel.projeId && bekleyenVar()) ? yerel : varsayilanDurum(VERI.okulTurleri[0].id);
      if (durum === yerel) yereliGonder = true; else { delete durum.projeId; delete durum.projeRev; }
    } else {
      durum = yerel || varsayilanDurum(VERI.okulTurleri[0].id);
    }
    var hashAdim = (location.hash || '').replace('#', '');
    if (hashAdim && sayfaVarMi(hashAdim)) ui.adim = hashAdim;
    try { history.replaceState({ adim: ui.adim, katman: 0 }, '', '#' + ui.adim); } catch (e) { /* yok say */ }
    window.addEventListener('popstate', geriTusu);
    ciz();
    kayitDurumu(CFG.mod === 'sunucu' ? (B ? 'kaydedildi' : 'bos') : (yerel ? 'kaydedildi' : 'bos'));
    if (CFG.mod === 'sunucu') {
      projeleriGetir(); cpsatDurumuGetir();
      if (yereliGonder) { bildir('Bu cihazda kaydedilmemiş değişiklikler vardı; hesabınıza gönderiliyor.'); sunucuKaydet(true); }
      document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') surumDenetle(); });
      window.addEventListener('focus', surumDenetle);
      window.addEventListener('online', function () { if (bekleyenVar()) sunucuKaydet(true); });
      window.addEventListener('offline', function () { if (ui.kayit.durum === 'bekliyor' || bekleyenVar()) kayitDurumu('hata'); });
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', baslat); else baslat();
})();

/* Ağır genetik aramayı arayüzü kilitlemeden ayrı iş parçacığında çalıştırır. */
'use strict';
importScripts('scheduler.js', 'genetik.js');
self.onmessage = function (event) {
  try {
    var g = event.data.girdi;
    var sonuc = self.GenetikDagitim.dagit(g, Object.assign({}, event.data.ayarlar || {}, {
      ilerleme: function (p) { self.postMessage({ tip: 'ilerleme', ilerleme: p }); }
    }));
    self.postMessage({ tip: 'sonuc', sonuc: sonuc });
  } catch (e) {
    self.postMessage({ tip: 'hata', mesaj: (e && e.message) || String(e) });
  }
};

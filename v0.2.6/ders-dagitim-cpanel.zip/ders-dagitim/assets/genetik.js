/* EvrakPlus genetik ders dağıtım motoru.
 * Kromozom = ders başına {öncelik, tercih edilen gün/saat, izinli blok kalıbı}.
 * Popülasyon, turnuva seçimi, tek gen düzeyinde çaprazlama, mutasyon ve elitizm.
 * Her kromozom mevcut güvenli Hızlı yerleştirici ile bir çizelgeye çözülür;
 * genetik algoritma sırf rastgele çoklu deneme değildir, yerleştirme stratejisi evrimleşir.
 * Tam zorunlu kural doğrulaması arayüz tarafından ayrıca yapılır.
 */
(function (root) {
  'use strict';
  function rng(seed) {
    var s = (seed >>> 0) || 12345;
    return function () {
      s ^= s << 13; s ^= s >>> 17; s ^= s << 5;
      return (s >>> 0) / 4294967296;
    };
  }
  function sinir(v, lo, hi, d) {
    v = Number(v);
    return Number.isFinite(v) ? Math.max(lo, Math.min(hi, Math.floor(v))) : d;
  }
  function rastgeleGen(r, d, H, ders) {
    return {
      oncelik: r(),
      gun: Math.floor(r() * d),
      saat: Math.floor(r() * H),
      kalip: Math.floor(r() * Math.max(1, (ders.yerlesimSecenekleri || []).length))
    };
  }
  function kromozom(r, girdi) {
    return girdi.dersler.map(function (ders) { return rastgeleGen(r, girdi.gunSayisi, girdi.gunlukSaat, ders); });
  }
  function caprazla(r, a, b) {
    return a.map(function (gen, i) {
      var diger = b[i], c = {};
      ['oncelik', 'gun', 'saat', 'kalip'].forEach(function (k) { c[k] = r() < 0.5 ? gen[k] : diger[k]; });
      return c;
    });
  }
  function mutasyon(r, g, girdi, oran) {
    return g.map(function (x, i) {
      var c = Object.assign({}, x);
      if (r() < oran) c.oncelik = r();
      if (r() < oran) c.gun = Math.floor(r() * girdi.gunSayisi);
      if (r() < oran) c.saat = Math.floor(r() * girdi.gunlukSaat);
      if (r() < oran) c.kalip = Math.floor(r() * Math.max(1, (girdi.dersler[i].yerlesimSecenekleri || []).length));
      return c;
    });
  }
  function sec(r, pop) {
    var en = pop[Math.floor(r() * pop.length)];
    for (var i = 0; i < 2; i++) {
      var x = pop[Math.floor(r() * pop.length)];
      if (x.fitness < en.fitness) en = x;
    }
    return en;
  }
  function girdiCoz(girdi, genler, tohum, kalanMs) {
    var tercih = {}, dersler = girdi.dersler.map(function (d, i) {
      var gene = genler[i], secenek = d.yerlesimSecenekleri || [];
      tercih[d.id] = { oncelik: gene.oncelik, gun: gene.gun, saat: gene.saat };
      var kopya = Object.assign({}, d);
      if (secenek.length) kopya.yerlesim = secenek[Math.min(gene.kalip, secenek.length - 1)];
      return kopya;
    });
    var gg = Object.assign({}, girdi, {
      dersler: dersler, genetik: tercih,
      denemeSayisi: 1, tohum: tohum,
      maxIterasyon: sinir(girdi.gaIterasyon, 200, 40000, 3000),
      sureLimitMs: Math.max(75, Math.min(450, kalanMs)),
      iyilestirmeTuru: 1
    });
    var sonuc = root.DersDagitim.dagit(gg);
    sonuc.cozucu = { asama: genler.some(function (gene) { return gene.kalip > 0; }) ? 'Alternatif blok' : 'Genetik arama',
      durum: 'UNKNOWN', basarili: false };
    return sonuc;
  }
  /** Genetik seçiminde zorunlu kuralları tercih cezasından üstün tut.
   * Son karar yine app.js içindeki K01-K16 doğrulayıcısına aittir.
   */
  function ihlalSayisi(g, r) {
    var ders = {}, ogr = {}, sube = {}, gun = {}, blok = {}, yer = {}, dil = {},
      tSaat = {}, tGun = {}, dolu = {}, hatalar = 0, D = g.gunSayisi, H = g.gunlukSaat, kur = g.kurallar || {};
    g.dersler.forEach(function (x) { ders[x.id] = x; });
    g.ogretmenler.forEach(function (x) { ogr[x.id] = x; });
    g.subeler.forEach(function (x) { sube[x.id] = x; });
    r.yerlesim.forEach(function (y) {
      var d = ders[y.dersId];
      if (!d) { hatalar++; return; }
      if (y.gun < 0 || y.gun >= D || y.saat < 0 || y.saat + y.uzunluk > H || y.uzunluk <= 0) { hatalar++; return; }
      var k = d.id + '|' + y.gun;
      (blok[d.id] = blok[d.id] || []).push(y.uzunluk);
      (yer[d.id] = yer[d.id] || []).push(y);
      gun[k] = (gun[k] || 0) + y.uzunluk;
      if (d.dil && kur.dilAyriGun !== false) (dil[d.subeId + '|' + y.gun] = dil[d.subeId + '|' + y.gun] || {})[d.dil] = 1;
      for (var i = 0; i < y.uzunluk; i++) {
        var slot = y.gun + '-' + (y.saat + i);
        if ((sube[d.subeId].kapali || []).includes(slot)) hatalar++;
        var sk = 'S|' + d.subeId + '|' + slot;
        if (dolu[sk] && dolu[sk] !== d.id) hatalar++;
        dolu[sk] = d.id;
        (d.ogretmenler || []).forEach(function (t) {
          if ((ogr[t] || {}).kapali && ogr[t].kapali.includes(slot)) hatalar++;
          var tk = 'T|' + t + '|' + slot;
          if (dolu[tk] && dolu[tk] !== d.id) hatalar++;
          dolu[tk] = d.id;
          tSaat[t + '|' + y.gun] = (tSaat[t + '|' + y.gun] || 0) + 1;
          (tGun[t] = tGun[t] || {})[y.gun] = 1;
        });
      }
    });
    g.dersler.forEach(function (d) {
      var y = yer[d.id] || [], uzunluk = y.reduce(function (sum, v) { return sum + v.uzunluk; }, 0);
      if (uzunluk !== d.saat) return; // eksik saat cezası ayrıca verilir
      var secenek = d.yerlesimSecenekleri || [];
      var kaliplar = secenek.length ? secenek : [Array(Math.floor(d.saat / 2)).fill(2).concat(d.saat % 2 ? [1] : [])];
      var kullanilan = y.map(function (v) { return v.uzunluk; }).sort(function (a, b) { return a - b; }).join(',');
      if (!kaliplar.some(function (v) { return v.slice().sort(function (a, b) { return a - b; }).join(',') === kullanilan; })) hatalar++;
      var limit = +kur.gunlukAyniDersMax || 2, gunler = {};
      y.forEach(function (v) {
        gunler[v.gun] = (gunler[v.gun] || 0) + 1;
        if (gun[d.id + '|' + v.gun] > limit) hatalar++;
      });
      if (kur.blokFarkliGun !== false && Object.keys(gunler).some(function (day) { return gunler[day] > 1; })) hatalar++;
      if (kur.ucluTekrarYasak !== false) {
        var saatler = {};
        y.forEach(function (v) { for (var i = 0; i < v.uzunluk; i++) saatler[v.gun + '|' + (v.saat + i)] = 1; });
        for (var dd = 0; dd < D; dd++) for (var hh = 0; hh < H - 2; hh++) {
          if (saatler[dd + '|' + hh] && saatler[dd + '|' + (hh + 1)] && saatler[dd + '|' + (hh + 2)]) hatalar++;
        }
      }
      (d.kilitli || []).forEach(function (k) {
        for (var i = 0; i < (k.uzunluk || 1); i++) {
          if (!y.some(function (v) { return v.gun === +k.gun && +k.saat + i >= v.saat && +k.saat + i < v.saat + v.uzunluk; })) hatalar++;
        }
      });
    });
    Object.keys(dil).forEach(function (k) { if (Object.keys(dil[k]).length > 1) hatalar++; });
    Object.keys(tSaat).forEach(function (k) { var a = k.split('|'), o = ogr[a[0]]; if (o && o.maxGunluk && tSaat[k] > o.maxGunluk) hatalar++; });
    Object.keys(tGun).forEach(function (t) { var o = ogr[t]; if (o && o.maxGunKesin && o.maxGun && Object.keys(tGun[t]).length > o.maxGun) hatalar++; });
    return hatalar;
  }
  function fitness(r, girdi) {
    var ist = r.istatistik || {}, kural = girdi ? ihlalSayisi(girdi, r) : 0;
    return kural * 1000000000 + (ist.eksikSaat || 0) * 1000000 +
      (ist.subeBosluk || 0) * 20 + (ist.ogretmenBosluk || 0) * 5 + (ist.ihlal || 0) * 10000;
  }
  function ayarlar(girdi, o) {
    o = o || {};
    var n = (girdi.dersler || []).length;
    return { populasyon: sinir(o.populasyon, 4, 16, n > 150 ? 6 : 8),
      nesil: sinir(o.nesil, 2, 20, n > 150 ? 4 : 6),
      sureMs: sinir(o.sureMs, 1000, 120000, n > 150 ? 22000 : 16000),
      mutasyon: Math.max(.01, Math.min(.6, Number(o.mutasyon) || .13)),
      tohum: (Number(girdi.tohum) || 12345) >>> 0 };
  }
  function dagit(girdi, opts) {
    if (!root.DersDagitim || typeof root.DersDagitim.dagit !== 'function') throw new Error('Hızlı yerleştirme bileşeni bulunamadı.');
    if (!girdi || !Array.isArray(girdi.dersler) || !girdi.dersler.length) throw new Error('Ders listesi boş.');
    opts = opts || {};
    var a = ayarlar(girdi, opts), R = rng(a.tohum), t0 = Date.now();
    var en = null, pop = [], degerlendirme = 0, tamamlanan = 0;
    for (var nesil = 0; nesil < a.nesil; nesil++) {
      var yeniler = [];
      if (pop.length) {
        pop.sort(function (x, y) { return x.fitness - y.fitness; });
        yeniler.push({ genler: pop[0].genler, fitness: pop[0].fitness, sonuc: pop[0].sonuc });
        if (pop.length > 1) yeniler.push({ genler: pop[1].genler, fitness: pop[1].fitness, sonuc: pop[1].sonuc });
      }
      while (yeniler.length < a.populasyon) {
        if (Date.now() - t0 >= a.sureMs && degerlendirme > 0) break;
        var genes;
        if (pop.length >= 2) genes = mutasyon(R, caprazla(R, sec(R, pop).genler, sec(R, pop).genler), girdi, a.mutasyon);
        else genes = kromozom(R, girdi);
        var sonuc = girdiCoz(girdi, genes, (a.tohum + degerlendirme * 7919) >>> 0, a.sureMs - (Date.now() - t0));
        var birey = { genler: genes, sonuc: sonuc, fitness: fitness(sonuc, girdi) };
        degerlendirme++;
        if (!en || birey.fitness < en.fitness) en = birey;
        yeniler.push(birey);
      }
      pop = yeniler;
      tamamlanan++;
      if (typeof opts.ilerleme === 'function') opts.ilerleme({ nesil: tamamlanan, toplamNesil: a.nesil,
        degerlendirme: degerlendirme, enIyiEksik: en.sonuc.istatistik.eksikSaat, gecenMs: Date.now() - t0 });
      if (Date.now() - t0 >= a.sureMs) break;
    }
    var r = en.sonuc;
    r.istatistik.motor = 'Genetik';
    r.istatistik.sureMs = Date.now() - t0;
    r.istatistik.gaNesil = tamamlanan;
    r.istatistik.gaDegerlendirme = degerlendirme;
    r.cozucu.nesil = tamamlanan;
    r.cozucu.degerlendirme = degerlendirme;
    return r;
  }
  var api = { dagit: dagit, caprazla: caprazla, mutasyon: mutasyon, kromozom: kromozom, fitness: fitness, ayarlar: ayarlar, ihlalSayisi: ihlalSayisi };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.GenetikDagitim = api;
})(typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : globalThis);

/*
 * PWA: service worker kaydı, "Uygulamayı yükle" düğmesi (Android/Chrome/Edge) ve
 * iPhone/iPad için "Ana Ekrana Ekle" yönergesi, çevrimdışı uyarı bandı.
 */
(function () {
  'use strict';
  var CFG = window.APP_CONFIG || {};
  var dugme = document.getElementById('pwa-yukle');
  var kok = document.getElementById('pwa-kok');
  var istem = null;

  var bagimsiz = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  var ua = navigator.userAgent || '';
  var ios = /iphone|ipad|ipod/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

  if (bagimsiz) document.documentElement.classList.add('pwa-bagimsiz');
  // iPhone: yazı kutusuna dokununca sayfa yakınlaşmasın (iOS parmakla yakınlaştırmaya yine izin verir)
  if (ios) { var vp = document.querySelector('meta[name=viewport]'); if (vp && vp.content.indexOf('maximum-scale') < 0) vp.content += ', maximum-scale=1'; }

  if ('serviceWorker' in navigator && window.isSecureContext) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js', { scope: './' }).catch(function (e) { console.warn('[pwa] service worker kaydedilemedi', e); });
    });
  }

  function goster() { if (dugme && !bagimsiz) dugme.hidden = false; }
  function gizle() { if (dugme) dugme.hidden = true; }

  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    istem = e;
    goster();
  });
  window.addEventListener('appinstalled', function () {
    istem = null; gizle(); kapat();
    var b = document.getElementById('bildirim');
    if (b) { b.textContent = 'Uygulama yüklendi. Ana ekranınızdaki “Ders Dağıtım” simgesinden açabilirsiniz.'; b.className = 'bildirim'; setTimeout(function () { b.classList.add('gizli'); }, 4000); }
  });

  // iPhone/iPad Safari "yükle" olayı vermez: düğme yönerge gösterir
  if (ios && !bagimsiz) goster();

  // Programın geri kalanı için: menüde "Telefona yükle" gösterilsin mi, yükleme başlat
  window.PWA = {
    bagimsiz: bagimsiz,
    kurulabilir: function () { return !bagimsiz && (!!istem || ios); },
    yukle: function () { if (dugme) dugme.click(); }
  };

  // Telefonda tarayıcıdan açanlara bir kez "uygulama olarak yükleyin" önerisi
  var ONERI = 'ders-dagitim-pwa-oneri';
  function oneriGoster() {
    if (bagimsiz || !kok || kok.innerHTML) return;
    if (!(window.matchMedia && window.matchMedia('(max-width: 860px)').matches)) return;
    try { if (localStorage.getItem(ONERI)) return; localStorage.setItem(ONERI, '1'); } catch (e) { return; }
    kok.innerHTML = '<div class="pwa-ipucu pwa-oneri" role="dialog" aria-label="Uygulama olarak yükleyin"><div class="pwa-oneri-ust"><img src="assets/ikon/ikon-192.png" alt=""><div><h4>Telefonunuza yükleyin</h4>' +
      '<p>Ders Dağıtım ana ekranınızda uygulama gibi açılır; verileriniz evrakplus.com hesabınızda kalır.</p></div></div>' +
      '<div class="satir"><button type="button" class="btn" id="pwa-sonra">Daha sonra</button><button type="button" class="btn ana" id="pwa-simdi">Yükle</button></div></div>';
    document.getElementById('pwa-sonra').onclick = kapat;
    document.getElementById('pwa-simdi').onclick = function () { kapat(); if (dugme) dugme.click(); };
  }
  window.addEventListener('beforeinstallprompt', function () { setTimeout(oneriGoster, 4000); });
  if (ios && !bagimsiz) setTimeout(oneriGoster, 4000);

  function kapat() { if (kok) kok.innerHTML = ''; }
  function ipucu(baslik, adimlar) {
    if (!kok) return;
    kok.innerHTML = '<div class="pwa-ipucu" role="dialog" aria-label="' + baslik + '"><h4>' + baslik + '</h4><ol>' +
      adimlar.map(function (a) { return '<li>' + a + '</li>'; }).join('') + '</ol><div class="satir"><button type="button" class="btn ana" id="pwa-tamam">Tamam</button></div></div>';
    document.getElementById('pwa-tamam').onclick = kapat;
  }

  if (dugme) dugme.addEventListener('click', function () {
    if (istem) {
      istem.prompt();
      istem.userChoice.then(function (s) { if (s && s.outcome === 'accepted') gizle(); istem = null; });
      return;
    }
    if (ios) {
      ipucu('Ana ekrana ekleyin', ['Safari’de alttaki <b>Paylaş</b> simgesine (kare ve yukarı ok) dokunun.', '<b>Ana Ekrana Ekle</b>’yi seçin.', '<b>Ekle</b>’ye dokunun. Program ana ekranınızda uygulama gibi açılır.']);
      return;
    }
    ipucu('Uygulama olarak yükleyin', ['Tarayıcı menüsünü (⋮) açın.', '<b>Uygulamayı yükle</b> ya da <b>Ana ekrana ekle</b>’yi seçin.']);
  });

  // Çevrimdışı uyarısı
  var bant = null;
  function cevrim() {
    if (navigator.onLine === false) {
      if (!bant) { bant = document.createElement('div'); bant.className = 'cevrimdisi-bant'; bant.textContent = 'İnternet bağlantısı yok — değişiklikler bu cihazda tutuluyor, bağlantı gelince hesabınıza kaydedilecek.'; document.body.appendChild(bant); }
    } else if (bant) { bant.remove(); bant = null; }
  }
  window.addEventListener('online', cevrim);
  window.addEventListener('offline', cevrim);
  cevrim();
})();

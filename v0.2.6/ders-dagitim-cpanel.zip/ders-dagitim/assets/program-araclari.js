/*
 * Etkin ders programı sıfırlama ve blok sütunu yardımcıları.
 * Depolanmış dağıtım sürümlerine, okul/ders/öğretmen verilerine dokunmaz.
 * Hem tarayıcı hem de Node testleri için bağımsız tutulur.
 */
(function (root) {
  'use strict';
  function sifirlaEtkinDagitim(durum) {
    if (!durum || typeof durum !== 'object') throw new TypeError('Proje durumu gerekli.');
    var sonuc = durum.sonuc;
    var saatSayisi = sonuc && Array.isArray(sonuc.yerlesim) ? sonuc.yerlesim.reduce(function (toplam, y) {
      return toplam + (Number(y.uzunluk) || 0);
    }, 0) : 0;
    var kilitSayisi = Object.keys(durum.kilitler || {}).reduce(function (toplam, k) {
      return toplam + (Array.isArray(durum.kilitler[k]) ? durum.kilitler[k].length : 0);
    }, 0);
    durum.sonuc = null;
    durum.kilitler = {};
    return { temizlenenSaat: saatSayisi, temizlenenKilit: kilitSayisi };
  }
  function blokSaatEtiketleri(baslangic, uzunluk) {
    var bas = Number(baslangic), uz = Number(uzunluk);
    if (!Number.isInteger(bas) || bas < 0 || !Number.isInteger(uz) || uz < 1 || uz > 24) {
      throw new RangeError('Blok başlangıcı veya uzunluğu geçersiz.');
    }
    return Array.from({ length: uz }, function (_, i) { return bas + i + 1; });
  }
  /** Dağıtım başlamadan kaydedilmiş sabit blokları yalnız görünüm için toplar.
      Gerçek sonuç üretmez; bu liste kayıtlı dağıtım olarak saklanmaz. */
  function onYerlesimler(dersler, kilitler) {
    var mevcud = {};
    (dersler || []).forEach(function (d) { if (d && d.id) mevcud[d.id] = true; });
    var out = [];
    Object.keys(kilitler || {}).forEach(function (id) {
      if (!mevcud[id]) return;
      (kilitler[id] || []).forEach(function (k) {
        var gun = Number(k.gun), saat = Number(k.saat), uzunluk = Number(k.uzunluk);
        if (Number.isInteger(gun) && gun >= 0 && Number.isInteger(saat) && saat >= 0 &&
            Number.isInteger(uzunluk) && uzunluk > 0) {
          out.push({ dersId: id, gun: gun, saat: saat, uzunluk: uzunluk, kilitli: true });
        }
      });
    });
    return out;
  }
  var api = { sifirlaEtkinDagitim: sifirlaEtkinDagitim, blokSaatEtiketleri: blokSaatEtiketleri, onYerlesimler: onYerlesimler };
  root.DersProgramAraclari = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof window === 'object' ? window : globalThis);

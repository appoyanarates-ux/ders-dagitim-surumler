/* Otomatik motor güvenlik politikası; tarayıcıda ve testlerde bağımsız çalışır. */
(function (root) {
  'use strict';
  function hizliEksikleri(g) {
    var l = [];
    if ((g.dersler || []).some(function (d) { return (d.ogretmenler || []).length > 1; })) l.push('ortak öğretmenli dersler (K01)');
    if ((g.dersler || []).some(function (d) { return !!d.grup; })) l.push('paralel seçmeli grupları (K02)');
    if ((g.dersler || []).some(function (d) { return !!d.derslikTuru || !!d.derslikId; })) l.push('zorunlu derslikler (K12)');
    if ((g.subeler || []).some(function (s) { return !!s.derslikId; })) l.push('sabit şube derslikleri (K12)');
    if ((g.binalar || []).length > 1 && (+(g.kurallar || {}).binaGecisDk || (g.binaGecis || []).length)) l.push('bina geçiş süreleri (K13)');
    if ((g.kulupler || []).some(function (k) { return !k.sabit; })) l.push('otomatik kulüp saatleri (K15)');
    if ((g.kulupler || []).some(function (k) { return !!k.derslikId; })) l.push('kulüp derslikleri (K12/K15)');
    if ((g.etiketKurallari || []).length) l.push('etiket kuralları (K16)');
    return l;
  }
  function gecisKarari(cozucu, eksikler) {
    if (cozucu && cozucu.basarili) return { dene: false, neden: 'CP-SAT geçerli bir dağıtım buldu.' };
    if (cozucu && cozucu.durum === 'INFEASIBLE') return { dene: false, neden: 'CP-SAT veya kesin ön denetim çözümsüzlük belirledi; aynı zorunlu kurallarla başka motorun çözmesi beklenmez.' };
    if (eksikler && eksikler.length) return { dene: false, neden: 'Genetik ve Hızlı motorlara otomatik geçiş engellendi: ' + eksikler.join(', ') };
    return { dene: true, neden: 'CP-SAT tamamlayamadı; Genetik ve ardından Hızlı motor geçerli çözüm arayacak.' };
  }
  function motorSirasi(secim, cpsatHazir) {
    if (secim === 'otomatik') return cpsatHazir ? ['cpsat', 'genetik', 'hizli'] : ['genetik', 'hizli'];
    return ['cpsat', 'genetik', 'hizli'].indexOf(secim) >= 0 ? [secim] : ['genetik', 'hizli'];
  }
  root.DersMotorSecim = { hizliEksikleri: hizliEksikleri, gecisKarari: gecisKarari, motorSirasi: motorSirasi };
})(typeof window !== 'undefined' ? window : globalThis);

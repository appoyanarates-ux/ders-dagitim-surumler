# EvrakPlus Ders Dağıtım — UX V3 Geliştirme Yol Haritası

**Başlangıç paketi:** `evrakplus-ders-dagitim-menu5-8-sekme-duzeltme.zip`  
**Amaç:** 18 menünün anlaşılır, sezgisel ve bütün cihazlarda tutarlı bir deneyime kavuşması.  
**Temel ilke:** Mevcut okul verileri, CP-SAT/Genetik/Hızlı motorlar, kilitler ve kayıtlar korunacaktır.

## Aşama 1 — Tasarım sistemi, güvenli pilot ve HTML laboratuvarı (TAMAMLANDI)

- Sol menü sıra numaraları ile ekran başlıkları aynı 1–18 numaralandırmayı kullanır.
- Ana uygulamada mevcut menüler çalışmaya devam eder.
- Uygulamanın üst barına **Yeni tasarımı dene ↗** bağlantısı eklenir.
- Ayrı `tasarim-lab.html` dosyasında 18 menülük navigasyon ve öncelikli 5 menünün (4, 5, 8, 9, 12) etkileşimli taslakları bulunur.
- Laboratuvarda kullanılan öğretmen, şube ve dersler **yalnızca örnek veri**dir, gerçek okul kayıtlarını okumaz veya değiştirmez.

**Bitti kabul ölçütü:** 18 menü açılır, HTML tek dosya olarak çevrimdışı çalışır; mobilde sayfa taşmaz; mevcut uygulamada PHP/JS sözdizimi ve eski testler geçer.

## Aşama 2 — Dersler ve şube atamaları (Menü 4) (BU PAKETTE)

- Tek şube seçimi; zorunlu/seçmeli iki görünüm.
- Havuzdan **ders ekle**, ders saatini değiştir, yalnız o şubeden kaldır, geri al.
- MEB'den gelen hazır derslerin saatlerini koru; manuel düzeltme her zaman yapılabilsin.
- İsteğe bağlı çoklu şube ataması ayrı panelde; toplu değişim önce özet ve onay gösterir.
- Seçmeli saat sınırını aşan işlem hiçbir şubeye kısmen uygulanamaz.

**Bitti kabul ölçütü:** 5-A değişince 5-B korunur; zorunlu/seçmeli toplamlar tutarlı; klavye ve mobil kullanım mümkün.

## Aşama 3 — Blok ve öğretmen atama (Menü 5 ve 8)

- Menü 5: ders seç > önerilen blok > uygula. Alternatif bloklar tek açılır listede.
- Menü 8: **Atanmamış dersler** ilk görünüm, ders satırında öğretmen seç/değiştir.
- Yerel sekmeler menüden ayrılmadan içerik değiştirir; geriye gitmek kayıplara yol açmaz.
- Toplu otomatik öğretmen üretme işlemi önce önizleme/onay alır.

**Bitti kabul ölçütü:** 2+2, 2+2+1, 2+2+2 blokları doğrulanır; öğretmen değişiklikleri kayıt ve çizelgeye yansır.

## Aşama 4 — Kısıtlar ve kilitler (Menü 9, 11 ve ilişkili ekranlar)

- Öğretmen ve şube kapalı gün/saatleri aynı takvim bileşeninde düzenlenir.
- Kilitli blok bulunan saat kapatılamaz; uygulanamayan işlem anlaşılır gerekçe gösterir.
- Temel ve gelişmiş kısıtlar birbirinden ayrılır, otomatik motor esnetme koşulları açık olur.

**Bitti kabul ölçütü:** Kilit/kapalı gün/öğretmen müsaitliği tutarlı denetlenir; çelişki sonucu kaydedilmez.

## Aşama 5 — Dört çizelge (Menü 12)

- Şube programı, öğretmen programı, şube çarşafı ve öğretmen çarşafı boşken de gösterilir.
- Hem sol tık/dokunma hem sağ tık ile: ders yerleştir, kaldır, öğretmen değiştir, kilitle, kapat/aç, blok düzenle.
- İkili dersler doğru genişlikte birleşik hücredir; taşırken bütün blok taşınır.
- Geri al / yeniden yap, işlem geçmişi ve gerçek zamanlı çakışma uyarısı eklenir.

**Bitti kabul ölçütü:** Dört görünümde aynı veri ve aynı kilit kuralları çalışır; sürükle/taşıma çakışma yaratmaz.

## Aşama 6 — Kalan menüler, çıktı ve raporlar

- Okul, şubeler, öğretmenler, derslikler, kulüpler, nöbet, kaynaklar, veri, ayarlar, raporlar, A4/PDF ekranları tek tasarım diline geçirilir.
- Arama/filtre, boş durumlar, işlem geri bildirimi ve kritik işlem onayı tutarlı olur.
- Sekmeler yerinde içerik değiştirir, iç sayfalardan yanlışlıkla menü atlaması olmaz.

**Bitti kabul ölçütü:** 18 menü ve alt sekmeler klavye/mobil/masaüstü senaryolarıyla onaylanır.

## Aşama 7 — Güvenilirlik ve gerçek okul testleri

- 10, 30–50, 100–150 öğretmenli sentetik ve izinli gerçek okul senaryoları.
- Üç motorun gerçek dağıtımı, zaman aşımı, ara çözüm, başarısızlık ve otomatik geçiş testi.
- Veri aktarımı ve yedek/geri yükleme, performans, yazdırma, erişilebilirlik ve cPanel uyumluluğu testleri.

**Bitti kabul ölçütü:** Eksik saat ve zorunlu kural ihlaline sahip çizelgeler **başarılı** sayılmaz. Her dağıtım raporunda motor, süre, çözüm durumu ve doğrulama sonucu görünür.

---

### Çalışma kuralı

Her aşamada **iki ayrı çıktı** verilecektir: (1) mevcut programın üzerine kurulabilen, veri kayıtlarını ezmeyen cPanel ZIP paketi; (2) önerilen değişikliklerin tek HTML dosyasında denenebilen önizlemesi. Bir ekran gerçek programa taşınmadan önce örnek işlemler test edilir. Prototipte görünen işlevlerin üretim sürümünde tamamlandığı varsayılmaz.

### Kurulum önlemleri

- Var olan `ders-dagitim` klasörünün ve verilerin yedeğini alın.
- Güncelleme paketindeki **data** dizini okul verisi içermez; `data/.htaccess` mevcut erişim kuralını korumak içindir.
- Mevcut `data` ve `storage` klasörlerini silmeyin.
- Canlı cPanel üzerinde CP-SAT motorunun çalıştığı ayrıca doğrulanmalıdır.

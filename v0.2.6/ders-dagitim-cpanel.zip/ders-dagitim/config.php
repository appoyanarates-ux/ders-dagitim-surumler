<?php
/**
 * Program ayarları (CP-SAT çözücüsü, MEB listesi).
 * WordPress köprüsü ayarları (giriş adresi, veri anahtarı) index.php dosyasının en üstündedir.
 */
return [
    'dagitim' => [
        'sure_limit_ms' => 8000,     // PHP sezgisel motoru için bir isteğin üst süresi
        'max_iterasyon' => 300000,
    ],
    // OR-Tools CP-SAT çözücüsü (Python). İsteğe bağlı; yoksa tarayıcıdaki hızlı motor kullanılır.
    'cpsat' => [
        'etkin' => true,
        // 'otomatik': DERS_PYTHON ortam değişkeni, cPanel “Setup Python App” sanal ortamları ve python3 sırayla denenir.
        // Elle vermek için örn. '/home/KULLANICI/virtualenv/ders-dagitim-python/3.11/bin/python'
        'python' => getenv('DERS_PYTHON') ?: 'otomatik',
        'varsayilan_sure_sn' => 60,
        'azami_sure_sn' => 300,      // üye sitesinde bir dağıtımın en uzun süresi
        'isci' => 1,                 // paylaşımlı hostingde 1 önerilir
        'azami_isci' => 2,
        // Sunucuyu korumak için: aynı anda en fazla kaç CP-SAT işi, bir üyenin aynı anda en fazla kaç işi
        'es_zamanli_is' => 2,
        'uye_basina_is' => 1,
        'is_klasoru' => __DIR__ . '/storage/isler',
    ],
    'meb' => [
        'liste_adresi' => 'https://ttkb.meb.gov.tr/www/icerik_listele_ajax.php',
        'kategori' => 7,
        'zaman_asimi' => 15,
    ],
];

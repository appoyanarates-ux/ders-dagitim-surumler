<?php
declare(strict_types=1);

namespace DersDagitim;

use RuntimeException;

/**
 * Üyenin okul projelerini kendi WordPress hesabında (wp_usermeta) saklar.
 *
 * Tek meta anahtarı: <programkodu>_data   (ör. ders_dagitim_data)
 * Değer (JSON):
 *   {
 *     "uygulama": "ders-dagitim", "surum": 1,
 *     "sonId": 3,            // son verilen proje numarası
 *     "acikId": 2,           // en son açılan / kaydedilen proje (başka cihazda buradan devam edilir)
 *     "projeler": {
 *       "2": { "ad": "...", "turId": "...", "olusturma": "...", "guncelleme": "...", "rev": 17,
 *              "durum": {...} }      // büyük projelerde "durumZ": sıkıştırılmış (gzip + base64)
 *     }
 *   }
 * "rev" her kayıtta bir artar; iki cihaz aynı projeyi değiştirirse eski sürümden gelen kayıt reddedilir (çakışma).
 */
final class UyeDeposu
{
    /** Bu boyutun üstündeki proje durumları sıkıştırılarak saklanır (bayt) */
    private const SIKISTIRMA_ESIGI = 256 * 1024;

    public function __construct(
        private int $uyeId,
        private string $anahtar,
        private int $azamiProje = 20,
        private int $azamiBayt = 12 * 1024 * 1024,
    ) {
        if ($uyeId <= 0) throw new RuntimeException('Üye bulunamadı');
    }

    // ---------- okuma / yazma ----------

    private function oku(): array
    {
        $ham = get_user_meta($this->uyeId, $this->anahtar, true);
        $v = is_string($ham) && $ham !== '' ? json_decode($ham, true) : (is_array($ham) ? $ham : null);
        if (!is_array($v)) $v = [];
        $v += ['uygulama' => 'ders-dagitim', 'surum' => 1, 'sonId' => 0, 'acikId' => null, 'projeler' => []];
        if (!is_array($v['projeler'])) $v['projeler'] = [];
        return $v;
    }

    private function yaz(array $v): void
    {
        $json = json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        if (strlen($json) > $this->azamiBayt) {
            throw new RuntimeException('Hesabınızdaki toplam veri çok büyüdü (' . round(strlen($json) / 1048576, 1) . ' MB). Kullanmadığınız projeleri ya da kayıtlı dağıtımları silin.');
        }
        // update_user_meta değeri wp_unslash'tan geçirir: JSON'daki ters bölüler bozulmasın diye wp_slash şart
        update_user_meta($this->uyeId, $this->anahtar, wp_slash($json));
    }

    /** Aynı üyenin eşzamanlı kayıtları birbirini ezmesin (MySQL GET_LOCK) */
    private function kilitli(callable $is): mixed
    {
        global $wpdb;
        $ad = 'dd_' . substr(md5($this->anahtar . '|' . $this->uyeId . '|' . (defined('DB_NAME') ? DB_NAME : '')), 0, 24);
        $kilit = isset($wpdb) ? (int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 10)', $ad)) : 0;
        try {
            return $is();
        } finally {
            if ($kilit && isset($wpdb)) $wpdb->query($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $ad));
        }
    }

    private static function simdi(): string
    {
        return function_exists('wp_date') ? (string)wp_date('Y-m-d H:i:s') : date('Y-m-d H:i:s');
    }

    private static function durumCoz(array $p): ?array
    {
        if (isset($p['durum']) && is_array($p['durum'])) return $p['durum'];
        if (isset($p['durumZ']) && is_string($p['durumZ'])) {
            $ham = @gzinflate((string)base64_decode($p['durumZ'], true));
            $d = $ham !== false ? json_decode($ham, true) : null;
            return is_array($d) ? $d : null;
        }
        return null;
    }

    private static function durumYerlestir(array &$p, array $durum): void
    {
        unset($p['durum'], $p['durumZ']);
        $json = json_encode($durum, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        if (strlen($json) > self::SIKISTIRMA_ESIGI && function_exists('gzdeflate')) {
            $p['durumZ'] = base64_encode((string)gzdeflate($json, 6));
        } else {
            $p['durum'] = $durum;
        }
    }

    private static function ozet(int $id, array $p): array
    {
        return [
            'id' => $id,
            'ad' => (string)($p['ad'] ?? 'Adsız okul'),
            'okul_turu' => (string)($p['turId'] ?? ''),
            'olusturma' => (string)($p['olusturma'] ?? ''),
            'guncelleme' => (string)($p['guncelleme'] ?? ''),
            'rev' => (int)($p['rev'] ?? 0),
        ];
    }

    // ---------- işlemler ----------

    public function listele(): array
    {
        $v = $this->oku();
        $l = [];
        foreach ($v['projeler'] as $id => $p) if (is_array($p)) $l[] = self::ozet((int)$id, $p);
        usort($l, fn($a, $b) => strcmp($b['guncelleme'], $a['guncelleme']) ?: $b['id'] <=> $a['id']);
        return $l;
    }

    /** @return array{id:int, ad:string, durum:array, rev:int, guncelleme:string}|null */
    public function getir(int $id): ?array
    {
        $v = $this->oku();
        $p = $v['projeler'][(string)$id] ?? null;
        if (!is_array($p)) return null;
        $d = self::durumCoz($p);
        if ($d === null) return null;
        return ['id' => $id, 'ad' => (string)($p['ad'] ?? ''), 'durum' => $d, 'rev' => (int)($p['rev'] ?? 0), 'guncelleme' => (string)($p['guncelleme'] ?? '')];
    }

    /** Başka cihazdan girildiğinde açılacak proje: en son açılan, yoksa en son güncellenen */
    public function sonAcik(): ?array
    {
        $v = $this->oku();
        $id = $v['acikId'] ?? null;
        if ($id !== null && isset($v['projeler'][(string)$id])) {
            $p = $this->getir((int)$id);
            if ($p) return $p;
        }
        $l = $this->listele();
        return $l ? $this->getir($l[0]['id']) : null;
    }

    public function surum(int $id): ?array
    {
        $v = $this->oku();
        $p = $v['projeler'][(string)$id] ?? null;
        return is_array($p) ? ['id' => $id, 'rev' => (int)($p['rev'] ?? 0), 'guncelleme' => (string)($p['guncelleme'] ?? '')] : null;
    }

    /**
     * Projeyi kaydeder. $rev verilirse ve sunucudaki sürümden farklıysa (başka cihaz değiştirmiş) kaydetmez:
     * ['cakisma' => true, ...] döner. $zorla ile yine de üzerine yazılır.
     */
    public function kaydet(?int $id, string $ad, string $turId, array $durum, ?int $rev, bool $zorla = false): array
    {
        unset($durum['projeId'], $durum['projeRev']);
        return $this->kilitli(function () use ($id, $ad, $turId, $durum, $rev, $zorla) {
            $v = $this->oku();
            $simdi = self::simdi();
            $anahtar = $id ? (string)$id : null;
            if ($anahtar !== null && isset($v['projeler'][$anahtar]) && is_array($v['projeler'][$anahtar])) {
                $p = $v['projeler'][$anahtar];
                $sunucuRev = (int)($p['rev'] ?? 0);
                if (!$zorla && $rev !== null && $rev !== $sunucuRev) {
                    return ['cakisma' => true, 'id' => (int)$id, 'rev' => $sunucuRev, 'guncelleme' => (string)($p['guncelleme'] ?? '')];
                }
            } else {
                // yeni proje (ya da başka cihazda silinmiş proje yeniden oluşturuluyor)
                if (count($v['projeler']) >= $this->azamiProje) {
                    throw new RuntimeException('En fazla ' . $this->azamiProje . ' proje saklanabilir. Kullanmadığınız bir projeyi Veri ve yedek sayfasından silin.');
                }
                $id = (int)$v['sonId'] + 1;
                $v['sonId'] = $id;
                $anahtar = (string)$id;
                $p = ['olusturma' => $simdi, 'rev' => 0];
            }
            $p['ad'] = $ad;
            $p['turId'] = $turId;
            $p['guncelleme'] = $simdi;
            $p['rev'] = (int)($p['rev'] ?? 0) + 1;
            self::durumYerlestir($p, $durum);
            $v['projeler'][$anahtar] = $p;
            $v['acikId'] = (int)$id;
            $this->yaz($v);
            return ['id' => (int)$id, 'rev' => $p['rev'], 'guncelleme' => $simdi];
        });
    }

    public function acikIsaretle(int $id): void
    {
        $this->kilitli(function () use ($id) {
            $v = $this->oku();
            if (isset($v['projeler'][(string)$id]) && ($v['acikId'] ?? null) !== $id) {
                $v['acikId'] = $id;
                $this->yaz($v);
            }
        });
    }

    public function sil(int $id): bool
    {
        return $this->kilitli(function () use ($id) {
            $v = $this->oku();
            if (!isset($v['projeler'][(string)$id])) return false;
            unset($v['projeler'][(string)$id]);
            if ((int)($v['acikId'] ?? 0) === $id) $v['acikId'] = null;
            $this->yaz($v);
            return true;
        });
    }
}

<?php
declare(strict_types=1);

namespace DersDagitim;

use RuntimeException;

/**
 * MEB haftalık ders çizelgesi verisi (data/cizelgeler.json) ve
 * TTKB "Haftalık Ders Çizelgeleri" listesinin canlı çekilmesi.
 */
final class CizelgeDeposu
{
    private array $veri;

    public function __construct(private string $dosya)
    {
        $icerik = file_get_contents($dosya);
        if ($icerik === false) throw new RuntimeException('Çizelge verisi okunamadı: ' . $dosya);
        $this->veri = json_decode($icerik, true, 512, JSON_THROW_ON_ERROR);
    }

    public function tumu(): array
    {
        return $this->veri;
    }

    public function turler(): array
    {
        return $this->veri['okulTurleri'];
    }

    public function tur(string $id): ?array
    {
        foreach ($this->veri['okulTurleri'] as $t) if ($t['id'] === $id) return $t;
        return null;
    }

    /**
     * Bir okul türünün çizelgesini sınıf bazında ilişkisel diziye çevirir:
     * ['9' => ['Matematik' => 6, ...], ...]
     */
    public function sinifDersleri(string $turId): array
    {
        $t = $this->tur($turId);
        if (!$t) return [];
        $out = [];
        foreach ($t['siniflar'] as $i => $s) {
            foreach ($t['dersler'] as [$ad, $grup, $saatler]) {
                if ($saatler[$i] > 0) $out[$s][$ad] = $saatler[$i];
            }
            $out[$s]['(Seçmeli)'] = $t['secmeliSaat'][$i];
        }
        return $out;
    }

    /**
     * TTKB sitesindeki çizelge listesini çeker. Sayfa listeyi
     * /www/icerik_listele_ajax.php adresine POST ederek (DataTables) yüklüyor.
     *
     * @return array{cekilme:string, kayitlar:array<int,array{baslik:string,tarih:string,link:string}>}
     */
    public static function mebListesiCek(array $ayar): array
    {
        if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL eklentisi gerekli.');
        $alanlar = [
            'draw' => 1, 'start' => 0, 'length' => 200,
            'search[value]' => '', 'search[regex]' => 'false',
            'order[0][column]' => 2, 'order[0][dir]' => 'desc',
            'columns[0][data]' => 'ISLEMSAAT', 'columns[1][data]' => 'BASLIK', 'columns[2][data]' => 'SIRAID',
            'kategori' => (string)$ayar['kategori'], 'dil' => 'tr',
        ];
        $ch = curl_init($ayar['liste_adresi']);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($alanlar),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => (int)($ayar['zaman_asimi'] ?? 15),
            CURLOPT_HTTPHEADER => ['X-Requested-With: XMLHttpRequest', 'Accept: application/json'],
            CURLOPT_REFERER => 'https://ttkb.meb.gov.tr/www/haftalik-ders-cizelgeleri/kategori/' . $ayar['kategori'],
            CURLOPT_USERAGENT => 'DersDagitim/1.0 (+okul ders programi)',
        ]);
        $govde = curl_exec($ch);
        $kod = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $hata = curl_error($ch);
        curl_close($ch);
        if ($govde === false || $kod !== 200) throw new RuntimeException('TTKB yanıt vermedi (' . ($hata ?: 'HTTP ' . $kod) . ')');
        $j = json_decode((string)$govde, true);
        if (!is_array($j) || !isset($j['data'])) throw new RuntimeException('TTKB yanıtı beklenen biçimde değil.');
        $kayitlar = [];
        foreach ($j['data'] as $k) {
            $link = (string)($k['LINK'] ?? '');
            if ($link !== '' && $link[0] === '/') $link = 'https://ttkb.meb.gov.tr' . $link;
            $kayitlar[] = [
                'baslik' => trim(html_entity_decode((string)($k['BASLIK'] ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8')),
                'tarih' => (string)($k['ISLEMSAAT'] ?? ''),
                'link' => $link,
            ];
        }
        return ['cekilme' => date('Y-m-d H:i'), 'kayitlar' => $kayitlar];
    }
}

<?php
declare(strict_types=1);

namespace DersDagitim;

/**
 * Ders Dağıtım Motoru (PHP)
 *
 * public/assets/scheduler.js ile aynı algoritma:
 *   0) Kilitli (sabit) blokları verilen yere koy
 *   1) Açgözlü yerleştirme (zor bloklar önce)
 *   2) Tabu destekli çıkarma zinciri ile onarım
 *   3) Şube/öğretmen boşluklarını ve öğretmen gün sayısı aşımını azaltan yerel iyileştirme
 *
 * Girdi:
 *   gunSayisi, gunlukSaat, blok ('ikili'|'tekli'), denemeSayisi, tohum,
 *   subeler     => [['id' => ..., 'kapali' => ['gün-saat', ...]], ...]
 *   ogretmenler => [['id' => ..., 'kapali' => [...], 'maxGunluk' => int?, 'maxGun' => int?], ...]
 *   dersler     => [['id', 'subeId', 'ogretmenId'|null, 'saat', 'yerlesim' => [2,2,1]?,
 *                    'kilitli' => [['gun' => 0, 'saat' => 0, 'uzunluk' => 2], ...]?], ...]
 */
final class Scheduler
{
    private int $D;
    private int $H;
    private array $bloklar = [];
    private array $dersBloklari = [];
    private array $subeIzgara = [];
    private array $ogrIzgara = [];
    private array $ogrGunYuk = [];
    private array $kapali = [];
    private array $subeKapali = [];
    private array $maxGunluk = [];
    private array $maxGun = [];
    private array $subeH = [];

    public function __construct(
        private int $maxIterasyon = 300000,
        private int $sureLimitMs = 8000
    ) {
    }

    /** @return string[] Girdideki yapısal hatalar */
    public static function dogrula(array $girdi): array
    {
        $hatalar = [];
        $D = (int)($girdi['gunSayisi'] ?? 0);
        $H = (int)($girdi['gunlukSaat'] ?? 0);
        if ($D < 1 || $D > 7) $hatalar[] = 'gunSayisi 1-7 olmalı';
        if ($H < 1 || $H > 14) $hatalar[] = 'gunlukSaat 1-14 olmalı';
        $subeler = [];
        foreach (($girdi['subeler'] ?? []) as $s) $subeler[(string)($s['id'] ?? '')] = true;
        $ogr = [];
        foreach (($girdi['ogretmenler'] ?? []) as $o) $ogr[(string)($o['id'] ?? '')] = true;
        if (!$subeler) $hatalar[] = 'şube listesi boş';
        foreach (($girdi['dersler'] ?? []) as $i => $d) {
            if (!isset($subeler[(string)($d['subeId'] ?? '')])) { $hatalar[] = "ders #$i: bilinmeyen şube"; continue; }
            if (!empty($d['ogretmenId']) && !isset($ogr[(string)$d['ogretmenId']])) $hatalar[] = "ders #$i: bilinmeyen öğretmen";
            $saat = (int)($d['saat'] ?? 0);
            if ($saat < 1 || $saat > 40) $hatalar[] = "ders #$i: saat 1-40 olmalı";
            if (isset($d['kilitli']) && !is_array($d['kilitli'])) $hatalar[] = "ders #$i: kilitli bir liste olmalı";
        }
        if (count($girdi['dersler'] ?? []) > 5000) $hatalar[] = 'en fazla 5000 ders';
        return array_slice($hatalar, 0, 20);
    }

    /** Haftalık saati bloklara böler: 5 -> [2,2,1], 20 (5 gün) -> [4,4,4,4,4] */
    public static function bloklaraBol(int $saat, int $gunSayisi, string $mod, ?array $kalip = null): array
    {
        if ($saat <= 0) return [];
        if ($kalip && count($kalip) <= $gunSayisi) {
            $gecerli = true;
            foreach ($kalip as $x) if (!is_int($x) || $x < 1) $gecerli = false;
            if ($gecerli && array_sum($kalip) === $saat) { rsort($kalip); return $kalip; }
        }
        $boy = $mod === 'tekli' ? 1 : 2;
        $boy = max($boy, (int)ceil($saat / max(1, $gunSayisi)));
        $sonuc = [];
        while ($saat > 0) {
            $b = min($boy, $saat);
            $sonuc[] = $b;
            $saat -= $b;
        }
        return $sonuc;
    }

    private static function kaliptanDus(?array $kalip, array $kilitler, int $kalan): ?array
    {
        if (!$kalip) return null;
        foreach ($kilitler as $k) {
            $j = array_search($k['uzunluk'], $kalip, true);
            if ($j === false) return null;
            array_splice($kalip, (int)$j, 1);
        }
        return array_sum($kalip) === $kalan ? array_values($kalip) : null;
    }

    private function slotSeti(array $liste): array
    {
        $k = [];
        foreach ($liste as $x) {
            $p = explode('-', (string)$x);
            $d = (int)($p[0] ?? -1);
            $h = (int)($p[1] ?? -1);
            if ($d >= 0 && $d < $this->D && $h >= 0 && $h < $this->H) $k[$d * $this->H + $h] = true;
        }
        return $k;
    }

    /**
     * VEYA kuralı: ders['yerlesimSecenekleri'] = [[2,2],[2,1,1]] ise önce ilk kalıp denenir; dersin bloğu
     * yerleşemezse sonraki denemede bir sonraki kalıba geçilir.
     */
    public function dagit(array $girdi): array
    {
        $bas = microtime(true);
        $n = max(1, min(10, (int)($girdi['denemeSayisi'] ?? 3)));
        $tohum = (int)($girdi['tohum'] ?? 20261119);
        $enIyi = null;
        $bitis = $bas + $this->sureLimitMs / 1000;
        $dersler0 = array_values($girdi['dersler']);
        $secim = array_fill(0, count($dersler0), 0);
        $idx = [];
        $secenekli = false;
        foreach ($dersler0 as $j => $d) {
            $idx[(string)$d['id']] = $j;
            if (!empty($d['yerlesimSecenekleri']) && count($d['yerlesimSecenekleri']) > 1) $secenekli = true;
        }
        $toplam = $n + ($secenekli ? 4 : 0);
        for ($i = 0; $i < $toplam; $i++) {
            $kullanilan = [];
            $g2 = $girdi;
            $g2['dersler'] = [];
            foreach ($dersler0 as $j => $d) {
                $s = $d['yerlesimSecenekleri'] ?? null;
                if (is_array($s) && $s) {
                    $d['yerlesim'] = array_map('intval', $s[min($secim[$j], count($s) - 1)]);
                    $kullanilan[$d['id']] = implode('+', $d['yerlesim']);
                }
                $g2['dersler'][] = $d;
            }
            $kalanMs = (int)max(500, ($bitis - microtime(true)) * 1000);
            $r = $this->tekDeneme($g2, $tohum + $i * 7919, $kalanMs);
            $r['kullanilanKalip'] = (object)$kullanilan;
            if ($enIyi === null || $r['istatistik']['ceza'] < $enIyi['istatistik']['ceza']) $enIyi = $r;
            if ($enIyi['istatistik']['ceza'] === 0 || microtime(true) > $bitis) break;
            if ($secenekli) {
                foreach ($r['yerlesmeyen'] as $y) {
                    $j = $idx[(string)$y['dersId']] ?? null;
                    if ($j === null) continue;
                    $s = $dersler0[$j]['yerlesimSecenekleri'] ?? null;
                    if (is_array($s) && $secim[$j] < count($s) - 1) $secim[$j]++;
                }
            }
        }
        $enIyi['istatistik']['sureMs'] = (int)round((microtime(true) - $bas) * 1000);
        $enIyi['istatistik']['motor'] = 'PHP';
        return $enIyi;
    }

    private function r(): float
    {
        return mt_rand() / mt_getrandmax();
    }

    private function tekDeneme(array $girdi, int $tohum, int $sureMs): array
    {
        mt_srand($tohum);
        $D = $this->D = (int)$girdi['gunSayisi'];
        $H = $this->H = (int)$girdi['gunlukSaat'];
        $blokMod = (string)($girdi['blok'] ?? 'ikili');
        $subeListe = array_values($girdi['subeler']);
        $ogrListe = array_values($girdi['ogretmenler'] ?? []);
        $subeIdx = [];
        $ogrIdx = [];
        foreach ($subeListe as $i => $s) $subeIdx[(string)$s['id']] = $i;
        foreach ($ogrListe as $i => $o) $ogrIdx[(string)$o['id']] = $i;
        $S = count($subeListe);
        $T = count($ogrListe);

        $this->subeH = [];
        $this->subeKapali = [];
        foreach ($subeListe as $s) {
            $this->subeH[] = min($H, (int)($s['gunlukSaat'] ?? $H) ?: $H);
            $this->subeKapali[] = $this->slotSeti($s['kapali'] ?? []);
        }
        $this->kapali = [];
        $this->maxGunluk = [];
        $this->maxGun = [];
        foreach ($ogrListe as $t => $o) {
            $this->kapali[$t] = $this->slotSeti($o['kapali'] ?? []);
            $this->maxGunluk[$t] = !empty($o['maxGunluk']) && (int)$o['maxGunluk'] > 0 ? (int)$o['maxGunluk'] : $H;
            $this->maxGun[$t] = !empty($o['maxGun']) && (int)$o['maxGun'] > 0 ? min($D, (int)$o['maxGun']) : $D;
        }

        // Bloklar
        $this->bloklar = [];
        $this->dersBloklari = [];
        $kilitHatalari = [];
        $ogrYuk = array_fill(0, max(1, $T), 0);
        $dersler = array_values($girdi['dersler']);
        foreach ($dersler as $di => $ders) {
            $t = (isset($ders['ogretmenId']) && $ders['ogretmenId'] !== null && isset($ogrIdx[(string)$ders['ogretmenId']])) ? $ogrIdx[(string)$ders['ogretmenId']] : -1;
            $si = $subeIdx[(string)$ders['subeId']];
            $saat = (int)$ders['saat'];
            if ($t >= 0) $ogrYuk[$t] += $saat;
            $this->dersBloklari[$di] = [];
            $kilitler = [];
            $kilitToplam = 0;
            foreach (($ders['kilitli'] ?? []) ?: [] as $k) {
                $g = (int)($k['gun'] ?? -1); $s = (int)($k['saat'] ?? -1); $u = (int)($k['uzunluk'] ?? 0);
                if ($u <= 0 || $g < 0 || $g >= $D || $s < 0 || $s + $u > $this->subeH[$si] || $kilitToplam + $u > $saat) {
                    $kilitHatalari[] = ['dersId' => $ders['id'], 'uzunluk' => max(0, $u), 'neden' => 'geçersiz kilit'];
                    continue;
                }
                $kilitler[] = ['gun' => $g, 'saat' => $s, 'uzunluk' => $u];
                $kilitToplam += $u;
            }
            foreach ($kilitler as $k) {
                $this->dersBloklari[$di][] = count($this->bloklar);
                $this->bloklar[] = ['ders' => $di, 'sube' => $si, 'ogr' => $t, 'boy' => $k['uzunluk'], 'gun' => -1, 'saat' => -1, 'deneme' => 0, 'gevsek' => false, 'sabit' => true, 'hedef' => [$k['gun'], $k['saat']], 'bos' => 0];
            }
            $kalan = $saat - $kilitToplam;
            $kullanilanGun = count(array_unique(array_column($kilitler, 'gun')));
            $kalip = isset($ders['yerlesim']) && is_array($ders['yerlesim']) ? array_map('intval', $ders['yerlesim']) : null;
            foreach (self::bloklaraBol($kalan, max(1, $D - $kullanilanGun), $blokMod, self::kaliptanDus($kalip, $kilitler, $kalan)) as $boy) {
                $this->dersBloklari[$di][] = count($this->bloklar);
                $this->bloklar[] = ['ders' => $di, 'sube' => $si, 'ogr' => $t, 'boy' => $boy, 'gun' => -1, 'saat' => -1, 'deneme' => 0, 'gevsek' => false, 'sabit' => false, 'bos' => 0];
            }
        }
        $this->subeIzgara = array_fill(0, $S, array_fill(0, $D * $H, -1));
        $this->ogrIzgara = $T ? array_fill(0, $T, array_fill(0, $D * $H, -1)) : [];
        $this->ogrGunYuk = $T ? array_fill(0, $T, array_fill(0, $D, 0)) : [];

        // 0) Kilitli bloklar
        $kilitCakisan = [];
        foreach ($this->bloklar as $b => $B) {
            if (!$B['sabit']) continue;
            [$d, $h] = $B['hedef'];
            $bos = true;
            for ($k = 0; $k < $B['boy']; $k++) {
                $i = $d * $H + $h + $k;
                if ($this->subeIzgara[$B['sube']][$i] >= 0 || ($B['ogr'] >= 0 && $this->ogrIzgara[$B['ogr']][$i] >= 0)) $bos = false;
            }
            if ($bos) $this->yerlestir($b, $d, $h); else $kilitCakisan[$b] = true;
        }

        // 1) Açgözlü yerleştirme
        $sira = [];
        $anahtar = [];
        foreach ($this->bloklar as $b => $B) {
            if ($B['sabit']) continue;
            $sira[] = $b;
            $anahtar[$b] = $B['boy'] * 100 + ($B['ogr'] >= 0 ? (count($this->kapali[$B['ogr']]) + ($D - $this->maxGun[$B['ogr']]) * $H) * 3 + $ogrYuk[$B['ogr']] : 0) + $this->r();
        }
        usort($sira, fn($a, $b) => $anahtar[$b] <=> $anahtar[$a]);

        $kuyruk = [];
        foreach ($sira as $b) {
            $en = null;
            $enP = INF;
            for ($d = 0; $d < $D; $d++) {
                for ($h = 0; $h < $H; $h++) {
                    $c = $this->catisma($b, $d, $h);
                    if ($c === null || $c) continue;
                    $p = $this->konumPuani($b, $d, $h);
                    if ($p < $enP) { $enP = $p; $en = [$d, $h]; }
                }
            }
            if ($en) $this->yerlestir($b, $en[0], $en[1]); else $kuyruk[] = $b;
        }

        // 2) Onarım
        $iter = 0;
        $kalici = [];
        $enIyiEksik = count($kuyruk);
        $enIyiYer = $this->konumlar();
        $tabu = array_fill(0, max(1, count($this->bloklar)), -1000);
        $TENURE = 12;
        $bitis = microtime(true) + $sureMs / 1000;
        while ($kuyruk && $iter < $this->maxIterasyon && (($iter % 256) || microtime(true) < $bitis)) {
            $iter++;
            $bi = mt_rand(0, count($kuyruk) - 1);
            $b = $kuyruk[$bi];
            $kuyruk[$bi] = $kuyruk[count($kuyruk) - 1];
            array_pop($kuyruk);
            if (++$this->bloklar[$b]['deneme'] > 400) $this->bloklar[$b]['gevsek'] = true;
            $B0 = $this->bloklar[$b];

            $adaylar = [];
            $enM = INF;
            for ($d = 0; $d < $D; $d++) {
                for ($h = 0; $h < $H; $h++) {
                    $c = $this->catisma($b, $d, $h);
                    if ($c === null) continue;
                    $m = 0.0;
                    foreach ($c as $x) {
                        $m += $this->bloklar[$x]['boy'] * 2 + 1 + min($this->bloklar[$x]['deneme'], 40) * 0.25;
                        if ($iter - $tabu[$x] < $TENURE) $m += 50;
                    }
                    if ($B0['gevsek']) $m += $this->ayniGunSayisi($b, $d) * 4;
                    $m += $this->gunAsimi($b, $d) * 25;
                    $m += $this->r() * 2;
                    if ($m < $enM - 0.0001) { $enM = $m; $adaylar = [[$d, $h, $c]]; }
                    elseif (abs($m - $enM) < 0.0001) $adaylar[] = [$d, $h, $c];
                }
            }
            if (!$adaylar) {
                if (++$this->bloklar[$b]['bos'] > 30) $kalici[] = $b; else $kuyruk[] = $b;
                continue;
            }
            $sec = $adaylar[mt_rand(0, count($adaylar) - 1)];
            foreach ($sec[2] as $x) { $this->kaldir($x); $kuyruk[] = $x; }
            $this->yerlestir($b, $sec[0], $sec[1]);
            $tabu[$b] = $iter;
            if (count($kuyruk) + count($kalici) < $enIyiEksik) {
                $enIyiEksik = count($kuyruk) + count($kalici);
                $enIyiYer = $this->konumlar();
                if ($enIyiEksik === 0) break;
            }
        }
        if (count($kuyruk) + count($kalici) > $enIyiEksik) {
            foreach (array_keys($this->bloklar) as $i) $this->kaldir($i);
            foreach ($enIyiYer as $i => [$d, $h]) if ($d >= 0) $this->yerlestir($i, $d, $h);
        }

        // 3) Yerel iyileştirme
        $tur = (int)($girdi['iyilestirmeTuru'] ?? 4);
        for ($k = 0; $k < $tur; $k++) {
            $degisti = false;
            $karisik = [];
            foreach ($this->bloklar as $b => $B) if (!$B['sabit']) $karisik[] = $b;
            shuffle($karisik);
            foreach ($karisik as $b) {
                $B = $this->bloklar[$b];
                if ($B['gun'] < 0) continue;
                $once = $this->yerelCeza($b);
                if ($once === 0) continue;
                $eski = [$B['gun'], $B['saat']];
                $this->kaldir($b);
                $en = $eski;
                $enC = $once;
                for ($d = 0; $d < $D; $d++) {
                    for ($h = 0; $h < $H; $h++) {
                        $c = $this->catisma($b, $d, $h);
                        if ($c === null || $c) continue;
                        $this->yerlestir($b, $d, $h);
                        $cz = $this->yerelCeza($b);
                        $this->kaldir($b);
                        if ($cz < $enC) { $enC = $cz; $en = [$d, $h]; }
                    }
                }
                $this->yerlestir($b, $en[0], $en[1]);
                if ($en !== $eski) $degisti = true;
            }
            if (!$degisti) break;
        }

        // Sonuç
        $yerlesim = [];
        $yerlesmeyen = [];
        $eksik = 0;
        foreach ($this->bloklar as $i => $B) {
            $id = $dersler[$B['ders']]['id'];
            if ($B['gun'] >= 0) $yerlesim[] = ['dersId' => $id, 'gun' => $B['gun'], 'saat' => $B['saat'], 'uzunluk' => $B['boy'], 'kilitli' => $B['sabit']];
            else { $yerlesmeyen[] = ['dersId' => $id, 'uzunluk' => $B['boy'], 'neden' => isset($kilitCakisan[$i]) ? 'kilit çakışması' : 'yer bulunamadı']; $eksik += $B['boy']; }
        }
        foreach ($kilitHatalari as $kh) { $yerlesmeyen[] = $kh; $eksik += $kh['uzunluk']; }
        $sb = 0;
        for ($s = 0; $s < $S; $s++) $sb += $this->subeBosluk($s);
        $ob = 0;
        $ihlaller = [];
        for ($t = 0; $t < $T; $t++) {
            $ob += $this->bosluk($this->ogrIzgara[$t]);
            $gs = $this->ogrGunSayisi($t);
            if ($gs > $this->maxGun[$t]) $ihlaller[] = ['tip' => 'gunSayisi', 'ogretmenId' => $ogrListe[$t]['id'], 'deger' => $gs, 'sinir' => $this->maxGun[$t]];
        }
        return [
            'yerlesim' => $yerlesim,
            'yerlesmeyen' => $yerlesmeyen,
            'ihlaller' => $ihlaller,
            'istatistik' => [
                'blokSayisi' => count($this->bloklar),
                'kilitliBlok' => count(array_filter($this->bloklar, fn($B) => $B['sabit'])),
                'toplamSaat' => array_sum(array_map(fn($d) => (int)$d['saat'], $dersler)),
                'eksikSaat' => $eksik,
                'subeBosluk' => $sb,
                'ogretmenBosluk' => $ob,
                'ihlal' => count($ihlaller),
                'iterasyon' => $iter,
                'ceza' => $eksik * 1000 + count($ihlaller) * 200 + $sb * 10 + $ob,
                'tohum' => $tohum,
            ],
        ];
    }

    private function konumlar(): array
    {
        return array_map(fn($B) => [$B['gun'], $B['saat']], $this->bloklar);
    }

    private function yerlestir(int $b, int $d, int $h): void
    {
        $B = &$this->bloklar[$b];
        $B['gun'] = $d;
        $B['saat'] = $h;
        for ($k = 0; $k < $B['boy']; $k++) {
            $this->subeIzgara[$B['sube']][$d * $this->H + $h + $k] = $b;
            if ($B['ogr'] >= 0) $this->ogrIzgara[$B['ogr']][$d * $this->H + $h + $k] = $b;
        }
        if ($B['ogr'] >= 0) $this->ogrGunYuk[$B['ogr']][$d] += $B['boy'];
    }

    private function kaldir(int $b): void
    {
        $B = &$this->bloklar[$b];
        if ($B['gun'] < 0) return;
        for ($k = 0; $k < $B['boy']; $k++) {
            $this->subeIzgara[$B['sube']][$B['gun'] * $this->H + $B['saat'] + $k] = -1;
            if ($B['ogr'] >= 0) $this->ogrIzgara[$B['ogr']][$B['gun'] * $this->H + $B['saat'] + $k] = -1;
        }
        if ($B['ogr'] >= 0) $this->ogrGunYuk[$B['ogr']][$B['gun']] -= $B['boy'];
        $B['gun'] = -1;
        $B['saat'] = -1;
    }

    private function ogrGunSayisi(int $t): int
    {
        $n = 0;
        foreach ($this->ogrGunYuk[$t] as $v) if ($v > 0) $n++;
        return $n;
    }

    /** @return int[]|null Çakışan bloklar; null => konum imkânsız */
    private function catisma(int $b, int $d, int $h): ?array
    {
        $B = $this->bloklar[$b];
        if ($h + $B['boy'] > $this->subeH[$B['sube']]) return null;
        $set = [];
        for ($k = 0; $k < $B['boy']; $k++) {
            $i = $d * $this->H + $h + $k;
            if (isset($this->subeKapali[$B['sube']][$i])) return null;
            if ($B['ogr'] >= 0 && isset($this->kapali[$B['ogr']][$i])) return null;
            $x = $this->subeIzgara[$B['sube']][$i];
            if ($x >= 0 && $x !== $b) { if ($this->bloklar[$x]['sabit']) return null; $set[$x] = true; }
            if ($B['ogr'] >= 0) {
                $y = $this->ogrIzgara[$B['ogr']][$i];
                if ($y >= 0 && $y !== $b) { if ($this->bloklar[$y]['sabit']) return null; $set[$y] = true; }
            }
        }
        if (!$B['gevsek']) {
            foreach ($this->dersBloklari[$B['ders']] as $x) {
                $K = $this->bloklar[$x];
                if ($x !== $b && $K['gun'] === $d && !$K['gevsek']) {
                    if ($K['sabit']) return null;
                    $set[$x] = true;
                }
            }
        }
        if ($B['ogr'] >= 0) {
            $yuk = $this->ogrGunYuk[$B['ogr']][$d] + $B['boy'];
            foreach (array_keys($set) as $x) {
                $C = $this->bloklar[$x];
                if ($C['ogr'] === $B['ogr'] && $C['gun'] === $d) $yuk -= $C['boy'];
            }
            if ($yuk > $this->maxGunluk[$B['ogr']]) return null;
        }
        return array_keys($set);
    }

    private function gunAsimi(int $b, int $d): int
    {
        $B = $this->bloklar[$b];
        if ($B['ogr'] < 0 || $this->ogrGunYuk[$B['ogr']][$d] > 0) return 0;
        return $this->ogrGunSayisi($B['ogr']) >= $this->maxGun[$B['ogr']] ? 1 : 0;
    }

    private function ayniGunSayisi(int $b, int $d): int
    {
        $n = 0;
        foreach ($this->dersBloklari[$this->bloklar[$b]['ders']] as $x) if ($x !== $b && $this->bloklar[$x]['gun'] === $d) $n++;
        return $n;
    }

    private function gunDolu(array $izgara, int $d): int
    {
        $n = 0;
        for ($h = 0; $h < $this->H; $h++) if ($izgara[$d * $this->H + $h] >= 0) $n++;
        return $n;
    }

    private function konumPuani(int $b, int $d, int $h): float
    {
        $B = $this->bloklar[$b];
        $p = $h + $this->gunDolu($this->subeIzgara[$B['sube']], $d) * 2.5;
        if ($B['ogr'] >= 0) {
            $g = $this->ogrIzgara[$B['ogr']];
            $od = $this->ogrGunYuk[$B['ogr']][$d];
            $p += $od * 0.8 + $this->gunAsimi($b, $d) * 100;
            if ($od > 0) {
                $komsu = ($h > 0 && $g[$d * $this->H + $h - 1] >= 0) || ($h + $B['boy'] < $this->H && $g[$d * $this->H + $h + $B['boy']] >= 0);
                $p += $komsu ? -2 : 1.5;
            }
        }
        return $p + $this->r() * 1.5;
    }

    private function bosluk(array $g): int
    {
        $top = 0;
        for ($d = 0; $d < $this->D; $d++) {
            $ilk = -1; $son = -1; $dolu = 0;
            for ($h = 0; $h < $this->H; $h++) {
                if ($g[$d * $this->H + $h] >= 0) { if ($ilk < 0) $ilk = $h; $son = $h; $dolu++; }
            }
            if ($son >= 0) $top += ($son - $ilk + 1) - $dolu;
        }
        return $top;
    }

    /** Şube boşluğu: ilk dersten önceki boş saatler de sayılır; şubenin kapalı saatleri sayılmaz. */
    private function subeBosluk(int $s): int
    {
        $g = $this->subeIzgara[$s];
        $top = 0;
        for ($d = 0; $d < $this->D; $d++) {
            $son = -1; $dolu = 0;
            for ($h = 0; $h < $this->H; $h++) if ($g[$d * $this->H + $h] >= 0) { $son = $h; $dolu++; }
            if ($son < 0) continue;
            $kap = 0;
            for ($h = 0; $h <= $son; $h++) if (isset($this->subeKapali[$s][$d * $this->H + $h])) $kap++;
            $top += ($son + 1) - $dolu - $kap;
        }
        return $top;
    }

    private function yerelCeza(int $b): int
    {
        $B = $this->bloklar[$b];
        $c = $this->subeBosluk($B['sube']) * 10;
        if ($B['ogr'] >= 0) $c += $this->bosluk($this->ogrIzgara[$B['ogr']]) + max(0, $this->ogrGunSayisi($B['ogr']) - $this->maxGun[$B['ogr']]) * 60;
        return $c;
    }
}

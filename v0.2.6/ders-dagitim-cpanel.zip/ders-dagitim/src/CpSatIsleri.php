<?php
declare(strict_types=1);

namespace DersDagitim;

use RuntimeException;

/**
 * OR-Tools CP-SAT çözücüsünü (solver/ Python paketi) arka plan işi olarak çalıştırır.
 * Arayüz donmaz: iş başlatılır, durum dosyası sorgulanır, sonuç hazır olunca alınır.
 *
 * Her iş storage/isler/<id>/ altında: girdi.json, durum.json, sonuc.json, pid, kayit.log
 */
final class CpSatIsleri
{
    public function __construct(private array $ayar, private string $kok)
    {
    }

    private function klasor(): string
    {
        $k = $this->ayar['is_klasoru'];
        if (!is_dir($k) && !mkdir($k, 0775, true) && !is_dir($k)) {
            throw new RuntimeException('İş klasörü oluşturulamadı: ' . $k);
        }
        return $k;
    }

    private function isYolu(string $id): string
    {
        if (!preg_match('/^[a-f0-9]{20}$/', $id)) throw new RuntimeException('Geçersiz iş kimliği');
        return $this->klasor() . '/' . $id;
    }

    /** exec/shell_exec/popen sunucuda kullanılabilir mi (paylaşımlı hostingde kapatılmış olabilir) */
    public static function komutAcik(): bool
    {
        $kapali = array_map('trim', explode(',', (string)ini_get('disable_functions')));
        foreach (['exec', 'shell_exec', 'popen'] as $f) {
            if (!function_exists($f) || in_array($f, $kapali, true)) return false;
        }
        return true;
    }

    /** Denenecek Python yolları: ayar, DERS_PYTHON, cPanel sanal ortamları, sistem python3 */
    public function pythonAdaylari(): array
    {
        $l = [];
        $ayar = (string)($this->ayar['python'] ?? 'otomatik');
        if ($ayar !== '' && $ayar !== 'otomatik') $l[] = $ayar;
        if (getenv('DERS_PYTHON')) $l[] = (string)getenv('DERS_PYTHON');
        $evler = array_filter([getenv('HOME') ?: null, preg_match('#^(/home\d*/[^/]+)/#', $this->kok, $m) ? $m[1] : null]);
        foreach (array_unique($evler) as $ev) {
            // cPanel "Setup Python App": ~/virtualenv/<uygulama>/<sürüm>/bin/python
            foreach (glob($ev . '/virtualenv/*/*/bin/python') ?: [] as $p) $l[] = $p;
        }
        foreach (['/usr/local/bin/python3', '/usr/bin/python3', '/opt/alt/python311/bin/python3', '/opt/alt/python39/bin/python3'] as $p) {
            if (@is_executable($p)) $l[] = $p;
        }
        $l[] = PHP_OS_FAMILY === 'Windows' ? 'python' : 'python3';
        return array_values(array_unique($l));
    }

    private function python(): string
    {
        $h = $this->hazirMi();
        return (string)($h['python'] ?? $this->pythonAdaylari()[0]);
    }

    /** Python ve OR-Tools kullanılabilir mi? (sonuç 10 dakika önbelleklenir) */
    public function hazirMi(bool $tazele = false): array
    {
        $onbellek = $this->klasor() . '/.kontrol.json';
        if (!$tazele && is_file($onbellek) && filemtime($onbellek) > time() - 600) {
            $j = json_decode((string)file_get_contents($onbellek), true);
            if (is_array($j)) return $j;
        }
        if (!self::komutAcik()) {
            $j = ['hazir' => false, 'neden' => 'Sunucuda komut çalıştırma (exec/shell_exec/popen) kapalı; tarayıcıdaki hızlı motor kullanılır.', 'denenen' => []];
        } else {
            $j = ['hazir' => false, 'neden' => 'Python bulunamadı.', 'denenen' => []];
            $kod_ = "import sys,importlib.util as u;print(('OK '+__import__('ortools').__version__) if u.find_spec('ortools') else 'YOK', sys.version.split()[0])";
            foreach ($this->pythonAdaylari() as $py) {
                $cikti = [];
                $kod = 1;
                @exec(escapeshellarg($py) . ' -c ' . escapeshellarg($kod_) . ' 2>&1', $cikti, $kod);
                $satir = trim((string)end($cikti));
                $j['denenen'][] = ['python' => $py, 'sonuc' => $kod === 0 ? $satir : 'çalışmadı'];
                if ($kod === 0 && str_starts_with($satir, 'OK')) {
                    $p = explode(' ', $satir);
                    $j = ['hazir' => true, 'python' => $py, 'surum' => ($p[1] ?? '') . ' ' . ($p[2] ?? ''), 'denenen' => $j['denenen']];
                    break;
                }
                if ($kod === 0 && str_starts_with($satir, 'YOK')) {
                    $j['neden'] = 'Python var (' . $py . ') ama OR-Tools kurulu değil: ' . $py . ' -m pip install ortools';
                }
            }
        }
        @file_put_contents($onbellek, json_encode($j, JSON_UNESCAPED_UNICODE));
        return $j;
    }

    public function islemciSayisi(): int
    {
        $n = 0;
        if (is_readable('/proc/cpuinfo')) $n = substr_count((string)@file_get_contents('/proc/cpuinfo'), 'processor');
        if ($n <= 0 && getenv('NUMBER_OF_PROCESSORS')) $n = (int)getenv('NUMBER_OF_PROCESSORS');
        return max(1, $n);
    }

    /** Şu an çalışan işler: [sahip => adet], toplam */
    private function calisanlar(): array
    {
        $sahipler = [];
        $toplam = 0;
        foreach (glob($this->klasor() . '/*', GLOB_ONLYDIR) ?: [] as $d) {
            if (!preg_match('/[a-f0-9]{20}$/', $d) || is_file("$d/sonuc.json")) continue;
            $pid = (int)@file_get_contents("$d/pid");
            $bas = (int)@file_get_contents("$d/baslangic");
            $canli = $pid > 0 ? $this->yasiyor($pid) : ($bas === 0 || time() - $bas < 60);
            if (!$canli) continue;
            $s = (int)@file_get_contents("$d/sahip");
            $sahipler[$s] = ($sahipler[$s] ?? 0) + 1;
            $toplam++;
        }
        return [$sahipler, $toplam];
    }

    /** İş bu üyenin mi? (başka üyenin işine erişilemez) */
    private function sahipDenetle(string $yol, int $sahip): void
    {
        if ($sahip > 0 && (int)@file_get_contents("$yol/sahip") !== $sahip) throw new RuntimeException('İş bulunamadı');
    }

    public function baslat(array $girdi, int $sahip = 0): string
    {
        $this->temizle();
        [$sahipler, $toplam] = $this->calisanlar();
        $uyeSiniri = max(1, (int)($this->ayar['uye_basina_is'] ?? 1));
        $genelSinir = max(1, (int)($this->ayar['es_zamanli_is'] ?? 2));
        if (($sahipler[$sahip] ?? 0) >= $uyeSiniri) throw new RuntimeException('Zaten çalışan bir dağıtımınız var. Bitmesini bekleyin ya da durdurun.');
        if ($toplam >= $genelSinir) throw new RuntimeException('Sunucu şu an başka dağıtımları çözüyor. Birkaç dakika sonra yeniden deneyin ya da “Hızlı” motoru kullanın.');
        $id = bin2hex(random_bytes(10));
        $yol = $this->isYolu($id);
        if (!mkdir($yol, 0775) && !is_dir($yol)) throw new RuntimeException('İş klasörü oluşturulamadı');
        $c = $girdi['cozucu'] ?? [];
        $istek = (int)($c['isci'] ?? 0);
        $isci = $istek > 0 ? $istek : (int)($this->ayar['isci'] ?? 0);
        if ($isci <= 0) $isci = $this->islemciSayisi();
        $girdi['cozucu'] = [
            'sureSn' => max(5, min((int)$this->ayar['azami_sure_sn'], (int)($c['sureSn'] ?? $this->ayar['varsayilan_sure_sn']))),
            'isci' => max(1, min((int)($this->ayar['azami_isci'] ?? 16) ?: 16, $isci)),
        ];
        file_put_contents("$yol/sahip", (string)$sahip);
        file_put_contents("$yol/girdi.json", json_encode($girdi, JSON_UNESCAPED_UNICODE));
        file_put_contents("$yol/durum.json", json_encode(['durum' => 'kuyrukta', 'oran' => 0, 'mesaj' => 'Başlatılıyor', 'zaman' => time()]));
        if (!self::komutAcik()) throw new RuntimeException('Sunucuda komut çalıştırma kapalı');
        $python = $this->python();
        if (PHP_OS_FAMILY === 'Windows') {
            // Windows: işi küçük bir .bat ile arka planda başlat (start /B)
            $bat = "@echo off\r\n" .
                'cd /d "' . $this->kok . "\"\r\n" .
                '"' . $python . '" -m solver.cli --girdi "' . "$yol\\girdi.json" . '" --cikti "' . "$yol\\sonuc.json" .
                '" --durum "' . "$yol\\durum.json" . '" --pid "' . "$yol\\pid" . '" > "' . "$yol\\kayit.log" . "\" 2>&1\r\n";
            file_put_contents("$yol/calistir.bat", $bat);
            $h = popen('start "" /B "' . str_replace('/', '\\', "$yol/calistir.bat") . '"', 'r');
            if ($h === false) throw new RuntimeException('Çözücü başlatılamadı');
            pclose($h);
        } else {
            $komut = sprintf(
                'cd %s && exec %s -m solver.cli --girdi %s --cikti %s --durum %s --pid %s > %s 2>&1',
                escapeshellarg($this->kok),
                escapeshellarg($python),
                escapeshellarg("$yol/girdi.json"),
                escapeshellarg("$yol/sonuc.json"),
                escapeshellarg("$yol/durum.json"),
                escapeshellarg("$yol/pid"),
                escapeshellarg("$yol/kayit.log")
            );
            $pid = trim((string)shell_exec('nohup sh -c ' . escapeshellarg($komut) . ' > /dev/null 2>&1 & echo $!'));
            if (!ctype_digit($pid)) throw new RuntimeException('Çözücü başlatılamadı');
            file_put_contents("$yol/pid", $pid);
        }
        file_put_contents("$yol/baslangic", (string)time());
        return $id;
    }

    public function durum(string $id, int $sahip = 0): array
    {
        $yol = $this->isYolu($id);
        if (!is_dir($yol)) throw new RuntimeException('İş bulunamadı');
        $this->sahipDenetle($yol, $sahip);
        if (is_file("$yol/sonuc.json")) {
            $j = json_decode((string)file_get_contents("$yol/sonuc.json"), true);
            if (!is_array($j)) return ['durum' => 'hata', 'mesaj' => 'Sonuç okunamadı'];
            if (!($j['tamam'] ?? false)) return ['durum' => 'hata', 'mesaj' => (string)($j['hata'] ?? 'Çözücü hatası')];
            return ['durum' => 'bitti', 'oran' => 1, 'sonuc' => $j['sonuc']];
        }
        $d = json_decode((string)@file_get_contents("$yol/durum.json"), true) ?: ['durum' => 'calisiyor'];
        $pid = (int)@file_get_contents("$yol/pid");
        $bas = (int)@file_get_contents("$yol/baslangic");
        $d['gecenSn'] = $bas ? time() - $bas : null;
        // PID dosyası henüz yazılmadıysa (yeni başladı) canlı say; 60 sn sonra hâlâ yoksa başlamamıştır
        if ($pid <= 0 && $bas && time() - $bas > 60 && !is_file("$yol/sonuc.json")) {
            return ['durum' => 'hata', 'mesaj' => 'Çözücü başlamadı. Python yolu ve OR-Tools kurulumunu denetleyin. ' . mb_substr((string)@file_get_contents("$yol/kayit.log"), -600)];
        }
        if ($pid > 0 && !$this->yasiyor($pid) && !is_file("$yol/sonuc.json")) {
            clearstatcache();
            if (!is_file("$yol/sonuc.json")) {
                $log = mb_substr((string)@file_get_contents("$yol/kayit.log"), -800);
                return ['durum' => 'hata', 'mesaj' => 'Çözücü beklenmedik şekilde durdu. ' . $log];
            }
        }
        return $d;
    }

    public function iptal(string $id, int $sahip = 0): bool
    {
        $yol = $this->isYolu($id);
        if (!is_dir($yol)) return false;
        $this->sahipDenetle($yol, $sahip);
        $pid = (int)@file_get_contents("$yol/pid");
        if ($pid > 0 && $this->yasiyor($pid)) {
            if (PHP_OS_FAMILY === 'Windows') @exec('taskkill /PID ' . $pid . ' /T /F');
            else @posix_kill($pid, 15) || @exec('kill ' . $pid);
            file_put_contents("$yol/sonuc.json", json_encode(['tamam' => false, 'hata' => 'Kullanıcı iptal etti']));
            return true;
        }
        return false;
    }

    private function yasiyor(int $pid): bool
    {
        if (PHP_OS_FAMILY === 'Windows') {
            $c = [];
            @exec('tasklist /FI "PID eq ' . $pid . '" /NH 2>NUL', $c);
            return str_contains(implode(' ', $c), (string)$pid);
        }
        if (function_exists('posix_kill')) return @posix_kill($pid, 0);
        return is_dir("/proc/$pid");
    }

    /** 1 günden eski işleri siler */
    private function temizle(): void
    {
        foreach (glob($this->klasor() . '/*', GLOB_ONLYDIR) ?: [] as $d) {
            if (filemtime($d) < time() - 86400 && preg_match('/[a-f0-9]{20}$/', $d)) {
                array_map('unlink', glob("$d/*") ?: []);
                @rmdir($d);
            }
        }
    }
}

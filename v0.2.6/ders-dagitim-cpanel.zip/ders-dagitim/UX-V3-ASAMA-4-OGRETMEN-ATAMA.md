# EVRAKPLUS – UX V3 AŞAMA 4 – ÖĞRETMEN ATAMA

## Değişenler
- 8. menü, zorunlu ve seçmeli dersleri birlikte gösteren tek ders–öğretmen listesi ile açılır.
- Atanmamış dersler listenin başındadır; şube, tür, durum ve metin araması bulunur.
- Öğretmen Ata / Değiştir penceresi branşa uygun adayları önde gösterir ve atama sonrası haftalık ders yükünü hesaplar.
- Kapasite aşan veya kilitli dersle kapalı saati çakışan adayların seçilmesi engellenir.
- Branş dışı atamada açık onay alınır.
- Atamayı kaldırma işleminde onay istenir.
- Öğretmen bazında, sınıf bazında ve çapraz çizelge gibi eski görünüm ve toplu araçlar Gelişmiş görünüm altında kalır.
- Eski otomatik atama yeni öğretmen kaydı oluşturabileceği için bilgilendirme ve onay eklenmiştir.
- PWA sürüm anahtarı yenilenmiştir.

## Kurulum ve veri koruma
Bu ZIP, Aşama 3 üzerine güncelleme içindir. Önce mevcut /ders-dagitim dizininin ve kayıtların yedeğini alın.
ZIP içinde okul veri dosyası, kullanıcı projeleri veya kayıtlı yerel durumlar bulunmaz. data/ ve storage/ içindeki kayıtları silmeyin.
Yalnızca kod ve statik dosyalar güncellenir. Kurulumdan sonra Ctrl+F5 ve gerekirse PWA yeniden başlatma uygulayın.

## Test ve sınırlar
Node.js kural/arayüz testleri ve örnek verili tarayıcı iş akışı denenmiştir. Python OR-Tools çözümünün canlı cPanel sunucusunda çalışması bu aşamada doğrulanmadı.
Yeni atama penceresi henüz bütün gerçek okul kombinasyonlarını kapsamlı uçtan uca sınamış değildir. Özellikle ortak öğretmenler ve kilitli dersler gerçek okul verileriyle kontrol edilmelidir.
HTML tasarım laboratuvarı gerçek okul verilerine bağlı değildir.
